package scripts.Sulphur.gui;

import core.context.ScriptContext;
import core.gui.AbstractSettingsTab;
import scripts.Sulphur.SulphurConfig;

/**
 * Settings tab for Sulphur script equipment configuration
 */
public class SulphurEquipmentTab extends AbstractSettingsTab {
    private final SulphurConfig config;
    private GearPanel gearPanel;

    public SulphurEquipmentTab(ScriptContext context, SulphurConfig config) {
        super(context);
        this.config = config;
    }

    @Override
    public void createComponents() {
        // Guard against duplicate initialization
        if (gearPanel != null) {
            return;
        }
        
        // Create the gear panel
        gearPanel = new GearPanel(config);
        
        // Add it directly without a section title to avoid duplication
        addSection("", gearPanel);
    }

    @Override
    public String getTitle() {
        return "Equipment";
    }

    @Override
    public void loadSettings() {
        if (gearPanel != null) {
            gearPanel.loadSettings();
        }
    }

    @Override
    public void saveSettings() {
        if (gearPanel != null) {
            gearPanel.saveSettings();
        }
        super.saveSettings();
    }

    @Override
    public void resetToDefaults() {
        if (gearPanel != null) {
            gearPanel.clearAllFields();
        }
    }
} 