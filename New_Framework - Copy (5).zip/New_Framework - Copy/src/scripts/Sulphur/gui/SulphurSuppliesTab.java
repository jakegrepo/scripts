package scripts.Sulphur.gui;

import core.context.ScriptContext;
import core.gui.AbstractSettingsTab;
import scripts.Sulphur.SulphurConfig;

/**
 * Settings tab for Sulphur script supplies configuration
 */
public class SulphurSuppliesTab extends AbstractSettingsTab {
    private final SulphurConfig config;
    private SuppliesPanel suppliesPanel;

    public SulphurSuppliesTab(ScriptContext context, SulphurConfig config) {
        super(context);
        this.config = config;
    }

    @Override
    public void createComponents() {
        // Guard against duplicate initialization
        if (suppliesPanel != null) {
            return;
        }
        
        // Create the supplies panel
        suppliesPanel = new SuppliesPanel(config);
        
        // Add it directly without a section title to avoid duplication
        addSection("", suppliesPanel);
    }

    @Override
    public String getTitle() {
        return "Supplies";
    }

    @Override
    public void loadSettings() {
        if (suppliesPanel != null) {
            suppliesPanel.loadSettings();
        }
    }

    @Override
    public void saveSettings() {
        if (suppliesPanel != null) {
            suppliesPanel.saveSettings();
        }
        super.saveSettings();
    }

    @Override
    public void resetToDefaults() {
        if (suppliesPanel != null) {
            suppliesPanel.clearAllFields();
        }
    }
} 