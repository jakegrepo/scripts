package scripts.Sulphur.gui;

import core.gui.components.Icons;
import core.gui.style.StyleManager;
import core.gui.style.ModernUITheme;
import core.config.RestockConfig;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.items.Item;
import scripts.Sulphur.SulphurConfig;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class SuppliesPanel extends JPanel {
    private final SulphurConfig config;
    private boolean isLoading = false;
    
    // UI Components
    private JPanel suppliesListPanel;
    private JButton fetchInventoryButton;
    private JButton saveButton;
    private JLabel statusLabel;
    private Map<String, SupplyItemPanel> supplyPanels;
    
    public SuppliesPanel(SulphurConfig config) {
        this.config = config;
        this.supplyPanels = new HashMap<>();
        initializeComponents();
    }
    
    private void initializeComponents() {
        setLayout(new BorderLayout(0, 0));
        setBorder(null);
        StyleManager.applyStyle(this);
        
        // Main panel with modern card layout
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setOpaque(false);
        
        // Header with modern design
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Modern supplies list with card layout
        suppliesListPanel = new JPanel();
        suppliesListPanel.setLayout(new BoxLayout(suppliesListPanel, BoxLayout.Y_AXIS));
        suppliesListPanel.setOpaque(false);
        suppliesListPanel.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        
        // Set minimum and preferred size to match equipment panel height
        Dimension minSize = new Dimension(300, 400);
        suppliesListPanel.setMinimumSize(minSize);
        suppliesListPanel.setPreferredSize(minSize);
        
        // Add supplies list directly (no internal scroll pane - handled at framework level)
        mainPanel.add(suppliesListPanel, BorderLayout.CENTER);
        
        // Modern status bar
        JPanel statusPanel = createStatusPanel();
        mainPanel.add(statusPanel, BorderLayout.SOUTH);
        
        add(mainPanel, BorderLayout.CENTER);
        
        // Load initial settings
        loadSettings();
    }
    
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout(0, 0));
        headerPanel.setOpaque(false);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        
        // Title with modern styling
        JLabel titleLabel = new JLabel("SUPPLIES");
        titleLabel.setFont(StyleManager.HEADER_FONT);
        titleLabel.setForeground(StyleManager.ACCENT);
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        // Modern button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        buttonPanel.setOpaque(false);
        
        fetchInventoryButton = createModernButton("Fetch", Icons.REFRESH);
        fetchInventoryButton.addActionListener(e -> handleFetchInventory());
        
        saveButton = createModernButton("Save", Icons.SAVE);
        saveButton.addActionListener(e -> handleSaveSupplies());
        
        buttonPanel.add(fetchInventoryButton);
        buttonPanel.add(saveButton);
        headerPanel.add(buttonPanel, BorderLayout.EAST);
        
        return headerPanel;
    }
    
    private JPanel createStatusPanel() {
        JPanel statusPanel = new JPanel(new BorderLayout(0, 0));
        statusPanel.setOpaque(false);
        statusPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        
        statusLabel = new JLabel("Ready");
        statusLabel.setFont(StyleManager.SMALL_FONT);
        statusLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        statusPanel.add(statusLabel, BorderLayout.WEST);
        
        return statusPanel;
    }
    
    private class SupplyItemPanel extends JPanel {
        private final JLabel nameLabel;
        private final JSpinner quantitySpinner;
        private final JCheckBox restockCheckbox;
        
        public SupplyItemPanel(String itemName, int quantity) {
            setLayout(new BorderLayout(8, 0));
            setOpaque(false);
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(StyleManager.BORDER_COLOR),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
            ));
            setBackground(StyleManager.COMPONENT_BG);
            setOpaque(true);
            
            // Item name
            nameLabel = new JLabel(itemName);
            nameLabel.setFont(StyleManager.REGULAR_FONT);
            nameLabel.setForeground(StyleManager.FOREGROUND);
            add(nameLabel, BorderLayout.CENTER);
            
            // Right panel for controls
            JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            rightPanel.setOpaque(false);
            
            // Restock checkbox
            restockCheckbox = new JCheckBox("Restock");
            restockCheckbox.setFont(StyleManager.SMALL_FONT);
            restockCheckbox.setSelected(config.isUsingGrandExchange());
            restockCheckbox.addActionListener(e -> updateRestockState());
            rightPanel.add(restockCheckbox);
            
            // Quantity spinner
            quantitySpinner = new JSpinner(new SpinnerNumberModel(quantity, 0, Integer.MAX_VALUE, 1));
            JComponent editor = quantitySpinner.getEditor();
            JFormattedTextField textField = ((JSpinner.DefaultEditor) editor).getTextField();
            textField.setColumns(5);
            textField.setFont(StyleManager.REGULAR_FONT);
            quantitySpinner.setPreferredSize(new Dimension(80, 24));
            rightPanel.add(quantitySpinner);
            
            add(rightPanel, BorderLayout.EAST);
        }
        
        public String getItemName() {
            return nameLabel.getText();
        }
        
        public int getQuantity() {
            return (Integer) quantitySpinner.getValue();
        }
        
        public boolean isRestockEnabled() {
            return restockCheckbox.isSelected();
        }
        
        private void updateRestockState() {
            if (!isLoading) {
                handleSaveSupplies();
            }
        }
    }
    
    private JButton createModernButton(String text, Icon icon) {
        JButton button = new JButton(text, icon);
        button.setFont(StyleManager.REGULAR_FONT);
        button.setForeground(StyleManager.FOREGROUND);
        button.setBackground(StyleManager.COMPONENT_BG);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
    
    private void handleFetchInventory() {
        if (!Client.isLoggedIn()) {
            JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),
                    "Please log in first to fetch your inventory.",
                    "Not Logged In",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            // Clear existing supplies
            suppliesListPanel.removeAll();
            supplyPanels.clear();
            
            // Get all inventory items
            Map<String, Integer> inventoryItems = new HashMap<>();
            for (Item item : Inventory.all()) {
                if (item != null) {
                    String itemName = item.getName();
                    inventoryItems.merge(itemName, item.getAmount(), Integer::sum);
                }
            }
            
            // Add each item to the panel, or show placeholder if empty
            if (!inventoryItems.isEmpty()) {
                for (Map.Entry<String, Integer> entry : inventoryItems.entrySet()) {
                    SupplyItemPanel itemPanel = new SupplyItemPanel(entry.getKey(), entry.getValue());
                    supplyPanels.put(entry.getKey(), itemPanel);
                    suppliesListPanel.add(itemPanel);
                }
            } else {
                addPlaceholder();
            }
            
            // Update the panel
            suppliesListPanel.revalidate();
            suppliesListPanel.repaint();
            
            // Save to config
            config.setSupplies(inventoryItems);
            config.saveConfig();
            
            // Update restock config
            updateRestockConfig();
            
            statusLabel.setText("Inventory items fetched successfully!");
            
        } catch (Exception e) {
            Logger.log("Error fetching inventory: " + e.getMessage());
            statusLabel.setText("Error: " + e.getMessage());
            JOptionPane.showMessageDialog(this,
                    "Error fetching inventory: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void handleSaveSupplies() {
        try {
            Map<String, Integer> supplies = new HashMap<>();
            
            // Get quantities from panels
            for (SupplyItemPanel panel : supplyPanels.values()) {
                supplies.put(panel.getItemName(), panel.getQuantity());
            }
            
            if (!supplies.isEmpty()) {
                config.setSupplies(supplies);
                config.saveConfig();
                
                // Update restock config
                updateRestockConfig();
                
                statusLabel.setText("Supplies saved successfully!");
            } else {
                statusLabel.setText("No supplies to save!");
            }
        } catch (Exception e) {
            Logger.log("Error saving supplies: " + e.getMessage());
            statusLabel.setText("Error: " + e.getMessage());
        }
    }
    
    private void updateRestockConfig() {
        RestockConfig restockConfig = config.getRestockConfig();
        int multiplier = config.getSuppliesMultiplier();
        
        // Clear existing items
        for (String itemName : restockConfig.getInventoryItemsToRestock()) {
            restockConfig.removeInventoryItem(itemName);
        }
        
        // Add items with multiplied quantities
        for (SupplyItemPanel panel : supplyPanels.values()) {
            if (panel.isRestockEnabled()) {
                String itemName = panel.getItemName();
                int baseQuantity = panel.getQuantity();
                int desiredQuantity = baseQuantity * multiplier;
                int minimumQuantity = (int) (baseQuantity * 0.5); // Set minimum to 50% of base quantity
                
                restockConfig.addInventoryItem(itemName, desiredQuantity);
                restockConfig.setInventoryItemMinimumQuantity(itemName, minimumQuantity);
            }
        }
        
        config.saveConfig();
    }
    
    public void loadSettings() {
        isLoading = true;
        try {
            // Clear existing supplies
            suppliesListPanel.removeAll();
            supplyPanels.clear();
            
            // Get supplies from config
            Map<String, Integer> supplies = config.getSupplies();
            if (supplies != null && !supplies.isEmpty()) {
                for (Map.Entry<String, Integer> entry : supplies.entrySet()) {
                    SupplyItemPanel itemPanel = new SupplyItemPanel(entry.getKey(), entry.getValue());
                    supplyPanels.put(entry.getKey(), itemPanel);
                    suppliesListPanel.add(itemPanel);
                }
            } else {
                // Add placeholder when no supplies are configured
                addPlaceholder();
            }
            
            // Update the panel
            suppliesListPanel.revalidate();
            suppliesListPanel.repaint();
            
        } finally {
            isLoading = false;
        }
    }
    
    private void addPlaceholder() {
        JPanel placeholderPanel = new JPanel(new BorderLayout());
        placeholderPanel.setOpaque(false);
        placeholderPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        placeholderPanel.setBackground(StyleManager.COMPONENT_BG);
        placeholderPanel.setOpaque(true);
        
        JLabel placeholderLabel = new JLabel("<html><div style='text-align: center;'>" +
            "<span style='font-size: 14px; color: rgb(150,150,150);'>No supplies configured</span><br><br>" +
            "<span style='font-size: 12px; color: rgb(120,120,120);'>Click 'Fetch' to load your current inventory items</span>" +
            "</div></html>");
        placeholderLabel.setHorizontalAlignment(SwingConstants.CENTER);
        placeholderPanel.add(placeholderLabel, BorderLayout.CENTER);
        
        suppliesListPanel.add(placeholderPanel);
    }
    
    public void saveSettings() {
        if (!isLoading) {
            handleSaveSupplies();
        }
    }
    
    public void clearAllFields() {
        suppliesListPanel.removeAll();
        supplyPanels.clear();
        suppliesListPanel.revalidate();
        suppliesListPanel.repaint();
        statusLabel.setText("Ready");
    }
} 