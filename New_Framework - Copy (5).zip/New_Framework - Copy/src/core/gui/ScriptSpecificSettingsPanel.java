package core.gui;

import core.gui.style.StyleManager;
import core.context.ScriptContext;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Panel that contains all script-specific settings in a tabbed interface.
 * This provides a single entry point for script settings while organizing
 * different aspects (Equipment, Supplies, etc.) into separate tabs.
 */
public class ScriptSpecificSettingsPanel extends JPanel {
    private final ScriptContext context;
    private final List<AbstractSettingsTab> scriptTabs;
    private final String scriptDisplayName;
    private final String scriptDescription;
    private JTabbedPane tabbedPane;
    
    // Status components for setup progress
    private JLabel equipmentStatusLabel;
    private JLabel suppliesStatusLabel;
    private JLabel configStatusLabel;
    private JProgressBar setupProgressBar;

    public ScriptSpecificSettingsPanel(ScriptContext context, 
                                       List<AbstractSettingsTab> scriptTabs, 
                                       String scriptDisplayName, 
                                       String scriptDescription) {
        this.context = context;
        this.scriptTabs = scriptTabs;
        this.scriptDisplayName = scriptDisplayName;
        this.scriptDescription = scriptDescription;
        
        initializeComponents();
    }

    private void initializeComponents() {
        setLayout(new BorderLayout(0, 0));
        setOpaque(false);

        // Create header with script information
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);

        // Create tabbed pane for different settings aspects
        tabbedPane = createTabbedPane();
        add(tabbedPane, BorderLayout.CENTER);

        // Initialize all tabs
        for (AbstractSettingsTab tab : scriptTabs) {
            tab.initialize();
            tab.createComponents();
        }
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout(0, 0));
        headerPanel.setOpaque(false);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        // Setup status dashboard (no title, just the dashboard)
        JPanel statusDashboard = createStatusDashboard();
        headerPanel.add(statusDashboard, BorderLayout.CENTER);

        return headerPanel;
    }
    
    private JPanel createStatusDashboard() {
        JPanel dashboard = new JPanel(new BorderLayout(10, 5));
        dashboard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(StyleManager.ACCENT, 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        dashboard.setBackground(StyleManager.CARD_BG);
        dashboard.setOpaque(true);

        // Progress bar
        setupProgressBar = new JProgressBar(0, 100);
        setupProgressBar.setStringPainted(true);
        setupProgressBar.setString("Configuration Progress");
        setupProgressBar.setForeground(StyleManager.ACCENT);
        setupProgressBar.setBackground(StyleManager.COMPONENT_BG);
        setupProgressBar.setFont(StyleManager.REGULAR_FONT);
        dashboard.add(setupProgressBar, BorderLayout.NORTH);

        // Center panel with status and quick settings
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setOpaque(false);

        // Status indicators panel
        JPanel statusPanel = new JPanel(new GridLayout(1, 3, 10, 0));
        statusPanel.setOpaque(false);

        equipmentStatusLabel = createStatusLabel("Equipment", "Not Configured", false);
        suppliesStatusLabel = createStatusLabel("Supplies", "Not Configured", false);
        configStatusLabel = createStatusLabel("Settings", "Not Configured", false);

        statusPanel.add(equipmentStatusLabel);
        statusPanel.add(suppliesStatusLabel);
        statusPanel.add(configStatusLabel);

        centerPanel.add(statusPanel, BorderLayout.CENTER);

        // Quick settings panel
        JPanel quickSettingsPanel = createQuickSettingsPanel();
        centerPanel.add(quickSettingsPanel, BorderLayout.SOUTH);

        dashboard.add(centerPanel, BorderLayout.CENTER);

        return dashboard;
    }
    
    private JPanel createQuickSettingsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 8));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(StyleManager.BORDER_COLOR.getRed(),
                StyleManager.BORDER_COLOR.getGreen(), StyleManager.BORDER_COLOR.getBlue(), 100)),
            BorderFactory.createEmptyBorder(8, 0, 0, 0)
        ));

        try {
            // Cast to ScarScript to access config methods
            if (!(context.getScript() instanceof core.base.ScarScript)) {
                // Fallback for non-ScarScript implementations
                JLabel infoLabel = new JLabel("Quick settings not available for this script");
                infoLabel.setFont(StyleManager.SMALL_FONT);
                infoLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
                panel.add(infoLabel);
                return panel;
            }
            Object config = ((core.base.ScarScript<?>) context.getScript()).getConfig();
            
            // Try to get Grand Exchange setting
            try {
                boolean useGE = (Boolean) config.getClass().getMethod("isUsingGrandExchange").invoke(config);
                JCheckBox useGECheckbox = new JCheckBox("Use Grand Exchange");
                useGECheckbox.setFont(StyleManager.SMALL_FONT);
                useGECheckbox.setOpaque(false);
                useGECheckbox.setForeground(StyleManager.FOREGROUND);
                useGECheckbox.setSelected(useGE);
                useGECheckbox.addActionListener(e -> {
                    try {
                        config.getClass().getMethod("setUseGrandExchange", boolean.class).invoke(config, useGECheckbox.isSelected());
                        config.getClass().getMethod("saveConfig").invoke(config);
                        updateSetupStatus();
                    } catch (Exception ex) { /* ignore */ }
                });
                panel.add(useGECheckbox);
            } catch (Exception e) { /* method not available */ }

            // Try to get supplies multiplier
            try {
                int multiplier = (Integer) config.getClass().getMethod("getSuppliesMultiplier").invoke(config);
                panel.add(new JLabel("Supplies:"));
                JSpinner multiplierSpinner = new JSpinner(new SpinnerNumberModel(multiplier, 1, 10, 1));
                multiplierSpinner.setPreferredSize(new Dimension(60, 24));
                multiplierSpinner.addChangeListener(e -> {
                    try {
                        config.getClass().getMethod("setSuppliesMultiplier", int.class).invoke(config, (Integer) multiplierSpinner.getValue());
                        config.getClass().getMethod("saveConfig").invoke(config);
                        updateSetupStatus();
                    } catch (Exception ex) { /* ignore */ }
                });
                panel.add(multiplierSpinner);
            } catch (Exception e) { /* method not available */ }

            // Try to get loot threshold
            try {
                int threshold = (Integer) config.getClass().getMethod("getLootValueThreshold").invoke(config);
                panel.add(new JLabel("Loot Min GP:"));
                JSpinner lootSpinner = new JSpinner(new SpinnerNumberModel(threshold, 0, 100000, 1000));
                lootSpinner.setPreferredSize(new Dimension(80, 24));
                lootSpinner.addChangeListener(e -> {
                    try {
                        config.getClass().getMethod("setLootValueThreshold", int.class).invoke(config, (Integer) lootSpinner.getValue());
                        config.getClass().getMethod("saveConfig").invoke(config);
                        updateSetupStatus();
                    } catch (Exception ex) { /* ignore */ }
                });
                panel.add(lootSpinner);
            } catch (Exception e) { /* method not available */ }

        } catch (Exception e) {
            // Fallback for scripts without quick settings
            JLabel infoLabel = new JLabel("Quick settings not available for this script");
            infoLabel.setFont(StyleManager.SMALL_FONT);
            infoLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
            panel.add(infoLabel);
        }

        return panel;
    }
    
    private JLabel createStatusLabel(String title, String status, boolean isComplete) {
        String icon = isComplete ? "✓" : "⚠";
        Color color = isComplete ? new Color(46, 160, 67) : new Color(255, 152, 0);

        JLabel label = new JLabel(String.format("<html><div style='text-align: center;'>" +
            "<span style='font-size: 16px; color: rgb(%d,%d,%d);'>%s</span><br>" +
            "<span style='font-size: 12px; color: rgb(150,150,150);'>%s</span><br>" +
            "<span style='font-size: 10px; color: rgb(120,120,120);'>%s</span>" +
            "</div></html>",
            color.getRed(), color.getGreen(), color.getBlue(), icon, title, status));

        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        label.setOpaque(true);
        label.setBackground(StyleManager.COMPONENT_BG);

        return label;
    }

    private JTabbedPane createTabbedPane() {
        tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        StyleManager.applyStyle(tabbedPane);
        
        // Configure tabbed pane styling
        tabbedPane.setBackground(StyleManager.PANEL_BG);
        tabbedPane.setForeground(StyleManager.FOREGROUND);
        tabbedPane.setFont(StyleManager.REGULAR_FONT);
        
        // Add each script tab as a separate tab in the pane
        for (AbstractSettingsTab tab : scriptTabs) {
            String tabTitle = getTabDisplayName(tab);
            JPanel tabPanel = tab.getPanel();
            
            // Wrap the tab panel to ensure proper styling and no nested scroll bars
            JPanel wrappedPanel = createTabWrapper(tabPanel);
            tabbedPane.addTab(tabTitle, wrappedPanel);
        }

        return tabbedPane;
    }

    private JPanel createTabWrapper(JPanel tabPanel) {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Add the tab panel directly without a scroll pane to avoid nested scrolling
        wrapper.add(tabPanel, BorderLayout.CENTER);
        
        return wrapper;
    }

    private String getTabDisplayName(AbstractSettingsTab tab) {
        String title = tab.getTitle();
        
        // Remove script name prefix if present to avoid redundancy
        if (title.startsWith(scriptDisplayName)) {
            title = title.substring(scriptDisplayName.length()).trim();
        }
        
        // Remove "Settings" suffix if present
        if (title.endsWith("Settings")) {
            title = title.substring(0, title.length() - 8).trim();
        }
        
        // Default to the full title if we couldn't clean it up
        if (title.isEmpty()) {
            title = tab.getTitle();
        }
        
        return title;
    }

    /**
     * Updates all tabs from their respective configurations
     */
    public void updateFromConfig() {
        for (AbstractSettingsTab tab : scriptTabs) {
            tab.updateFromConfig();
        }
    }

    /**
     * Saves all tab settings to their respective configurations
     */
    public void saveToConfig() {
        for (AbstractSettingsTab tab : scriptTabs) {
            tab.saveToConfig();
        }
    }

    /**
     * Resets all tabs to their default values
     */
    public void resetToDefaults() {
        for (AbstractSettingsTab tab : scriptTabs) {
            tab.resetToDefaults();
        }
    }

    /**
     * Gets the currently selected tab index
     */
    public int getSelectedTabIndex() {
        return tabbedPane != null ? tabbedPane.getSelectedIndex() : 0;
    }

    /**
     * Sets the selected tab by index
     */
    public void setSelectedTabIndex(int index) {
        if (tabbedPane != null && index >= 0 && index < tabbedPane.getTabCount()) {
            tabbedPane.setSelectedIndex(index);
        }
    }

    /**
     * Gets the number of tabs in this panel
     */
    public int getTabCount() {
        return scriptTabs.size();
    }
    
    /**
     * Updates the setup status based on current configuration
     */
    public void updateSetupStatus() {
        if (setupProgressBar == null || equipmentStatusLabel == null || 
            suppliesStatusLabel == null || configStatusLabel == null) {
            return;
        }
        
        try {
            // Cast to ScarScript to access config methods
            if (!(context.getScript() instanceof core.base.ScarScript)) {
                return; // Not a ScarScript, can't get config
            }
            Object config = ((core.base.ScarScript<?>) context.getScript()).getConfig();
            
            // Check equipment status
            boolean equipmentConfigured = false;
            try {
                Object equipment = config.getClass().getMethod("getEquipment").invoke(config);
                if (equipment instanceof java.util.Map) {
                    equipmentConfigured = !((java.util.Map<?, ?>) equipment).isEmpty();
                }
            } catch (Exception e) { /* method not available */ }
            updateStatusLabel(equipmentStatusLabel, "Equipment", 
                equipmentConfigured ? "Configured" : "Not Configured", equipmentConfigured);
            
            // Check supplies status  
            boolean suppliesConfigured = false;
            try {
                Object supplies = config.getClass().getMethod("getSupplies").invoke(config);
                if (supplies instanceof java.util.Map) {
                    suppliesConfigured = !((java.util.Map<?, ?>) supplies).isEmpty();
                }
            } catch (Exception e) { /* method not available */ }
            updateStatusLabel(suppliesStatusLabel, "Supplies",
                suppliesConfigured ? "Configured" : "Not Configured", suppliesConfigured);
            
            // Check general settings status
            boolean settingsConfigured = false;
            try {
                boolean useGE = (Boolean) config.getClass().getMethod("isUsingGrandExchange").invoke(config);
                int multiplier = (Integer) config.getClass().getMethod("getSuppliesMultiplier").invoke(config);
                settingsConfigured = useGE || multiplier > 1;
            } catch (Exception e) { /* methods not available */ }
            updateStatusLabel(configStatusLabel, "Settings",
                settingsConfigured ? "Configured" : "Default Values", settingsConfigured);
            
            // Update progress bar
            int configuredCount = 0;
            if (equipmentConfigured) configuredCount++;
            if (suppliesConfigured) configuredCount++;
            if (settingsConfigured) configuredCount++;
            
            int progress = (configuredCount * 100) / 3;
            setupProgressBar.setValue(progress);
            setupProgressBar.setString(progress + "% Complete");
            
        } catch (Exception e) {
            // Fallback for scripts without reflection support
            updateStatusLabel(equipmentStatusLabel, "Equipment", "Unknown", false);
            updateStatusLabel(suppliesStatusLabel, "Supplies", "Unknown", false);
            updateStatusLabel(configStatusLabel, "Settings", "Unknown", false);
            setupProgressBar.setValue(0);
            setupProgressBar.setString("Status Unknown");
        }
    }
    
    private void updateStatusLabel(JLabel label, String title, String status, boolean isComplete) {
        String icon = isComplete ? "✓" : "⚠";
        Color color = isComplete ? new Color(46, 160, 67) : new Color(255, 152, 0);

        label.setText(String.format("<html><div style='text-align: center;'>" +
            "<span style='font-size: 16px; color: rgb(%d,%d,%d);'>%s</span><br>" +
            "<span style='font-size: 12px; color: rgb(150,150,150);'>%s</span><br>" +
            "<span style='font-size: 10px; color: rgb(120,120,120);'>%s</span>" +
            "</div></html>",
            color.getRed(), color.getGreen(), color.getBlue(), icon, title, status));
    }
} 