package core.gui;

import java.util.List;

/**
 * Interface for scripts that provide their own settings tabs to the framework GUI.
 * This allows scripts to register multiple settings tabs that will be integrated
 * into the main framework GUI automatically.
 */
public interface ScriptSettingsProvider {
    
    /**
     * Returns a list of settings tabs that this script provides.
     * These tabs will be automatically integrated into the framework GUI.
     * 
     * @return List of AbstractSettingsTab instances, or empty list if no additional tabs
     */
    List<AbstractSettingsTab> getAdditionalSettingsTabs();
    
    /**
     * Gets the display name for this script's settings group.
     * This will be used as a prefix for all settings tabs from this script.
     * 
     * @return Display name for the script settings group
     */
    default String getScriptDisplayName() {
        return getClass().getSimpleName();
    }
    
    /**
     * Gets the description for this script's settings.
     * This will be displayed in the settings overview.
     * 
     * @return Description of what this script does
     */
    default String getScriptDescription() {
        return "Script-specific configuration";
    }
} 