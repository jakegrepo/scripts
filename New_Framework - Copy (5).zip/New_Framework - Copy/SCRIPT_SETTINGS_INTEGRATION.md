# Script-Specific Settings Integration

## Overview
This system allows individual scripts to register their own settings tabs that will be seamlessly integrated into the main framework GUI. This provides a modular approach where each script can have its own specialized configuration interfaces.

## System Components

### 1. ScriptSettingsProvider Interface
- **Location**: `src/core/gui/ScriptSettingsProvider.java`
- **Purpose**: Interface that scripts can implement to provide additional settings tabs
- **Methods**:
  - `getAdditionalSettingsTabs()`: Returns list of script-specific settings tabs
  - `getScriptDisplayName()`: Returns display name for the script
  - `getScriptDescription()`: Returns description for the script settings

### 2. Enhanced FrameworkGUI
- **Location**: `src/core/gui/FrameworkGUI.java`
- **Enhancements**:
  - Dynamic grid layout that adjusts based on number of settings tabs
  - Automatic integration of script-specific settings cards
  - Support for ScriptSettingsProvider interface
  - Refresh mechanism for home panel when new tabs are added

### 3. Script-Specific Settings Tabs
Scripts can now create multiple specialized settings tabs:

#### For Sulphur Script:
1. **SulphurSettingsTab** - Main script configuration
2. **SulphurEquipmentTab** - Equipment management
3. **SulphurSuppliesTab** - Supplies configuration

## Implementation for Scripts

### Step 1: Implement ScriptSettingsProvider
```java
public class YourScript extends ScarScript<YourConfig> implements ScriptSettingsProvider {
    
    @Override
    public List<AbstractSettingsTab> getAdditionalSettingsTabs() {
        List<AbstractSettingsTab> tabs = new ArrayList<>();
        tabs.add(new YourCustomTab1(getContext(), config));
        tabs.add(new YourCustomTab2(getContext(), config));
        return tabs;
    }
    
    @Override
    public String getScriptDisplayName() {
        return "Your Script Name";
    }
    
    @Override
    public String getScriptDescription() {
        return "Description of what your script does";
    }
}
```

### Step 2: Create Custom Settings Tabs
```java
public class YourCustomTab extends AbstractSettingsTab {
    private final YourConfig config;
    private YourCustomPanel panel;

    public YourCustomTab(ScriptContext context, YourConfig config) {
        super(context);
        this.config = config;
    }

    @Override
    public void createComponents() {
        panel = new YourCustomPanel(config);
        addSection("Your Section", panel);
    }

    @Override
    public String getTitle() {
        return "Your Tab Title";
    }

    // Implement other required methods...
}
```

## Features

### Automatic Integration
- Script tabs are automatically added to the main framework GUI
- No manual registration required - just implement the interface
- Dynamic grid layout adjusts to accommodate additional tabs

### Modular Design
- Each script can have multiple specialized settings tabs
- Settings are organized by functionality (e.g., Equipment, Supplies, Combat)
- Easy to maintain and extend

### Consistent UI
- All tabs use the framework's styling system
- Consistent look and feel across all settings
- Modern card-based design with proper spacing

## Benefits

1. **Separation of Concerns**: Different aspects of script configuration are separated into focused tabs
2. **Maintainability**: Easier to maintain and update individual settings sections
3. **User Experience**: Cleaner, more organized settings interface
4. **Scalability**: Easy to add new settings tabs without modifying the framework
5. **Consistency**: All scripts use the same integration pattern

## Example: Sulphur Script Implementation

The Sulphur script demonstrates this system with:

1. **Main Settings** (`SulphurSettingsTab`): Core script configuration
2. **Equipment Settings** (`SulphurEquipmentTab`): Equipment loadout management
3. **Supplies Settings** (`SulphurSuppliesTab`): Supply and inventory management

Each tab is focused on a specific aspect of the script configuration, making it easier for users to find and configure what they need.

## Framework Integration Points

### FrameworkGUI Integration
- `initializeFrameworkTabs()`: Automatically registers script tabs if ScriptSettingsProvider is implemented
- `addScriptSpecificCards()`: Adds cards for each script-specific tab to the home panel
- `getScriptTabDescription()`: Uses script description from ScriptSettingsProvider

### ScarScript Integration
- Maintains backward compatibility with existing `getScriptTab()` method
- Additional tabs are registered automatically via ScriptSettingsProvider
- No changes required to existing scripts that don't want to use this system

This system provides a clean, extensible way for scripts to integrate their settings into the framework while maintaining consistency and usability. 