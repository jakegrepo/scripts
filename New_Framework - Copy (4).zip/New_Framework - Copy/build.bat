@echo off
echo Building ScarFramework with Maven...
mvn clean package
if %ERRORLEVEL% EQU 0 (
    echo Build successful! JAR file created at %USERPROFILE%\DreamBot\Scripts\ScarFramework.jar
) else (
    echo Build failed with error code %ERRORLEVEL%
)
pause
