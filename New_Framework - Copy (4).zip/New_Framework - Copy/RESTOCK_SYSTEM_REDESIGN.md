# Simplified Restock System - Complete Redesign

## Overview

The restock system has been completely redesigned to be **much simpler and more user-friendly**. Instead of confusing min/max quantities, users now work with intuitive concepts:

- **Usage per trip**: How many of each item you use per trip
- **Multiplier**: How many trips worth you want to stock up to (default 6x)
- **Automatic calculation**: System calculates min (triggers restock) and max (target stock) automatically

## Key Benefits

### ✅ Much Simpler for Users
- **Before**: "Set minimum to 200, desired to 1000" (confusing)
- **After**: "I use 20 food per trip, stock 6 trips worth" (intuitive)

### ✅ Universal Approach
- Works for all script types (combat, skilling, etc.)
- Same logic applies whether you use 5 items or 500 items per trip
- Scales automatically based on usage patterns

### ✅ Smart Item Detection
- Automatically detects consumable items from inventory/bank/equipment
- Categorizes items (Food, Potion, Rune, Ammunition, etc.)
- Provides intelligent usage estimates based on item type
- Filters out non-consumable items (tools, quest items, etc.)

### ✅ Better User Experience
- Single table showing all restock items
- Clear column headers: Usage/Trip, Multiplier, Min Stock, Max Stock
- "Detect Items" button for automatic setup
- Real-time calculation of min/max values

## Example: Your Karambwan Scenario

**User Setup:**
- Usage per trip: 20 karambwan
- Multiplier: 6x

**Automatic Calculation:**
- **Min Stock (triggers restock)**: 20 (when you drop below 1 trip worth)
- **Max Stock (restock target)**: 120 (6 trips worth)

**Behavior:**
- Script runs normally using karambwan from bank/inventory
- When total karambwan drops below 20, restock is triggered
- Script goes to GE and buys enough to reach 120 total
- User has enough for 6 trips before needing to restock again

## Files Changed

### 1. `RestockConfig.java` - Complete Redesign
- **New**: `RestockItem` class with `usagePerTrip` and `multiplier`
- **Automatic**: `getMinStock()` and `getMaxStock()` methods
- **Backward Compatible**: Legacy methods still work with existing scripts
- **Simplified**: Much cleaner data structure

### 2. `RestockSettingsPanel.java` - New GUI
- **Single Table**: One table showing all items with clear columns
- **Inline Editing**: Edit usage/trip and multiplier directly in table
- **Smart Detection**: "Detect Items" button with intelligent categorization
- **Multiplier Control**: Apply same multiplier to all items easily

### 3. `RestockItemUtils.java` - New Utility
- **Smart Categorization**: Food, Potion, Rune, Ammunition, Teleport, Jewelry
- **Intelligent Estimates**: Suggests usage per trip based on item type
- **Auto-Exclusion**: Filters out tools, quest items, containers
- **Pattern Matching**: Recognizes items even with variants

### 4. `RestockCheckUtility.java` - Compatible
- Works with new system through legacy compatibility methods
- No changes needed - existing logic still functions

### 5. `RestockGrandExchangeNode.java` - Compatible
- Works seamlessly with new system
- Uses legacy methods for backward compatibility

## GUI Improvements

### Before: Complex Dual-Table Interface
```
Buying Items Table:
- Item Name | Desired Quantity | Minimum Quantity

Selling Items Table:  
- Item Name | Sell Quantity | Is Selling

Separate controls for each table with confusing spinners
```

### After: Simple Single-Table Interface
```
Restock Items Table:
- Item Name | Usage/Trip | Multiplier | Min Stock | Max Stock | Enabled | Sell Excess

Single multiplier control affects all items
"Detect Items" button for automatic setup
```

## Smart Item Detection Features

### Automatic Categorization
- **Food**: Estimates 8-30 usage per trip based on healing value
- **Potions**: Estimates 1-5 usage per trip based on potion type
- **Runes**: Estimates 10-200 usage per trip based on spell costs
- **Ammunition**: Estimates 50-500 usage per trip based on combat style
- **Teleports**: Estimates 1-10 usage per trip based on teleport type

### Intelligent Filtering
- **Excludes**: Tools, quest items, containers, cosmetics
- **Includes**: Consumables, stackables, combat supplies
- **Smart Recognition**: Pattern matching for item variants

### Color-Coded Display
- **Green**: Food items
- **Blue**: Potions
- **Purple**: Runes
- **Orange**: Ammunition
- **Teal**: Teleports
- **Yellow**: Jewelry

## Migration from Old System

### Automatic Migration
The new `RestockConfig` includes legacy compatibility methods, so existing scripts continue to work without changes:

```java
// Old method calls still work:
config.getInventoryItemMinimumQuantity("Shark");  // Returns usagePerTrip
config.getInventoryItemDesiredQuantity("Shark");  // Returns usagePerTrip * multiplier
```

### Manual Migration Benefits
Scripts can optionally migrate to the new simpler API:

```java
// Old way (confusing):
config.addInventoryItem("Shark", 1000);  // Desired quantity
config.setInventoryItemMinimumQuantity("Shark", 200);  // Minimum quantity

// New way (intuitive):
config.addItem("Shark", 15, 6.0);  // 15 per trip, 6x multiplier = min:15, max:90
```

## Usage Examples

### Combat Script Setup
```java
config.addItem("Karambwan", 20);           // Food: 20 per trip
config.addItem("Super combat potion(4)", 1); // Potion: 1 per trip  
config.addItem("Prayer potion(4)", 2);    // Prayer: 2 per trip
config.addItem("Dragon arrow", 250);      // Ammo: 250 per trip
```

### Skilling Script Setup
```java
config.addItem("Law rune", 50);           // Teleports: 50 per trip
config.addItem("Nature rune", 100);       // Alchemy: 100 per trip
config.addItem("Teleport to house", 5);   // House teles: 5 per trip
```

### Multiplier Adjustment
```java
// For longer trips, increase multiplier
config.setDefaultMultiplier(10.0);        // Stock 10 trips worth
config.updateAllMultipliers(10.0);        // Apply to all existing items
```

## Implementation Status

### ✅ Completed
- [x] New `RestockConfig` with multiplier system
- [x] Smart item categorization utility
- [x] Simplified GUI with single table
- [x] Automatic item detection
- [x] Backward compatibility with existing scripts
- [x] Real-time calculation of min/max values

### 🔄 Maintains Compatibility
- [x] Existing `RestockCheckUtility` works unchanged
- [x] Existing `RestockGrandExchangeNode` works unchanged
- [x] All current scripts continue functioning
- [x] Legacy API methods still available

## User Workflow

### Setting Up Restock (New Way)
1. Open restock settings tab
2. Click "Detect Items" button
3. Select items from smart categorized list
4. Adjust usage per trip values if needed
5. Set desired multiplier (default 6x is good for most cases)
6. Done! Min/max values calculate automatically

### Understanding the System
- **Usage/Trip**: How many you actually consume per trip
- **Multiplier**: How many trips worth to keep in stock
- **Min Stock**: When to trigger restock (= Usage/Trip)
- **Max Stock**: How much to buy (= Usage/Trip × Multiplier)

### Example Scenarios
- **Conservative**: 3x multiplier (3 trips worth)
- **Standard**: 6x multiplier (6 trips worth) 
- **Extended**: 10x multiplier (10 trips worth)

## Benefits Summary

1. **Intuitive**: Users think in terms of actual usage, not arbitrary numbers
2. **Scalable**: Works for any script type or usage pattern
3. **Smart**: Automatic detection and intelligent suggestions
4. **Flexible**: Easy to adjust multiplier for different play styles
5. **Compatible**: Existing scripts continue working without changes
6. **Future-Proof**: Clean architecture for future enhancements

The new system transforms the confusing "set min 200, max 1000" approach into the intuitive "I use 20 per trip, stock 6 trips worth" approach that makes immediate sense to users. 