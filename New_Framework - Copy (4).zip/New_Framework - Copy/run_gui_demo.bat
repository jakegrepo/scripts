@echo off
echo Building and running GUI Preview Demo...
echo.

rem Build the project
call mvn clean package

rem Run the demo
java -cp target\scar-framework-1.0-SNAPSHOT.jar demo.GUIPreviewDemo

echo.
echo Done.
pause
