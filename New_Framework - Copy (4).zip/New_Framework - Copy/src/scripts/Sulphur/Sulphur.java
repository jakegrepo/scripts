package scripts.Sulphur;

import core.base.ScarScript;
import core.gui.AbstractSettingsTab;
import core.node.TaskNode;
import core.paint.PaintBuilder;
import core.paint.ScriptPaint;
import core.paint.XPTracker;
import core.state.ScriptState;
import events.EventType;
import events.ScriptEvent;
import events.listeners.ScarExperienceListener;
import events.listeners.ScarInventoryListener;
import org.dreambot.api.Client;
import org.dreambot.api.data.GameState;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.container.impl.equipment.EquipmentSlot;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.prayer.Prayers;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManager;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.items.Item;
import scripts.Sulphur.data.SulphurLoadoutData;
import scripts.Sulphur.gui.SulphurDebugOverlay;
import scripts.Sulphur.gui.SulphurSettingsTab;
import scripts.Sulphur.nodes.*;
import scripts.Sulphur.utils.ConsumablesNode;
import scripts.Sulphur.utils.SulphurPrayerFlicker;

import java.awt.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static scripts.Sulphur.webnodes.AncientPrison.AncientPrisonNode;

@ScriptManifest(
        name = "ScarNaga",
        author = "Scarfade",
        version = 2.0,
        description = "Naga Killers",
        category = Category.MONEYMAKING
)
public class Sulphur extends ScarScript<SulphurConfig> implements SulphurStateListener {
    private SulphurConfig config;
    private ScriptPaint paint;
    private PaintBuilder paintBuilder;
    private SulphurStateListener listener;
    private long startTime;
    private SulphurDebugOverlay SulphurDebugOverlay;
    private CombatNode combatNode;
    private ConsumablesNode consumablesNode;
    private MovementNode movementNode;
    private Thread consumablesThread;
    private int totalKills = 0;
    private Thread dodgeWallsThread;
    private SulphurPrayerFlicker prayerFlicker;
    private SulphurGENode geNode;
    private static final int ICE_KING_DEAD_ID   = 14149;
    private static final int FIRE_QUEEN_DEAD_ID = 12597;
    private static final int SULPHUR_NPC_ID     = 13033; // Adding Sulphur NPC ID for consistency
    private boolean killCounted = false;

    // Scheduled executor for periodic location updates
    private ScheduledExecutorService locationUpdater;

    private ScarInventoryListener inventoryListener;

    // Add XP tracking fields
    private Map<Skill, Long> startXpMap = new HashMap<>();
    private Map<Skill, Long> lastXpGainMap = new HashMap<>();
    private static final Set<Skill> COMBAT_SKILLS = Set.of(
            Skill.ATTACK,
            Skill.STRENGTH,
            Skill.DEFENCE,
            Skill.HITPOINTS,
            Skill.RANGED,
            Skill.MAGIC);
    private static final long XP_TIMEOUT = 15 * 60 * 1000; // 15 minutes in milliseconds

    @Override
    public void openTestingGUI() {
        if (context.tasks().getNodes().isEmpty()) {
            context.getLogger().info("Initializing nodes for testing...");
            initializeNodes();
        }
        super.openTestingGUI();
    }

    @Override
    protected void onScriptStart() {
        try {
            context.getLogger().info("=== STARTING TEST SCRIPT ===");
            
            // Initialize startTime first to ensure accurate XP/hr calculations
            startTime = System.currentTimeMillis();
            context.getLogger().info("Start time initialized: " + startTime);
            
            // Reset kill counter
            totalKills = 0;
            
            AncientPrisonNode();
            // Initialize configuration early so we know the role
            config = getScriptConfig();

            // Initialize context and logger first
            context.initialize();
            context.initializeLogger(getClass().getSimpleName());
            context.getLogger().info("Context and logger initialized");

            // Explicitly initialize and start the experience listener
            ScarExperienceListener experienceListener = new ScarExperienceListener(context);
            experienceListener.start();
            context.getLogger().info("Experience listener explicitly started");

            // Reset global state
            SulphurGlobalState.resetAllStates();
            context.getLogger().info("Global state reset");

            // Initialize base overlays
            SulphurDebugOverlay = new SulphurDebugOverlay(context);
            SulphurDebugOverlay.setEnabled(true);
            context.getLogger().info("Debug overlay initialized and enabled");

            // Initialize XP tracking
            for (Skill skill : COMBAT_SKILLS) {
                startXpMap.put(skill, (long) Skills.getExperience(skill));
                lastXpGainMap.put(skill, 0L);
            }
            
            // Log initial Strength XP for verification
            long initialStrengthXp = startXpMap.getOrDefault(Skill.STRENGTH, 0L);
            context.getLogger().info("Initial Strength XP: " + initialStrengthXp);

            // Create and initialize the paint with improved styling
            paintBuilder = new PaintBuilder(context)
                    .setTitle("ScarSulphurs")
                    .addStyledRow("Status", this::getScriptStatus, PaintBuilder.RowIcon.STATUS)
                    .addCombatXpTracker() // This will now show only active skills
                    .addStyledRow("Kills", this::getKillsStatus, PaintBuilder.RowIcon.COMBAT)
                    .addStyledRow("Loot", this::getLootStatus, PaintBuilder.RowIcon.COINS);

            // Initialize XP tracker with combat skills
            XPTracker xpTracker = paintBuilder.getXpTracker();
            for (Skill skill : COMBAT_SKILLS) {
                xpTracker.initializeSkill(skill);
            }

            // Build the paint with styled rows and icons
            paint = paintBuilder.build();

            context.getLogger().info("Enhanced paint initialized with XP tracking");




            // Initialize remaining components
            prayerFlicker = new SulphurPrayerFlicker(getContext());
            prayerFlicker.startPrayerFlick();
            context.getLogger().info("Prayer flicker initialized and started");
            context.getLogger().info("DodgeWalls thread started");

            initializeNodes();
            context.getLogger().info("Nodes initialized: " + context.tasks().getNodes().size() + " nodes");



            // Add after networkManager initialization
            inventoryListener = new ScarInventoryListener(context);
            inventoryListener.start();
            context.getEventManager().addEventListener(EventType.ITEM_GAINED, this::handleItemGained);

            // Add experience listener with correct event handling
            context.getEventManager().addEventListener(EventType.EXPERIENCE_GAINED, event -> {
                try {
                    // Assuming ScriptEvent provides attributes like "skill_id" and "xp_gained"
                    int skillId = (int) event.getAttribute("skill_id");
                    int xpGained = (int) event.getAttribute("xp_gained");

                    // Map skill ID to Skill enum (expanded for all combat skills)
                    Skill skill = null;
                    switch (skillId) {
                        case 0: skill = Skill.ATTACK; break;
                        case 1: skill = Skill.DEFENCE; break;
                        case 2: skill = Skill.STRENGTH; break;
                        case 3: skill = Skill.HITPOINTS; break;
                        case 4: skill = Skill.RANGED; break;
                        case 6: skill = Skill.MAGIC; break;
                        default: return; // Ignore non-combat skills
                    }

                    if (COMBAT_SKILLS.contains(skill)) {
                        context.getLogger().info(String.format("Combat XP gained: %s +%d", skill.name(), xpGained));
                        lastXpGainMap.put(skill, System.currentTimeMillis());
                        // Don't update startXpMap here - it should be set only at script start
                    }
                } catch (Exception e) {
                    context.getLogger().error("Error handling XP gain event: " + e.getMessage());
                }
            });

            setState(ScriptState.RUNNING);
            context.getLogger().info("=== SCRIPT STARTED SUCCESSFULLY ===");



        } catch (Exception e) {
            context.getLogger().error("Error during script start: " + e.getMessage());
            e.printStackTrace();
            setState(ScriptState.ERROR);
        }
    }



    private String getRuntime() {
        long millis = System.currentTimeMillis() - startTime;
        long seconds = millis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        minutes %= 60;
        seconds %= 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    private double getKillsPerHour() {
        long runtime = System.currentTimeMillis() - startTime;
        if (runtime == 0) return 0;
        return (totalKills * 3600000.0) / runtime;
    }

    public static void incrementTotalKills() {
        Sulphur instance = getInstance();
        if(instance != null) {
            instance.totalKills++;
            instance.context.getLogger().info("Total Sulphur kills: " + instance.totalKills);
            
            // No need to explicitly update the paint as it will automatically
            // use the updated totalKills value on the next paint cycle
        }
    }

    private static Sulphur getInstance() {
        return (Sulphur) ScriptManager.getScriptManager().getCurrentScript();
    }

    private void initializeNodes() {
        context.getLogger().info("=== INITIALIZING NODES ===");
        clearNodes();

        try {
            // Initialize GE node first since banking node may need it
            geNode = new SulphurGENode(config, this);
            context.tasks().addNode(geNode);
            
            // Create LootingNode first so we can reference it in CombatNode
            LootingNode lootingNode = new LootingNode(config, this);
            addNode(lootingNode);
            
            // Add the potion-related nodes with appropriate priorities
            addNode(new PotionsNode(config));          // Priority 1
            addNode(new MoonlightGrub(config));        // Priority 2
            addNode(new MakePotionNode(config));       // Priority 3
            
            // Add other nodes
            addNode(new MovementNode(config));
            addNode(new ConsumablesNode(config));
            addNode(new SulphurBankingNode(config));    // Priority 1

            // Create and connect CombatNode with LootingNode
            combatNode = new CombatNode(config, this);
            combatNode.setLootingNode(lootingNode); // Connect the nodes
            addNode(combatNode);
            

            if (consumablesNode == null) {
                consumablesNode = new ConsumablesNode(config);
                consumablesThread = new Thread(consumablesNode);
                consumablesThread.start();
                context.getLogger().info("Consumables node started on a separate thread");
            }

            context.getLogger().info("=== NODE INITIALIZATION COMPLETE ===");
            context.getLogger().info("Total nodes initialized: " + context.tasks().getNodes().size());
            context.tasks().getNodes().forEach(node ->
                    context.getLogger().info("Registered node: " + node.getClass().getSimpleName() +
                            " (Priority: " + node.getPriority() + ")"));
        } catch (Exception e) {
            context.getLogger().error("Error initializing nodes: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    protected int onScriptLoop() {
        try {
            // Update XP tracking on each loop
            updateXpTracking();
            
            // Add game state check at start of loop
            if (Client.getGameState() == GameState.LOGIN_SCREEN) {
                context.getLogger().info("Detected login screen - resetting global states");
                SulphurGlobalState.resetAllStates();
            }

            if (getState().isRunnable()) {
                // Dynamically check for the Ice King dead status

                return context.tasks().execute();
            }
            return 600;
        } catch (Exception e) {
            context.getLogger().error("Error in script loop: " + e.getMessage());
            setState(ScriptState.ERROR);
            return 1000;
        }
    }

    @Override
    protected void onScriptStop() throws InterruptedException {
        context.getLogger().info("Test script stopping...");
        if (consumablesNode != null) {
            consumablesNode.stopNode();
        }

        if (prayerFlicker != null) {
            prayerFlicker.stop();
        }

        if (locationUpdater != null && !locationUpdater.isShutdown()) {
            locationUpdater.shutdownNow();
        }

        if (inventoryListener != null) {
            inventoryListener.stop();
        }

        context.getLogger().info("Test script stopped.");
    }

    @Override
    public void onPaint(Graphics2D g) {
        try {
            if (!Client.isLoggedIn()) {
                return;
            }

            // Always render main paint if available
            if (paint != null) {
                paint.render(g);
            }

            // Always try to render debug overlay
            if (SulphurDebugOverlay != null) {
                SulphurDebugOverlay.render(g);
            }


        } catch (Exception e) {
            context.getLogger().error("Error in paint: " + e.getMessage());
        }
    }

    @Override
    public SulphurConfig getScriptConfig() {
        if (config == null) {
            config = new SulphurConfig(getContext());
        }
        return config;
    }

    @Override
    public boolean requiresGUI() {
        return true;
    }

    @Override
    protected AbstractSettingsTab getScriptTab() {
        return new SulphurSettingsTab(getContext());
    }

    private String getScriptStatus() {
        TaskNode activeNode = context.tasks().getActiveNode();
        return activeNode != null ? activeNode.getStatus() : "Idle";
    }

    private String getCombatXpStatus() {
        // This method is now replaced by the XP tracker but kept for backward compatibility
        // It will use the XP tracker if available, otherwise fall back to the old implementation
        if (paintBuilder != null && paintBuilder.getXpTracker() != null) {
            Set<Skill> activeSkills = paintBuilder.getXpTracker().getActiveSkills().stream()
                .filter(skill -> skill == Skill.ATTACK || skill == Skill.STRENGTH || 
                       skill == Skill.DEFENCE || skill == Skill.RANGED || 
                       skill == Skill.MAGIC || skill == Skill.HITPOINTS || 
                       skill == Skill.PRAYER)
                .collect(Collectors.toSet());
            
            if (!activeSkills.isEmpty()) {
                return paintBuilder.getXpTracker().getFormattedTotalXpInfo(activeSkills);
            }
        }
        
        // Fallback to old implementation
        long currentXp = Skills.getExperience(Skill.STRENGTH);
        long startXp = startXpMap.getOrDefault(Skill.STRENGTH, currentXp);
        long xpGained = currentXp - startXp;
        
        if (xpGained <= 0) {
            return "0 XP";
        }
        
        long runtime = System.currentTimeMillis() - startTime;
        long xpPerHour = (long) ((xpGained * 3600000.0) / runtime);
        
        return formatNumber(xpGained) + " (" + formatNumber(xpPerHour) + "/hr)";
    }

    private String getKillsStatus() {
        double killsPerHour = getKillsPerHour();
        return String.format("%d (%.1f/hr)", totalKills, killsPerHour);
    }

    private String getLootStatus() {
        // This method is now replaced by the profit tracker
        // We'll keep it for backward compatibility
        return formatNumber(SulphurGlobalState.getTotalLootValue());
    }

    @Override
    public void onEscapeStateChange(boolean shouldEscape) {
        if (shouldEscape) {
            Logger.log("ESCAPE STATE CHANGE DETECTED - Initiating emergency procedures!");
            if (inCombat()) {
                togglePrayers(false);
            }
            getConsumablesNode().handleConsumables(true);
        } else {
            Logger.log("Escape state cleared - resuming normal operations");
            SulphurGlobalState.resetAllStates();
        }
    }

    private boolean inCombat() {
        return Players.getLocal().isInCombat();
    }

    private void togglePrayers(boolean enable) {
        if (enable) {
            Prayers.toggleQuickPrayer(true);
        } else {
            Prayers.toggleQuickPrayer(false);
        }
    }

    public ConsumablesNode getConsumablesNode() {
        return this.consumablesNode;
    }

    private void handleItemGained(ScriptEvent event) {
        Item item = (Item) event.getAttribute("item");
        int quantity = (int) event.getAttribute("quantity");
        int itemId = item.getID();
        
        // Check if item is part of supplies/equipment
        if (isSupplyItem(itemId) || isInLoadoutEquipment(itemId) || isFoodOrPotion(itemId)) {
            return;
        }
        
        SulphurGlobalState.addLootItem(itemId, quantity);
    }
    
    private boolean isSupplyItem(int itemId) {
        // Check all supply types from config
        Map<String, Integer> supplies = config.getSupplies();
        if (supplies == null || supplies.isEmpty()) return false;
        
        return supplies.keySet().stream()
            .anyMatch(name -> {
                Item item = Inventory.get(name);
                return item != null && item.getID() == itemId;
            });
    }
    
    private boolean isFoodOrPotion(int itemId) {
        // Matches SulphurBankingNode's food check logic
        Item item = Inventory.get(itemId);
        return item != null && (item.hasAction("Eat") || item.hasAction("Drink"));
    }
    
    private boolean isInLoadoutEquipment(int itemId) {
        SulphurLoadoutData loadout = new SulphurLoadoutData();
        if (loadout == null) return false;
        
        // Check both inventory and equipment for loadout items
        return loadout.getEquipment().entrySet().stream()
            .anyMatch(entry -> {
                String slotName = entry.getKey();
                String name = entry.getValue();
                EquipmentSlot slot = getSlotForName(slotName);
                
                // Check equipped items
                if (slot != null && Equipment.getItemInSlot(slot) != null) {
                    Item equipped = Equipment.getItemInSlot(slot);
                    if (equipped != null && equipped.getID() == itemId) return true;
                }
                
                // Check inventory items
                Item invItem = Inventory.get(name);
                return invItem != null && invItem.getID() == itemId;
            });
    }

    private EquipmentSlot getSlotForName(String slotName) {
        switch (slotName.toLowerCase()) {
            case "head": return EquipmentSlot.HAT;
            case "cape": return EquipmentSlot.CAPE;
            case "neck": return EquipmentSlot.AMULET;
            case "weapon": return EquipmentSlot.WEAPON;
            case "body": return EquipmentSlot.CHEST;
            case "shield": return EquipmentSlot.SHIELD;
            case "legs": return EquipmentSlot.LEGS;
            case "hands": return EquipmentSlot.HANDS;
            case "feet": return EquipmentSlot.FEET;
            case "ring": return EquipmentSlot.RING;
            case "ammo": return EquipmentSlot.ARROWS;
            default: return null;
        }
    }

    private String formatNumber(long number) {
        return String.format("%,d", number);
    }

    /**
     * Updates XP tracking on each script loop to ensure we're always tracking XP
     * even if the event system isn't firing properly
     */
    private void updateXpTracking() {
        try {
            // Update Strength XP tracking
            Skill strengthSkill = Skill.STRENGTH;
            long currentXp = Skills.getExperience(strengthSkill);
            long startXp = startXpMap.getOrDefault(strengthSkill, 0L);
            
            // If XP has changed since last check, update the last gain time
            if (currentXp > startXp) {
                lastXpGainMap.put(strengthSkill, System.currentTimeMillis());
                context.getLogger().debug("Updated Strength XP tracking: " + (currentXp - startXp) + " XP gained");
            }
        } catch (Exception e) {
            context.getLogger().error("Error updating XP tracking: " + e.getMessage());
        }
    }
}
