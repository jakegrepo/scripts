package scripts.Sulphur.utils;

import core.base.SimpleNode;
import org.dreambot.api.Client;
import org.dreambot.api.methods.combat.Combat;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.grandexchange.LivePrices;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.item.GroundItems;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.interactive.Player;
import org.dreambot.api.wrappers.items.GroundItem;
import org.dreambot.api.wrappers.items.Item;
import scripts.Sulphur.Sulphur;
import scripts.Sulphur.SulphurConfig;
import scripts.Sulphur.SulphurGlobalState;

import static org.dreambot.api.methods.skills.Skill.HITPOINTS;
import static org.dreambot.api.methods.skills.Skill.PRAYER;

public class ConsumablesNode extends SimpleNode<SulphurConfig> implements Runnable {
    private volatile boolean stopRequested = false;
    public Area FEROX_ENCLAVE = new Area(3125, 3640, 3158, 3617);
    private long instanceEntryTime = 0;
    private static final long TELEPORT_DELAY = 5000; // 5 seconds delay
    private static final int MIN_POTIONS_REQUIRED = 6;
    private static final int MAX_POTION_DOSE = 4;
    public ConsumablesNode(SulphurConfig config) {
        super("Consumables", 2, config);
    }

    @Override
    public boolean validate() {
        return false;
    }
    @Override
    protected int onExecute() {
        // Not used since we're running in a separate thread
        return 0;
    }

    @Override
    public void run() {
        while (!stopRequested) {
            try {
                // Check if we just entered a dynamic region (instance)
                if (Client.isDynamicRegion() && instanceEntryTime == 0) {
                    instanceEntryTime = System.currentTimeMillis();
                    Logger.log("[DEBUG] Entered instance at: " + instanceEntryTime);
                } else if (!Client.isDynamicRegion()) {
                    // Reset the timer when not in an instance
                    instanceEntryTime = 0;
                }
                
                // Only allow teleport checks if we've been in the instance for at least TELEPORT_DELAY
                boolean allowTeleportChecks = instanceEntryTime > 0 && 
                                             (System.currentTimeMillis() - instanceEntryTime) > TELEPORT_DELAY;

                


                // Always handle consumables regardless of other conditions
                handleConsumables(allowTeleportChecks);
                
                Thread.sleep(100);
            } catch (Exception e) {
                Logger.log("ConsumablesNode error: " + e.getMessage());
            }
        }
    }
    private boolean shouldCombinePotions() {
        // Get count of potions that are not max dose
        int nonMaxDosePotions = Inventory.count(item ->
                item != null &&
                        item.getName().contains("Moonlight potion") &&
                        !item.getName().contains("(" + MAX_POTION_DOSE + ")"));

        // Only combine if we have at least 2 non-max dose potions
        return nonMaxDosePotions >= 2;
    }

    private int combinePotions() {
        setStatus("Combining potions to save inventory space");

        // Get all our potions
        Item[] potions = Inventory.all(item ->
                item != null && item.getName().contains("Moonlight potion")).toArray(new Item[0]);

        if (potions.length < 2) {
            return 100; // Not enough potions to combine
        }

        // First find any non-4 dose potions to combine
        for (Item sourcePotion : potions) {
            // Skip if this potion is already max dose
            if (sourcePotion.getName().contains("(" + MAX_POTION_DOSE + ")")) {
                continue;
            }

            // Find a target potion to combine with (that isn't max dose)
            for (Item targetPotion : potions) {
                // Skip if this is the same potion or it's max dose
                if (targetPotion.equals(sourcePotion) ||
                        targetPotion.getName().contains("(" + MAX_POTION_DOSE + ")")) {
                    continue;
                }

                // Use source potion on target potion
                if (sourcePotion.useOn(targetPotion)) {
                    sleepUntil(() -> !Players.getLocal().isAnimating(), 1500);
                    return 600; // Wait a bit then check again
                }
            }
        }

        return 100;
    }
    public boolean teleportToFerox() {
        try {
            Player local = Players.getLocal();
            if (local == null) return false;

            // Check both equipment and inventory for any charge level
            Item ring = findDuelingRing();
            
            if (ring != null) {
                Logger.log("Attempting teleport with " + ring.getName());
                if (ring.interact("Ferox Enclave")) {
                    if (Sleep.sleepUntil(() -> FEROX_ENCLAVE.contains(local), 8000)) {
                        Logger.log("Teleport successful using " + ring.getName());
                        return true;
                    }
                    Logger.log("Teleport initiated but didn't reach Ferox in time");
                    return false;
                }
                Logger.log("Failed to interact with " + ring.getName());
                return false;
            }

            Logger.log("No Ring of dueling available");
            return false;

        } catch (Exception e) {
            Logger.log("Teleport error: " + e.getMessage());
            return false;
        }
    }

    private Item findDuelingRing() {
        // Use the utility class to find a charged Ring of dueling
        return ChargedItemUtils.findChargedItem("Ring of dueling");
    }
    
    // Add a new method to find any charged item by slot
    private Item findChargedItemBySlot(String slotName) {
        return ChargedItemUtils.findChargedItemForSlot(slotName);
    }
    
    // Add a new method to check if we have a charged item for a slot
    private boolean hasChargedItemForSlot(String slotName) {
        return ChargedItemUtils.hasValidChargedItemForSlotInEquipment(slotName) || 
               ChargedItemUtils.hasValidChargedItemForSlotInInventory(slotName);
    }

    public void handleConsumables(boolean allowTeleportChecks) {
        handleGroundLoot();
if (Inventory.contains("Vial")){
    Inventory.dropAll("Vial");
}
if (shouldCombinePotions()){
    combinePotions();
}
        boolean inBossFight = Client.isDynamicRegion();
        
        // Add logging to diagnose teleport triggers
        boolean hasNoFood = noFood();
        int currentHp = HITPOINTS.getBoostedLevel();
        
        if (inBossFight) {
            Logger.log("[DEBUG] ConsumablesNode state: HasFood=" + !hasNoFood + 
                      ", CurrentHP=" + currentHp + 
                      ", InBossFight=" + inBossFight + 
                      ", AllowTeleportChecks=" + allowTeleportChecks);
        }

        boolean shouldEscape = (hasNoFood && currentHp <= 50 && inBossFight && allowTeleportChecks);

        // Set escape state without resetting others
        if (shouldEscape && !FEROX_ENCLAVE.contains(Players.getLocal())) {
            Logger.log("[ESCAPE] Triggering teleport to Ferox: NoFood=" + hasNoFood + 
                      ", HP=" + currentHp + 
                      ", InBossFight=" + inBossFight);
            teleportToFerox();
            return;
        }
        
        handleBossLoot();
        if (Combat.isPoisoned()) {
            handlePoison();
        }

        // Second priority: Handle antifire if needed
        if (!Combat.isSuperAntiFireEnabled() && !Combat.isAntiFireEnabled() && Players.getLocal().isInCombat()) {
            handleAntifire();
        }

        // Third priority: Handle stamina if needed
        if (!hasStaminaEffect() && Walking.getRunEnergy() <= 60 && !Bank.isOpen()) {
            handleStamina();
        }

        // Fourth priority: Eat if health is low
        if (isHealthLow() && !Bank.isOpen()) {
            eatFood();
        }
        if (Players.getLocal().isInCombat()) {
            // Fifth priority: Handle potions
            handlePotions();
        }

        // New logic: Handle boss loot if available and increment kill count once after successful loot.
        handleBossLoot();
    }

    private boolean noFood() {
        // Count food items with the "Eat" action
        int foodCount = Inventory.count(i -> i != null && !i.isNoted() && i.hasAction("Eat"));
        if (Client.isDynamicRegion()) {
            Logger.log("[DEBUG] Food count in inventory: " + foodCount);
        }
        return foodCount == 0;
    }
    private boolean isHealthLow() {
        int currentHealth = Skills.getBoostedLevel(Skill.HITPOINTS);
        int maxHp = Skills.getRealLevel(Skill.HITPOINTS);
        int hpPercent = (currentHealth * 100) / maxHp;
        return hpPercent <= 65;
    }

    private boolean isPrayerLow() {
        int currentPrayer = Skills.getBoostedLevel(PRAYER);
        int maxPrayer = Skills.getRealLevel(PRAYER);
        int prayerPercent = (currentPrayer * 100) / maxPrayer;
        return prayerPercent <= 25;
    }

    private boolean eatFood() {
        Logger.log("Attempting to eat food...");

        // First try configured food
        if (eatConfiguredFood()) {
            return true;
        }

        // If no configured food available, try looted common foods
        if (tryEatFood("Shark")) return true;
        if (tryEatFood("Monkfish")) return true;
        if (tryEatFood("Cooked karambwan")) return true;

        Logger.log("Failed to eat any food!");
        return false;
    }

    private boolean eatConfiguredFood() {
        if (!config.getFoodNames().isEmpty()) {
            String foodName = config.getFoodNames().get(0);
            return tryEatFood(foodName);
        }
        return false;
    }

    private boolean tryEatFood(String foodName) {
        Item food = Inventory.get(foodName);
        if (food != null && food.hasAction("Eat")) {
            status("Eating " + foodName);
            int initialCount = Inventory.count(foodName);
            if (food.interact("Eat")) {
                return sleepUntil(() -> Inventory.count(foodName) < initialCount, 1200);
            }
        }
        return false;
    }

    private boolean shouldBoost(Skill skill) {
        int currentLevel = Skills.getBoostedLevel(skill);
        int baseLevel = Skills.getRealLevel(skill);
        int boostThreshold = 5;
        return currentLevel <= baseLevel + boostThreshold;
    }

    private void handlePotions() {
        // Combat boosting potions
        if (shouldBoost(Skill.ATTACK) || shouldBoost(Skill.STRENGTH)) {
            if (drinkPotion("Moonlight potion")) return;
            if (shouldBoost(Skill.ATTACK) && drinkPotion("Moonlight potion")) return;
            if (shouldBoost(Skill.STRENGTH) && drinkPotion("Moonlight potion")) return;
        }

        // Ranging potion
        if (shouldBoost(Skill.RANGED) && drinkPotion("Ranging potion")) return;

        // Prayer restore
        if (isPrayerLow()) {
            if (drinkPotion("Moonlight potion")) return;
            drinkPotion("Moonlight potion");
        }
    }

    private boolean drinkPotion(String baseName) {
        for (int dose = 1; dose <= 4; dose++) {
            String potionName = baseName + "(" + dose + ")";
            Item potion = Inventory.get(potionName);
            if (potion != null && potion.hasAction("Drink")) {
                status("Drinking " + potionName);
                if (potion.interact("Drink")) {
                    sleepUntil(() -> !Inventory.contains(potionName), 1200);
                    return true;
                }
            }
        }
        return false;
    }

    private boolean handlePoison() {
        // Try antidote++ first (best option)
        if (drinkAntiPoison("Antidote++")) return true;

        // Then try regular antidote
        if (drinkAntiPoison("Antidote+")) return true;

        // Finally try super antipoison
        if (drinkAntiPoison("Superantipoison")) return true;

        return false;
    }

    private boolean drinkAntiPoison(String baseName) {
        for (int dose = 1; dose <= 4; dose++) {
            String potionName = baseName + "(" + dose + ")";
            Item potion = Inventory.get(potionName);
            if (potion != null && potion.hasAction("Drink")) {
                status("Drinking " + potionName + " to cure poison");
                if (potion.interact("Drink")) {
                    return sleepUntil(() -> !Combat.isPoisoned(), 1200);
                }
            }
        }
        return false;
    }

    private boolean handleAntifire() {
        // Try extended super antifire first (best option)
        if (drinkAntifire("Extended super antifire")) return true;

        // Then try super antifireb
        if (drinkAntifire("Super antifire")) return true;

        // Then try extended antifire
        if (drinkAntifire("Extended antifire")) return true;

        // Finally try regular antifire
        if (drinkAntifire("Antifire potion")) return true;

        return false;
    }

    private boolean drinkAntifire(String baseName) {
        for (int dose = 1; dose <= 4; dose++) {
            String potionName = baseName + "(" + dose + ")";
            Item potion = Inventory.get(potionName);
            if (potion != null && potion.hasAction("Drink")) {
                status("Drinking " + potionName + " for antifire protection");
                if (potion.interact("Drink")) {
                    return sleepUntil(Combat::isAntiFireEnabled, 1200);
                }
            }
        }
        return false;
    }

    private boolean hasStaminaEffect() {
        return Walking.getRunEnergy() > 50 && Walking.isStaminaActive();
    }

    private boolean handleStamina() {
        // Only drink stamina if run energy is below 50%
        if (Walking.getRunEnergy() <= 50) {
            return drinkStamina("Stamina potion");
        }
        return false;
    }

    private boolean drinkStamina(String baseName) {
        for (int dose = 1; dose <= 4; dose++) {
            String potionName = baseName + "(" + dose + ")";
            Item potion = Inventory.get(potionName);
            if (potion != null && potion.hasAction("Drink")) {
                status("Drinking " + potionName + " for stamina boost");
                if (potion.interact("Drink")) {
                    return sleepUntil(Walking::isStaminaActive, 1200);
                }
            }
        }
        return false;
    }

    /**
     * Updated boss loot handling:
     * If NPCs with IDs 14148 and 14149 both exist and both have the "Loot" action,
     * this method will loot the one that is closest to the player and increment the kill counter.
     */
    private void handleBossLoot() {
        // Retrieve NPCs with IDs 14148 and 14149 that have the "Loot" action.
        NPC npc14148 = NPCs.closest(n -> n.getID() == 14148 && n.hasAction("Loot"));
        NPC npc14149 = NPCs.closest(n -> n.getID() == 14149 && n.hasAction("Loot"));

        // Only proceed if both exist.
        if (npc14148 != null && npc14149 != null) {
            // Determine the closest NPC to the player.
            NPC closest = (npc14148.distance() <= npc14149.distance()) ? npc14148 : npc14149;
            if (closest.interact("Loot")) {
                Sleep.sleepUntil(() -> !closest.exists(), 22000);
                Sulphur.incrementTotalKills(); // Increment the kill count that appears in the overlay.
            }
        }
    }

    private boolean handleGroundLoot() {
        GroundItem loot = GroundItems.closest(item -> {
            if (item == null || !item.exists()) return false;
            
            // Always loot our specific boss drops
            int id = item.getID();
            if (id == 30628 || id == 30631) return true;
            
            // In boss area, loot items worth 5k+ 
            if (Client.isDynamicRegion()) {
                int value = getItemValue(item);
                return value >= 5000;
            }
            return false;
        });
        
        if (loot == null || !loot.exists()) {
            return false;
        }

        // If inventory is full, try to eat food
        if (Inventory.isFull()) {
            Item food = Inventory.get(i -> i != null && !i.isNoted() && i.hasAction("Eat"));
            if (food != null && food.interact("Eat")) {
                Sleep.sleepUntil(() -> !Inventory.isFull(), 1200);
                return true;
            }
        }

        // Check if we need to walk to the loot
        if (loot.distance() > 2) {
            Logger.log("[LOOT] Walking to loot: " + loot.getName());
            if (Walking.walk(loot.getTile())) {
                Sleep.sleepUntil(() -> loot.distance() <= 2, 5000);
                return true;
            }
        }

        // Try to take the loot
        if (loot.interact("Take")) {
            Logger.log("[LOOT] Picking up: " + loot.getName());
            Sleep.sleepUntil(() -> !loot.exists(), 1200);
            return true;
        }

        return false;
    }

    private int getItemValue(GroundItem item) {
        if (item == null) return 0;
        try {
            // Get average price from LivePrices API
            return LivePrices.get(item.getItem());
        } catch (Exception e) {
            Logger.error("Error getting item value: " + e.getMessage());
            return 0;
        }
    }

    public void stopNode() {
        stopRequested = true;
    }

    // Add a helper method to determine if the player is at the boss entrance.
    // The boss entrance area is defined using the coordinates from NetworkManager ("2947,9572,2951,9576").
    private boolean isAtBossEntrance() {
        Player local = Players.getLocal();
        if (local == null) return false;
        int x = local.getX();
        int y = local.getY();
        return x >= 2947 && x <= 2951 && y >= 9572 && y <= 9576;
    }
} 