package scripts.Sulphur.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.dreambot.api.utilities.Logger;
import scripts.Sulphur.data.ProfileData;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ProfileFileManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /**
     * Gets the path to the script's main directory.
     */
    public static String getScriptDirectory() {
        String userProfile = System.getenv("USERPROFILE");
        if (userProfile == null) {
            userProfile = System.getProperty("user.home");
        }
        return userProfile
                + File.separator + "DreamBot"
                + File.separator + "Scripts"
                + File.separator + "ScarSulphurs";
    }

    /**
     * Returns the "profiles" folder under the script directory.
     */
    public static File getProfilesDirectory() {
        File profilesDir = new File(getScriptDirectory(), "profiles");
        if (!profilesDir.exists()) {
            boolean created = profilesDir.mkdirs();
            if (created) {
                Logger.log("Created profiles directory at " + profilesDir.getAbsolutePath());
            } else {
                Logger.log("Failed to create profiles directory at " + profilesDir.getAbsolutePath());
            }
        }
        return profilesDir;
    }

    /**
     * Saves a profile to a JSON file with the given name.
     */
    public static void saveProfile(String profileName, ProfileData data) {
        // Ensure the profile has the same name as the file
        data.setName(profileName);

        File outFile = new File(getProfilesDirectory(), profileName + ".json");
        try (Writer writer = new FileWriter(outFile)) {
            GSON.toJson(data, writer);
            Logger.log("Successfully saved profile: " + outFile.getAbsolutePath());
        } catch (IOException e) {
            Logger.log("Error saving profile: " + e.getMessage());
            throw new RuntimeException("Failed to save profile", e);
        }
    }

    /**
     * Loads a profile from the specified JSON file.
     */
    public static ProfileData loadProfile(File file) {
        if (!file.exists()) {
            Logger.log("Profile file doesn't exist: " + file.getAbsolutePath());
            return null;
        }
        try (Reader reader = new FileReader(file)) {
            ProfileData data = GSON.fromJson(reader, ProfileData.class);
            Logger.log("Loaded profile from file: " + file.getAbsolutePath());
            return data;
        } catch (IOException e) {
            Logger.log("Error loading profile: " + e.getMessage());
            return null;
        }
    }

    /**
     * Returns a list of available profile names by scanning the profiles folder.
     */
    public static List<String> getAvailableProfiles() {
        File dir = getProfilesDirectory();
        List<String> profiles = new ArrayList<>();

        File[] jsonFiles = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".json"));
        if (jsonFiles == null) {
            Logger.log("No profiles folder or no .json files found.");
            return profiles;
        }
        for (File file : jsonFiles) {
            String fileName = file.getName();
            String profileName = fileName.substring(0, fileName.lastIndexOf('.'));
            profiles.add(profileName);
        }
        return profiles;
    }

    /**
     * Loads all profile files and returns them as a List.
     */
    public static List<ProfileData> loadAllProfiles() {
        List<ProfileData> allProfiles = new ArrayList<>();
        File dir = getProfilesDirectory();

        File[] jsonFiles = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".json"));
        if (jsonFiles == null) {
            return allProfiles;
        }

        for (File file : jsonFiles) {
            ProfileData data = loadProfile(file);
            if (data != null) {
                allProfiles.add(data);
            }
        }
        return allProfiles;
    }

    /**
     * Deletes a profile file.
     */
    public static boolean deleteProfile(String profileName) {
        File file = new File(getProfilesDirectory(), profileName + ".json");
        if (file.exists()) {
            boolean deleted = file.delete();
            if (deleted) {
                Logger.log("Successfully deleted profile: " + profileName);
            } else {
                Logger.log("Failed to delete profile: " + profileName);
            }
            return deleted;
        }
        return false;
    }
}