package scripts.Sulphur.utils;

import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.utilities.Logger;

public class SupplyManager {
    public static final int MIN_VIALS_REQUIRED = 6;
    private static final int MIN_GRUBS_REQUIRED = 6;
    private static final int MIN_POTIONS_REQUIRED = 5;
    private static boolean supplyGatheringComplete = false;
    
    // Define the training area (same as in CombatNode)
    private static final Area TRAINING_AREA = new Area(1343, 9597, 1392, 9536);
    // Define an area slightly larger than the training area to include nearby regions
    private static final Area NEAR_TRAINING_AREA = new Area(1338, 9602, 1397, 9531);
    
    /**
     * Checks if the player is in or near the training area
     * @return true if the player is in or near the training area
     */
    public static boolean isInTrainingArea() {
        return TRAINING_AREA.contains(Players.getLocal());
    }
    
    /**
     * Checks if the player is near the training area (includes a slightly larger area)
     * @return true if the player is near the training area
     */
    public static boolean isNearTrainingArea() {
        return NEAR_TRAINING_AREA.contains(Players.getLocal());
    }
    
    /**
     * Checks if the player needs to gather supplies for the Sulphur script
     * @return true if supplies need to be gathered
     */
    public static boolean needsSupplyGathering() {
        // If we're not near the training area, don't gather supplies
        if (!isNearTrainingArea()) {
            return false;
        }
        
        // If we're below potion requirements, reset completion state
        if (!hasSufficientPotionSupplies()) {
            supplyGatheringComplete = false;
        }

        int vialCount = Inventory.count("Vial of water");
        int grubCount = Inventory.count("Moonlight grub");
        int grubPasteCount = Inventory.count("Moonlight grub paste");
        int potionCount = Inventory.count(item -> 
            item != null && item.getName().contains("Moonlight potion"));
        
        // Check if we have enough potions
        if (potionCount >= MIN_POTIONS_REQUIRED) {
            supplyGatheringComplete = true;
            return false;
        }
        
        // Check if we have enough materials to make potions
        boolean hasEnoughMaterials = (vialCount >= MIN_VIALS_REQUIRED) && 
                                    (grubCount + grubPasteCount >= MIN_GRUBS_REQUIRED);
        
        if (hasEnoughMaterials) {
            supplyGatheringComplete = true;
        }

        // Return true if we need more supplies
        return !supplyGatheringComplete;
    }
    
    /**
     * Checks if the player has sufficient supplies to make potions
     * @return true if the player has enough supplies
     */
    public static boolean hasSufficientPotionSupplies() {
        // If we're not near the training area, don't check supplies
        if (!isNearTrainingArea()) {
            return false;
        }
        
        int vialCount = Inventory.count("Vial of water");
        int grubCount = Inventory.count("Moonlight grub");
        int grubPasteCount = Inventory.count("Moonlight grub paste");
        int potionCount = Inventory.count(item -> 
            item != null && item.getName().contains("Moonlight potion"));
        
        // If we already have enough potions, we're good
        if (potionCount >= MIN_POTIONS_REQUIRED) {
            return true;
        }
        
        // Check if we have enough materials to make the remaining potions
        int potionsNeeded = MIN_POTIONS_REQUIRED - potionCount;
        int materialsAvailable = Math.min(vialCount, grubCount + grubPasteCount);
        
        return materialsAvailable >= potionsNeeded;
    }
    
    /**
     * Checks if the player has enough potions for combat
     * @return true if the player has enough potions
     */
    public static boolean hasEnoughPotionsForCombat() {
        // If we're not near the training area, don't check potions
        if (!isNearTrainingArea()) {
            return false;
        }
        
        int potionCount = Inventory.count(item -> 
            item != null && item.getName().contains("Moonlight potion"));
        
        return potionCount >= 1;
    }

    /**
     * Checks if supply gathering is complete
     * @return true if supply gathering is complete
     */
    public static boolean isSupplyGatheringComplete() {
        return supplyGatheringComplete;
    }

    /**
     * Resets the supply gathering state
     */
    public static void resetSupplyGatheringState() {
        supplyGatheringComplete = false;
        Logger.log("[SUPPLY] Supply gathering state reset");
    }
}
