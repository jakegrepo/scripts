package scripts.Sulphur.utils;

import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.container.impl.equipment.EquipmentSlot;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.items.Item;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Utility class for handling items with charges, such as jewelry.
 */
public class ChargedItemUtils {

    // Map of base item names to their minimum required charge
    private static final Map<String, Integer> CHARGED_ITEMS = new HashMap<>();
    
    // Map of equipment slots to the charged items that can be equipped in that slot
    private static final Map<String, String[]> SLOT_CHARGED_ITEMS = new HashMap<>();
    
    // Pattern to extract charge number from item name
    private static final Pattern CHARGE_PATTERN = Pattern.compile("\\((\\d+)\\)$");
    
    static {
        // Initialize with known charged items and their minimum required charge
        CHARGED_ITEMS.put("Ring of dueling", 2);      // Charges 2-8 are valid
        CHARGED_ITEMS.put("Games necklace", 2);       // Charges 2-8 are valid
        CHARGED_ITEMS.put("Ring of wealth", 2);       // Charges 2-5 are valid
        CHARGED_ITEMS.put("Amulet of glory", 2);      // Charges 2-6 are valid
        CHARGED_ITEMS.put("Skills necklace", 2);      // Charges 2-6 are valid
        CHARGED_ITEMS.put("Combat bracelet", 2);      // Charges 2-6 are valid
        CHARGED_ITEMS.put("Necklace of passage", 2);  // Charges 2-5 are valid
        CHARGED_ITEMS.put("Digsite pendant", 2);      // Charges 2-5 are valid
        CHARGED_ITEMS.put("Xeric's talisman", 2);     // Charges 2-100 are valid
        CHARGED_ITEMS.put("Slayer ring", 2);          // Charges 2-8 are valid
        
        // Initialize equipment slots with their corresponding charged items
        SLOT_CHARGED_ITEMS.put("ring", new String[]{"Ring of dueling", "Ring of wealth"});
        SLOT_CHARGED_ITEMS.put("necklace", new String[]{"Amulet of glory", "Games necklace", "Skills necklace", "Necklace of passage", "Digsite pendant"});
    }
    
    /**
     * Checks if an item is a charged item that we handle specially
     * @param itemName The item name to check
     * @return True if this is a charged item we handle specially
     */
    public static boolean isChargedItem(String itemName) {
        if (itemName == null) return false;
        
        return CHARGED_ITEMS.keySet().stream()
            .anyMatch(itemName::startsWith);
    }
    
    /**
     * Checks if an equipment slot can contain charged items
     * @param slotName The equipment slot name (e.g., "ring", "necklace", "gloves")
     * @return True if the slot can contain charged items
     */
    public static boolean isChargedItemSlot(String slotName) {
        if (slotName == null) return false;
        return SLOT_CHARGED_ITEMS.containsKey(slotName.toLowerCase());
    }
    
    /**
     * Gets all charged items that can be equipped in the specified slot
     * @param slotName The equipment slot name (e.g., "ring", "necklace", "gloves")
     * @return Array of base item names for charged items in this slot, or empty array if none
     */
    public static String[] getChargedItemsForSlot(String slotName) {
        if (slotName == null) return new String[0];
        return SLOT_CHARGED_ITEMS.getOrDefault(slotName.toLowerCase(), new String[0]);
    }
    
    /**
     * Creates a predicate to check if an item is a valid charged version of the specified base item
     * @param baseItemName The base name of the item (e.g., "Ring of dueling")
     * @return A predicate that checks if an item is a valid charged version
     */
    public static Predicate<Item> hasValidCharges(String baseItemName) {
        if (!CHARGED_ITEMS.containsKey(baseItemName)) {
            return item -> false;
        }
        
        int minCharge = CHARGED_ITEMS.get(baseItemName);
        
        return item -> {
            if (item == null || item.getName() == null) return false;
            
            // Check if it starts with the base name and has a charge pattern
            if (item.getName().startsWith(baseItemName + "(")) {
                // Extract the charge number using regex
                Matcher matcher = CHARGE_PATTERN.matcher(item.getName());
                if (matcher.find()) {
                    try {
                        int charge = Integer.parseInt(matcher.group(1));
                        return charge >= minCharge;
                    } catch (NumberFormatException e) {
                        return false;
                    }
                }
            }
            
            return false;
        };
    }
    
    /**
     * Creates a predicate to check if an item is a valid charged version of any item for the specified slot
     * @param slotName The equipment slot name (e.g., "ring", "necklace", "gloves")
     * @return A predicate that checks if an item is a valid charged version for the slot
     */
    public static Predicate<Item> hasValidChargesForSlot(String slotName) {
        String[] baseItems = getChargedItemsForSlot(slotName);
        
        return item -> {
            if (item == null || item.getName() == null) return false;
            
            for (String baseItem : baseItems) {
                if (hasValidCharges(baseItem).test(item)) {
                    return true;
                }
            }
            
            return false;
        };
    }
    
    /**
     * Checks if the player has a valid charged version of the specified item in equipment
     * @param baseItemName The base name of the item (e.g., "Ring of dueling")
     * @return True if a valid charged version is found in equipment
     */
    public static boolean hasValidChargedItemInEquipment(String baseItemName) {
        return Equipment.contains(i -> hasValidCharges(baseItemName).test(i));
    }
    
    /**
     * Checks if the player has any valid charged item for the specified slot in equipment
     * @param slotName The equipment slot name (e.g., "ring", "necklace", "gloves")
     * @return True if a valid charged item for the slot is found in equipment
     */
    public static boolean hasValidChargedItemForSlotInEquipment(String slotName) {
        return Equipment.contains(i -> hasValidChargesForSlot(slotName).test(i));
    }
    
    /**
     * Checks if the player has a valid charged version of the specified item in inventory
     * @param baseItemName The base name of the item (e.g., "Ring of dueling")
     * @return True if a valid charged version is found in inventory
     */
    public static boolean hasValidChargedItemInInventory(String baseItemName) {
        return Inventory.contains(i -> hasValidCharges(baseItemName).test(i));
    }
    
    /**
     * Checks if the player has any valid charged item for the specified slot in inventory
     * @param slotName The equipment slot name (e.g., "ring", "necklace", "gloves")
     * @return True if a valid charged item for the slot is found in inventory
     */
    public static boolean hasValidChargedItemForSlotInInventory(String slotName) {
        return Inventory.contains(i -> hasValidChargesForSlot(slotName).test(i));
    }
    
    /**
     * Checks if the player has a valid charged version of the specified item in bank
     * @param baseItemName The base name of the item (e.g., "Ring of dueling")
     * @return True if a valid charged version is found in bank
     */
    public static boolean hasValidChargedItemInBank(String baseItemName) {
        return Bank.contains(i -> hasValidCharges(baseItemName).test(i));
    }
    
    /**
     * Checks if the player has any valid charged item for the specified slot in bank
     * @param slotName The equipment slot name (e.g., "ring", "necklace", "gloves")
     * @return True if a valid charged item for the slot is found in bank
     */
    public static boolean hasValidChargedItemForSlotInBank(String slotName) {
        return Bank.contains(i -> hasValidChargesForSlot(slotName).test(i));
    }
    
    /**
     * Checks if the player has a valid charged version of the specified item anywhere
     * (equipment, inventory, or bank)
     * @param baseItemName The base name of the item (e.g., "Ring of dueling")
     * @return True if a valid charged version is found anywhere
     */
    public static boolean hasValidChargedItemAnywhere(String baseItemName) {
        return hasValidChargedItemInEquipment(baseItemName) ||
               hasValidChargedItemInInventory(baseItemName) ||
               hasValidChargedItemInBank(baseItemName);
    }
    
    /**
     * Checks if the player has any valid charged item for the specified slot anywhere
     * (equipment, inventory, or bank)
     * @param slotName The equipment slot name (e.g., "ring", "necklace", "gloves")
     * @return True if a valid charged item for the slot is found anywhere
     */
    public static boolean hasValidChargedItemForSlotAnywhere(String slotName) {
        return hasValidChargedItemForSlotInEquipment(slotName) ||
               hasValidChargedItemForSlotInInventory(slotName) ||
               hasValidChargedItemForSlotInBank(slotName);
    }
    
    /**
     * Finds a valid charged item in equipment or inventory
     * @param baseItemName The base name of the item (e.g., "Ring of dueling")
     * @return The item if found, null otherwise
     */
    public static Item findChargedItem(String baseItemName) {
        // Check equipment first
        Item equipped = Stream.of(EquipmentSlot.values())
            .map(Equipment::getItemInSlot)
            .filter(i -> i != null && hasValidCharges(baseItemName).test(i))
            .findFirst()
            .orElse(null);

        if (equipped != null) return equipped;
        
        // Check inventory - using item -> filter instead of direct predicate
        return Inventory.get(i -> hasValidCharges(baseItemName).test(i));
    }
    
    /**
     * Finds any valid charged item for the specified slot in equipment or inventory
     * @param slotName The equipment slot name (e.g., "ring", "necklace", "gloves")
     * @return The item if found, null otherwise
     */
    public static Item findChargedItemForSlot(String slotName) {
        // Check equipment first
        Item equipped = Stream.of(EquipmentSlot.values())
            .map(Equipment::getItemInSlot)
            .filter(i -> i != null && hasValidChargesForSlot(slotName).test(i))
            .findFirst()
            .orElse(null);

        if (equipped != null) return equipped;
        
        // Check inventory - using item -> filter instead of direct predicate
        return Inventory.get(i -> hasValidChargesForSlot(slotName).test(i));
    }
    
    /**
     * Counts the number of valid charged items in bank
     * @param baseItemName The base name of the item (e.g., "Ring of dueling")
     * @return The count of valid charged items in bank
     */
    public static int countValidChargedItemsInBank(String baseItemName) {
        // Using item -> filter instead of direct predicate
        return Bank.count(i -> hasValidCharges(baseItemName).test(i));
    }
    
    /**
     * Counts the number of valid charged items for the specified slot in bank
     * @param slotName The equipment slot name (e.g., "ring", "necklace", "gloves")
     * @return The count of valid charged items for the slot in bank
     */
    public static int countValidChargedItemsForSlotInBank(String slotName) {
        int count = 0;
        for (String baseItem : getChargedItemsForSlot(slotName)) {
            count += countValidChargedItemsInBank(baseItem);
        }
        return count;
    }
    
    /**
     * Gets the fully charged version name for a base item
     * @param baseItemName The base name of the item (e.g., "Ring of dueling")
     * @return The fully charged version name (e.g., "Ring of dueling(8)")
     */
    public static String getFullyChargedName(String baseItemName) {
        switch (baseItemName) {
            case "Ring of dueling":
                return "Ring of dueling(8)";
            case "Games necklace":
                return "Games necklace(8)";
            case "Ring of wealth":
                return "Ring of wealth(5)";
            case "Amulet of glory":
                return "Amulet of glory(6)";
            case "Skills necklace":
                return "Skills necklace(6)";
            case "Combat bracelet":
                return "Combat bracelet(6)";
            case "Necklace of passage":
                return "Necklace of passage(5)";
            case "Digsite pendant":
                return "Digsite pendant(5)";
            case "Xeric's talisman":
                return "Xeric's talisman(100)";
            case "Slayer ring":
                return "Slayer ring(8)";
            default:
                return baseItemName;
        }
    }
    
    /**
     * Checks if an item in a loadout is a charged item and should be handled specially
     * @param slotName The equipment slot name (e.g., "ring", "necklace", "gloves")
     * @param itemName The item name from the loadout
     * @return True if this is a charged item that should be handled specially
     */
    public static boolean isChargedItemInLoadout(String slotName, String itemName) {
        if (itemName == null || slotName == null) return false;
        
        // First check if the slot can contain charged items
        if (!isChargedItemSlot(slotName.toLowerCase())) {
            return false;
        }
        
        // Then check if the item is a charged item
        return isChargedItem(itemName);
    }
    
    /**
     * Validates if a player has the required charged item for a loadout slot
     * @param slotName The equipment slot name (e.g., "ring", "necklace", "gloves")
     * @param requiredItem The item name from the loadout
     * @return True if the player has a valid charged item for this slot
     */
    public static boolean validateChargedItemForLoadout(String slotName, String requiredItem) {
        if (!isChargedItemInLoadout(slotName, requiredItem)) {
            return false; // Not a charged item, use normal validation
        }
        
        // Extract the base item name (without charges)
        String baseItemName = requiredItem.split("\\(")[0].trim();
        
        // Check if the player has this charged item anywhere
        return hasValidChargedItemAnywhere(baseItemName);
    }
    
    /**
     * Logs information about all charged items the player has
     */
    public static void logChargedItemStatus() {
        Logger.log("=== Charged Item Status ===");
        for (String baseItem : CHARGED_ITEMS.keySet()) {
            boolean inEquipment = hasValidChargedItemInEquipment(baseItem);
            boolean inInventory = hasValidChargedItemInInventory(baseItem);
            boolean inBank = hasValidChargedItemInBank(baseItem);
            
            Logger.log(baseItem + ": " + 
                      (inEquipment ? "Equipped" : 
                       inInventory ? "In Inventory" : 
                       inBank ? "In Bank" : "Not Found"));
        }
        Logger.log("=========================");
    }
} 