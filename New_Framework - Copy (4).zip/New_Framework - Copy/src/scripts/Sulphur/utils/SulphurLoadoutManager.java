package scripts.Sulphur.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.dreambot.api.utilities.Logger;
import scripts.Sulphur.data.SulphurLoadoutData;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class SulphurLoadoutManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /**
     * Gets the path to the script's main directory.
     */
    public static String getScriptDirectory() {
        String userProfile = System.getenv("USERPROFILE");
        if (userProfile == null) {
            userProfile = System.getProperty("user.home");
        }
        return userProfile
                + File.separator + "DreamBot"
                + File.separator + "Scripts"
                + File.separator + "ScarSulphurs";
    }

    /**
     * Returns the "loadouts" folder under the script directory.
     */
    public static File getLoadoutsDirectory() {
        File loadoutsDir = new File(getScriptDirectory(), "loadouts");
        if (!loadoutsDir.exists()) {
            boolean created = loadoutsDir.mkdirs();
            if (created) {
                Logger.log("Created loadouts directory at " + loadoutsDir.getAbsolutePath());
            } else {
                Logger.log("Failed to create loadouts directory at " + loadoutsDir.getAbsolutePath());
            }
        }
        return loadoutsDir;
    }

    /**
     * Saves a single loadout to a JSON file with the given name.
     */
    public static void saveLoadout(String loadoutName, SulphurLoadoutData data) {
        // Ensure the loadout has the same name as the file
        data.setName(loadoutName);

        File outFile = new File(getLoadoutsDirectory(), loadoutName + ".json");
        try (Writer writer = new FileWriter(outFile)) {
            GSON.toJson(data, writer);
            Logger.log("Successfully saved loadout: " + outFile.getAbsolutePath());
        } catch (IOException e) {
            Logger.log("Error saving loadout: " + e.getMessage());
        }
    }

    /**
     * Loads a single loadout from the specified JSON file.
     */
    public static SulphurLoadoutData loadLoadout(File file) {
        if (!file.exists()) {
            return null;
        }
        try (Reader reader = new FileReader(file)) {
            SulphurLoadoutData data = GSON.fromJson(reader, SulphurLoadoutData.class);
            
            // For backward compatibility: if combat style is not set, try to determine it from the name
            if (data != null && (data.getCombatStyle() == null || data.getCombatStyle().isEmpty())) {
                String name = data.getName().toLowerCase();
                if (name.contains("melee")) {
                    data.setCombatStyle("Melee");
                } else if (name.contains("range")) {
                    data.setCombatStyle("Range");
                } else if (name.contains("magic")) {
                    data.setCombatStyle("Magic");
                }
            }
            
            return data;
        } catch (IOException e) {
            Logger.log("Error loading loadout: " + e.getMessage());
            return null;
        }
    }

    /**
     * Returns a list of available loadout names by scanning the loadouts folder.
     */
    public static List<String> getAvailableLoadouts() {
        File dir = getLoadoutsDirectory();
        List<String> loadouts = new ArrayList<>();

        File[] jsonFiles = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".json"));
        if (jsonFiles == null) {
            Logger.log("No loadouts folder or no .json files found.");
            return loadouts;
        }
        for (File file : jsonFiles) {
            String fileName = file.getName();
            String loadoutName = fileName.substring(0, fileName.lastIndexOf('.'));
            loadouts.add(loadoutName);
        }
        return loadouts;
    }

    /**
     * Loads all loadout files and returns them as a List.
     */
    public static List<SulphurLoadoutData> loadAllLoadouts() {
        List<SulphurLoadoutData> allLoadouts = new ArrayList<>();
        File dir = getLoadoutsDirectory();

        File[] jsonFiles = dir.listFiles((d, name) -> name.toLowerCase().endsWith(".json"));
        if (jsonFiles == null) {
            return allLoadouts;
        }

        for (File file : jsonFiles) {
            SulphurLoadoutData data = loadLoadout(file);
            if (data != null) {
                allLoadouts.add(data);
            }
        }
        return allLoadouts;
    }

    /**
     * Deletes a loadout file.
     */
    public static boolean deleteLoadout(String loadoutName) {
        File file = new File(getLoadoutsDirectory(), loadoutName + ".json");
        if (file.exists()) {
            boolean deleted = file.delete();
            if (deleted) {
                Logger.log("Successfully deleted loadout: " + loadoutName);
            } else {
                Logger.log("Failed to delete loadout: " + loadoutName);
            }
            return deleted;
        }
        return false;
    }
}