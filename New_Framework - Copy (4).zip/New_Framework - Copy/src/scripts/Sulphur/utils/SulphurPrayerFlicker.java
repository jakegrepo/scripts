package scripts.Sulphur.utils;

import core.context.ScriptContext;
import org.dreambot.api.Client;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.prayer.Prayer;
import org.dreambot.api.methods.prayer.Prayers;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.widgets.WidgetChild;
import scripts.Sulphur.SulphurGlobalState;

public class SulphurPrayerFlicker implements GameTickListener {
    private int lastGameTick;
    private int gameTick;
    public boolean prayerFlickingRunning = false;
    private Thread prayerThread;
    private boolean shouldFlickPrayer = false;
    private Prayer currentPrayer = null;
    private final ScriptContext context;
    private static final int SULHPUR_NPC_ID       = 13033; // Branda the Fire Queen
    Area herbloreArea = new Area(1347, 9583, 1352, 9577);
    public SulphurPrayerFlicker(ScriptContext context) {
        this.lastGameTick = Client.getGameTick();
        Logger.log("Initializing CorpPrayerFlicker");
        this.context = context;
        Client.getInstance().getScriptManager().addListener(this);
        Logger.log("CorpPrayerFlicker initialized successfully");
    }

    @Override
    public void onServerTick() {
        NPC sulphurNPC = NPCs.closest(SULHPUR_NPC_ID);

        gameTick++;
        try {
            shouldFlickPrayer = sulphurNPC != null && !herbloreArea.contains(Players.getLocal());

            if (sulphurNPC == null) {
                shouldFlickPrayer = false;
            }
        } catch (Exception e) {
        }
    }

    public void startPrayerFlick() {
        if (!prayerFlickingRunning) {
            prayerFlickingRunning = true;
            context.getScript().getScriptManager().addListener(this);
            Thread prayerFlickingThread = new Thread(() -> {
                try {
                    while (prayerFlickingRunning && !Thread.currentThread().isInterrupted()) {
                        if (!SulphurGlobalState.isPartyReady() && SulphurGlobalState.isDuoMode()) {
                            Sleep.sleep(100);
                            continue;
                        }
                        if (shouldFlickPrayer && Skills.getBoostedLevel(Skill.PRAYER) > 0) {
                            handlePrayerFlicking();
                        }
                        Sleep.sleep(100); // Small delay to prevent excessive CPU usage
                    }
                } catch (Exception e) {
                    Logger.error("Prayer flicking thread error: " + e.getMessage());
                } finally {
                    prayerFlickingRunning = false;
                }
            });
            prayerFlickingThread.setDaemon(true);
            prayerFlickingThread.start();
        }
    }

    private void handlePrayerFlicking() {
        int currentGameTick = gameTick;
        if (currentGameTick != lastGameTick) {
            lastGameTick = currentGameTick;
            if (Skills.getBoostedLevel(Skill.PRAYER) > 0) {
                Prayer prayerToUse = Prayer.PROTECT_FROM_MELEE;

                // Toggle prayer on
                togglePrayerWidget(prayerToUse, true);

                // Wait until next game tick using Client's tick
                Sleep.sleepUntil(() -> gameTick != currentGameTick, 600);

                // Toggle prayer off at the start of next tick if we're still running
                togglePrayerWidget(prayerToUse, false);
            }
        }
    }

    private boolean togglePrayerWidget(Prayer prayer, boolean activate) {
        int child = getWidgetChildForPrayer(prayer);
        if (child == -1) {
            return false;
        }

        WidgetChild wc = Widgets.get(160, child);
        if (wc == null) {
            return false;
        }

        String action = activate ? "Activate" : "Deactivate";
        return wc.interact(action);
    }

    private int getWidgetChildForPrayer(Prayer prayer) {
        switch (prayer) {
            case PROTECT_FROM_MAGIC:
                return 21;
            case PROTECT_FROM_MISSILES:
                return 22;
            case PROTECT_FROM_MELEE:
                return 19;
            default:
                return -1;
        }
    }

    public void stop() {
        if (prayerFlickingRunning) {
            context.getScript().getScriptManager().removeListener(this);
            prayerFlickingRunning = false;
            shouldFlickPrayer = false;


            // Also turn off quick prayers if they're on
            if (Prayers.isQuickPrayerActive()) {
                Prayers.toggleQuickPrayer(false);
            }

            currentPrayer = null;
            Logger.log("Prayer flicker stopped and all protection prayers forcefully deactivated");
        }
    }

}