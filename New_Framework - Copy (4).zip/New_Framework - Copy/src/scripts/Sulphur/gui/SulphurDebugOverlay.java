package scripts.Sulphur.gui;

import core.context.ScriptContext;
import org.dreambot.api.methods.interactive.GraphicsObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.wrappers.graphics.GraphicsObject;
import org.dreambot.api.wrappers.interactive.NPC;

import java.awt.*;
import java.util.List;

/**
 * Enhanced debug overlay for the Sulphur script with improved visual design
 * and better information display for combat encounters
 */
public class SulphurDebugOverlay {
    private final ScriptContext context;
    private boolean enabled = true;
    private boolean showHealthBars = true;
    private boolean showDamageNumbers = false;

    // Enhanced color palette for entity highlighting
    private static final Color FIRE_QUEEN_COLOR = new Color(255, 80, 80, 140);
    private static final Color ICE_KING_COLOR = new Color(80, 120, 255, 140);
    private static final Color ICE_ELEMENTAL_COLOR = new Color(80, 220, 255, 140);
    private static final Color WALL_DANGER_COLOR = new Color(255, 165, 0, 180);
    private static final Color SAFE_ZONE_COLOR = new Color(46, 160, 67, 100);

    // Enhanced border colors for highlighted entities
    private static final Color FIRE_QUEEN_BORDER = new Color(255, 0, 0, 200);
    private static final Color ICE_KING_BORDER = new Color(0, 60, 255, 200);
    private static final Color ICE_ELEMENTAL_BORDER = new Color(0, 180, 220, 200);
    private static final Color WALL_DANGER_BORDER = new Color(255, 120, 0, 240);
    private static final Color SAFE_ZONE_BORDER = new Color(46, 160, 67, 180);

    // Enhanced text colors with better contrast
    private static final Color LABEL_TEXT_COLOR = new Color(255, 255, 255, 240);
    private static final Color LABEL_SHADOW_COLOR = new Color(0, 0, 0, 200);
    private static final Color INFO_TEXT_COLOR = new Color(200, 200, 200, 220);
    private static final Color WARNING_TEXT_COLOR = new Color(255, 200, 0, 240);
    
    // Boss and wall IDs (must match those used in CombatNode)
    private static final int FIRE_QUEEN_ID = 12596;
    private static final int ICE_KING_ID = 14147;
    private static final int SPECIAL_NPC_ID = 14154;
    private static final int ICE_WALL_GRAPHIC_ID = 3221;
    private static final int FIRE_WALL_GRAPHIC_ID = 3218;
    
    // Animation effects
    private long lastUpdateTime = System.currentTimeMillis();
    private float pulseEffect = 0f;
    private boolean pulseDirection = true;
    
    public SulphurDebugOverlay(ScriptContext context) {
        this.context = context;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Sets whether to show health bars above NPCs
     */
    public void setShowHealthBars(boolean showHealthBars) {
        this.showHealthBars = showHealthBars;
    }

    /**
     * Sets whether to show damage numbers (future feature)
     */
    public void setShowDamageNumbers(boolean showDamageNumbers) {
        this.showDamageNumbers = showDamageNumbers;
    }
    
    /**
     * Call this method to render the debug overlay.
     * Typically, your main script's paint method would call this.
     */
    public void render(Graphics2D g) {
        if (!enabled) return;

        // Update animation effects
        updateAnimationEffects();

        // Save original settings
        Stroke originalStroke = g.getStroke();
        Font originalFont = g.getFont();

        // Apply high quality rendering
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);

        // Render game elements with enhanced visuals
        renderBossHighlights(g);
        renderDangerousWallHighlights(g);
        renderInfoPanel(g);

        // Restore original settings
        g.setStroke(originalStroke);
        g.setFont(originalFont);
    }

    /**
     * Renders an information panel in the top-right corner
     */
    private void renderInfoPanel(Graphics2D g) {
        // Get screen dimensions
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int panelWidth = 200;
        int panelHeight = 100;
        int x = screenSize.width - panelWidth - 20;
        int y = 20;

        // Draw semi-transparent background
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRoundRect(x, y, panelWidth, panelHeight, 10, 10);

        // Draw border
        g.setColor(new Color(100, 100, 100, 200));
        g.setStroke(new BasicStroke(2.0f));
        g.drawRoundRect(x, y, panelWidth, panelHeight, 10, 10);

        // Draw title
        g.setColor(LABEL_TEXT_COLOR);
        g.setFont(new Font("SansSerif", Font.BOLD, 14));
        g.drawString("Sulphur Debug", x + 10, y + 20);

        // Draw status information
        g.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g.setColor(INFO_TEXT_COLOR);

        int lineY = y + 40;
        g.drawString("Overlay: " + (enabled ? "Enabled" : "Disabled"), x + 10, lineY);
        lineY += 15;
        g.drawString("Health Bars: " + (showHealthBars ? "On" : "Off"), x + 10, lineY);
        lineY += 15;

        // Count visible entities
        int bossCount = 0;
        if (NPCs.closest(FIRE_QUEEN_ID) != null) bossCount++;
        if (NPCs.closest(ICE_KING_ID) != null) bossCount++;
        if (NPCs.closest(SPECIAL_NPC_ID) != null) bossCount++;

        g.drawString("Bosses Visible: " + bossCount, x + 10, lineY);
    }
    
    /**
     * Updates animation effects for pulsing highlights
     */
    private void updateAnimationEffects() {
        long currentTime = System.currentTimeMillis();
        long deltaTime = currentTime - lastUpdateTime;
        lastUpdateTime = currentTime;
        
        // Update pulse effect (0.0 to 1.0 and back)
        float pulseSpeed = 0.0008f;
        if (pulseDirection) {
            pulseEffect += pulseSpeed * deltaTime;
            if (pulseEffect >= 1.0f) {
                pulseEffect = 1.0f;
                pulseDirection = false;
            }
        } else {
            pulseEffect -= pulseSpeed * deltaTime;
            if (pulseEffect <= 0.0f) {
                pulseEffect = 0.0f;
                pulseDirection = true;
            }
        }
    }
    
    /**
     * Renders the bosses (Fire Queen, Ice King), the special NPC and any Ice Elemental.
     */
    private void renderBossHighlights(Graphics2D g) {
        NPC fireQueen = NPCs.closest(FIRE_QUEEN_ID);
        NPC iceKing = NPCs.closest(ICE_KING_ID);
        NPC specialNPC = NPCs.closest(SPECIAL_NPC_ID);
        
        if (fireQueen != null && fireQueen.exists()) {
            renderNPCOverlay(g, fireQueen, "Fire Queen", FIRE_QUEEN_COLOR, FIRE_QUEEN_BORDER);
        }
        
        if (iceKing != null && iceKing.exists()) {
            renderNPCOverlay(g, iceKing, "Ice King", ICE_KING_COLOR, ICE_KING_BORDER);
        }
        
        if (specialNPC != null && specialNPC.exists()) {
            // Using a purple color for the special NPC
            Color specialFill = new Color(150, 80, 200, 130);
            Color specialBorder = new Color(120, 0, 180, 180);
            renderNPCOverlay(g, specialNPC, "Special NPC", specialFill, specialBorder);
        }
        
        // Optionally highlight any Ice elementals by name
        NPC iceElemental = NPCs.closest("Ice elemental");
        if (iceElemental != null && iceElemental.exists()) {
            renderNPCOverlay(g, iceElemental, "Ice Elemental", ICE_ELEMENTAL_COLOR, ICE_ELEMENTAL_BORDER);
        }
    }
    
    /**
     * Renders dangerous wall graphics (ice and fire walls) as a highlight.
     */
    private void renderDangerousWallHighlights(Graphics2D g) {
        List<GraphicsObject> graphics = GraphicsObjects.all();
        for (GraphicsObject graphic : graphics) {
            if (graphic == null) continue;
            
            if (graphic.getID() == ICE_WALL_GRAPHIC_ID || graphic.getID() == FIRE_WALL_GRAPHIC_ID) {
                Tile tile = graphic.getTile();
                Polygon poly = tile.getPolygon();
                
                if (poly != null) {
                    // Determine if it's ice or fire wall
                    boolean isIceWall = graphic.getID() == ICE_WALL_GRAPHIC_ID;
                    String wallType = isIceWall ? "Ice Wall" : "Fire Wall";
                    
                    // Apply pulsing effect to make dangerous walls more noticeable
                    float alpha = 0.5f + (0.3f * pulseEffect);
                    Color fillColor = new Color(
                        WALL_DANGER_COLOR.getRed(),
                        WALL_DANGER_COLOR.getGreen(),
                        WALL_DANGER_COLOR.getBlue(),
                        (int)(WALL_DANGER_COLOR.getAlpha() * alpha)
                    );
                    
                    // Fill the polygon with semi-transparent color
                    g.setColor(fillColor);
                    g.fillPolygon(poly);
                    
                    // Draw a more visible border
                    g.setStroke(new BasicStroke(2.0f));
                    g.setColor(WALL_DANGER_BORDER);
                    g.drawPolygon(poly);
                    
                    // Calculate center point for label
                    Point center = new Point(
                        (poly.xpoints[0] + poly.xpoints[2]) / 2,
                        (poly.ypoints[0] + poly.ypoints[2]) / 2
                    );
                    
                    // Draw text with shadow for better visibility
                    drawTextWithShadow(g, wallType, center.x, center.y, LABEL_TEXT_COLOR, LABEL_SHADOW_COLOR);
                }
            }
        }
    }
    
    /**
     * Helper method to render an overlay for the given NPC.
     */
    private void renderNPCOverlay(Graphics2D g, NPC npc, String label, Color fillColor, Color borderColor) {
        Tile tile = npc.getTile();
        Polygon poly = tile.getPolygon();
        
        if (poly != null) {
            // Apply pulsing effect to the fill color
            float alpha = 0.7f + (0.3f * pulseEffect);
            Color dynamicFillColor = new Color(
                fillColor.getRed(),
                fillColor.getGreen(),
                fillColor.getBlue(),
                (int)(fillColor.getAlpha() * alpha)
            );
            
            // Fill the polygon with semi-transparent color
            g.setColor(dynamicFillColor);
            g.fillPolygon(poly);
            
            // Draw a more visible border
            g.setStroke(new BasicStroke(2.0f));
            g.setColor(borderColor);
            g.drawPolygon(poly);
            
            // Calculate center point for label
            Point center = new Point(
                (poly.xpoints[0] + poly.xpoints[2]) / 2,
                (poly.ypoints[0] + poly.ypoints[2]) / 2
            );
            
            // Draw text with shadow for better visibility
            drawTextWithShadow(g, label, center.x, center.y, LABEL_TEXT_COLOR, LABEL_SHADOW_COLOR);
            
            // Draw health bar if available and enabled
            if (showHealthBars && npc.getHealthPercent() > 0) {
                drawHealthBar(g, npc, center.x, center.y + 15);
            }
        }
    }
    
    /**
     * Draws text with a shadow for better visibility against any background
     */
    private void drawTextWithShadow(Graphics2D g, String text, int x, int y, Color textColor, Color shadowColor) {
        Font labelFont = new Font("SansSerif", Font.BOLD, 12);
        g.setFont(labelFont);
        
        // Draw shadow
        g.setColor(shadowColor);
        g.drawString(text, x + 1, y + 1);
        
        // Draw text
        g.setColor(textColor);
        g.drawString(text, x, y);
    }
    
    /**
     * Draws a health bar for an NPC
     */
    private void drawHealthBar(Graphics2D g, NPC npc, int x, int y) {
        int healthPercent = npc.getHealthPercent();
        int barWidth = 60;
        int barHeight = 6;
        
        // Background
        g.setColor(new Color(0, 0, 0, 180));
        g.fillRoundRect(x - barWidth/2, y, barWidth, barHeight, 3, 3);
        
        // Health fill
        Color healthColor;
        if (healthPercent > 66) {
            healthColor = new Color(50, 200, 50); // Green
        } else if (healthPercent > 33) {
            healthColor = new Color(230, 230, 0); // Yellow
        } else {
            healthColor = new Color(230, 50, 50); // Red
        }
        
        int fillWidth = (int)(barWidth * (healthPercent / 100.0));
        g.setColor(healthColor);
        g.fillRoundRect(x - barWidth/2, y, fillWidth, barHeight, 3, 3);
        
        // Border
        g.setColor(new Color(0, 0, 0, 150));
        g.setStroke(new BasicStroke(1.0f));
        g.drawRoundRect(x - barWidth/2, y, barWidth, barHeight, 3, 3);
    }
} 