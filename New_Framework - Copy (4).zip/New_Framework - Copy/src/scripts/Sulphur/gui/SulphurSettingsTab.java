package scripts.Sulphur.gui;

import core.context.ScriptContext;
import core.gui.AbstractSettingsTab;
import core.gui.style.StyleManager;
import org.dreambot.api.utilities.Logger;
import scripts.Sulphur.Sulphur;
import scripts.Sulphur.SulphurConfig;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;

/**
 * Modern redesigned settings tab for the Sulphur script
 * Features improved organization, better visual hierarchy, and enhanced user experience
 */
public class SulphurSettingsTab extends AbstractSettingsTab {
    private final SulphurConfig config;
    private static final String SCRIPT_NAME = "Sulphur";

    // Main UI Components
    private JPanel mainContentPanel;
    private JScrollPane mainScrollPane;
    private GearPanel gearPanel;
    private SuppliesPanel suppliesPanel;

    // Quick Setup Components
    private JPanel quickSetupCard;
    private JCheckBox useGrandExchangeCheckbox;
    private JSpinner suppliesMultiplierSpinner;
    private JSpinner lootValueThresholdSpinner;
    private JButton quickSetupButton;
    private JLabel setupStatusLabel;

    // Status Dashboard Components
    private JPanel statusDashboard;
    private JLabel equipmentStatusLabel;
    private JLabel suppliesStatusLabel;
    private JLabel configStatusLabel;
    private JProgressBar setupProgressBar;

    private boolean isLoading = false;
    private boolean isSetupComplete = false;

    public SulphurSettingsTab(ScriptContext context) {
        super(context);
        Sulphur script = (Sulphur) context.getScript();
        this.config = script.getConfig();

        // Ensure we start with default settings
        config.setDefaults();

        // Create the redesigned content panel
        JPanel contentPanel = createModernContentPanel();
        addSection("Sulphur Configuration", contentPanel);

        // Load initial settings and update status
        loadSettings();
        updateSetupStatus();
    }

    @Override
    public void createComponents() {
        // Components are created in the constructor for better initialization flow
    }

    /**
     * Creates the modern content panel with improved organization and visual hierarchy
     */
    private JPanel createModernContentPanel() {
        mainContentPanel = new JPanel();
        mainContentPanel.setLayout(new BoxLayout(mainContentPanel, BoxLayout.Y_AXIS));
        mainContentPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainContentPanel.setBackground(StyleManager.BACKGROUND);

        // Create status dashboard at the top
        statusDashboard = createStatusDashboard();
        mainContentPanel.add(statusDashboard);
        mainContentPanel.add(Box.createVerticalStrut(15));

        // Create quick setup card
        quickSetupCard = createQuickSetupCard();
        mainContentPanel.add(quickSetupCard);
        mainContentPanel.add(Box.createVerticalStrut(15));

        // Create equipment and supplies sections
        JPanel equipmentSuppliesPanel = createEquipmentSuppliesPanel();
        mainContentPanel.add(equipmentSuppliesPanel);

        // Wrap in scroll pane for better usability
        mainScrollPane = new JScrollPane(mainContentPanel);
        StyleManager.styleScrollPane(mainScrollPane);
        mainScrollPane.setBorder(null);
        mainScrollPane.setOpaque(false);
        mainScrollPane.getViewport().setOpaque(false);

        // Create wrapper panel
        JPanel wrapperPanel = new JPanel(new BorderLayout());
        wrapperPanel.setBackground(StyleManager.BACKGROUND);
        wrapperPanel.add(mainScrollPane, BorderLayout.CENTER);

        return wrapperPanel;
    }
    
    /**
     * Creates the status dashboard showing current setup progress and status
     */
    private JPanel createStatusDashboard() {
        JPanel dashboard = new JPanel(new BorderLayout(10, 10));
        dashboard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(BorderFactory.createLineBorder(StyleManager.ACCENT, 2),
                "Setup Status", 0, 0, StyleManager.HEADER_FONT, StyleManager.ACCENT),
            new EmptyBorder(10, 15, 15, 15)
        ));
        dashboard.setBackground(StyleManager.CARD_BG);

        // Progress bar
        setupProgressBar = new JProgressBar(0, 100);
        setupProgressBar.setStringPainted(true);
        setupProgressBar.setString("Configuration Progress");
        setupProgressBar.setForeground(StyleManager.ACCENT);
        setupProgressBar.setBackground(StyleManager.COMPONENT_BG);
        setupProgressBar.setFont(StyleManager.REGULAR_FONT);
        dashboard.add(setupProgressBar, BorderLayout.NORTH);

        // Status indicators panel
        JPanel statusPanel = new JPanel(new GridLayout(1, 3, 10, 0));
        statusPanel.setOpaque(false);

        equipmentStatusLabel = createStatusLabel("Equipment", "Not Configured", false);
        suppliesStatusLabel = createStatusLabel("Supplies", "Not Configured", false);
        configStatusLabel = createStatusLabel("Settings", "Not Configured", false);

        statusPanel.add(equipmentStatusLabel);
        statusPanel.add(suppliesStatusLabel);
        statusPanel.add(configStatusLabel);

        dashboard.add(statusPanel, BorderLayout.CENTER);

        return dashboard;
    }

    /**
     * Creates a status label with icon and styling
     */
    private JLabel createStatusLabel(String title, String status, boolean isComplete) {
        String icon = isComplete ? "✓" : "⚠";
        Color color = isComplete ? new Color(46, 160, 67) : new Color(255, 152, 0);

        JLabel label = new JLabel(String.format("<html><div style='text-align: center;'>" +
            "<span style='font-size: 16px; color: rgb(%d,%d,%d);'>%s</span><br>" +
            "<span style='font-size: 12px; color: rgb(150,150,150);'>%s</span><br>" +
            "<span style='font-size: 10px; color: rgb(120,120,120);'>%s</span>" +
            "</div></html>",
            color.getRed(), color.getGreen(), color.getBlue(), icon, title, status));

        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(StyleManager.BORDER_COLOR),
            new EmptyBorder(8, 8, 8, 8)
        ));
        label.setOpaque(true);
        label.setBackground(StyleManager.COMPONENT_BG);

        return label;
    }

    /**
     * Creates the quick setup card with essential settings
     */
    private JPanel createQuickSetupCard() {
        JPanel card = new JPanel(new BorderLayout(10, 10));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(BorderFactory.createLineBorder(StyleManager.ACCENT, 1),
                "Quick Setup", 0, 0, StyleManager.HEADER_FONT, StyleManager.FOREGROUND),
            new EmptyBorder(15, 20, 20, 20)
        ));
        card.setBackground(StyleManager.CARD_BG);

        // Description
        JLabel descLabel = new JLabel("<html><div style='color: rgb(150,150,150); font-size: 11px;'>" +
            "Configure essential settings to get started quickly. You can fine-tune equipment and supplies later." +
            "</div></html>");
        card.add(descLabel, BorderLayout.NORTH);

        // Settings panel
        JPanel settingsPanel = new JPanel(new GridBagLayout());
        settingsPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 5, 8, 15);
        gbc.anchor = GridBagConstraints.WEST;

        // Use Grand Exchange
        gbc.gridx = 0; gbc.gridy = 0;
        useGrandExchangeCheckbox = new JCheckBox("Use Grand Exchange for supplies");
        StyleManager.styleCheckBox(useGrandExchangeCheckbox);
        useGrandExchangeCheckbox.addActionListener(e -> {
            saveCurrentSettings();
            updateSetupStatus();
        });
        settingsPanel.add(useGrandExchangeCheckbox, gbc);

        // Supplies Multiplier
        gbc.gridy = 1;
        JPanel multiplierPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        multiplierPanel.setOpaque(false);
        multiplierPanel.add(new JLabel("Supplies Multiplier: "));

        suppliesMultiplierSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        StyleManager.styleSpinner(suppliesMultiplierSpinner);
        suppliesMultiplierSpinner.addChangeListener(e -> {
            saveCurrentSettings();
            updateSetupStatus();
        });
        multiplierPanel.add(suppliesMultiplierSpinner);

        JLabel multiplierHelp = new JLabel(" (Higher = more supplies)");
        multiplierHelp.setForeground(StyleManager.FOREGROUND_SECONDARY);
        multiplierHelp.setFont(StyleManager.SMALL_FONT);
        multiplierPanel.add(multiplierHelp);

        settingsPanel.add(multiplierPanel, gbc);

        // Loot Value Threshold
        gbc.gridy = 2;
        JPanel lootPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        lootPanel.setOpaque(false);
        lootPanel.add(new JLabel("Loot Value Threshold: "));

        lootValueThresholdSpinner = new JSpinner(new SpinnerNumberModel(5000, 0, 100000, 1000));
        StyleManager.styleSpinner(lootValueThresholdSpinner);
        lootValueThresholdSpinner.addChangeListener(e -> {
            saveCurrentSettings();
            updateSetupStatus();
        });
        lootPanel.add(lootValueThresholdSpinner);

        JLabel lootHelp = new JLabel(" GP (minimum value to loot)");
        lootHelp.setForeground(StyleManager.FOREGROUND_SECONDARY);
        lootHelp.setFont(StyleManager.SMALL_FONT);
        lootPanel.add(lootHelp);

        settingsPanel.add(lootPanel, gbc);

        card.add(settingsPanel, BorderLayout.CENTER);

        // Quick setup button
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);

        quickSetupButton = new JButton("Auto-Configure Equipment & Supplies");
        StyleManager.styleButton(quickSetupButton);
        quickSetupButton.addActionListener(e -> handleQuickSetup());
        buttonPanel.add(quickSetupButton);

        setupStatusLabel = new JLabel("Click to automatically fetch your current equipment and inventory");
        setupStatusLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        setupStatusLabel.setFont(StyleManager.SMALL_FONT);
        setupStatusLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setOpaque(false);
        bottomPanel.add(buttonPanel, BorderLayout.CENTER);
        bottomPanel.add(setupStatusLabel, BorderLayout.SOUTH);

        card.add(bottomPanel, BorderLayout.SOUTH);

        return card;
    }

    /**
     * Creates the equipment and supplies panel with improved layout
     */
    private JPanel createEquipmentSuppliesPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 2, 15, 0));
        panel.setOpaque(false);

        // Equipment panel
        gearPanel = new GearPanel(config);
        panel.add(gearPanel);

        // Supplies panel
        suppliesPanel = new SuppliesPanel(config);
        panel.add(suppliesPanel);

        return panel;
    }

    /**
     * Handles the quick setup button click
     */
    private void handleQuickSetup() {
        try {
            quickSetupButton.setEnabled(false);
            setupStatusLabel.setText("Fetching current equipment and inventory...");

            // Use reflection to call private methods or trigger button clicks
            if (gearPanel != null) {
                // Simulate clicking the fetch button in gear panel
                triggerGearPanelFetch();
            }

            if (suppliesPanel != null) {
                // Simulate clicking the fetch button in supplies panel
                triggerSuppliesPanelFetch();
            }

            setupStatusLabel.setText("Auto-configuration completed successfully!");
            updateSetupStatus();

        } catch (Exception e) {
            Logger.log("Error during quick setup: " + e.getMessage());
            setupStatusLabel.setText("Error during auto-configuration. Please try manual setup.");
        } finally {
            quickSetupButton.setEnabled(true);
        }
    }

    /**
     * Triggers the fetch equipment functionality
     */
    private void triggerGearPanelFetch() {
        try {
            // Use reflection to access the private handleFetchEquipment method
            java.lang.reflect.Method method = GearPanel.class.getDeclaredMethod("handleFetchEquipment");
            method.setAccessible(true);
            method.invoke(gearPanel);
        } catch (Exception e) {
            Logger.log("Could not trigger gear panel fetch: " + e.getMessage());
        }
    }

    /**
     * Triggers the fetch inventory functionality
     */
    private void triggerSuppliesPanelFetch() {
        try {
            // Use reflection to access the private handleFetchInventory method
            java.lang.reflect.Method method = SuppliesPanel.class.getDeclaredMethod("handleFetchInventory");
            method.setAccessible(true);
            method.invoke(suppliesPanel);
        } catch (Exception e) {
            Logger.log("Could not trigger supplies panel fetch: " + e.getMessage());
        }
    }

    /**
     * Updates the setup status indicators and progress bar
     */
    private void updateSetupStatus() {
        if (equipmentStatusLabel == null || suppliesStatusLabel == null || configStatusLabel == null) {
            return;
        }

        int completedSteps = 0;
        int totalSteps = 3;

        // Check equipment status
        boolean hasEquipment = config.getEquipment() != null && !config.getEquipment().isEmpty();
        updateStatusLabel(equipmentStatusLabel, "Equipment",
            hasEquipment ? "Configured" : "Not Configured", hasEquipment);
        if (hasEquipment) completedSteps++;

        // Check supplies status
        boolean hasSupplies = config.getSupplies() != null && !config.getSupplies().isEmpty();
        updateStatusLabel(suppliesStatusLabel, "Supplies",
            hasSupplies ? "Configured" : "Not Configured", hasSupplies);
        if (hasSupplies) completedSteps++;

        // Check basic settings
        boolean hasBasicSettings = useGrandExchangeCheckbox != null &&
            (useGrandExchangeCheckbox.isSelected() ||
             (Integer) suppliesMultiplierSpinner.getValue() > 1 ||
             (Integer) lootValueThresholdSpinner.getValue() != 5000);
        updateStatusLabel(configStatusLabel, "Settings",
            hasBasicSettings ? "Configured" : "Default Values", hasBasicSettings);
        if (hasBasicSettings) completedSteps++;

        // Update progress bar
        int progress = (completedSteps * 100) / totalSteps;
        setupProgressBar.setValue(progress);
        setupProgressBar.setString(String.format("Configuration Progress (%d/%d)", completedSteps, totalSteps));

        isSetupComplete = completedSteps == totalSteps;
    }

    /**
     * Updates a status label with new information
     */
    private void updateStatusLabel(JLabel label, String title, String status, boolean isComplete) {
        String icon = isComplete ? "✓" : "⚠";
        Color color = isComplete ? new Color(46, 160, 67) : new Color(255, 152, 0);

        label.setText(String.format("<html><div style='text-align: center;'>" +
            "<span style='font-size: 16px; color: rgb(%d,%d,%d);'>%s</span><br>" +
            "<span style='font-size: 12px; color: rgb(150,150,150);'>%s</span><br>" +
            "<span style='font-size: 10px; color: rgb(120,120,120);'>%s</span>" +
            "</div></html>",
            color.getRed(), color.getGreen(), color.getBlue(), icon, title, status));
    }

    private void saveCurrentSettings() {
        if (isLoading) return;

        try {
            // Save basic settings
            config.setUseGrandExchange(useGrandExchangeCheckbox.isSelected());
            config.setSuppliesMultiplier((Integer) suppliesMultiplierSpinner.getValue());
            config.setLootValueThreshold((Integer) lootValueThresholdSpinner.getValue());

            // Save gear and supplies settings
            if (gearPanel != null) {
                gearPanel.saveSettings();
            }
            if (suppliesPanel != null) {
                suppliesPanel.saveSettings();
            }

            config.markDirty();

        } catch (Exception e) {
            Logger.log("Error saving current settings: " + e.getMessage());
        }
    }
    
    public void loadSettings() {
        isLoading = true;
        try {
            // Load basic settings with null checks
            if (useGrandExchangeCheckbox != null) {
                useGrandExchangeCheckbox.setSelected(config.isUsingGrandExchange());
            }
            if (suppliesMultiplierSpinner != null) {
                suppliesMultiplierSpinner.setValue(config.getSuppliesMultiplier());
            }
            if (lootValueThresholdSpinner != null) {
                lootValueThresholdSpinner.setValue(config.getLootValueThreshold());
            }

            // Load gear and supplies settings
            if (gearPanel != null) {
                gearPanel.loadSettings();
            }
            if (suppliesPanel != null) {
                suppliesPanel.loadSettings();
            }

            // Update status after loading
            SwingUtilities.invokeLater(this::updateSetupStatus);

        } finally {
            isLoading = false;
        }
    }

    @Override
    public void saveSettings() {
        saveCurrentSettings();
        updateSetupStatus();
    }

    @Override
    public void resetToDefaults() {
        config.setDefaults();
        loadSettings();
        updateSetupStatus();
    }

    @Override
    public File getProfilesDirectory() {
        // Get the directory path from where ScriptSettings saves files
        String scriptDir = System.getProperty("user.home") + File.separator + 
                          "DreamBot" + File.separator + 
                          "Scripts" + File.separator + 
                          "ScarSulphur" + File.separator +
                          "profiles";
        
        File dir = new File(scriptDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }
}
