package scripts.Sulphur.gui;

import core.gui.style.StyleManager;
import core.gui.style.ModernUITheme;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.container.impl.equipment.EquipmentSlot;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.items.Item;
import scripts.Sulphur.SulphurConfig;

import javax.swing.*;
import java.awt.*;
import java.util.Map;
import java.util.HashMap;

public class GearPanel extends JPanel {
    private final SulphurConfig config;
    private boolean isLoading = false;
    private JPanel equipmentGridPanel;
    private JLabel statusLabel;
    private Map<EquipmentSlot, JLabel> slotLabels;

    public GearPanel(SulphurConfig config) {
        this.config = config;
        this.slotLabels = new HashMap<>();
        initializeComponents();
    }

    private void initializeComponents() {
        setLayout(new BorderLayout(0, 0));
        setBorder(null);
        StyleManager.applyStyle(this);
        
        // Main panel with modern card layout
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setOpaque(false);
        
        // Header with modern design
        JPanel headerPanel = new JPanel(new BorderLayout(0, 0));
        headerPanel.setOpaque(false);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        
        // Title with modern styling
        JLabel titleLabel = new JLabel("EQUIPMENT");
        titleLabel.setFont(StyleManager.HEADER_FONT);
        titleLabel.setForeground(StyleManager.ACCENT);
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        // Modern button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        buttonPanel.setOpaque(false);
        
        JButton fetchButton = createModernButton("Fetch", null);
        fetchButton.addActionListener(e -> handleFetchEquipment());
        
        JButton saveButton = createModernButton("Save", null);
        saveButton.addActionListener(e -> handleSaveEquipment());
        
        buttonPanel.add(fetchButton);
        buttonPanel.add(saveButton);
        headerPanel.add(buttonPanel, BorderLayout.EAST);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Equipment grid with modern card layout
        equipmentGridPanel = createEquipmentGrid();
        JScrollPane scrollPane = new JScrollPane(equipmentGridPanel);
        StyleManager.styleScrollPane(scrollPane);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Modern status bar
        JPanel statusPanel = new JPanel(new BorderLayout(0, 0));
        statusPanel.setOpaque(false);
        statusPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        
        statusLabel = new JLabel("Ready");
        statusLabel.setFont(StyleManager.SMALL_FONT);
        statusLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        statusPanel.add(statusLabel, BorderLayout.WEST);
        
        mainPanel.add(statusPanel, BorderLayout.SOUTH);
        
        add(mainPanel, BorderLayout.CENTER);
        
        // Load initial settings
        loadSettings();
    }
    
    private JPanel createEquipmentGrid() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Create equipment slots in a grid layout
        EquipmentSlot[] slots = {
            EquipmentSlot.HAT, EquipmentSlot.CAPE, EquipmentSlot.AMULET,
            EquipmentSlot.WEAPON, EquipmentSlot.CHEST, EquipmentSlot.SHIELD,
            EquipmentSlot.LEGS, EquipmentSlot.HANDS, EquipmentSlot.FEET,
            EquipmentSlot.RING, EquipmentSlot.ARROWS
        };
        
        int row = 0;
        int col = 0;
        for (EquipmentSlot slot : slots) {
            gbc.gridx = col;
            gbc.gridy = row;
            
            JPanel slotPanel = createSlotPanel(slot);
            panel.add(slotPanel, gbc);
            
            col++;
            if (col > 2) {  // 3 columns
                col = 0;
                row++;
            }
        }
        
        return panel;
    }
    
    private JPanel createSlotPanel(EquipmentSlot slot) {
        JPanel panel = new JPanel(new BorderLayout(6, 0));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
        panel.setBackground(StyleManager.COMPONENT_BG);
        panel.setOpaque(true);
        
        // Slot name with modern styling
        JLabel slotLabel = new JLabel(getSlotName(slot).toUpperCase());
        slotLabel.setFont(StyleManager.SMALL_FONT);
        slotLabel.setForeground(StyleManager.ACCENT);
        panel.add(slotLabel, BorderLayout.NORTH);
        
        // Item name with modern styling
        JLabel itemLabel = new JLabel("None");
        itemLabel.setFont(StyleManager.REGULAR_FONT);
        itemLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        panel.add(itemLabel, BorderLayout.CENTER);
        
        // Store the label for later updates
        slotLabels.put(slot, itemLabel);
        
        return panel;
    }
    
    private JButton createModernButton(String text, Icon icon) {
        JButton button = new JButton(text, icon);
        button.setFont(StyleManager.REGULAR_FONT);
        button.setForeground(StyleManager.FOREGROUND);
        button.setBackground(StyleManager.COMPONENT_BG);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
    
    private void handleFetchEquipment() {
        if (!Client.isLoggedIn()) {
            JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),
                    "Please log in first to fetch your equipment.",
                    "Not Logged In",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            Map<String, String> equipment = new HashMap<>();
            
            // Update all slot labels
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                Item item = Equipment.getItemInSlot(slot);
                JLabel label = slotLabels.get(slot);
                if (label != null) {
                    if (item != null) {
                        String itemName = item.getName();
                        label.setText(itemName);
                        label.setForeground(new Color(60, 60, 60));
                        equipment.put(getSlotName(slot), itemName);
                    } else {
                        label.setText("None");
                        label.setForeground(new Color(150, 150, 150));
                    }
                }
            }
            
            // Save to config
            config.setEquipment(equipment);
            config.saveConfig();
            
            statusLabel.setText("Equipment fetched successfully!");
            
        } catch (Exception e) {
            Logger.log("Error fetching equipment: " + e.getMessage());
            statusLabel.setText("Error: " + e.getMessage());
            JOptionPane.showMessageDialog(this,
                    "Error fetching equipment: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void handleSaveEquipment() {
        try {
            Map<String, String> equipment = config.getEquipment();
            if (equipment != null && !equipment.isEmpty()) {
                config.saveConfig();
                statusLabel.setText("Equipment saved successfully!");
            } else {
                statusLabel.setText("No equipment to save!");
            }
        } catch (Exception e) {
            Logger.log("Error saving equipment: " + e.getMessage());
            statusLabel.setText("Error: " + e.getMessage());
        }
    }
    
    private String getSlotName(EquipmentSlot slot) {
        switch (slot) {
            case HAT: return "Helmet";
            case CAPE: return "Cape";
            case AMULET: return "Necklace";
            case WEAPON: return "Weapon";
            case CHEST: return "Body";
            case SHIELD: return "Shield";
            case LEGS: return "Legs";
            case HANDS: return "Gloves";
            case FEET: return "Boots";
            case RING: return "Ring";
            case ARROWS: return "Ammo";
            default: return null;
        }
    }
    
    public void loadSettings() {
        isLoading = true;
        try {
            Map<String, String> equipment = config.getEquipment();
            if (equipment != null && !equipment.isEmpty()) {
                for (EquipmentSlot slot : EquipmentSlot.values()) {
                    String slotName = getSlotName(slot);
                    if (slotName != null) {
                        String itemName = equipment.get(slotName.toLowerCase());
                        JLabel label = slotLabels.get(slot);
                        if (label != null) {
                            label.setText(itemName != null ? itemName : "None");
                            label.setForeground(itemName != null ? 
                                new Color(60, 60, 60) : new Color(150, 150, 150));
                        }
                    }
                }
            }
        } finally {
            isLoading = false;
        }
    }
    
    public void saveSettings() {
        if (!isLoading) {
            handleSaveEquipment();
        }
    }
    
    public void clearAllFields() {
        for (JLabel label : slotLabels.values()) {
            label.setText("None");
            label.setForeground(new Color(150, 150, 150));
        }
        statusLabel.setText("Ready");
    }
} 