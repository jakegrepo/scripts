package scripts.Sulphur;

import org.dreambot.api.Client;
import org.dreambot.api.methods.grandexchange.LivePrices;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.interactive.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public class SulphurGlobalState {


    // Party management.
    private static String partyLeaderName = "";
    private static final ConcurrentHashMap<String, PartyMemberStatus> partyMembers = new ConcurrentHashMap<>();
    private static final AtomicBoolean partyReady = new AtomicBoolean(false);
    private static final AtomicBoolean fightStarting = new AtomicBoolean(false);
    private static final Set<String> playersAtEntrance = Collections.synchronizedSet(new HashSet<>());

    // Duo mode flag.
    private static boolean duoMode = false;
    private static final long READY_TIMEOUT = 20000; // 5 seconds timeout for readiness updates


    // Teleport override.

    public static class PartyMemberStatus {
        public boolean ready = false;
        public int hp;
        public int x;
        public int y;
        public String action;
        public String target;
        public long lastUpdate;
        public String role;

        public PartyMemberStatus(int hp, int x, int y, boolean ready, String action, String target) {
            this.hp = hp;
            this.x = x;
            this.y = y;
            this.ready = ready;
            this.action = action;
            this.target = target;
            this.lastUpdate = System.currentTimeMillis();
        }
    }

    // Returns the expected number of additional party members.
    private static int getExpectedMemberCount() {
        return duoMode ? 1 : 3;
    }

    /**
     * Initializes the party state. Always adds the local player.
     * If isLeader is true, the local player is registered as the leader.
     */
    public static void initializeParty(boolean isLeader) {
        partyMembers.clear();
        playersAtEntrance.clear();
        partyReady.set(false);
        fightStarting.set(false);

        if (isLeader) {
            Player localPlayer = Players.getLocal();
            if (localPlayer != null) {
                String localName = localPlayer.getName();
                partyLeaderName = localName;
                // Create an entry for the leader with role LEADER
                addPartyMember(localName);  // This will set the correct role
            }
        }
    }



    public static boolean isPartyLeader() {
        Player localPlayer = Players.getLocal();
        return localPlayer != null && localPlayer.getName().equals(partyLeaderName);
    }

    public synchronized static void addPartyMember(String memberName) {
        memberName = memberName.trim();
        // Don't add duplicate entries
        if (partyMembers.containsKey(memberName)) {
            return;
        }

        String role;
        if (memberName.equals(partyLeaderName) && partyLeaderName != null && !partyLeaderName.isEmpty()) {
            role = "LEADER";
        } else {
            role = "MEMBER";
        }
        
        PartyMemberStatus status = new PartyMemberStatus(100, 0, 0, false, "IDLE", "");
        status.role = role;
        partyMembers.put(memberName, status);

        // Log current party state
    }


    public static List<String> getPartyMembers() {
        return new ArrayList<>(partyMembers.keySet());
    }

    public static void setPartyReady(boolean ready) {
        partyReady.set(ready);
    }

    public static boolean isPartyReady() {
        return partyReady.get();
    }

    public static String getPartyLeaderName() {
        return partyLeaderName;
    }

    public static void setPartyLeaderName(String name) {
        partyLeaderName = name;
    }

    public static void setFightStarting(boolean starting) {
        fightStarting.set(starting);
        Logger.log("Fight starting state set to: " + starting);
    }

    public static boolean isFightStarting() {
        return fightStarting.get();
    }

    public static Set<String> getPlayersAtEntrance() {
        return Collections.unmodifiableSet(playersAtEntrance);
    }

    /**
     * Sets a player as "ready" at the entrance.
     * If the player is already marked ready, no duplicate update is performed.
     */
    public synchronized static void setPlayerAtEntrance(String playerName) {
        PartyMemberStatus status = partyMembers.get(playerName);
        if (status != null) {
            status.lastUpdate = System.currentTimeMillis();
            if (status.ready) {
                return;
            }
        }
        partyMembers.compute(playerName, (k, v) -> {
            if (v == null) {
                v = new PartyMemberStatus(100, 0, 0, false, "IDLE", "");
            }
            v.ready = true;
            v.lastUpdate = System.currentTimeMillis();
            return v;
        });

        // Only check party ready state if we have the correct number of players
        if (duoMode) {
            // For duo mode, we need exactly 2 players
            if (partyMembers.size() != 2) {
                Logger.log("Waiting for both players to join before checking ready state (current size: " + partyMembers.size() + ")");
                return;
            }
            
            // Make sure we have both a leader and a member
            boolean hasLeader = false;
            boolean hasMember = false;
            for (PartyMemberStatus memberStatus : partyMembers.values()) {
                if ("LEADER".equals(memberStatus.role)) hasLeader = true;
                if ("MEMBER".equals(memberStatus.role)) hasMember = true;
            }
            
            if (!hasLeader || !hasMember) {
                return;
            }
        }
        
        // Now check if all players are ready with recent updates
        if (areAllMembersReady() && areAllPlayersAtEntrance()) {
            setPartyReady(true);
            Logger.log("All players ready and at entrance - Party is now ready!");
        } else {
            Logger.log("Not all players are ready yet");
        }
    }

    public static void setPlayerReady(String playerName, boolean ready) {
        PartyMemberStatus status = partyMembers.get(playerName);
        if (status != null) {
            status.ready = ready;
            status.lastUpdate = System.currentTimeMillis();
        } else {
            status = new PartyMemberStatus(100, 0, 0, ready, "IDLE", "");
            partyMembers.put(playerName, status);
        }

        if (areAllMembersReady() && areAllPlayersAtEntrance()) {
            partyReady.set(true);
            Logger.log("Party is fully ready!");
        } else {
            partyReady.set(false);
        }
    }

    public static boolean areAllMembersReady() {
        List<String> expectedPlayers = new ArrayList<>(partyMembers.keySet());

        // In duo mode, we expect exactly 2 players (leader + 1 member)
        if (duoMode && expectedPlayers.size() != 2) {
            return false;
        }
        
        long currentTime = System.currentTimeMillis();
        for (String name : expectedPlayers) {
            PartyMemberStatus status = partyMembers.get(name);
            if (status == null || !status.ready || (currentTime - status.lastUpdate > READY_TIMEOUT)) {
                return false;
            }
        }
        
        Logger.log("All members are ready!");
        return true;
    }

    public static boolean areAllPlayersAtEntrance() {
        List<String> expectedPlayers = new ArrayList<>(partyMembers.keySet());

        // In duo mode, we expect exactly 2 players (leader + 1 member)
        if (duoMode && expectedPlayers.size() != 2) {
            Logger.log("Incorrect number of players for duo mode. Expected 2, got: " + expectedPlayers.size());
            return false;
        }
        
        long currentTime = System.currentTimeMillis();
        for (String name : expectedPlayers) {
            PartyMemberStatus status = partyMembers.get(name);
            if (status == null || !status.ready || (currentTime - status.lastUpdate > READY_TIMEOUT)) {
                return false;
            }
        }
        
        Logger.log("All players are at entrance!");
        return true;
    }

    public static void resetEntranceState() {
        playersAtEntrance.clear();
    }

    public synchronized static boolean isPartyComplete() {
        Player local = Players.getLocal();
        int requiredMembers = duoMode ? 1 : 3;
        return local != null && partyMembers.size() == requiredMembers && playersAtEntrance.size() == partyMembers.size() + 1;
    }

    public static void setDuoMode(boolean mode) {
        duoMode = mode;
    }

    public static boolean isDuoMode() {
        return duoMode;
    }



    public static PartyMemberStatus getPartyMemberStatus(String name) {
        return partyMembers.get(name);
    }


    public static void resetAllStates() {
        resetEntranceState();

        // Reset the ready state for each party member
        for (PartyMemberStatus status : partyMembers.values()) {
            status.ready = false;
        }

        partyReady.set(false);
        fightStarting.set(false);
        playersAtEntrance.clear();
        Logger.log("Reset all non-escape states, including player ready states");
    }
    public synchronized static void updatePartyMemberRole(String playerName, String role) {
        playerName = playerName.trim();
        // If the global state says this name is the leader, override the role
        if (playerName.equals(getPartyLeaderName())) {
            role = "LEADER";
        }
        PartyMemberStatus existing = partyMembers.get(playerName);
        if (existing == null) {
            addPartyMember(playerName);
            existing = partyMembers.get(playerName);
        }
        if (!existing.role.equals(role)) {
            existing.role = role;
        }
    }





    public static String getCurrentAction() {
        return "IDLE";
    }

    public static String getCurrentTarget() {
        return Players.getLocal().getInteractingCharacter().getName();
    }

    public static List<String> getActiveBuffs() {
        return new ArrayList<>();
    }

    public static boolean isPlayerAtEntrance(String playerName) {
        return partyMembers.containsKey(playerName) && partyMembers.get(playerName).ready;
    }

    // New method to cleanup stale ready states using timestamps
    public static void cleanupStaleMembers() {
        // If the client is in the boss instance (dynamic region), mark all members as ready and set fightStarting
        if (Client.isDynamicRegion()) {
            for (Map.Entry<String, PartyMemberStatus> entry : partyMembers.entrySet()) {
                PartyMemberStatus status = entry.getValue();
                if (!status.ready) {
                    status.ready = true;
                    status.lastUpdate = System.currentTimeMillis();
                }
            }
            setFightStarting(true);
            setPartyReady(true);
            Logger.log("In dynamic region: All members marked as ready and fight state set.");
            return;
        }

        // Normal cleanup if not in boss instance
        long currentTime = System.currentTimeMillis();
        for (Map.Entry<String, PartyMemberStatus> entry : partyMembers.entrySet()) {
            PartyMemberStatus status = entry.getValue();
            if (status.ready && (currentTime - status.lastUpdate > READY_TIMEOUT)) {
                status.ready = false;
            }
        }
        // Update the overall party ready flag after cleanup
        if (!(areAllMembersReady() && areAllPlayersAtEntrance())) {
            partyReady.set(false);
            Logger.log("Party is not ready after cleanup.");
        }
    }

    private static final Map<Integer, Integer> lootHistory = new ConcurrentHashMap<>();
    private static long totalLootValue = 0;
    
    public static void addLootItem(int itemId, int quantity) {
        int price = LivePrices.getLow(itemId); // Use low price for conservative estimates
        lootHistory.merge(itemId, quantity, Integer::sum);
        totalLootValue += quantity * price;
    }
    
    public static long getTotalLootValue() {
        return totalLootValue;
    }
    
    public static Map<Integer, Integer> getLootHistory() {
        return new HashMap<>(lootHistory);
    }
}
