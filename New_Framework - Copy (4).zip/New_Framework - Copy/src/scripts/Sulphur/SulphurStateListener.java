package scripts.Sulphur;

public interface SulphurStateListener {
    void onEscapeStateChange(boolean shouldEscape);
} 