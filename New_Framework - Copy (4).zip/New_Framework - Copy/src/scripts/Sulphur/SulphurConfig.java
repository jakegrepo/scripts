package scripts.Sulphur;

import com.google.gson.annotations.Expose;
import core.config.ScriptConfig;
import core.context.ScriptContext;
import core.grandexchange.GrandExchangeConfig;
import org.dreambot.api.methods.prayer.Prayer;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.settings.ScriptSettings;
import org.dreambot.api.utilities.Logger;
import scripts.Sulphur.data.ProfileData;
import scripts.Sulphur.data.SulphurLoadoutData;
import scripts.Sulphur.gui.SulphurSettingsTab;
import scripts.Sulphur.utils.ProfileFileManager;
import scripts.Sulphur.utils.SulphurLoadoutManager;


import java.io.File;
import java.util.*;

public class SulphurConfig extends ScriptConfig implements GrandExchangeConfig {
    private static final String DEFAULT_FOOD_TYPE = "Shark";
    private static final int DEFAULT_HEALTH_THRESHOLD = 65;
    private static final int DEFAULT_AMMO_QUANTITY = 1000;
    private static final int SLAYER_TASK_SIZE_VARP = 394;
    private static final int SLAYER_TASK_CREATURE_VARBIT = 395;

    // Inner class to hold serializable data
    private static class ConfigData {
        public String foodType;
        public int healthThreshold;
        public int ammoQuantity;
        public int lootValueThreshold = 5000;
        public List<String> unwantedTasks = new ArrayList<>();
        public Map<String, String> npcLoadoutAssignments = new HashMap<>();
        public Map<String, String> npcLoadouts = new HashMap<>();
        public Map<String, String> preferredLocationNames = new HashMap<>(); // Store as NPC name -> location name
        public boolean useGrandExchange = false;
        public boolean useShop = false;
        public List<String> foodNames = new ArrayList<>();
        public int suppliesMultiplier = 1;
        public boolean alchemyEnabled = false;
        public int targetFoodCount = 0;
        public List<String> quickPrayers = new ArrayList<>();
        public Map<String, String> equipment = new HashMap<>();
        public Map<String, Integer> supplies = new HashMap<>();
        public Map<String, String> taskLoadouts = new HashMap<>();
        public String defaultLoadout = null;
        public boolean usingCannon = false;  // Add cannon setting
    }

    private String foodType;
    private int healthThreshold;
    private int ammoQuantity;
    @Expose private int lootValueThreshold = 5000;
    private List<String> unwantedTasks;
    @Expose private boolean useGrandExchange = false;
    @Expose private boolean useShop = false;
    @Expose private List<String> foodNames = new ArrayList<>();
    @Expose private int suppliesMultiplier = 1;
    @Expose private boolean alchemyEnabled = false;
    @Expose private int targetFoodCount = 0;
    private List<Prayer> quickPrayers;
    private boolean dirty = false;
    @Expose private Map<String, String> equipment = new HashMap<>();
    @Expose private Map<String, Integer> supplies = new HashMap<>();
    private ProfileData data;
    private Map<String, SulphurLoadoutData> loadouts = new HashMap<>();
    private Map<String, String> taskLoadouts = new HashMap<>();
    private SulphurSettingsTab parentTab;

    public SulphurConfig(ScriptContext context) {
        super(context, "sulphur_config");
        setDefaults();
        this.data = new ProfileData();
    }

    @Override
    public void saveConfig() {
        if (!dirty) {
            return;  // Only save if changes were made
        }
        try {
            ConfigData data = new ConfigData();
            data.foodType = this.foodType;
            data.healthThreshold = this.healthThreshold;
            data.ammoQuantity = this.ammoQuantity;
            data.lootValueThreshold = this.lootValueThreshold;
            data.useGrandExchange = this.useGrandExchange;
            data.useShop = this.useShop;
            data.foodNames = new ArrayList<>(this.foodNames);
            data.suppliesMultiplier = this.suppliesMultiplier;
            data.alchemyEnabled = this.alchemyEnabled;
            data.targetFoodCount = this.targetFoodCount;
            if (this.quickPrayers != null) {
                data.quickPrayers = this.quickPrayers.stream()
                        .map(Prayer::toString)
                        .collect(java.util.stream.Collectors.toList());
            }
            data.equipment = new HashMap<>(this.equipment);
            data.supplies = new HashMap<>(this.supplies);
            data.defaultLoadout = this.data != null ? this.data.getDefaultLoadout() : null;

            // Log the selected master before saving

            ScriptSettings.save(data, "ScarSulphur", "config.json");
            dirty = false;
            Logger.log("Config saved successfully");
        } catch (Exception e) {
            Logger.log("Error saving config: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void loadConfig() {
        try {
            ConfigData data = ScriptSettings.load(ConfigData.class, "ScarSulphur", "config.json");
            if (data != null) {
                this.foodType = data.foodType;
                this.healthThreshold = data.healthThreshold;
                this.ammoQuantity = data.ammoQuantity;
                this.lootValueThreshold = data.lootValueThreshold;
                this.useGrandExchange = data.useGrandExchange;
                this.useShop = data.useShop;
                this.foodNames = new ArrayList<>(data.foodNames);
                this.suppliesMultiplier = data.suppliesMultiplier;
                this.alchemyEnabled = data.alchemyEnabled;
                this.targetFoodCount = data.targetFoodCount;
                if (data.quickPrayers != null) {
                    this.quickPrayers = data.quickPrayers.stream()
                            .map(Prayer::valueOf)
                            .collect(java.util.stream.Collectors.toList());
                }
                this.equipment = new HashMap<>(data.equipment);
                this.supplies = new HashMap<>(data.supplies);
                if (data.defaultLoadout != null) {
                    if (this.data == null) {
                        this.data = new ProfileData();
                    }
                    this.data.setDefaultLoadout(data.defaultLoadout);
                }
            }
        } catch (Exception e) {
            Logger.log("Error loading config: " + e.getMessage());
            e.printStackTrace();
            setDefaults();  // Fall back to defaults if loading fails
        }
    }

    public void saveToFile(File file) {
        Logger.log("Saving config to file: " + file.getName());
        try {
            String fileName = file.getName();
            String profileName = fileName.substring(0, fileName.lastIndexOf('.'));

            // Create data object
            ConfigData data = new ConfigData();
            // Copy current state to data object (same as in saveConfig)
            data.foodType = this.foodType;
            data.healthThreshold = this.healthThreshold;
            data.ammoQuantity = this.ammoQuantity;
            data.lootValueThreshold = this.lootValueThreshold;
            data.useGrandExchange = this.useGrandExchange;
            data.useShop = this.useShop;
            data.foodNames = new ArrayList<>(this.foodNames);
            data.suppliesMultiplier = this.suppliesMultiplier;
            data.alchemyEnabled = this.alchemyEnabled;
            data.targetFoodCount = this.targetFoodCount;
            data.quickPrayers = this.quickPrayers.stream()
                    .map(Prayer::toString)
                    .collect(java.util.stream.Collectors.toList());
            data.equipment = new HashMap<>(this.equipment);
            data.supplies = new HashMap<>(this.supplies);
            data.taskLoadouts = new HashMap<>(this.taskLoadouts);
            data.defaultLoadout = this.data.getDefaultLoadout();

            ScriptSettings.save(data, "ScarSlayer", "profiles", profileName + ".json");
            Logger.log("Config saved successfully");
        } catch (Exception e) {
            Logger.log("Error saving config to file: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void loadFromFile(File file) {
        Logger.log("Loading config from file: " + file.getName());
        try {
            String fileName = file.getName();
            String profileName = fileName.substring(0, fileName.lastIndexOf('.'));
            ConfigData data = ScriptSettings.load(ConfigData.class, "ScarSlayer", "profiles", profileName + ".json");

            // Copy data back to config (same as in loadConfig)
            this.foodType = data.foodType;
            this.healthThreshold = data.healthThreshold;
            this.ammoQuantity = data.ammoQuantity;
            this.lootValueThreshold = data.lootValueThreshold;
            this.unwantedTasks = new ArrayList<>(data.unwantedTasks);
            this.useGrandExchange = data.useGrandExchange;
            this.useShop = data.useShop;
            this.foodNames = new ArrayList<>(data.foodNames);
            this.suppliesMultiplier = data.suppliesMultiplier;
            this.alchemyEnabled = data.alchemyEnabled;
            this.targetFoodCount = data.targetFoodCount;
            this.quickPrayers = data.quickPrayers.stream()
                    .map(Prayer::valueOf)
                    .collect(java.util.stream.Collectors.toList());
            this.equipment = new HashMap<>(data.equipment);
            this.supplies = new HashMap<>(data.supplies);
            this.taskLoadouts = new HashMap<>(data.taskLoadouts);
            if (data.defaultLoadout != null) {
                this.data.setDefaultLoadout(data.defaultLoadout);
            }

            Logger.log("Config loaded successfully");
        } catch (Exception e) {
            Logger.log("Error loading config from file: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private String getScriptDirectory() {
        return System.getProperty("user.home") + File.separator +
                "DreamBot" + File.separator +
                "Scripts" + File.separator +
                "ScarSlayer";
    }

    private void createDirectories() {
        String baseDir = getScriptDirectory();

        // Create profiles directory
        File profilesDir = new File(baseDir + File.separator + "profiles");
        if (!profilesDir.exists()) {
            profilesDir.mkdirs();
        }

        // Create loadouts directory
        File loadoutsDir = new File(baseDir + File.separator + "loadouts");
        if (!loadoutsDir.exists()) {
            loadoutsDir.mkdirs();
        }
    }

    @Override
    public void setDefaults() {
        this.foodType = DEFAULT_FOOD_TYPE;
        this.healthThreshold = DEFAULT_HEALTH_THRESHOLD;
        this.ammoQuantity = DEFAULT_AMMO_QUANTITY;
        this.lootValueThreshold = 5000;
        this.useGrandExchange = false;
        this.useShop = false;
        this.foodNames = new ArrayList<>();
        this.suppliesMultiplier = 1;
        this.alchemyEnabled = false;
        this.targetFoodCount = 0;
        this.quickPrayers = new ArrayList<>();
        this.equipment = new HashMap<>();
        this.supplies = new HashMap<>();
        this.data = null;  // Ensure no profile is loaded by default
        this.loadouts = new HashMap<>();
        this.taskLoadouts = new HashMap<>();
        // Create necessary directories
        createDirectories();

        markDirty();
    }



    @Override
    public Map<String, String> getEquipment() {
        return equipment;
    }

    @Override
    public void setEquipment(Map<String, String> equipment) {
        this.equipment = new HashMap<>(equipment);
        markDirty();
    }

    @Override
    public Map<String, Integer> getSupplies() {
        return supplies;
    }

    @Override
    public void setSupplies(Map<String, Integer> supplies) {
        this.supplies = new HashMap<>(supplies);
        markDirty();
    }

    @Override
    public boolean isUsingGrandExchange() {
        return useGrandExchange;
    }

    @Override
    public void setUseGrandExchange(boolean use) {
        this.useGrandExchange = use;
        markDirty();
    }

    @Override
    public List<String> getFoodNames() {
        return foodNames;
    }

    @Override
    public void setFoodNames(List<String> foodNames) {
        this.foodNames = new ArrayList<>(foodNames);
        markDirty();
    }

    @Override
    public int getTargetFoodCount() {
        return targetFoodCount;
    }

    @Override
    public void setTargetFoodCount(int count) {
        this.targetFoodCount = count;
        markDirty();
    }

    @Override
    public boolean isAlchemyEnabled() {
        return alchemyEnabled;
    }

    @Override
    public void setAlchemyEnabled(boolean enabled) {
        this.alchemyEnabled = enabled;
        markDirty();
    }

    @Override
    public int getSuppliesMultiplier() {
        return suppliesMultiplier;
    }

    @Override
    public void setSuppliesMultiplier(int multiplier) {
        this.suppliesMultiplier = multiplier;
        markDirty();
    }

    @Override
    public String getTeleportMethod() {
        return null;  // No teleport method available
    }

    @Override
    public void setTeleportMethod(String method) {
        // No teleport method available
    }

    @Override
    public void copyConfigValues(ScriptConfig other) {
        if (other instanceof SulphurConfig) {
            SulphurConfig otherConfig = (SulphurConfig) other;
            this.foodType = otherConfig.foodType;
            this.healthThreshold = otherConfig.healthThreshold;
            this.ammoQuantity = otherConfig.ammoQuantity;
            this.quickPrayers = new ArrayList<>(otherConfig.quickPrayers);
            this.equipment = new HashMap<>(otherConfig.equipment);
            this.supplies = new HashMap<>(otherConfig.supplies);
            this.foodNames = new ArrayList<>(otherConfig.foodNames);
            this.lootValueThreshold = otherConfig.lootValueThreshold;
            this.useGrandExchange = otherConfig.useGrandExchange;
            this.useShop = otherConfig.useShop;
            this.suppliesMultiplier = otherConfig.suppliesMultiplier;
            this.alchemyEnabled = otherConfig.alchemyEnabled;
            this.targetFoodCount = otherConfig.targetFoodCount;
            this.dirty = true;
        }
    }


    // Varbit and Varp Methods
    protected int[] getVarps() {
        return PlayerSettings.getConfigs();
    }

    protected int[] getVarbits() {
        return PlayerSettings.getVarBits();
    }

    // Loadout Management Methods
    public List<String> getAvailableLoadouts() {
        return SulphurLoadoutManager.getAvailableLoadouts();
    }

    public void saveLoadout(String name, SulphurLoadoutData loadout) {
        // If this loadout is being set as default, update the profile's default loadout
        if (loadout.isDefault()) {
            // If we have a loaded profile, update its default loadout
            if (data != null) {
                data.setDefaultLoadout(name);
            }

            // Unset default flag from other loadouts
            List<SulphurLoadoutData> allLoadouts = SulphurLoadoutManager.loadAllLoadouts();
            for (SulphurLoadoutData existingLoadout : allLoadouts) {
                if (existingLoadout.isDefault() && !existingLoadout.getName().equals(name)) {
                    existingLoadout.setDefault(false);
                    SulphurLoadoutManager.saveLoadout(existingLoadout.getName(), existingLoadout);
                }
            }
        }

        // Save the loadout file
        SulphurLoadoutManager.saveLoadout(name, loadout);
        markDirty();
    }



    public SulphurLoadoutData getLoadout(String name) {
        return SulphurLoadoutManager.loadLoadout(new File(SulphurLoadoutManager.getLoadoutsDirectory(), name + ".json"));
    }

    public void deleteLoadout(String name) {
        // Check if this is the default loadout
        String defaultLoadout = getDefaultLoadout();
        boolean isDefault = (defaultLoadout != null && defaultLoadout.equals(name));

        // If this is the default loadout, remove it from all NPCs that were using it
        if (isDefault) {
            // Clear the default loadout in the profile
            if (data != null) {
                data.setDefaultLoadout(null);
            }

        }

        SulphurLoadoutManager.deleteLoadout(name);
        markDirty();
    }


    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
        this.dirty = true;
    }

    public int getHealthThreshold() {
        return healthThreshold;
    }

    public void setHealthThreshold(int threshold) {
        this.healthThreshold = threshold;
        this.dirty = true;
    }

    public int getAmmoQuantity() {
        return ammoQuantity;
    }

    public void setAmmoQuantity(int quantity) {
        this.ammoQuantity = quantity;
        this.dirty = true;
    }


    public List<Prayer> getQuickPrayers() {
        return new ArrayList<>(quickPrayers);
    }

    public void setQuickPrayers(List<Prayer> prayers) {
        this.quickPrayers = new ArrayList<>(prayers);
        this.dirty = true;
    }



    @Override
    public boolean isDirty() {
        return this.dirty;
    }

    @Override
    public void markDirty() {
        this.dirty = true;
    }

    @Override
    public void markClean() {
        this.dirty = false;
    }

    public void setDirty(boolean isDirty) {
        this.dirty = isDirty;
    }

    // Profile Management Methods
    public List<String> getAvailableProfiles() {
        Logger.log("Getting available profiles");
        List<String> profiles = ProfileFileManager.getAvailableProfiles();
        Logger.log("Found profiles: " + profiles);
        return profiles;
    }

    public void saveProfile(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }

        ProfileData profileData = new ProfileData();
        profileData.setName(name.trim());
        profileData.setFoodType(this.foodType);
        profileData.setHealthThreshold(this.healthThreshold);
        profileData.setAmmoQuantity(this.ammoQuantity);
        profileData.setLootValueThreshold(this.lootValueThreshold);
        profileData.setUseGrandExchange(this.useGrandExchange);
        profileData.setFoodNames(this.foodNames);
        profileData.setSuppliesMultiplier(this.suppliesMultiplier);
        profileData.setAlchemyEnabled(this.alchemyEnabled);
        profileData.setTargetFoodCount(this.targetFoodCount);
        profileData.setQuickPrayers(this.quickPrayers.stream()
                .map(Prayer::toString)
                .collect(java.util.stream.Collectors.toList()));
        profileData.setEquipment(this.equipment);
        profileData.setSupplies(this.supplies);
        profileData.setDefaultLoadout(getDefaultLoadout());

        try {
            ProfileFileManager.saveProfile(name.trim(), profileData);
            Logger.log("Profile saved successfully: " + name);
            dirty = true;
            saveConfig();
        } catch (Exception e) {
            Logger.log("Error saving profile: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void loadProfile(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }
        try {
            ProfileData profileData = ProfileFileManager.loadProfile(
                    new File(ProfileFileManager.getProfilesDirectory(), name + ".json")
            );
            if (profileData != null) {
                this.data = profileData;
                this.foodType = profileData.getFoodType();
                this.healthThreshold = profileData.getHealthThreshold();
                this.ammoQuantity = profileData.getAmmoQuantity();
                this.lootValueThreshold = profileData.getLootValueThreshold();
                this.useGrandExchange = profileData.isUseGrandExchange();
                this.foodNames = new ArrayList<>(profileData.getFoodNames());
                this.suppliesMultiplier = profileData.getSuppliesMultiplier();
                this.alchemyEnabled = profileData.isAlchemyEnabled();
                this.targetFoodCount = profileData.getTargetFoodCount();
                this.quickPrayers = profileData.getQuickPrayers().stream()
                        .map(Prayer::valueOf)
                        .collect(java.util.stream.Collectors.toList());
                this.equipment = new HashMap<>(profileData.getEquipment());
                this.supplies = new HashMap<>(profileData.getSupplies());

                // Load profile-specific default loadout
                String defaultLoadout = profileData.getDefaultLoadout();
                if (defaultLoadout != null) {
                    SulphurLoadoutData loadoutData = getLoadout(defaultLoadout);
                    if (loadoutData != null) {
                        loadoutData.setDefault(true);
                        saveLoadout(defaultLoadout, loadoutData);
                    }
                }

                markDirty();
                saveConfig();
            }
        } catch (Exception e) {
            Logger.log("Error loading profile: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void deleteProfile(String name) {
        if (name != null && !name.trim().isEmpty()) {
            Logger.log("Removing profile: " + name);

            boolean deleted = ProfileFileManager.deleteProfile(name.trim());
            if (deleted) {
                Logger.log("Deleted profile file: " + name);
            } else {
                Logger.log("Failed to delete profile file: " + name);
            }

            Logger.log("Remaining profiles: " + getAvailableProfiles());
            dirty = true;
            saveConfig();
        }
    }

    @Override
    public void reset() {
        super.reset();
    }

    public void load() {
    }

    public Map<String, SulphurLoadoutData> getLoadouts() {
        return SulphurLoadoutManager.loadAllLoadouts().stream()
                .collect(java.util.stream.Collectors.toMap(
                        SulphurLoadoutData::getName,
                        loadout -> loadout
                ));
    }

    public void setTaskLoadout(String taskName, String loadoutName) {
        // Verify loadout exists
        if (SulphurLoadoutManager.loadLoadout(new File(SulphurLoadoutManager.getLoadoutsDirectory(), loadoutName + ".json")) != null) {
            taskLoadouts.put(taskName, loadoutName);
            markDirty();
        } else {
            throw new IllegalArgumentException("Loadout does not exist: " + loadoutName);
        }
    }

    public void removeTaskLoadout(String taskName) {
        taskLoadouts.remove(taskName);
        markDirty();
    }

    public Map<String, String> getTaskLoadouts() {
        return new HashMap<>(taskLoadouts);
    }

    public String getDefaultLoadout() {
        return data != null ? data.getDefaultLoadout() : null;
    }
    
    /**
     * Sets the default loadout to be used by the script
     * @param loadoutName The name of the loadout to set as default
     */
    public void setDefaultLoadout(String loadoutName) {
        if (data == null) {
            data = new ProfileData();
        }
        data.setDefaultLoadout(loadoutName);
        markDirty();
        Logger.log("Set default loadout to: " + loadoutName);
    }

    // Add getter and setter for useShop


    public boolean hasLoadedProfile() {
        return data != null;
    }



    public int getLootValueThreshold() {
        return lootValueThreshold;
    }

    public void setLootValueThreshold(int threshold) {
        this.lootValueThreshold = threshold;
        markDirty();
    }


    /**
     * Calculate supply quantities for a specific NPC task
     *
     * @param npc The slayer NPC
     * @param taskSize The size of the task
     * @return Map of supply names to calculated quantities
     */


    /**
     * Get the selected supplies for a specific NPC task (without quantities)
     *
     * @param npc The slayer NPC
     * @return Set of selected supply names
     */


    /**
     * Checks if the script should temporarily use the Grand Exchange for the current operation.
     * This is different from isUsingGrandExchange() which checks if GE is enabled in settings.
     *
     * This method is used for temporary GE operations triggered by other nodes,
     * such as when the banking node needs to purchase missing supplies.
     *
     * @return true if the script should currently use the Grand Exchange, false otherwise
     */
    public boolean isUseGrandExchange() {
        return useGrandExchange;
    }

    public SulphurSettingsTab getParentTab() {
        return parentTab;
    }

    public void setParentTab(SulphurSettingsTab tab) {
        this.parentTab = tab;
    }
}