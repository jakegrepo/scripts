package scripts.Sulphur.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.container.impl.equipment.EquipmentSlot;
import org.dreambot.api.methods.grandexchange.LivePrices;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.item.GroundItems;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.GroundItem;
import org.dreambot.api.wrappers.items.Item;
import scripts.Sulphur.Sulphur;
import scripts.Sulphur.SulphurConfig;
import scripts.Sulphur.SulphurGlobalState;
import scripts.Sulphur.data.SulphurLoadoutData;

import java.util.*;

public class LootingNode extends SimpleNode<SulphurConfig> {
    private final Sulphur script;
    private static final Set<String> LOOT_ITEMS = new HashSet<>(Arrays.asList(
            "Sulphurous essence", "Death rune", "Chaos rune","Coal","Iron ore","Nature rune","Silver ore","Mithril ore","Sulphur blades","Archaic emblem (tier 1)","Archaic emblem (tier 5)"
    ));

    private String currentLootingItem = null;
    private long lootingStartTime = 0;
    private static final long LOOTING_TIMEOUT = 5000; // 5 seconds timeout
    
    // Track our kill locations
    private final Set<Tile> ourKillLocations = new HashSet<>();
    private static final long KILL_LOCATION_EXPIRY = 60000; // 60 seconds
    private final Map<Tile, Long> killTimestamps = new HashMap<>();
    
    // Maximum distance to loot from our kill
    private static final int MAX_LOOT_DISTANCE = 5;

    public LootingNode(SulphurConfig config, Sulphur script) {
        super("Looting", 1, config);
        this.script = script;
    }
    
    /**
     * Registers a kill at the specified location
     * @param location The tile where the kill occurred
     */
    public void registerKill(Tile location) {
        if (location != null) {
            ourKillLocations.add(location);
            killTimestamps.put(location, System.currentTimeMillis());
            Logger.log("Registered kill at location: " + location);
        }
    }
    
    /**
     * Cleans up expired kill locations
     */
    private void cleanupExpiredKillLocations() {
        long currentTime = System.currentTimeMillis();
        Iterator<Map.Entry<Tile, Long>> iterator = killTimestamps.entrySet().iterator();
        
        while (iterator.hasNext()) {
            Map.Entry<Tile, Long> entry = iterator.next();
            if (currentTime - entry.getValue() > KILL_LOCATION_EXPIRY) {
                ourKillLocations.remove(entry.getKey());
                iterator.remove();
                Logger.log("Removed expired kill location: " + entry.getKey());
            }
        }
    }
    
    /**
     * Checks if a ground item is near one of our kill locations
     * @param item The ground item to check
     * @return true if the item is near one of our kill locations
     */
    private boolean isNearOurKill(GroundItem item) {
        if (ourKillLocations.isEmpty()) {
            return false; // No registered kills
        }
        
        Tile itemTile = item.getTile();
        for (Tile killLocation : ourKillLocations) {
            if (itemTile.distance(killLocation) <= MAX_LOOT_DISTANCE) {
                return true;
            }
        }
        
        return false;
    }

    @Override
    public boolean validate() {
        if (!isReadyToExecute()) return false;

        try {
            // Clean up expired kill locations
            cleanupExpiredKillLocations();
            
            // Reset stale looting state
            if (currentLootingItem != null) {
                long timeSpentLooting = System.currentTimeMillis() - lootingStartTime;
                if (timeSpentLooting > LOOTING_TIMEOUT) {
                    log("Resetting stale looting state for: " + currentLootingItem);
                    currentLootingItem = null;
                    lootingStartTime = 0;
                }
            }

            // If inventory is full, we should not validate
            if (Inventory.isFull()) {
                return false;
            }

            // Check for lootable items on ground with additional verification
            GroundItem[] lootItems = GroundItems.all(item -> {
                try {
                    return item != null &&
                            item.getName() != null &&
                            LOOT_ITEMS.contains(item.getName()) &&
                            item.exists() &&
                            item.canReach() &&
                            item.distance() <= MAX_LOOT_DISTANCE &&
                            isNearOurKill(item); // Only loot items near our kills
                } catch (Exception e) {
                    log("Error checking loot item: " + e.getMessage());
                    return false;
                }
            }).toArray(new GroundItem[0]);

            boolean hasGroundLoot = lootItems != null && lootItems.length > 0;

            // If we're not currently looting anything and there's nothing to do, return false
            if (currentLootingItem == null && !hasGroundLoot) {
                return false;
            }

            return true;

        } catch (Exception e) {
            log("Error in validate(): " + e.getMessage());
            return false;
        }
    }

    @Override
    protected int onExecute() {
        try {
            // Reset status if we're not actively looting
            if (currentLootingItem == null) {
                status("Looking for loot");
            }

            // Handle ground items with error handling
            GroundItem[] lootItems = GroundItems.all(item -> {
                try {
                    return item != null &&
                            item.getName() != null &&
                            LOOT_ITEMS.contains(item.getName()) &&
                            item.exists() &&
                            item.canReach() &&
                            item.distance() <= MAX_LOOT_DISTANCE &&
                            isNearOurKill(item); // Only loot items near our kills
                } catch (Exception e) {
                    log("Error filtering loot items: " + e.getMessage());
                    return false;
                }
            }).toArray(new GroundItem[0]);

            if (lootItems != null) {
                for (GroundItem loot : lootItems) {
                    try {
                        if (loot == null || !loot.exists() || !loot.canReach()) {
                            continue;
                        }

                        String itemName = loot.getName();
                        if (itemName == null) continue;

                        if (Inventory.isFull()) {
                            return 600;
                        }

                        int initialCount = Inventory.count(itemName);
                        if (loot.interact("Take")) {
                            currentLootingItem = itemName;
                            lootingStartTime = System.currentTimeMillis();
                            status("Looting " + itemName);
                            boolean looted = sleepUntil(() -> {
                                try {
                                    return !loot.exists() ||
                                            Inventory.count(itemName) > initialCount;
                                } catch (Exception e) {
                                    log("Error in loot sleepUntil: " + e.getMessage());
                                    return true;
                                }
                            }, 3000);

                            if (!looted) {
                                log("Failed to loot " + itemName + ", skipping...");
                                currentLootingItem = null;
                                continue;
                            }

                            // Reset looting state after successful loot
                            currentLootingItem = null;
                            lootingStartTime = 0;
                            
                            // Calculate how many items were actually looted
                            int lootedAmount = Inventory.count(itemName) - initialCount;
                            if (lootedAmount > 0) {
                                // Get the item ID and update the loot value
                                Item inventoryItem = Inventory.get(itemName);
                                if (inventoryItem != null) {
                                    int itemId = inventoryItem.getID();
                                    // Check if the item is a supply or equipment item before tracking it as loot
                                    if (!isSupplyItem(itemId) && !isEquipmentItem(itemId)) {
                                        int price = LivePrices.getLow(itemId);
                                        // Directly update the loot value in SulphurGlobalState
                                        SulphurGlobalState.addLootItem(itemId, lootedAmount);
                                        Logger.log("Successfully looted " + lootedAmount + "x " + itemName + " (value: " + (price * lootedAmount) + " gp)");
                                    } else {
                                        Logger.log("Looted " + lootedAmount + "x " + itemName + " but not counting as loot (supply/equipment item)");
                                    }
                                } else {
                                    Logger.log("Successfully looted " + itemName + " but couldn't find it in inventory");
                                }
                            } else {
                                Logger.log("Successfully looted " + itemName);
                            }
                        }
                    } catch (Exception e) {
                        log("Error processing loot item: " + e.getMessage());
                    }
                }
            }

            return 600;

        } catch (Exception e) {
            log("Error in onExecute(): " + e.getMessage());
            currentLootingItem = null;
            lootingStartTime = 0;
            return 600;
        }
    }

    /**
     * Checks if an item is a supply item based on the script's configuration
     * @param itemId The item ID to check
     * @return true if the item is a supply item
     */
    private boolean isSupplyItem(int itemId) {
        // Check all supply types from config
        Map<String, Integer> supplies = config.getSupplies();
        if (supplies == null || supplies.isEmpty()) return false;
        
        return supplies.keySet().stream()
            .anyMatch(name -> {
                Item item = Inventory.get(name);
                return item != null && item.getID() == itemId;
            }) || isFoodOrPotion(itemId);
    }
    
    /**
     * Checks if an item is food or a potion
     * @param itemId The item ID to check
     * @return true if the item is food or a potion
     */
    private boolean isFoodOrPotion(int itemId) {
        // Matches SulphurBankingNode's food check logic
        Item item = Inventory.get(itemId);
        return item != null && (item.hasAction("Eat") || item.hasAction("Drink"));
    }
    
    /**
     * Checks if an item is an equipment item
     * @param itemId The item ID to check
     * @return true if the item is an equipment item
     */
    private boolean isEquipmentItem(int itemId) {
        // Check if the item is currently equipped
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            Item equippedItem = Equipment.getItemInSlot(slot);
            if (equippedItem != null && equippedItem.getID() == itemId) {
                return true;
            }
        }
        
        // Check if the item has equip actions
        Item item = Inventory.get(itemId);
        return item != null && (item.hasAction("Wield") || item.hasAction("Wear") || item.hasAction("Equip"));
    }

    private boolean tryEatFoodForSpace() {
        Item food = Inventory.get(item -> item != null && item.hasAction("Eat"));
        if (food != null) {
            status("Eating " + food.getName() + " to make space");
            int initialCount = Inventory.count(food.getName());
            if (food.interact("Eat")) {
                return Sleep.sleepUntil(() -> Inventory.count(food.getName()) < initialCount, 1200);
            }
        }
        return false;
    }
} 