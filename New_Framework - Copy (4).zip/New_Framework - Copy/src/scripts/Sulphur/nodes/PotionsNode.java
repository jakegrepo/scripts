package scripts.Sulphur.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import scripts.Sulphur.SulphurConfig;

import java.util.Arrays;

public class PotionsNode extends SimpleNode<SulphurConfig> {
    // Constants for the Sulphur script
    private static final int SUPPLY_CRATE_ID = 51371;
    private static final int ENTRANCE_ID = 51375;
    private static final Tile SUPPLY_CRATE_TILE = new Tile(1348, 9582, 0);
    private static final Tile ENTRANCE_TILE = new Tile(1345, 9590, 0);
    private static final int MIN_VIALS_REQUIRED = 6;
    
    // Define the training area (same as in CombatNode)
    private static final Area TRAINING_AREA = new Area(1343, 9597, 1392, 9536);
    // Define an area slightly larger than the training area to include nearby regions
    private static final Area NEAR_TRAINING_AREA = new Area(1338, 9602, 1397, 9531);
    
    private enum SupplyState {
        GATHER_VIALS, ENTER_RESOURCE_AREA
    }
    
    private SupplyState currentState = SupplyState.GATHER_VIALS;

    public PotionsNode(SulphurConfig config) {
        super("Gather Potion Supplies", 1, config);
    }

    @Override
    public boolean validate() {
        // Check if we're in or near the training area
        if (!NEAR_TRAINING_AREA.contains(Players.getLocal())) {
            return false;
        }
        int foodCount = Inventory.count(i -> i != null
                && !i.isNoted() && i.hasAction("Eat"));
        // If we're at Ferox with low food, bank
        if (foodCount == 0) {
            Logger.log("No food, banking!");
            return false;
        }
        // Check if we need to gather vials
        int vialCount = Inventory.count("Vial of water");
        int potionCount = Inventory.count(item -> 
            item != null && item.getName().contains("Moonlight potion"));
        
        // If we already have enough potions, don't validate
        if (potionCount >= 1) {
            return false;
        }
        
        // If we have enough vials, don't validate this node
        if (vialCount >= MIN_VIALS_REQUIRED) {
            return false;
        }
        
        // Validate if we need to gather vials - this should be the first priority
        return true;
    }

    @Override
    protected int onExecute() {
        try {
            switch (currentState) {
                case GATHER_VIALS:
                    return gatherVials();
                case ENTER_RESOURCE_AREA:
                    return enterResourceArea();
                default:
                    return 100;
            }
        } catch (Exception e) {
            setStatus("Error: " + e.getMessage());
            return 600;
        }
    }

    private int gatherVials() {
        GameObject supplyCrate = GameObjects.closest(SUPPLY_CRATE_ID);
        
        if (supplyCrate == null) {
            setStatus("Supply crate not found, walking to location");
            
            // Check if player is already moving or animating
            if (Players.getLocal().isMoving() || Players.getLocal().isAnimating()) {
                Logger.log("Player is already moving, waiting to complete movement");
                return 1000; // Short delay to check again
            }
            
            if (Walking.walk(SUPPLY_CRATE_TILE)) {
                Logger.log("Started walking to supply crate location");
                // Wait until player reaches destination or stops moving
                boolean reached = Sleep.sleepUntil(
                    () -> GameObjects.closest(SUPPLY_CRATE_ID) != null || 
                         (!Players.getLocal().isMoving() && !Players.getLocal().isAnimating()),
                    5000
                );
                
                if (reached && GameObjects.closest(SUPPLY_CRATE_ID) != null) {
                    Logger.log("Found supply crate");
                } else {
                    Logger.log("Movement interrupted or failed to find supply crate");
                }
                return 1200; // Give some time before next check
            } else {
                Logger.log("Failed to start walking to supply crate location");
                return 1800; // Longer delay if walking failed to start
            }
        }
        
        // Check if we need to walk to the crate
        if (supplyCrate.distance() > 5) {
            setStatus("Walking to supply crate");
            
            // Check if player is already moving or animating
            if (Players.getLocal().isMoving() || Players.getLocal().isAnimating()) {
                Logger.log("Player is already moving, waiting to complete movement");
                return 1000; // Short delay to check again
            }
            
            if (Walking.walk(supplyCrate)) {
                Logger.log("Started walking to supply crate");
                // Wait until player reaches destination or stops moving
                boolean reached = Sleep.sleepUntil(
                    () -> supplyCrate.distance() <= 5 || 
                         (!Players.getLocal().isMoving() && !Players.getLocal().isAnimating()),
                    5000
                );
                
                if (reached && supplyCrate.distance() <= 5) {
                    Logger.log("Reached supply crate");
                } else {
                    Logger.log("Movement interrupted or failed to reach supply crate");
                }
                return 1200; // Give some time before next check
            } else {
                Logger.log("Failed to start walking to supply crate");
                return 1800; // Longer delay if walking failed to start
            }
        }
        
        // Take vials from the crate
        setStatus("Taking vials from supply crate");
        if (supplyCrate.interact("Take-from <col=00ffff>Herblore")) {
            Logger.log(Arrays.toString(supplyCrate.getActions()));
            sleepUntil(Dialogues::inDialogue, 5000);
        }
        if (Dialogues.inDialogue() && !Dialogues.canContinue()) {
            Dialogues.chooseFirstOptionContaining("Take herblore supplies.");
            sleepUntil(() -> Inventory.count("Vial of water") >= MIN_VIALS_REQUIRED, 3000);

            // Check if we have enough vials now
            if (Inventory.count("Vial of water") >= MIN_VIALS_REQUIRED) {
                setStatus("Gathered enough vials");
                currentState = SupplyState.ENTER_RESOURCE_AREA;
                return 100;
            }
            
            return 600;
        }
        
        return 2000;
    }
    
    private int enterResourceArea() {
        GameObject entrance = GameObjects.closest(ENTRANCE_ID);
        
        if (entrance == null) {
            setStatus("Entrance not found, walking to location");
            
            // Check if player is already moving or animating
            if (Players.getLocal().isMoving() || Players.getLocal().isAnimating()) {
                Logger.log("Player is already moving, waiting to complete movement");
                return 1000; // Short delay to check again
            }
            
            if (Walking.walk(ENTRANCE_TILE)) {
                Logger.log("Started walking to entrance location");
                // Wait until player reaches destination or stops moving
                boolean reached = Sleep.sleepUntil(
                    () -> GameObjects.closest(ENTRANCE_ID) != null || 
                         (!Players.getLocal().isMoving() && !Players.getLocal().isAnimating()),
                    5000
                );
                
                if (reached && GameObjects.closest(ENTRANCE_ID) != null) {
                    Logger.log("Found entrance");
                } else {
                    Logger.log("Movement interrupted or failed to find entrance");
                }
                return 1200; // Give some time before next check
            } else {
                Logger.log("Failed to start walking to entrance location");
                return 1800; // Longer delay if walking failed to start
            }
        }
        
        // Check if we need to walk to the entrance
        if (entrance.distance() > 3) {
            setStatus("Walking to resource entrance");
            
            // Check if player is already moving or animating
            if (Players.getLocal().isMoving() || Players.getLocal().isAnimating()) {
                Logger.log("Player is already moving, waiting to complete movement");
                return 1000; // Short delay to check again
            }
            
            if (Walking.walk(entrance)) {
                Logger.log("Started walking to entrance");
                // Wait until player reaches destination or stops moving
                boolean reached = Sleep.sleepUntil(
                    () -> entrance.distance() <= 3 || 
                         (!Players.getLocal().isMoving() && !Players.getLocal().isAnimating()),
                    5000
                );
                
                if (reached && entrance.distance() <= 3) {
                    Logger.log("Reached entrance");
                } else {
                    Logger.log("Movement interrupted or failed to reach entrance");
                }
                return 1200; // Give some time before next check
            } else {
                Logger.log("Failed to start walking to entrance");
                return 1800; // Longer delay if walking failed to start
            }
        }
        
        // Enter the resource area
        setStatus("Entering resource area");
        if (entrance.interact("Pass-through")) {
            sleepUntil(() -> !entrance.exists() || Players.getLocal().isMoving(), 3000);
            // Reset state for next time
            currentState = SupplyState.GATHER_VIALS;
            return 600;
        }
        
        return 1800;
    }

    @Override
    public void cleanup() {
        setStatus("Cleaning up potion supplies node");
    }
}