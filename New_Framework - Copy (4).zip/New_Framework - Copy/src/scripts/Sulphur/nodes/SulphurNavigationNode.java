package scripts.Sulphur.nodes;

import org.dreambot.api.methods.walking.pathfinding.impl.web.WebFinder;
import org.dreambot.api.methods.walking.web.node.AbstractWebNode;
import org.dreambot.api.methods.walking.web.node.impl.BasicWebNode;
import org.dreambot.api.methods.walking.web.node.impl.EntranceWebNode;
import org.dreambot.api.utilities.Logger;

public class SulphurNavigationNode {
    
    public static void initializeSulphurPath() {
        // Get all required global web nodes
        AbstractWebNode node6472 = WebFinder.getWebFinder().get(6472); // Surface trapdoor
        AbstractWebNode node6436 = WebFinder.getWebFinder().get(6436); // Underground after trapdoor
        AbstractWebNode node6439 = WebFinder.getWebFinder().get(6439);
        AbstractWebNode node6440 = WebFinder.getWebFinder().get(6440);
        AbstractWebNode node6441 = WebFinder.getWebFinder().get(6441);
        AbstractWebNode node6464 = WebFinder.getWebFinder().get(6464);
        AbstractWebNode node6463 = WebFinder.getWebFinder().get(6463);

        if (node6472 == null || node6436 == null || node6463 == null) {
            Logger.error("Failed to find critical global web nodes");
            return;
        }

        try {
            // First remove existing connections that we want to override
            if (node6472 != null && node6436 != null) {
                node6472.removeConnections(node6436);
                node6436.removeConnections(node6472);
            }

            // Create trapdoor entrance node with force next
            EntranceWebNode trapdoorEntrance = new EntranceWebNode(3008, 3150, 0, "Trapdoor", "Climb-down") {
                @Override
                public boolean forceNext() {
                    return true;
                }
            };

            // Connect trapdoor to global web and underground
            trapdoorEntrance.addDualConnections(node6472);
            trapdoorEntrance.addDualConnections(node6436);

            // Add trapdoor to web finder
            WebFinder.getWebFinder().addWebNode(trapdoorEntrance);

            // Remove existing connections in the underground path
            node6436.removeConnections(node6439);
            node6439.removeConnections(node6440);
            node6440.removeConnections(node6441);
            node6441.removeConnections(node6464);
            node6464.removeConnections(node6463);

            // Force new connections through the underground path
            node6436.addDualConnections(node6439);
            node6439.addDualConnections(node6440);
            node6440.addDualConnections(node6441);
            node6441.addDualConnections(node6464);
            node6464.addDualConnections(node6463);

            // Create tunnel entrance node
            EntranceWebNode tunnelEntrance = new EntranceWebNode(2991, 9591, 0, "Tunnel", "Enter") {
                @Override
                public boolean forceNext() {
                    return true;
                }
            };

            // Connect tunnel entrance to node6463
            tunnelEntrance.addDualConnections(node6463);
            WebFinder.getWebFinder().addWebNode(tunnelEntrance);

            // Create and connect the path nodes
            AbstractWebNode[] pathNodes = new AbstractWebNode[] {
                new BasicWebNode(2984, 9591, 0),
                new BasicWebNode(2979, 9592, 0),
                new BasicWebNode(2973, 9591, 0),
                new BasicWebNode(2969, 9589, 0),
                new BasicWebNode(2965, 9585, 0),
                new BasicWebNode(2964, 9581, 0),
                new BasicWebNode(2959, 9578, 0),
                new BasicWebNode(2956, 9575, 0),
                new BasicWebNode(2952, 9574, 0),
                new BasicWebNode(2949, 9574, 0)
            };

            // Connect tunnel to first path node
            tunnelEntrance.addDualConnections(pathNodes[0]);

            // Connect path nodes in sequence
            for (int i = 0; i < pathNodes.length - 1; i++) {
                pathNodes[i].addDualConnections(pathNodes[i + 1]);
            }

            // Add all path nodes to web finder
            for (AbstractWebNode node : pathNodes) {
                WebFinder.getWebFinder().addWebNode(node);
            }

            Logger.info("Sulphur navigation web initialized successfully");
        } catch (Exception e) {
            Logger.error("Error initializing Sulphur navigation web: " + e.getMessage());
        }
    }
    
    static {
        initializeSulphurPath();
    }
} 