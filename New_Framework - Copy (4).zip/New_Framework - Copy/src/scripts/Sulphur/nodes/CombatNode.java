package scripts.Sulphur.nodes;

import core.base.SimpleNode;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Character;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.interactive.Player;
import scripts.Sulphur.Sulphur;
import scripts.Sulphur.SulphurConfig;
import scripts.Sulphur.SulphurGlobalState;
import scripts.Sulphur.utils.SupplyManager;

import java.util.*;
import java.util.stream.Collectors;

public class CombatNode extends SimpleNode<SulphurConfig> implements GameTickListener {
    // New Sulphur Boss IDs and graphic object IDs
    private static final int SULHPUR_NPC_ID       = 13033; // Branda the Fire Queen
    private long lastLocationUpdate = 0;
    private static final long LOCATION_UPDATE_INTERVAL = 1000;
    private static final Set<Integer> BOSS_IDS = new HashSet<>(Arrays.asList(
            SULHPUR_NPC_ID));
    Area trainingArea = new Area(1343, 9597, 1392, 9536);
    Area moveArea = new Area(1345, 9583, 1385, 9541);
    private final Sulphur script;
    private boolean isTestMode = false;
    // New flags to track if bosses can be melee-attacked
    private boolean canMeleeIceBoss = false;
    private boolean canMeleeFireBoss = false;
    private boolean useMelee = false;

    // Flag to indicate that asynchronous gear switching for ice elementals is in progress.

    // Instance area boundaries (updated dynamically)
    private Tile topLeftBoundary;
    private Tile topRightBoundary;
    private Tile bottomRightBoundary;
    private Tile bottomLeftBoundary;

    // NEW: Add gearSwap node instance to delegate gear switching.

    private NPC currentTarget = null; // Add this field to track our current target
    private boolean killTracked = false; // Track if we've counted the current kill
    private long targetAcquiredTime = 0;
    private static final long TARGET_TIMEOUT = 5000; // 5 seconds

    // Add reference to LootingNode
    private LootingNode lootingNode;

    public CombatNode(SulphurConfig config, Sulphur script) {
        super("Combat", 5, config);
        this.script = script;
        Client.getInstance().getScriptManager().addListener(this);
    }



    public void setupTestMode() {
        isTestMode = true;
        Logger.log("[TEST MODE] Test mode activated. Prayer flicker is managed by main script.");
    }

    @Override
    public boolean validate() {
        try {

            if (isTestMode) {
                return true;
            }
            
            // Check if we have enough potions for combat using the SupplyManager
            if (!SupplyManager.hasEnoughPotionsForCombat()) {
                return false; // Don't validate if we don't have potions
            }
            
            // Check if we still have grub paste or vials that should be used first
            if (Inventory.contains("Moonlight grub paste") && Inventory.contains("Vial of water")) {
                return false; // Don't validate if we still have materials to make potions
            }
            if (trainingArea.contains(Players.getLocal())){
                return true;
            }
            NPC sulphurNPC = NPCs.closest(SULHPUR_NPC_ID);

            return ((sulphurNPC != null && sulphurNPC.exists()) || (sulphurNPC != null && sulphurNPC.exists()));
        } catch (Exception e) {
            context.getLogger().error("Error in CombatNode validate: " + e.getMessage());
            return false;
        }
    }

    @Override
    protected int onExecute() {
        try {

            // Check if our current target died between executions
            if (currentTarget != null && isNpcDead(currentTarget)) {
                // Simplified kill tracking - just check if the NPC is dead and has 0 health
                if (!killTracked && currentTarget.getHealthPercent() == 0) {
                    Logger.log("Sulphur kill detected! NPC Index: " + currentTarget.getIndex() + ", ID: " + currentTarget.getID());
                    Sulphur.incrementTotalKills();
                    killTracked = true;
                }
                currentTarget = null;
                Logger.log("Current target is dead or no longer exists");
            }
            
            // NEW: Add timeout check for current target
            if (currentTarget != null) {
                long timeWithTarget = System.currentTimeMillis() - targetAcquiredTime;
                if (timeWithTarget > TARGET_TIMEOUT && !Players.getLocal().isInCombat() && 
                    !Players.getLocal().isInteracting(currentTarget)) {
                    Logger.log("Target timeout reached - switching targets");
                    currentTarget = null;
                }
            }
            
            if (currentTarget == null && NPCs.closest(13033).distance(Players.getLocal()) >= 10) {
                // Check if player is already moving or animating
                if (Players.getLocal().isMoving() || Players.getLocal().isAnimating()) {
                    Logger.log("Player is already moving, waiting to complete movement");
                    return 1000; // Short delay to check again
                }
                
                Logger.log("No target and too far from boss area, walking closer");
                if (Walking.walk(moveArea)) {
                    Logger.log("Started walking to move area");
                    // Wait until player reaches destination or stops moving
                    boolean reached = Sleep.sleepUntil(
                        () -> moveArea.contains(Players.getLocal()) || 
                             (!Players.getLocal().isMoving() && !Players.getLocal().isAnimating()),
                        5000
                    );
                    
                    if (reached && moveArea.contains(Players.getLocal())) {
                        Logger.log("Reached move area");
                    } else {
                        Logger.log("Movement interrupted or failed to reach destination");
                    }
                    return 1200; // Give some time before next check
                } else {
                    Logger.log("Failed to start walking to move area");
                    return 1800; // Longer delay if walking failed to start
                }
            }
            // FIRST PRIORITY: Check if any NPC is attacking us
            NPC attackingUs = findNpcAttackingUs();
            if (attackingUs != null) {
                // If we're already targeting this NPC, just continue
                if (currentTarget != null && currentTarget.equals(attackingUs)) {
                    // If we're not interacting with our target, attack it
                    if (!Players.getLocal().isInteracting(currentTarget)) {
                        Logger.log("Re-attacking NPC that's attacking us: " + currentTarget.getName());
                        if (currentTarget.interact("Attack")) {
                            Sleep.sleepUntil(() -> Players.getLocal().isInteracting(currentTarget), 600);
                        }
                    }
                } else {
                    // We need to switch to the NPC that's attacking us
                    Logger.log("Switching to NPC that's attacking us: " + attackingUs.getName());
                    currentTarget = attackingUs;
                    resetKillTracking();
                    if (currentTarget.interact("Attack")) {
                        Sleep.sleepUntil(() -> Players.getLocal().isInteracting(currentTarget), 600);
                    }
                }
                return 600; // Keep checking our current target
            }

            // SECOND PRIORITY: If we have a current target, check if it's still valid
            if (currentTarget != null) {
                if (isNpcDead(currentTarget)) {
                    // Simplified kill tracking - just check if the NPC is dead and has 0 health
                    if (!killTracked && currentTarget.getHealthPercent() == 0) {
                        Logger.log("Sulphur kill detected! NPC Index: " + currentTarget.getIndex() + ", ID: " + currentTarget.getID());
                        Sulphur.incrementTotalKills();
                        killTracked = true;
                    }
                    currentTarget = null;
                    Logger.log("Current target is dead or no longer exists");
                } else if (isTargetInCombatWithOther(currentTarget)) {
                    // Target is now in combat with someone else
                    Logger.log("Current target is now in combat with another player");
                    currentTarget = null;
                } else {
                    // If we're not interacting with our target, attack it
                    if (!Players.getLocal().isInteracting(currentTarget)) {
                        if (currentTarget.interact("Attack")) {
                            Sleep.sleepUntil(() -> Players.getLocal().isInteracting(currentTarget), 600);
                        }
                    }
                }
                return 600; // Keep checking our current target
            }

            // THIRD PRIORITY: Find a new target if we don't have one
            NPC bestTarget = findBestTarget();
            
            if (bestTarget == null) {
                // Try a more direct approach to find any Sulphur NPC
                List<NPC> allSulphurNpcs = NPCs.all(npc -> 
                    npc != null && npc.exists() && npc.getID() == SULHPUR_NPC_ID && npc.getHealthPercent() > 0);
                
                if (!allSulphurNpcs.isEmpty()) {
                    // Just pick the closest one regardless of other criteria
                    bestTarget = allSulphurNpcs.stream()
                        .min(Comparator.comparingDouble(npc -> Players.getLocal().distance(npc)))
                        .orElse(null);
                    
                    if (bestTarget != null) {
                        Logger.log("Found a Sulphur NPC using direct search: " + bestTarget.getName() + 
                                 " (Index: " + bestTarget.getIndex() + ", Health: " + bestTarget.getHealthPercent() + "%)");
                    }
                }
                
                if (bestTarget == null) {
                    Logger.log("[BOSS] No available sulphur targets found - all are dead or in combat");
                    return 600;
                }
            }

            // Set new target and attack
            currentTarget = bestTarget;
            targetAcquiredTime = System.currentTimeMillis(); // Set acquisition time
            resetKillTracking();
            Logger.log("New target acquired: " + currentTarget.getName() + 
                       " (Distance: " + Players.getLocal().distance(currentTarget) + 
                       ", Health: " + currentTarget.getHealthPercent() + "%)");
            
            if (currentTarget.interact("Attack")) {
                Sleep.sleepUntil(() -> Players.getLocal().isInteracting(currentTarget), 600);
            }
            return 600;

        } catch (Exception e) {
            Logger.log("Error in Sulphur Boss CombatNode: " + e.getMessage());
            e.printStackTrace();
            return 600;
        }
    }

    /**
     * Finds any NPC that is currently attacking us
     * This is the highest priority target
     * 
     * @return The NPC attacking us, or null if none found
     */
    private NPC findNpcAttackingUs() {
        try {
            // Method 1: Check if any NPC is directly interacting with us
            NPC interactingWithUs = NPCs.closest(npc -> 
                npc != null && npc.exists() && 
                BOSS_IDS.contains(npc.getID()) && 
                npc.isInteracting(Players.getLocal()));
            
            if (interactingWithUs != null) {;
                return interactingWithUs;
            }
            
            // Method 2: Check if we're in combat and there's only one NPC nearby
            if (Players.getLocal().isInCombat()) {
                List<NPC> nearbyNpcs = NPCs.all(npc -> 
                    npc != null && npc.exists() && 
                    BOSS_IDS.contains(npc.getID()) && 
                    Players.getLocal().distance(npc) < 2);
                
                if (nearbyNpcs.size() == 1) {
                    Logger.log("We're in combat and there's only one NPC nearby: " + nearbyNpcs.get(0).getName() + 
                             " (Index: " + nearbyNpcs.get(0).getIndex() + ")");
                    return nearbyNpcs.get(0);
                }
            }
            
            // Method 3: Check if we're taking damage and there's only one NPC nearby
            if (Players.getLocal().getHealthPercent() < 100) {
                List<NPC> nearbyNpcs = NPCs.all(npc -> 
                    npc != null && npc.exists() && 
                    BOSS_IDS.contains(npc.getID()) && 
                    Players.getLocal().distance(npc) < 3);
                
                if (nearbyNpcs.size() == 1) {
                    Logger.log("We're taking damage and there's only one NPC nearby: " + nearbyNpcs.get(0).getName() + 
                             " (Index: " + nearbyNpcs.get(0).getIndex() + ")");
                    return nearbyNpcs.get(0);
                }
            }
            
            return null;
        } catch (Exception e) {
            Logger.log("Error in findNpcAttackingUs: " + e.getMessage());
            return null;
        }
    }

    /**
     * Finds the best target based on multiple criteria:
     * 1. Not in combat with another player
     * 2. Closest to player (primary sorting)
     * 3. Lowest health (secondary sorting)
     * 
     * @return The best NPC target or null if none found
     */
    private NPC findBestTarget() {
        // Find all Sulphur NPCs first to debug
        List<NPC> allSulphurNpcs = NPCs.all(npc -> npc != null && npc.exists() && npc.getID() == SULHPUR_NPC_ID);
        
        if (allSulphurNpcs.isEmpty()) {
            Logger.log("No Sulphur NPCs found at all in the area");
            return null;
        } else {
            Logger.log("Found " + allSulphurNpcs.size() + " total Sulphur NPCs in the area");
            // Log details of each NPC for debugging
            for (int i = 0; i < Math.min(allSulphurNpcs.size(), 5); i++) {
                NPC npc = allSulphurNpcs.get(i);
                Logger.log(String.format("Sulphur NPC %d: Index=%d, Health=%d%%, InCombat=%s, Distance=%.1f", 
                    i+1, npc.getIndex(), npc.getHealthPercent(), 
                    isTargetInCombatWithOther(npc), Players.getLocal().distance(npc)));
            }
        }
        
        // Find targets based on normal criteria, with proper filtering for NPCs in combat with others
        List<NPC> validTargets = allSulphurNpcs.stream()
            .filter(npc -> npc.getHealthPercent() > 0) // Filter out dead NPCs
            .filter(npc -> !isTargetInCombatWithOther(npc)) // Filter out NPCs in combat with other players
            .sorted(
                Comparator.comparingDouble(npc -> Players.getLocal().distance(npc))  // Primary sort: distance (closest first)
            )
            .collect(Collectors.toList());
        
        if (validTargets.isEmpty()) {
            Logger.log("No valid Sulphur targets found - all are dead or in combat with other players");
            return null;
        }
        
        // Log available targets for debugging
        if (validTargets.size() > 0) {
            Logger.log("Found " + validTargets.size() + " valid targets:");
            for (int i = 0; i < Math.min(validTargets.size(), 3); i++) {  // Limit to top 3 for cleaner logs
                NPC target = validTargets.get(i);
                Logger.log(String.format("  %d. %s (Distance: %.1f, Health: %d%%, Index: %d)", 
                    i+1, target.getName(), Players.getLocal().distance(target), 
                    target.getHealthPercent(), target.getIndex()));
            }
        }
        
        // Return the closest valid target
        return validTargets.isEmpty() ? null : validTargets.get(0);
    }
    
    /**
     * Checks if an NPC is already attacking the player
     * 
     * @param npc The NPC to check
     * @return true if the NPC is attacking the player
     */
    private boolean isAttackingUs(NPC npc) {
        try {
            // Check if NPC is performing attack animation AND targeting us
            if (npc.getAnimation() == 10988 &&
                    npc.getInteractingCharacter() != null &&
                    npc.getInteractingCharacter().equals(Players.getLocal())) {
                return true;
            }
            return false;
        } catch (Exception e) {
            Logger.log("Error in isAttackingUs: " + e.getMessage());
            return false;
        }
    }

    /**
     * Checks if a target is valid for attacking
     * 
     * @param npc The NPC to check
     * @return true if the target is valid, false otherwise
     */
    private boolean isValidTarget(NPC npc) {
        try {
            if (npc == null || !npc.exists() || npc.getHealthPercent() == 0) {
                return false;
            }
            
            // Check if the NPC is already in combat with another player
            if (isTargetInCombatWithOther(npc)) {
                Logger.log("NPC " + npc.getName() + " (Index: " + npc.getIndex() + ") is in combat with another player");
                return false;
            }
            
            // Method 1: Check if the NPC is attacking us
            if (isAttackingUs(npc)) {
                Logger.log("NPC " + npc.getName() + " (Index: " + npc.getIndex() + ") is attacking us");
                return true;
            }
            
            // Method 2: Check if we're in combat and this NPC is nearby
            if (Players.getLocal().isInCombat() && Players.getLocal().distance(npc) < 2) {
                // If we're in combat and this is the closest NPC, it's likely attacking us
                Logger.log("We're in combat and NPC " + npc.getName() + " (Index: " + npc.getIndex() + ") is very close");
                return true;
            }
            
            // Method 3: Check if we're taking damage and this is the only nearby NPC
            if (Players.getLocal().getHealthPercent() < 100 && Players.getLocal().distance(npc) < 3) {
                List<NPC> nearbyNpcs = NPCs.all(n -> 
                    n != null && n.exists() && n.getID() == SULHPUR_NPC_ID && 
                    Players.getLocal().distance(n) < 5);
                
                if (nearbyNpcs.size() == 1 && nearbyNpcs.get(0).equals(npc)) {
                    Logger.log("We're taking damage and NPC " + npc.getName() + " (Index: " + npc.getIndex() + ") is the only nearby NPC");
                    return true;
                }
            }
            
            // Method 4: If no other criteria match, consider any non-combat NPC as valid
            if (!npc.isInCombat()) {
                Logger.log("NPC " + npc.getName() + " (Index: " + npc.getIndex() + ") is not in combat and is available");
                return true;
            }
            
            return false;
        } catch (Exception e) {
            Logger.log("Error in isValidTarget: " + e.getMessage());
            return false;
        }
    }

    /**
     * Checks if a target NPC is in combat with another player
     * 
     * @param target The NPC to check
     * @return True if the NPC is in combat with another player
     */
    private boolean isTargetInCombatWithOther(NPC target) {
        try {
            if (target == null || !target.exists()) {
                return false;
            }
            
            // Method 1: Check if the NPC is in combat
            if (!target.isInCombat()) {
                return false; // Not in combat at all
            }
            
            // Method 2: Check if the NPC is interacting with us
            if (target.isInteracting(Players.getLocal())) {
                return false; // It's in combat with us, not someone else
            }
            
            // Method 3: Check if we're interacting with this NPC
            if (Players.getLocal().isInteracting(target)) {
                return false; // We're already fighting it
            }
            
            // Method 4: Check if the NPC is interacting with any other player
            Character interacting = target.getInteractingCharacter();
            if (interacting != null && interacting instanceof Player) {
                Player interactingPlayer = (Player) interacting;
                if (!interactingPlayer.equals(Players.getLocal())) {
                    Logger.log("NPC " + target.getName() + " (Index: " + target.getIndex() + ") is in combat with player: " + interactingPlayer.getName());
                    return true;
                }
            }
            
            // If we can't determine who it's in combat with, but it's in combat, assume it's with someone else
            if (target.isInCombat()) {
                Logger.log("NPC " + target.getName() + " (Index: " + target.getIndex() + ") appears to be in combat but we can't determine with whom");
                return true;
            }
            
            return false;
        } catch (Exception e) {
            Logger.log("Error in isTargetInCombatWithOther: " + e.getMessage());
            return false; // Default to false on error to avoid skipping potential targets
        }
    }

    /**
     * Checks for dangerous graphic objects (ice wall / fire wall)
     * and moves the player away if standing directly underneath them.
     */

    @Override
    public void cleanup() {
        Logger.log("Cleanup: Sulphur Boss CombatNode");
        Client.getInstance().getScriptManager().removeListener(this);
        currentTarget = null; // Reset target on cleanup
        super.cleanup();
    }

    @Override
    public void onServerTick() {
        try {
            // Check if our current target died
            if (currentTarget != null && isNpcDead(currentTarget)) {
                // Simplified kill tracking - just check if the NPC is dead and has 0 health
                if (!killTracked && currentTarget.getHealthPercent() == 0) {
                    Logger.log("Sulphur kill detected on server tick! NPC Index: " + currentTarget.getIndex() + ", ID: " + currentTarget.getID());
                    Sulphur.incrementTotalKills();
                    killTracked = true;
                    
                    // Register the kill location with the LootingNode
                    if (lootingNode != null) {
                        lootingNode.registerKill(currentTarget.getTile());
                        Logger.log("Registered kill location with LootingNode: " + currentTarget.getTile());
                    }
                }
            }
        } catch (Exception e) {
            Logger.log("Error in onServerTick: " + e.getMessage());
        }
    }

    /**
     * Checks if an NPC is dead or no longer exists
     * 
     * @param npc The NPC to check
     * @return True if the NPC is dead or no longer exists
     */
    private boolean isNpcDead(NPC npc) {
        try {
            if (npc == null) {
                return true;
            }
            
            if (!npc.exists()) {
                return true;
            }
            
            if (npc.getHealthPercent() <= 0) {
                return true;
            }
            
            return false;
        } catch (Exception e) {
            Logger.log("Error in isNpcDead: " + e.getMessage());
            return true; // Assume dead on error to avoid issues
        }
    }

    /**
     * Resets kill tracking for a new target
     */
    private void resetKillTracking() {
        // Simply reset the killTracked flag when we get a new target
        killTracked = false;
    }

    /**
     * Sets the LootingNode reference for kill registration
     * @param lootingNode The LootingNode instance
     */
    public void setLootingNode(LootingNode lootingNode) {
        this.lootingNode = lootingNode;
    }

}
