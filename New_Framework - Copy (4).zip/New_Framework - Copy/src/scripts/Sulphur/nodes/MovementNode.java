package scripts.Sulphur.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.NPC;
import scripts.Sulphur.SulphurConfig;
import scripts.Sulphur.data.SulphurLoadoutData;
import scripts.Sulphur.utils.ChargedItemUtils;

import java.util.Map;

public class MovementNode extends SimpleNode<SulphurConfig> {
    // The target tile for the Sulphur Boss instance entrance.
    private static final Tile ENTRANCE_TILE = new Tile(1388, 9569, 0);
    // Define an area around the entrance for convenience.
    private static final Area ENTRANCE_AREA = new Area(2947, 9572, 2951, 9576);
    Area trainingArea = new Area(1343, 9597, 1392, 9536);
    private static final Area RESOURCE_AREA = new Area(1362, 9691, 1406, 9666);
    public Area FEROX_ENCLAVE = new Area(3125, 3640, 3158, 3617);
    private static final int SULHPUR_NPC_ID       = 13033; // Branda the Fire Queen

    // Add a flag to track if we're currently walking
    private boolean isWalking = false;
    private long lastWalkTime = 0;
    private static final long WALK_COOLDOWN = 2000; // 2 seconds cooldown between walk attempts

    public MovementNode(SulphurConfig config) {
        super("Movement", 2, config);
    }

    @Override
    public boolean validate() {
        // Don't validate if a bank is open - let the banking node handle this
        if (Bank.isOpen()) {
            return false;
        }
        NPC sulphurNPC = NPCs.closest(SULHPUR_NPC_ID);

        // Only run movement logic if the player isn't in the boss instance
        if (sulphurNPC != null) {
            return false;
        }

        // Don't validate if in resource area with required materials
        if (RESOURCE_AREA.contains(Players.getLocal()) && Inventory.contains("Moonlight grub paste") && Inventory.contains("Vial of water")) {
            return false;
        }
        
        // Don't validate if player is already moving or animating
        if (Players.getLocal().isMoving() || Players.getLocal().isAnimating()) {
            return false;
        }
        
        // Don't validate if we recently started walking (cooldown)
        if (System.currentTimeMillis() - lastWalkTime < WALK_COOLDOWN) {
            return false;
        }
        
        // Check food requirements first
        int foodCount = Inventory.count(i -> i != null && !i.isNoted() && i.hasAction("Eat"));
        if (foodCount == 0) {
            Logger.log("No food, need to bank first!");
            return false;
        }
        
        // Get loadout from config - either default loadout or first available
        Map<String, SulphurLoadoutData> loadouts = config.getLoadouts();
        SulphurLoadoutData loadout = null;
        
        // Try to get the default loadout first
        String defaultLoadoutName = config.getDefaultLoadout();
        if (defaultLoadoutName != null && loadouts.containsKey(defaultLoadoutName)) {
            loadout = loadouts.get(defaultLoadoutName);
        } 
        // If no default loadout or it doesn't exist, use the first available loadout
        else if (!loadouts.isEmpty()) {
            loadout = loadouts.values().iterator().next();
        }
        
        // If no loadouts are configured, we can't continue
        if (loadout == null) {
            Logger.log("Required loadouts missing from configuration. Please create a loadout in settings.");
            return false;
        }
        
        // Validate that we have the required equipment
        if (loadout.getEquipment() != null && !loadout.getEquipment().isEmpty()) {
            for (Map.Entry<String, String> entry : loadout.getEquipment().entrySet()) {
                String slot = entry.getKey();
                String itemName = entry.getValue();
                
                // Skip if already equipped or in inventory
                if (Equipment.contains(itemName) || Inventory.contains(itemName)) {
                    continue;
                }
                
                // Special handling for charged items
                if (ChargedItemUtils.isChargedItem(itemName)) {
                    String baseItemName = itemName.split("\\(")[0].trim();
                    if (ChargedItemUtils.hasValidChargedItemInEquipment(baseItemName) ||
                            ChargedItemUtils.hasValidChargedItemInInventory(baseItemName)) {
                        continue;
                    }
                }
                
                // Check if this is a critical item
                if (isCriticalItem(itemName)) {
                    Logger.log("Missing critical equipment: " + itemName + ". Need to bank first.");
                    return false;
                }
            }
        }

        // All checks passed, we are ready to move
        return true;
    }

    /**
     * Determines if an item is critical for the script to function
     *
     * @param itemName The name of the item to check
     * @return true if the item is critical, false if it can be skipped
     */
    private boolean isCriticalItem(String itemName) {
        // Use the utility class to check if it's a charged item
        if (ChargedItemUtils.isChargedItem(itemName)) {
            return false; // Charged items are not critical
        }

        // Other non-critical items
        String[] nonCriticalItems = {
                "Amulet of fury", "Berserker ring", "Berserker ring (i)",
                "Amulet of torture", "Infernal cape", "Fire cape",
                "Avernic defender", "Dragon defender"
        };

        for (String nonCritical : nonCriticalItems) {
            if (itemName.equals(nonCritical)) {
                return false;
            }
        }

        return true;
    }

    @Override
    public int onExecute() {
        if (Bank.isOpen()) {
            Logger.log("Closing bank before moving");
            Bank.close();
            Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
            return 600;
        }

        // If the player is not in the entrance area, walk there
        if (!ENTRANCE_AREA.contains(Players.getLocal())) {
            status("Walking to Sulphurs");
            
            // If player is already moving, wait until movement completes
            if (Players.getLocal().isMoving() || Players.getLocal().isAnimating()) {
                Logger.log("Player is moving, waiting for movement to complete");
                Sleep.sleepUntil(() -> !Players.getLocal().isMoving() && !Players.getLocal().isAnimating(), 5000);
                return 600;
            }
            
            // Set walking flag and timestamp
            isWalking = true;
            lastWalkTime = System.currentTimeMillis();
            
            // Attempt to walk to the entrance tile
            if (Walking.walk(ENTRANCE_TILE)) {
                Logger.log("Started walking to entrance tile");
                
                // Wait for movement to start
                if (!Sleep.sleepUntil(() -> Players.getLocal().isMoving(), 3000)) {
                    Logger.log("Movement failed to start");
                    isWalking = false;
                    return 600;
                }
                
                // Wait until either:
                // 1. Player reaches the entrance area
                // 2. Player stops moving and isn't in the entrance area (need to try again)
                boolean reached = Sleep.sleepUntil(
                    () -> ENTRANCE_AREA.contains(Players.getLocal()) || 
                         (!Players.getLocal().isMoving() && !Players.getLocal().isAnimating()),
                    10000
                );
                
                isWalking = false;
                
                if (reached) {
                    if (ENTRANCE_AREA.contains(Players.getLocal())) {
                        Logger.log("Successfully reached entrance area");
                        return 600;
                    } else {
                        Logger.log("Movement completed but not at destination, will retry");
                        return 600;
                    }
                } else {
                    Logger.log("Movement timeout, will retry");
                    return 600;
                }
            } else {
                isWalking = false;
                Logger.log("Failed to start walking");
                return 600;
            }
        } else {
            Logger.log("Already at Sulphur entrance area");
        }
        
        return 600;
    }
}
