package scripts.Sulphur.nodes;

import core.base.SimpleNode;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.bank.BankLocation;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;
import scripts.Sulphur.SulphurConfig;
import scripts.Sulphur.SulphurGlobalState;
import scripts.Sulphur.data.SulphurLoadoutData;
import scripts.Sulphur.utils.ChargedItemUtils;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SulphurBankingNode extends SimpleNode<SulphurConfig> {
    private boolean transitioning = false;
    private boolean checkedGE = false;
    // This tile was formerly used for walking – now movement is handled separately.

    public SulphurBankingNode(SulphurConfig config) {
        super("Banking", 3, config);
    }

    // Example area used for healing via the Pool of Refreshment.
    public Area FEROX_ENCLAVE = new Area(3125, 3640, 3158, 3617);

    @Override
    public boolean validate() {
        int foodCount = Inventory.count(i -> i != null
                && !i.isNoted() && i.hasAction("Eat"));
        // If we're at Ferox with low food, bank
        if (foodCount == 0) {
            Logger.log("No food, banking!");
            return true;
        }

        return false;
    }

    /**
     * Checks if the player is in a player-owned house by looking for common POH objects
     * @return true if in a player-owned house, false otherwise
     */


    @Override
    protected int onExecute() {
        if (!Bank.isOpen()) {

            if (BankLocation.GRAND_EXCHANGE.getArea(5).contains(Players.getLocal().getTile())){
                Bank.open();
                Sleep.sleepUntil(Bank::open,5000);
                withdrawSupplies();
            }
            // Check if we're already at the bank location
            if (!BankLocation.CAM_TORUM.getArea(5).contains(Players.getLocal().getTile()) && !BankLocation.GRAND_EXCHANGE.getArea(5).contains(Players.getLocal().getTile())) {
                Logger.log("Walking to CAM_TORUM bank...");
                Walking.walk(BankLocation.CAM_TORUM);
                // Wait until we're at the bank location
                Sleep.sleepUntil(() -> BankLocation.CAM_TORUM.getArea(5).contains(Players.getLocal().getTile()), 2000);
                // If we're still not at the bank, return to try again
                if (!BankLocation.CAM_TORUM.getArea(5).contains(Players.getLocal().getTile())) {
                    Logger.log("Still walking to bank, continuing...");
                    return 600;
                }
            }
            
            // Now that we're at the bank, open it
            Logger.log("Opening bank at CAM_TORUM...");
            if (!Bank.open()) {
                Logger.log("Failed to open bank, will try again");
                return 600; // Return early to try again next cycle
            }
            
            // Wait to ensure bank is actually open
            Sleep.sleepUntil(Bank::isOpen, 3000);
            if (!Bank.isOpen()) {
                Logger.log("Bank still not open, will try again");
                return 600;
            }
        }

        // If we haven't checked GE yet, do it now.
        if (!checkedGE) {
            if (checkAndInitiateGE()) {
                checkedGE = true;
                reset();
                return 600;
            }
            checkedGE = true;
        }

        Set<String> itemsToKeep = new HashSet<>();



        // Add Rune Pouch if present.
        if (Inventory.contains("Rune pouch")) {
            itemsToKeep.add("Rune pouch");
        }
        // Keep Teleport to house if we have it.
        if (Inventory.contains("Teleport to house")) {
            itemsToKeep.add("Teleport to house");
        }


        // Deposit all except our protected items.
        if (!Bank.depositAllExcept(itemsToKeep.toArray(new String[0]))) {
            Logger.log("Failed to deposit items, closing bank and trying again");
            Bank.close();
            reset();
            return 600;
        }

        Sleep.sleepUntil(() -> Inventory.isEmpty() || Inventory.onlyContains(itemsToKeep.toArray(new String[0])), 3000);

        if (needsRestore() && FEROX_ENCLAVE.contains(Players.getLocal())){
            restorePool();
        }

        // Get loadout from config - only use the default loadout
        Map<String, SulphurLoadoutData> loadouts = config.getLoadouts();
        SulphurLoadoutData loadout = null;
        
        // Get the default loadout
        String defaultLoadoutName = config.getDefaultLoadout();
        if (defaultLoadoutName != null && loadouts.containsKey(defaultLoadoutName)) {
            loadout = loadouts.get(defaultLoadoutName);
            Logger.log("Using configured default loadout: " + defaultLoadoutName);
        } 
        // If no default loadout or it doesn't exist, use the first available loadout
        else if (!loadouts.isEmpty()) {
            loadout = loadouts.values().iterator().next();
            Logger.log("No default loadout configured, using first available: " + loadout.getName());
        }

        if (loadout == null) {
            Logger.log("No loadouts found in configuration. Please create a loadout in settings.");
            Bank.close();
            reset();
            return 600;
        }

        // Withdraw gear items for the loadout
        if (!withdrawLoadoutItems(loadout)) {
            if (checkAndInitiateGE()) {
                Bank.close();
                reset();
                return 600;
            }
            Bank.close();
            reset();
            return 600;
        }

        // Withdraw supplies from the bank based on the config's supplies mapping
        if (!withdrawSupplies()) {
            if (checkAndInitiateGE()) {
                Bank.close();
                reset();
                return 600;
            }
            Bank.close();
            reset();
            return 600;
        }
        
        // Close the bank before equipping items
        Bank.close();
        Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
        
        // Equip the loadout items
        if (!equipLoadoutItems(loadout)) {
            Logger.log("Failed to equip some loadout items");
        }

        return 600;
    }

    private boolean needsRestore() {
        return Skills.getBoostedLevel(Skill.HITPOINTS) < Skills.getRealLevel(Skill.HITPOINTS)
                || Skills.getBoostedLevel(Skill.PRAYER) < Skills.getRealLevel(Skill.PRAYER);
    }

    /**
     * Gets the default loadout from the config
     * @return The default loadout or null if none is available
     */
    private SulphurLoadoutData getDefaultLoadout() {
        String defaultLoadoutName = config.getDefaultLoadout();
        if (defaultLoadoutName != null) {
            Map<String, SulphurLoadoutData> loadouts = config.getLoadouts();
            if (loadouts != null && loadouts.containsKey(defaultLoadoutName)) {
                return loadouts.get(defaultLoadoutName);
            } else if (loadouts != null && !loadouts.isEmpty()) {
                // Return first available loadout if default not found
                return loadouts.values().iterator().next();
            }
        }
        return null;
    }

    private boolean checkAndInitiateGE() {
        if (!Bank.isOpen()) {
            Logger.log("Attempting to open bank...");
            if (Bank.open()) {
                Sleep.sleep(1000);
            } else {
                Sleep.sleepUntil(Bank::isOpen, 3000);
                return true;
            }
        }
        
        if (!config.isUsingGrandExchange()) return false;

        SulphurGENode geNode = context.tasks().getNodes().stream()
            .filter(node -> node instanceof SulphurGENode)
            .map(node -> (SulphurGENode) node)
            .findFirst().orElse(null);

        if (geNode == null) return false;

        boolean needsItems = false;
        int multiplier = config.getSuppliesMultiplier();

        // Check all supplies from config
        Map<String, Integer> supplies = config.getSupplies();
        if (supplies != null && !supplies.isEmpty()) {
            for (Map.Entry<String, Integer> entry : supplies.entrySet()) {
                String itemName = entry.getKey();
                int baseRequired = entry.getValue();
                
                // Special handling for Ring of dueling
                if (itemName.startsWith("Ring of dueling")) {
                    // Count all rings with charges (2-8)
                    int bankCount = Bank.count(i -> 
                        i != null && i.getName().startsWith("Ring of dueling(") && 
                        !i.getName().equals("Ring of dueling(1)"));
                    
                    if (bankCount < baseRequired) {
                        int amountToBuy = (baseRequired * multiplier) - bankCount;
                        Logger.log("GE: Need " + amountToBuy + " Ring of dueling(8)" + 
                                 " (Have: " + bankCount + ", Require: " + (baseRequired * multiplier) + ")");
                        geNode.addItem("Ring of dueling(8)", amountToBuy);
                        needsItems = true;
                    }
                    continue;
                }
                
                int bankCount = Bank.count(itemName);
                
                if (bankCount < baseRequired) {
                    int amountToBuy = (baseRequired * multiplier) - bankCount;
                    Logger.log("GE: Need " + amountToBuy + " " + itemName + 
                             " (Have: " + bankCount + ", Require: " + (baseRequired * multiplier) + ")");
                    geNode.addItem(itemName, amountToBuy);
                    needsItems = true;
                }
            }
        }

        // Check food
        if (!config.getFoodNames().isEmpty()) {
            String foodName = config.getFoodNames().get(0);
            int baseRequired = config.getTargetFoodCount();
            int bankCount = Bank.count(foodName);
            
            if (bankCount < baseRequired) {
                int amountToBuy = (baseRequired * multiplier) - bankCount;
                Logger.log("GE: Need " + amountToBuy + " " + foodName + 
                         " (Have: " + bankCount + ", Require: " + (baseRequired * multiplier) + ")");
                geNode.addItem(foodName, amountToBuy);
                needsItems = true;
            }
        }
        
        // Check gear items in the loadout
        SulphurLoadoutData loadout = getDefaultLoadout();
        if (loadout != null) {
            for (Map.Entry<String, String> entry : loadout.getEquipment().entrySet()) {
                String slot = entry.getKey();
                String itemName = entry.getValue();
                
                // Skip if already equipped or in inventory
                if (Equipment.contains(itemName) || Inventory.contains(itemName)) {
                    continue;
                }
                
                // Skip charged items - we'll buy the base version
                if (ChargedItemUtils.isChargedItem(itemName)) {
                    String baseItemName = itemName.split("\\(")[0].trim();
                    
                    // Skip if we already have this charged item
                    if (ChargedItemUtils.hasValidChargedItemInEquipment(baseItemName) || 
                        ChargedItemUtils.hasValidChargedItemInInventory(baseItemName) ||
                        ChargedItemUtils.hasValidChargedItemInBank(baseItemName)) {
                        continue;
                    }
                    
                    // For charged items, we'll buy the full charge version
                    if (baseItemName.equals("Ring of dueling")) {
                        Logger.log("GE: Need Ring of dueling(8) for loadout");
                        geNode.addItem("Ring of dueling(8)", 1);
                        needsItems = true;
                    } else if (baseItemName.equals("Ring of wealth")) {
                        Logger.log("GE: Need Ring of wealth(5) for loadout");
                        geNode.addItem("Ring of wealth(5)", 1);
                        needsItems = true;
                    } else if (baseItemName.equals("Skills necklace")) {
                        Logger.log("GE: Need Skills necklace(6) for loadout");
                        geNode.addItem("Skills necklace(6)", 1);
                        needsItems = true;
                    } else if (baseItemName.equals("Combat bracelet")) {
                        Logger.log("GE: Need Combat bracelet(6) for loadout");
                        geNode.addItem("Combat bracelet(6)", 1);
                        needsItems = true;
                    } else if (baseItemName.equals("Amulet of glory")) {
                        Logger.log("GE: Need Amulet of glory(6) for loadout");
                        geNode.addItem("Amulet of glory(6)", 1);
                        needsItems = true;
                    } else if (baseItemName.equals("Games necklace")) {
                        Logger.log("GE: Need Games necklace(8) for loadout");
                        geNode.addItem("Games necklace(8)", 1);
                        needsItems = true;
                    }
                    continue;
                }
                
                // For regular items, check if we need to buy them
                if (!Bank.contains(itemName) && isBuyableItem(itemName)) {
                    // For ammo slot, use the ammoQuantity. For other slots, buy 1.
                    int quantity = slot.equalsIgnoreCase("ammo") ? loadout.getAmmoQuantity() : 1;
                    Logger.log("GE: Need " + quantity + " " + itemName + " for loadout");
                    geNode.addItem(itemName, quantity);
                    needsItems = true;
                }
            }
        }

        if (needsItems) {
            geNode.setForceExecute(true);
            return true;
        }
        return false;
    }
    
    /**
     * Checks if an item can be bought on the Grand Exchange
     * @param itemName The name of the item to check
     * @return true if the item is buyable, false otherwise
     */
    private boolean isBuyableItem(String itemName) {
        // List of items that cannot be bought on the GE
        String[] nonBuyableItems = {
            "Fire cape", "Infernal cape", "Void", "Fighter torso", "Quest",
            "Imbued", "imbued", "Barrows gloves", "Dungeoneering"
        };
        
        for (String nonBuyable : nonBuyableItems) {
            if (itemName.contains(nonBuyable)) {
                return false;
            }
        }
        
        return true;
    }

    // --- Helper Methods ---
    private boolean restorePool() {
        if (FEROX_ENCLAVE.contains(Players.getLocal())) {
            GameObject pool = GameObjects.closest("Pool of Refreshment");
            if (pool != null && pool.interact("Drink")) {
                Sleep.sleepUntil(() ->
                                Skills.getBoostedLevel(Skill.HITPOINTS) == Skills.getRealLevel(Skill.HITPOINTS)
                                        && Skills.getBoostedLevel(Skill.PRAYER) == Skills.getRealLevel(Skill.PRAYER),
                        5000);
                return true;
            }
        }
        return false;
    }

    // Withdraw all gear items from a given loadout.
    private boolean withdrawLoadoutItems(SulphurLoadoutData loadout) {
        for (Map.Entry<String, String> entry : loadout.getEquipment().entrySet()) {
            String slot = entry.getKey();
            String itemName = entry.getValue();
            
            // Skip if already equipped or in inventory
            if (Equipment.contains(itemName) || Inventory.contains(itemName)) {
                continue;
            }
            
            // Special handling for charged items
            if (ChargedItemUtils.isChargedItem(itemName)) {
                String baseItemName = itemName.split("\\(")[0].trim();
                
                // Check if we already have this charged item in equipment or inventory
                if (ChargedItemUtils.hasValidChargedItemInEquipment(baseItemName) || 
                    ChargedItemUtils.hasValidChargedItemInInventory(baseItemName)) {
                    Logger.log("Already have a " + baseItemName + " with charges");
                    continue;
                }
                
                // Use the utility class to check for any valid charged version in bank
                if (!ChargedItemUtils.hasValidChargedItemInBank(baseItemName)) {
                    Logger.log("No " + baseItemName + " with charges found in bank");
                    if (isCriticalItem(itemName)) {
                        return false;
                    } else {
                        Logger.log("Continuing without non-critical item: " + itemName);
                        continue;
                    }
                }
                
                // Withdraw any valid charged version
                Item itemToDraw = Bank.get(i -> ChargedItemUtils.hasValidCharges(baseItemName).test(i));
                if (itemToDraw != null && itemToDraw.interact("Withdraw-1")) {
                    Sleep.sleepUntil(() -> ChargedItemUtils.hasValidChargedItemInInventory(baseItemName), 3000);
                    continue;
                } else {
                    Logger.log("Failed to withdraw " + baseItemName + " with charges");
                    if (isCriticalItem(itemName)) {
                        return false;
                    } else {
                        continue;
                    }
                }
            }
            
            // Normal item handling for non-charged items
            int quantity = slot.equalsIgnoreCase("ammo") ? loadout.getAmmoQuantity() : 1;
            if (!Bank.contains(itemName)) {
                Logger.log("Bank does not contain required gear: " + itemName);
                // Check if this is a critical item or we can continue without it
                if (isCriticalItem(itemName)) {
                    return false;
                } else {
                    Logger.log("Will try to continue without: " + itemName);
                    continue;
                }
            }
            if (!Bank.withdraw(itemName, quantity)) {
                Logger.log("Failed to withdraw gear: " + itemName);
                // Check if this is a critical item or we can continue without it
                if (isCriticalItem(itemName)) {
                    return false;
                } else {
                    Logger.log("Will try to continue without: " + itemName);
                    continue;
                }
            }
            Sleep.sleep(200);
        }
        return true;
    }

    /**
     * Determines if an item is critical for the script to function
     * @param itemName The name of the item to check
     * @return true if the item is critical, false if it can be skipped
     */
    private boolean isCriticalItem(String itemName) {
        // Use the utility class to check if it's a charged item
        if (ChargedItemUtils.isChargedItem(itemName)) {
            return false; // Charged items are not critical
        }
        
        // Other non-critical items
        String[] nonCriticalItems = {
            "Amulet of fury", "Berserker ring", "Berserker ring (i)",
            "Amulet of torture", "Infernal cape", "Fire cape",
            "Avernic defender", "Dragon defender"
        };
        
        for (String nonCritical : nonCriticalItems) {
            if (itemName.equals(nonCritical)) {
                return false;
            }
        }
        
        return true;
    }


    // Withdraw supplies from the bank based on the config's supplies mapping.
    private boolean withdrawSupplies() {
        Map<String, Integer> supplies = config.getSupplies();
        if (supplies != null && !supplies.isEmpty()) {
            for (Map.Entry<String, Integer> entry : supplies.entrySet()) {
                String supplyName = entry.getKey();
                int requiredQuantity = entry.getValue();
                
                // Special handling for charged items
                if (ChargedItemUtils.isChargedItem(supplyName)) {
                    String baseItemName = supplyName.split("\\(")[0].trim();
                    
                    // Check if we already have this charged item
                    if (ChargedItemUtils.hasValidChargedItemInEquipment(baseItemName) || 
                        ChargedItemUtils.hasValidChargedItemInInventory(baseItemName)) {
                        continue;
                    }
                    
                    // Try to withdraw if available in bank
                    if (ChargedItemUtils.hasValidChargedItemInBank(baseItemName)) {
                        Item itemToDraw = Bank.get(i -> ChargedItemUtils.hasValidCharges(baseItemName).test(i));
                        if (itemToDraw != null && itemToDraw.interact("Withdraw-1")) {
                            Sleep.sleepUntil(() -> ChargedItemUtils.hasValidChargedItemInInventory(baseItemName), 3000);
                        }
                    }
                    continue;
                }
                
                // For potions, handle differently
                if (supplyName.contains("potion")) {
                    String basePotionName = supplyName.split("\\(")[0].trim();
                    int currentInventoryQuantity = Inventory.count(i -> 
                        i != null && i.getName().startsWith(basePotionName));
                    
                    // If we already have at least one potion of this type, skip
                    if (currentInventoryQuantity >= 1) {
                        Logger.log("Already have " + currentInventoryQuantity + " " + basePotionName + " potions, skipping");
                        continue;
                    }
                    
                    // Try to withdraw any dose of the potion
                    Item anyPotion = Bank.get(i -> 
                        i != null && i.getName().startsWith(basePotionName));
                    
                    if (anyPotion != null) {
                        Logger.log("Found " + anyPotion.getName() + " in bank, attempting to withdraw");
                        if (Bank.withdraw(anyPotion.getName(), 1)) {
                            Logger.log("Successfully withdrew " + anyPotion.getName());
                            Sleep.sleep(200);
                        } else {
                            Logger.log("Failed to withdraw " + anyPotion.getName());
                            if (isCriticalItem(supplyName)) {
                                return false;
                            } else {
                                Logger.log("Will continue without: " + supplyName);
                            }
                        }
                    } else {
                        Logger.log("No " + basePotionName + " potions found in bank");
                        if (isCriticalItem(supplyName)) {
                            return false;
                        } else {
                            Logger.log("Will continue without: " + supplyName);
                        }
                    }
                } 
                // For other items, use the original logic
                else {
                    int currentInventoryQuantity = Inventory.count(supplyName);
                    // Check the bank count for the supply:
                    int bankQuantity = Bank.count(supplyName);
                    if (currentInventoryQuantity < requiredQuantity) {
                        int amountToWithdraw = requiredQuantity - currentInventoryQuantity;
                        if (bankQuantity < amountToWithdraw) {
                            Logger.log("Not enough " + supplyName + " in bank. Required: " + amountToWithdraw 
                                    + ", Available: " + bankQuantity);
                            if (isCriticalItem(supplyName)) {
                                return false;
                            } else {
                                Logger.log("Will continue without full quantity of: " + supplyName);
                                // Withdraw whatever we can
                                if (bankQuantity > 0) {
                                    Bank.withdraw(supplyName, bankQuantity);
                                    Sleep.sleep(200);
                                }
                                continue;
                            }
                        }
                        if (!Bank.withdraw(supplyName, amountToWithdraw)) {
                            Logger.log("Failed to withdraw supply: " + supplyName);
                            if (isCriticalItem(supplyName)) {
                                return false;
                            } else {
                                Logger.log("Will continue without: " + supplyName);
                                continue;
                            }
                        }
                        Sleep.sleep(200);
                    }
                }
            }
        }
        return true;
    }

    /**
     * Equips all loadout items that are in the inventory
     * @param loadout The loadout containing equipment to equip
     * @return True if all items were equipped or attempted to equip
     */
    private boolean equipLoadoutItems(SulphurLoadoutData loadout) {
        Logger.log("Equipping loadout items...");
        
        for (Map.Entry<String, String> entry : loadout.getEquipment().entrySet()) {
            String slot = entry.getKey();
            String itemName = entry.getValue();
            
            // Skip if already equipped
            if (Equipment.contains(itemName)) {
                continue;
            }
            
            // Check for charged items
            if (ChargedItemUtils.isChargedItem(itemName)) {
                String baseItemName = itemName.split("\\(")[0].trim();
                
                // Skip if already equipped
                if (ChargedItemUtils.hasValidChargedItemInEquipment(baseItemName)) {
                    continue;
                }
                
                // Try to find and equip any valid charged version in inventory
                if (ChargedItemUtils.hasValidChargedItemInInventory(baseItemName)) {
                    Item itemToEquip = Inventory.get(i -> ChargedItemUtils.hasValidCharges(baseItemName).test(i));
                    if (itemToEquip != null && itemToEquip.interact("Wear") || itemToEquip.interact("Wield") || itemToEquip.interact("Equip")) {
                        Logger.log("Equipped charged item: " + itemToEquip.getName());
                        Sleep.sleep(300, 500);
                    }
                }
                continue;
            }
            
            // Handle regular items
            if (Inventory.contains(itemName)) {
                Item itemToEquip = Inventory.get(itemName);
                if (itemToEquip != null) {
                    Logger.log("Equipping: " + itemName);
                    if (itemToEquip.interact("Wear") || itemToEquip.interact("Wield") || itemToEquip.interact("Equip")) {
                        Sleep.sleep(300, 500);
                    } else {
                        Logger.log("Failed to equip: " + itemName);
                    }
                }
            }
        }
        return true;
    }

    public void reset() {
        transitioning = false;
        checkedGE = false;
        Logger.log("Reset SulphurBankingNode state");
    }
}
