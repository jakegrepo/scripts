package scripts.Sulphur.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;
import scripts.Sulphur.SulphurConfig;

import java.util.Arrays;

import static scripts.Sulphur.utils.SupplyManager.MIN_VIALS_REQUIRED;

public class MoonlightGrub extends SimpleNode<SulphurConfig> {
    private static final int GRUBBY_SAPLING_ID = 51365;
    private static final Tile[] SAPLING_TILES = {
        new Tile(1377, 9675, 0),
        new Tile(1376, 9673, 0)
    };
    private static final int MIN_GRUBS_REQUIRED = 6;
    
    // Define the training area (same as in CombatNode)
    private static final Area TRAINING_AREA = new Area(1343, 9597, 1392, 9536);
    // Define an area slightly larger than the training area to include nearby regions
    private static final Area NEAR_TRAINING_AREA = new Area(1338, 9602, 1397, 9531);
    private static final Area RESOURCE_AREA = new Area(1362, 9691, 1406, 9666);

    private enum SupplyState {
        COLLECT_GRUB, GRIND_GRUB
    }
    
    private SupplyState currentState = SupplyState.COLLECT_GRUB;

    public MoonlightGrub(SulphurConfig config) {
        super("Collect Moonlight Grub", 2, config);
    }

    @Override
    public boolean validate() {
        // Check if we're in or near the training area
        if (!NEAR_TRAINING_AREA.contains(Players.getLocal()) && !RESOURCE_AREA.contains(Players.getLocal())) {
            return false;
        }
        if (Inventory.isFull() && Inventory.contains("Moonlight grub paste") && !Inventory.contains("Moonlight grub") && Inventory.contains("Vial of water")){
            return false;
        }
        // Check if we need to collect or process grubs
        int vialCount = Inventory.count("Vial of water");
        int grubCount = Inventory.count("Moonlight grub");
        int grubPasteCount = Inventory.count("Moonlight grub paste");
        int potionCount = Inventory.count(item -> 
            item != null && item.getName().contains("Moonlight potion"));
        
        // If we already have enough paste or potions, don't validate
        if (grubPasteCount >= MIN_GRUBS_REQUIRED || potionCount >= 5) {
            return false;
        }
        
        // Make sure we have enough vials first (PotionsNode should run first)
        if (vialCount < MIN_VIALS_REQUIRED) {
            return false;
        }
        
        // If we have grubs that need grinding, validate
        if (grubCount > 0) {
            currentState = SupplyState.GRIND_GRUB;
            return true;
        }
        
        // If we need more grubs, validate
        if (grubCount + grubPasteCount < MIN_GRUBS_REQUIRED) {
            currentState = SupplyState.COLLECT_GRUB;
            return true;
        }
        
        return false;
    }

    @Override
    protected int onExecute() {
        try {
            switch (currentState) {
                case COLLECT_GRUB:
                    return collectGrub();
                case GRIND_GRUB:
                    return grindGrub();
                default:
                    return 100;
            }
        } catch (Exception e) {
            setStatus("Error: " + e.getMessage());
            return 600;
        }
    }

    private int collectGrub() {
        if (Inventory.contains("Vial")){
            Inventory.dropAll("Vial");
        }
        // Find the closest sapling
        GameObject sapling = Arrays.stream(SAPLING_TILES).map(GameObjects::getTopObjectOnTile).filter(obj -> obj != null && obj.getID() == GRUBBY_SAPLING_ID).findFirst().orElse(null);

        // If no sapling found, try to find any with the ID
        if (sapling == null) {
            setStatus("Grubby sapling not found");
            
            // Check if player is already moving or animating
            if (Players.getLocal().isMoving() || Players.getLocal().isAnimating()) {
                Logger.log("Player is already moving, waiting to complete movement");
                return 1000; // Short delay to check again
            }
            
            // Try walking to one of the sapling locations
            Logger.log("Walking to sapling location");
            if (Walking.walk(SAPLING_TILES[0])) {
                Logger.log("Started walking to sapling location");
                // Wait until player reaches destination or stops moving
                boolean reached = Sleep.sleepUntil(
                    () -> !Players.getLocal().isMoving() && !Players.getLocal().isAnimating(),
                    5000
                );
                
                if (reached) {
                    Logger.log("Reached sapling area or stopped moving");
                } else {
                    Logger.log("Movement interrupted or timed out");
                }
                return 1200; // Give some time before next check
            } else {
                Logger.log("Failed to start walking to sapling location");
                return 1800; // Longer delay if walking failed to start
            }
        }
        
        // Check if we need to walk to the sapling
        if (sapling.distance() > 5) {
            setStatus("Walking to grubby sapling");
            
            // Check if player is already moving or animating
            if (Players.getLocal().isMoving() || Players.getLocal().isAnimating()) {
                Logger.log("Player is already moving, waiting to complete movement");
                return 1000; // Short delay to check again
            }
            
            if (Walking.walk(sapling)) {
                Logger.log("Started walking to sapling");
                // Wait until player reaches destination or stops moving
                boolean reached = Sleep.sleepUntil(
                    () -> sapling.distance() <= 5 || 
                         (!Players.getLocal().isMoving() && !Players.getLocal().isAnimating()),
                    5000
                );
                
                if (reached && sapling.distance() <= 5) {
                    Logger.log("Reached sapling");
                } else {
                    Logger.log("Movement interrupted or failed to reach sapling");
                }
                return 1200; // Give some time before next check
            } else {
                Logger.log("Failed to start walking to sapling");
                return 1800; // Longer delay if walking failed to start
            }
        }

        // Check if inventory is full
        if (Inventory.isFull() && Inventory.contains("Moonlight grub")) {
            setStatus("Inventory full, switching to grinding");
            currentState = SupplyState.GRIND_GRUB;
            return 100;
        }
        
        // Collect from the sapling
        setStatus("Collecting from grubby sapling");
        if (sapling.interact("Collect-from")) {
            sleepUntil(() -> !Players.getLocal().isAnimating() ||
                       Inventory.count("Moonlight grub") >= MIN_GRUBS_REQUIRED || 
                       Inventory.isFull(), 5000);
            
            // Check if we have enough grubs now
            if (Inventory.count("Moonlight grub") >= MIN_GRUBS_REQUIRED || Inventory.isFull() && Inventory.contains("Moonlight grub")) {
                setStatus("Collected enough grubs, switching to grinding");
                currentState = SupplyState.GRIND_GRUB;
                sleepUntil(() -> !Players.getLocal().isAnimating(),2000);
                return 600;
            }
            
            return 600;
        }
        
        return 1800;
    }

    private int grindGrub() {
        setStatus("Grinding moonlight grub");

        // Check if we have grubs to grind
        if (!Inventory.contains("Moonlight grub") && !Inventory.contains("Moonlight potion")) {
            setStatus("No grubs to grind, switching to collecting");
            currentState = SupplyState.COLLECT_GRUB;
            return 100;
        }

        // Check if we have pestle and mortar
        if (!Inventory.contains("Pestle and mortar")) {
            setStatus("Missing pestle and mortar");
            return 100;
        }

        // Get the items
        Item pestle = Inventory.get("Pestle and mortar");
        Item moonlightGrub = Inventory.get("Moonlight grub");

        // Use pestle on grub
        if (pestle != null && moonlightGrub != null) {
            if (pestle.useOn(moonlightGrub)) {
                sleepUntil(() -> !Players.getLocal().isAnimating(), 5000);
                
                // Check if we have enough paste now
                if (Inventory.count("Moonlight grub paste") >= MIN_GRUBS_REQUIRED) {
                    setStatus("Finished grinding required grubs");
                    return 100;
                }
                
                // If we have more grubs, continue grinding
                if (Inventory.contains("Moonlight grub")) {
                    return 100;
                } else {
                    // If no more grubs and we need more, switch to collecting
                    if (Inventory.count("Moonlight grub paste") < MIN_GRUBS_REQUIRED) {
                        currentState = SupplyState.COLLECT_GRUB;
                    }
                    return 100;
                }
            }
        }

        return 100;
    }

    @Override
    public void cleanup() {
        setStatus("Cleaning up moonlight grub node");
    }
}