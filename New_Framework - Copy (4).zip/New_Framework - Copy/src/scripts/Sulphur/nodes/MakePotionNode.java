package scripts.Sulphur.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.wrappers.items.Item;
import scripts.Sulphur.SulphurConfig;

public class MakePotionNode extends SimpleNode<SulphurConfig> {
    private static final int MIN_POTIONS_REQUIRED = 6;
    private static final int MAX_POTION_DOSE = 4;
    
    // Define the training area (same as in CombatNode)
    private static final Area TRAINING_AREA = new Area(1343, 9597, 1392, 9536);
    // Define an area slightly larger than the training area to include nearby regions
    private static final Area NEAR_TRAINING_AREA = new Area(1338, 9602, 1397, 9531);
    private static final Area RESOURCE_AREA = new Area(1362, 9691, 1406, 9666);

    public MakePotionNode(SulphurConfig config) {
        super("Make Moonlight Potion", 3, config);
    }

    @Override
    public boolean validate() {

        
        // Check if we have the materials to make potions
        int vialCount = Inventory.count("Vial of water");
        int pasteCount = Inventory.count("Moonlight grub paste");
        int potionCount = Inventory.count(item -> 
            item != null && item.getName().contains("Moonlight potion"));
        
        // If we already have enough potions, don't validate
        if (potionCount >= MIN_POTIONS_REQUIRED) {
            return false;
        }
        
        // Make sure we have enough vials first (PotionsNode should run first)
        if (vialCount == 0) {
            return false;
        }
        
        // Make sure we have enough paste (MoonlightGrub should run second)
        if (pasteCount == 0) {
            return false;
        }
        
        // Also validate if we need to combine potions (to free up inventory space)
        if (shouldCombinePotions()) {
            return true;
        }
        
        // Validate if we have materials to make potions - this should be the third priority
        return vialCount > 0 && pasteCount > 0;
    }

    @Override
    protected int onExecute() {
        try {
            // First check if we need to combine existing potions
            if (shouldCombinePotions()) {
                return combinePotions();
            }
            
            // Otherwise mix new potions
            return mixPotion();
        } catch (Exception e) {
            setStatus("Error: " + e.getMessage());
            return 600;
        }
    }

    private int mixPotion() {
        // Get the items
        Item vial = Inventory.get("Vial of water");
        Item paste = Inventory.get("Moonlight grub paste");
        
        // Check if we have the required items
        if (vial == null || paste == null) {
            setStatus("Missing items for potion making");
            return 100;
        }
        
        // If we're already mixing, wait
        if (Players.getLocal().isAnimating()) {
            setStatus("Currently mixing potion");
            return 600;
        }
        
        // Mix the potion
        setStatus("Mixing moonlight potion");
        if (paste.useOn(vial)) {
            sleepUntil(() -> !Players.getLocal().isAnimating(), 3000);

            // After mixing, combine potions if possible
            if (shouldCombinePotions()) {
                combinePotions();
            }

            // Check if we have enough potions now
            int potionCount = Inventory.count(item -> 
                item != null && item.getName().contains("Moonlight potion"));
            
            if (potionCount >= MIN_POTIONS_REQUIRED) {
                setStatus("Made enough potions");
                return 100;
            }
            
            // Check if we can make more potions
            if (Inventory.contains("Vial of water") && Inventory.contains("Moonlight grub paste")) {
                return 100; // Continue making potions
            }
            
            return 600;
        }
        
        return 100;
    }
    
    private boolean shouldCombinePotions() {
        // Get pairs of potions that can actually be combined
        Item[] potions = Inventory.all(item -> 
            item != null && 
            item.getName().contains("Moonlight potion")).toArray(new Item[0]);
        
        for (int i = 0; i < potions.length; i++) {
            for (int j = i + 1; j < potions.length; j++) {
                int dose1 = getDoseAmount(potions[i]);
                int dose2 = getDoseAmount(potions[j]);
                // Check if these two potions can be combined (sum <= 4)
                if (dose1 > 0 && dose2 > 0 && (dose1 + dose2) <= MAX_POTION_DOSE) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private int getDoseAmount(Item potion) {
        if (potion == null || !potion.getName().contains("Moonlight potion")) {
            return 0;
        }
        // Extract dose number from name like "Moonlight potion(3)"
        String name = potion.getName();
        int startIndex = name.indexOf('(');
        int endIndex = name.indexOf(')');
        if (startIndex >= 0 && endIndex > startIndex) {
            try {
                return Integer.parseInt(name.substring(startIndex + 1, endIndex));
            } catch (NumberFormatException e) {
                return 0;
            }
        }
        return 0;
    }
    
    private int combinePotions() {
        setStatus("Combining potions to save inventory space");
        
        Item[] potions = Inventory.all(item -> 
            item != null && item.getName().contains("Moonlight potion")).toArray(new Item[0]);
        
        if (potions.length < 2) {
            return 100;
        }
        
        // Find two potions that can be combined
        for (int i = 0; i < potions.length; i++) {
            for (int j = i + 1; j < potions.length; j++) {
                int dose1 = getDoseAmount(potions[i]);
                int dose2 = getDoseAmount(potions[j]);
                
                // Only combine if the sum is <= MAX_POTION_DOSE
                if (dose1 > 0 && dose2 > 0 && (dose1 + dose2) <= MAX_POTION_DOSE) {
                    if (potions[i].useOn(potions[j])) {
                        sleepUntil(() -> !Players.getLocal().isAnimating(), 1500);
                        return 600;
                    }
                }
            }
        }
        
        return 100;
    }

    @Override
    public void cleanup() {
        setStatus("Cleaning up make potion node");
    }
}