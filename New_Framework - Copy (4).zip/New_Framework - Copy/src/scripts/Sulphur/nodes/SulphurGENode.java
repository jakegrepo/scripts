package scripts.Sulphur.nodes;

import core.grandexchange.GrandExchangeNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.grandexchange.GrandExchangeItem;
import org.dreambot.api.methods.grandexchange.LivePrices;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import scripts.Sulphur.Sulphur;
import scripts.Sulphur.SulphurConfig;
import scripts.Sulphur.utils.ChargedItemUtils;

public class SulphurGENode extends GrandExchangeNode<SulphurConfig> {
    private final Sulphur script;
    private boolean itemsCollected = false;
    private boolean readyToCollect = false;
    private boolean collectionStarted = false;

    public SulphurGENode(SulphurConfig config, Sulphur script) {
        super("Sulphur GE", 1, config);
        this.script = script;
    }

    @Override
    public boolean validate() {
        // Only activate when forced AND there's work to do
        return forceExecute && (!itemsToBuy.isEmpty() || GrandExchange.getUsedSlots() > 0);
    }

    @Override
    protected int onExecute() {
        // Immediate exit if no work remains
        if (itemsToBuy.isEmpty() && GrandExchange.getUsedSlots() == 0) {
            Logger.log("[SulphurGE] Clean exit - no items or active offers");
            forceExecute = false;
            completed = true;
            config.setUseGrandExchange(false);
            
            // Add explicit banking node reset
            context.tasks().getNodes().stream()
                .filter(node -> node instanceof SulphurBankingNode)
                .findFirst()
                .ifPresent(node -> ((SulphurBankingNode) node).reset());
            
            return 0; // Exit immediately
        }
        return super.onExecute();
    }

    @Override
    protected void checkAndPreparePurchaseList() {
        Logger.log("[SulphurGE] Using pre-calculated purchase list from banking node");
        
        // Explicit completion check
        if (itemsToBuy.isEmpty() && GrandExchange.getUsedSlots() == 0) {
            Logger.log("[SulphurGE] Purchase list and GE slots empty");
            completed = true;
            forceExecute = false;
            config.setUseGrandExchange(false);
            return;
        }
        
        if (itemsToBuy.isEmpty()) {
            Logger.log("[SulphurGE] Purchase list empty after banking node check");
            completed = true;
            config.setUseGrandExchange(false);
        }
    }

    @Override
    protected boolean collectAndVerifyItems() {
        // Modified cleanup check
        if (itemsToBuy.isEmpty() && GrandExchange.getUsedSlots() == 0) {
            Logger.log("[SulphurGE] Final cleanup - closing GE and resetting");
            if (GrandExchange.isOpen()) {
                GrandExchange.close();
                Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 2000);
            }
            
            // Force banking node reset
            context.tasks().getNodes().stream()
                .filter(node -> node instanceof SulphurBankingNode)
                .forEach(node -> ((SulphurBankingNode) node).reset());
            
            forceExecute = false;
            completed = true;
            config.setUseGrandExchange(false);
            return true;
        }
        
        // Handle GE collection
        if (GrandExchange.isOpen()) {
            // Check if any offers are ready to collect
            boolean hasCompletedOffers = false;
            for (GrandExchangeItem item : GrandExchange.getItems()) {
                if (item != null && item.isReadyToCollect()) {
                    hasCompletedOffers = true;
                    Logger.log("[SulphurGE] Collecting completed offer: " + item.getName());
                    GrandExchange.collect();
                    Sleep.sleepUntil(() -> !item.isReadyToCollect(), 3000);
                    return false;
                }
            }

            // If no offers to collect, close GE to proceed with banking
            if (!hasCompletedOffers) {
                Logger.log("[SulphurGE] No offers to collect, closing GE");
                GrandExchange.close();
                Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 3000);
                return false;
            }
        }

        // Handle banking of collected items
        if (!Bank.isOpen()) {
            if (Inventory.isEmpty()) {
                return true; // Nothing to bank
            }
            Logger.log("[SulphurGE] Opening bank to deposit items");
            Bank.open();
            Sleep.sleepUntil(Bank::isOpen, 3000);
            return false;
        }

        if (!Inventory.isEmpty()) {
            Logger.log("[SulphurGE] Depositing items into bank");
            Bank.depositAllItems();
            Sleep.sleepUntil(Inventory::isEmpty, 3000);
            return false;
        }

        Bank.close();
        return true;
    }

    @Override
    protected void notifyComplete() {
        super.notifyComplete();
        setForceExecute(false);
        
        // Reset banking node to re-run checks
        context.tasks().getNodes().stream()
            .filter(node -> node instanceof SulphurBankingNode)
            .forEach(node -> ((SulphurBankingNode) node).reset());
        
        if (itemsToBuy.isEmpty()) {
            config.setUseGrandExchange(false);
        }
        Logger.log("[SulphurGE] Resupply completed - banking node reset");
    }

    @Override
    public void addItem(String itemName, int amount) {
        if (!Bank.isOpen()) {
            Logger.error("Tried to add GE item without bank open!");
            return;
        }
        
        int bankCount = Bank.count(itemName);
        if (bankCount > 0) {
            Logger.log("[SulphurGE] Bank contains " + bankCount + " " + itemName);
        }
        
        if (itemName == null || itemName.isEmpty() || amount <= 0) {
            Logger.log("[SulphurGE] Invalid item parameters - Name: " + itemName + ", Amount: " + amount);
            return;
        }
        
        // Check if item already exists in the list
        boolean exists = itemsToBuy.stream()
            .anyMatch(item -> item.getName().equals(itemName));
            
        if (!exists) {
            Logger.log("[SulphurGE] Adding " + amount + "x " + itemName + " to buy list");
            itemsToBuy.add(new ItemToBuy(itemName, amount));
            completed = false; // Reset completed flag when adding new items
            forceExecute = true; // Set force execute when adding items
        } else {
            Logger.log("[SulphurGE] Item already in buy list: " + itemName);
        }
    }

    @Override
    protected boolean buyItems() {
        // Add early exit check at start of method
        if (itemsToBuy.isEmpty() && GrandExchange.getUsedSlots() == 0) {
            Logger.log("[SulphurGE] Early exit - nothing to buy");
            return false;
        }
        
        if (!GrandExchange.isOpen()) {
            if (Bank.isOpen()) {
                Bank.close();
                Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
                return false;
            }
            Logger.log("[SulphurGE] Opening Grand Exchange");
            GrandExchange.open();
            Sleep.sleepUntil(GrandExchange::isOpen, 5000);
            return false;
        }

        // Check if we have any active offers that need collecting first
        for (GrandExchangeItem item : GrandExchange.getItems()) {
            if (item != null && item.isReadyToCollect()) {
                Logger.log("[SulphurGE] Found completed offers, moving to collection phase");
                return true;
            }
        }

        // Get next available slot
        int openSlot = GrandExchange.getFirstOpenSlot();
        if (openSlot == -1) {
            Logger.log("[SulphurGE] No open GE slots available, waiting for offers to complete");
            return false;
        }

        // Find next item to buy
        ItemToBuy nextItem = itemsToBuy.stream()
            .filter(item -> !item.isPurchased())
            .findFirst()
            .orElse(null);

        if (nextItem == null) {
            Logger.log("[SulphurGE] No more items to buy, checking for collections");
            return GrandExchange.getUsedSlots() > 0;
        }

        // Place buy offer
        int price = LivePrices.get(nextItem.getName());
        if (price > 0) {
            int buyPrice = (int)(price * 1.3);
            Logger.log("[SulphurGE] Buying " + nextItem.getQuantity() + "x " + nextItem.getName() + " at " + buyPrice + " each");
            if (GrandExchange.buyItem(nextItem.getName(), nextItem.getQuantity(), buyPrice)) {
                nextItem.setPurchased(true);
                Sleep.sleep(1000, 1500);
            }
        } else {
            Logger.log("[SulphurGE] Could not get price for: " + nextItem.getName());
            // Skip this item to prevent getting stuck
            nextItem.setPurchased(true);
        }

        return false;
    }

    @Override
    protected boolean hasItem(String itemName) {
        // Special handling for charged items
        if (ChargedItemUtils.isChargedItem(itemName)) {
            String baseItemName = itemName.split("\\(")[0].trim();
            return ChargedItemUtils.hasValidChargedItemAnywhere(baseItemName);
        }
        
        // Regular item checking
        return Bank.contains(itemName) || 
               Inventory.contains(itemName) || 
               Equipment.contains(itemName);
    }

    @Override
    public void reset() {
        super.reset();
        itemsToBuy.clear();
        itemsCollected = false;
        readyToCollect = false;
        collectionStarted = false;
        completed = false;
        forceExecute = false;
    }
} 