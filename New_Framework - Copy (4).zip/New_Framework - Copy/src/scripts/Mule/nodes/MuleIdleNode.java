package scripts.Mule.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.MethodProvider;
import org.dreambot.api.methods.RSLoginResponse;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.login.LoginUtility;
import org.dreambot.api.methods.tabs.Tab;
import org.dreambot.api.methods.tabs.Tabs;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import scripts.Mule.config.MuleConfig;
import scripts.Mule.muling.MuleServer;

/**
 * Handles the idle behavior of the mule, logging out when no active trade is in progress
 * and auto-logging in when a client connects.
 */
public class MuleIdleNode extends SimpleNode<MuleConfig> {

    private final MuleServer muleServer;
    private boolean wasConnected = false;
    private long lastLogoutCheck = 0;
    private long lastClientCheckTime = 0;
    private long lastLoginAttempt = 0;
    private int failedLoginAttempts = 0;
    
    private static final long LOGOUT_CHECK_INTERVAL = 30000; // Check every 30 seconds
    private static final long CLIENT_CHECK_INTERVAL = 5000; // Check for client connection every 5 seconds
    private static final long LOGIN_RETRY_COOLDOWN = 20000; // Wait 20 seconds between login attempts
    private static final int MAX_LOGIN_ATTEMPTS = 3; // Max number of consecutive failed login attempts
    
    private static final int LOGOUT_WIDGET_ID = 182;
    private static final int LOGOUT_CHILD_ID = 8;
    private static final int LOGOUT_CONFIRM_CHILD_ID = 3;

    public MuleIdleNode(MuleConfig config, MuleServer muleServer) {
        super("Mule Idle", 10, config); // Lower priority than trading nodes
        this.muleServer = muleServer;
        Logger.log("*** MuleIdleNode initialized ***");
        Logger.log("MuleIdleNode: Auto-logout feature will be " + 
                  (config.isAutoLogout() ? "ENABLED" : "DISABLED") +
                  " based on current settings");
        
        // Check if credentials are set
        boolean hasCredentials = config.getUsername() != null && !config.getUsername().isEmpty() &&
                                config.getPassword() != null && !config.getPassword().isEmpty();
        Logger.log("MuleIdleNode: Auto-login credentials are " + (hasCredentials ? "configured" : "NOT configured"));
        
        if (!hasCredentials) {
            Logger.warn("MuleIdleNode: To use auto-login feature, you must set your login credentials in the script settings!");
        }
    }

    @Override
    public boolean validate() {
        // This node handles both:
        // 1. Logging out when no client is connected or no trade is in progress (if autoLogout is enabled)
        // 2. Auto-logging in when a client connects and we're logged out

        // Only check for logout if autoLogout is enabled
        boolean autoLogoutEnabled = config.isAutoLogout();
        
        // First case: We're logged in and no active trade or client, check if we should logout
        boolean isLoggedIn = Players.getLocal() != null && Players.getLocal().exists();
        boolean noActiveClient = !muleServer.isClientConnected();
        boolean noActiveTrading = muleServer.getTradeStatus() == null || 
                                 muleServer.getTradeStatus().equals("WAITING") ||
                                 muleServer.getTradeStatus().equals("COMPLETE");
        long currentTime = System.currentTimeMillis();
        boolean checkTimeElapsed = (currentTime - lastLogoutCheck) > LOGOUT_CHECK_INTERVAL;

        // Second case: We're logged out but a client has connected, need to login
        boolean needsLogin = !isLoggedIn && muleServer.isClientConnected();
        boolean clientCheckTimeElapsed = (currentTime - lastClientCheckTime) > CLIENT_CHECK_INTERVAL;
        boolean loginCooldownElapsed = (currentTime - lastLoginAttempt) > LOGIN_RETRY_COOLDOWN;
        boolean canAttemptLogin = needsLogin && clientCheckTimeElapsed && (failedLoginAttempts < MAX_LOGIN_ATTEMPTS || loginCooldownElapsed);

        // For debugging - output state every so often
        if (currentTime % 30000 < 100) { // Log every ~30 seconds
            Logger.log("MuleIdleNode state: loggedIn=" + isLoggedIn + 
                      ", autoLogoutEnabled=" + autoLogoutEnabled + 
                      ", clientConnected=" + muleServer.isClientConnected() + 
                      ", tradeStatus=" + muleServer.getTradeStatus());
        }

        // Execute if either condition is met
        return (isLoggedIn && autoLogoutEnabled && checkTimeElapsed && (noActiveClient || noActiveTrading)) || 
               canAttemptLogin;
    }

    @Override
    protected int onExecute() {
        long currentTime = System.currentTimeMillis();
        
        // Track if we previously had a connection
        boolean currentlyConnected = muleServer.isClientConnected();
        
        // CASE 1: We're logged out and a client is connected - need to login
        if (!isLoggedIn() && currentlyConnected) {
            lastClientCheckTime = currentTime;
            
            // Check login cooldown
            if ((currentTime - lastLoginAttempt) < LOGIN_RETRY_COOLDOWN && failedLoginAttempts > 0) {
                Logger.log("MuleIdleNode: Waiting for login cooldown, " + 
                          ((LOGIN_RETRY_COOLDOWN - (currentTime - lastLoginAttempt)) / 1000) + 
                          " seconds remaining.");
                return 5000;
            }
            
            // Check max attempts
            if (failedLoginAttempts >= MAX_LOGIN_ATTEMPTS) {
                Logger.warn("MuleIdleNode: Reached maximum failed login attempts (" + MAX_LOGIN_ATTEMPTS + "). Resetting counter.");
                failedLoginAttempts = 0;
            }
            
            Logger.log("MuleIdleNode: Client connected while logged out, attempting to login");
            
            // Get the script's login info from config
            String username = config.getUsername();
            String password = config.getPassword();
            
            if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
                Logger.error("MuleIdleNode: Login credentials not configured in MuleConfig");
                Logger.error("MuleIdleNode: Please set your login credentials in the script settings!");
                
                // Notify client about missing credentials
                if (muleServer != null && muleServer.isClientConnected()) {
                    muleServer.queueOutgoingMessage("ERROR:MULE_MISSING_CREDENTIALS");
                    Logger.log("MuleIdleNode: Sent error message to client about missing credentials");
                }
                
                return 30000; // Longer wait to give user time to configure
            }
            
            // Update login attempt time
            lastLoginAttempt = currentTime;
            
            // Attempt login - properly handle RSLoginResponse
            RSLoginResponse loginResponse = null;
            try {
                Logger.log("MuleIdleNode: Attempting login with username: " + username);
                loginResponse = LoginUtility.login(username, password);
                Logger.log("MuleIdleNode: Login attempt response: " + loginResponse);
            } catch (Exception e) {
                Logger.error("MuleIdleNode: Exception during login attempt: " + e.getMessage());
            }
            
            boolean loginSuccess = loginResponse == RSLoginResponse.LOGGED_IN;
            
            if (loginSuccess) {
                Logger.log("MuleIdleNode: Successfully logged in for mule activity");
                failedLoginAttempts = 0; // Reset counter on success
                
                // Wait for login to complete
                if (Sleep.sleepUntil(() -> isLoggedIn(), 5000)) {
                    // Send success message to client
                    if (muleServer != null && muleServer.isClientConnected()) {
                        muleServer.queueOutgoingMessage("MULE_LOGGED_IN");
                    }
                    return 1000;
                } else {
                    Logger.warn("MuleIdleNode: Login utility reported success but character didn't appear to login");
                    failedLoginAttempts++;
                }
            } else {
                Logger.warn("MuleIdleNode: Failed to login, attempt #" + (failedLoginAttempts + 1) + " - Response: " + loginResponse);
                failedLoginAttempts++;
                
                // After multiple failures, notify client
                if (failedLoginAttempts >= MAX_LOGIN_ATTEMPTS) {
                    if (muleServer != null && muleServer.isClientConnected()) {
                        muleServer.queueOutgoingMessage("ERROR:MULE_LOGIN_FAILED");
                    }
                }
                
                return 10000; // Wait before retrying
            }
            
            return 5000; // Default return after login attempt
        }
        
        // CASE 2: We're logged in but no active client or trade - check if we should logout
        if (isLoggedIn() && config.isAutoLogout()) {
            // Update the last check time
            lastLogoutCheck = currentTime;
            
            // If a client just disconnected, wait a bit before logging out
            if (wasConnected && !currentlyConnected) {
                Logger.log("MuleIdleNode: Client just disconnected, waiting before logout");
                wasConnected = false;
                return 10000; // Wait 10 seconds
            }
            
            wasConnected = currentlyConnected;
            
            // If no client is connected, log out and wait for connection
            if (!muleServer.isClientConnected()) {
                Logger.log("MuleIdleNode: No active mule client, logging out to wait for request");
                
                // Open logout tab
                if (!Tabs.isOpen(Tab.LOGOUT)) {
                    Tabs.open(Tab.LOGOUT);
                    Sleep.sleepUntil(() -> Tabs.isOpen(Tab.LOGOUT), 2000);
                }
                
                // Click logout button
                if (Widgets.getWidget(LOGOUT_WIDGET_ID) != null && 
                    Widgets.getWidget(LOGOUT_WIDGET_ID).getChild(LOGOUT_CHILD_ID) != null) {
                    
                    Widgets.getWidget(LOGOUT_WIDGET_ID).getChild(LOGOUT_CHILD_ID).interact();
                    
                    // Handle confirmation if needed (for example, when in combat or certain areas)
                    Sleep.sleepUntil(() -> !isLoggedIn() || 
                                    (Widgets.getWidget(LOGOUT_WIDGET_ID) != null && 
                                    Widgets.getWidget(LOGOUT_WIDGET_ID).getChild(LOGOUT_CONFIRM_CHILD_ID) != null), 3000);
                    
                    if (isLoggedIn() && 
                        Widgets.getWidget(LOGOUT_WIDGET_ID) != null && 
                        Widgets.getWidget(LOGOUT_WIDGET_ID).getChild(LOGOUT_CONFIRM_CHILD_ID) != null) {
                        
                        Widgets.getWidget(LOGOUT_WIDGET_ID).getChild(LOGOUT_CONFIRM_CHILD_ID).interact();
                        
                        // Wait for successful logout
                        if (Sleep.sleepUntil(() -> !isLoggedIn(), 3000)) {
                            Logger.log("MuleIdleNode: Successfully logged out");
                            failedLoginAttempts = 0; // Reset login attempts after clean logout
                        } else {
                            Logger.warn("MuleIdleNode: Failed to log out, will retry");
                        }
                    }
                }
                
                // Return a long sleep to prevent rapid node execution while logged out
                return 30000; // 30 seconds
            }
        }
        
        // Just performed a check, whether logged in or not
        return 5000; // 5 seconds default return
    }
    
    /**
     * Utility method to check if player is logged in
     */
    private boolean isLoggedIn() {
        return Players.getLocal() != null && Players.getLocal().exists();
    }

    @Override
    public void cleanup() {
        Logger.log("MuleIdleNode cleanup.");
    }
} 