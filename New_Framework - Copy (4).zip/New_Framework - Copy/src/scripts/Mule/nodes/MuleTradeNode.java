package scripts.Mule.nodes;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import core.base.SimpleNode; // Assuming your framework's base node
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.BankLocation;
import org.dreambot.api.methods.grandexchange.LivePrices;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.trade.Trade;
import org.dreambot.api.methods.trade.TradeUser;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Player;
import org.dreambot.api.wrappers.items.Item;
import scripts.Mule.config.MuleConfig;
import scripts.Mule.muling.MuleServer;
import events.EventType;
import events.ScriptEvent;
import core.context.ScriptContext;
import scripts.Mule.gui.MuleOverlay;

import java.util.Map;

/**
 * Handles the in-game trading actions for the Mule.
 * Interacts with the MuleServer for communication status.
 */
public class MuleTradeNode extends SimpleNode<MuleConfig> {

    private final MuleServer muleServer;
    private String currentTrader = null; // Username of the client trading with
    private MuleTradeStatus tradeStatus = MuleTradeStatus.IDLE;

    // Timeout tracking
    private long stateChangeTime = System.currentTimeMillis();
    private static final long STATE_TIMEOUT = 120000; // 2 minutes timeout for any state

    // Define meeting areas (should match client node)
    private static final Area VARROCK_MID = new Area(3207, 3432, 3253, 3420); // Varrock center area (expanded to include fountain area)
    private static final Area FEROX_ENCLAVE_BANK = new Area(3134, 3632, 3139, 3627); // Ferox Enclave bank area
    private static final Area GRAND_EXCHANGE_AREA = new Area(3158, 3494, 3171, 3483); // Grand Exchange area
    private Area currentMeetingArea = BankLocation.VARROCK_EAST.getArea(5); // Default - should align with server communication if needed
    private String currentMeetingSpotName = "Varrock Mid"; // Track the current meeting spot name

    // Store expected items/quantities for this session
    private java.util.Map<String, Integer> expectedItemsToGain = new java.util.HashMap<>();
    private java.util.Map<String, Integer> gainedItems = new java.util.HashMap<>();
    private boolean inventoryListenerRegistered = false;

    private MuleOverlay muleOverlay; // Optional overlay reference

    private enum MuleTradeStatus {
        IDLE,
        WAITING_FOR_CLIENT_CONFIRM, // Client connected, waiting for them to find us
        SENDING_READY_SIGNAL,       // Client found us, sending ready signal
        WAITING_FOR_TRADE_INIT,   // Ready signal sent, waiting for trade request
        TRADING_SCREEN_1,
        TRADING_SCREEN_2,
        WAITING_FOR_COMPLETION,
        TRADE_COMPLETE,
        ERROR
    }

    public MuleTradeNode(MuleConfig config, MuleServer muleServer) {
        super("Mule Trading", 1, config); // High priority
        this.muleServer = muleServer;
        // Try to get overlay from context if available
        try {
            if (getContext() != null && getContext().getScript() instanceof scripts.Mule.MuleServerScript) {
                scripts.Mule.MuleServerScript script = (scripts.Mule.MuleServerScript) getContext().getScript();
                this.muleOverlay = script.muleOverlay;
            }
        } catch (Exception ignored) {}
        updateMeetingArea();
    }

    /**
     * Update the meeting area based on the provided meeting spot name
     * @param meetingSpot The meeting spot name to use
     */
    private void updateMeetingArea(String meetingSpot) {
        // Store the meeting spot name for logging
        currentMeetingSpotName = meetingSpot != null ? meetingSpot : "Varrock Mid";

        if (meetingSpot != null && meetingSpot.equalsIgnoreCase("Grand Exchange")) {
            currentMeetingArea = GRAND_EXCHANGE_AREA;
            Logger.log("MuleTradeNode: Meeting area set to Grand Exchange");
        } else if (meetingSpot != null && meetingSpot.equalsIgnoreCase("Ferox Enclave")) {
            currentMeetingArea = FEROX_ENCLAVE_BANK;
            Logger.log("MuleTradeNode: Meeting area set to Ferox Enclave");
        } else if (meetingSpot != null && (meetingSpot.equalsIgnoreCase("Varrock Mid") ||
                   meetingSpot.equalsIgnoreCase("Varrock"))) {
            currentMeetingArea = VARROCK_MID;
            Logger.log("MuleTradeNode: Meeting area set to Varrock Mid");
        } else {
            // Default to Varrock Mid if unknown
            currentMeetingArea = VARROCK_MID;
            Logger.warn("MuleTradeNode: Unknown meeting spot '" + meetingSpot + "', defaulting to Varrock Mid.");
        }
    }

    /**
     * Legacy method for backward compatibility
     */
    private void updateMeetingArea() {
        // Default to Varrock Mid if no specific location is provided
        updateMeetingArea("Varrock Mid");
    }

    /**
     * Updates the trade status and resets the state timeout
     * @param newStatus The new trade status
     */
    private void setTradeStatus(MuleTradeStatus newStatus) {
        if (tradeStatus != newStatus) {
            Logger.log("MuleTradeNode: State changing from " + tradeStatus + " to " + newStatus);
            tradeStatus = newStatus;
            stateChangeTime = System.currentTimeMillis();

            // Update overlay status
            if (muleOverlay != null) {
                muleOverlay.setStatus(tradeStatus.name() + (currentTrader != null ? " (" + currentTrader + ")" : ""));
            }

            // Update server status for client
            switch (newStatus) {
                case IDLE:
                    muleServer.setTradeStatus("WAITING");
                    break;
                case WAITING_FOR_CLIENT_CONFIRM:
                    muleServer.setTradeStatus("WAITING_FOR_PLAYER");
                    break;
                case SENDING_READY_SIGNAL:
                    muleServer.setTradeStatus("SENDING_READY");
                    break;
                case WAITING_FOR_TRADE_INIT:
                    muleServer.setTradeStatus("WAITING_FOR_TRADE");
                    break;
                case TRADING_SCREEN_1:
                case TRADING_SCREEN_2:
                    muleServer.setTradeStatus("TRADING");
                    break;
                case WAITING_FOR_COMPLETION:
                    muleServer.setTradeStatus("WAITING_FOR_COMPLETION");
                    break;
                case TRADE_COMPLETE:
                    muleServer.setTradeStatus("COMPLETE");
                    // Overlay: increment trade count
                    if (muleOverlay != null) muleOverlay.incrementTrades();
                    // Overlay: add incoming/outgoing GP (estimate from gainedItems/expectedItemsToGain)
                    updateOverlayGPStats();
                    break;
                case ERROR:
                    muleServer.setTradeStatus("ERROR");
                    break;
            }
        }
    }

    @Override
    public boolean validate() {
        // This node only runs if a client is connected and a trade is expected/in progress
        boolean isActive = muleServer.isClientConnected() &&
                          (tradeStatus != MuleTradeStatus.IDLE && tradeStatus != MuleTradeStatus.TRADE_COMPLETE);

        // Also activate if client just connected and we need to handle the initial connection
        boolean needsInitialHandling = muleServer.isClientConnected() &&
                                     tradeStatus == MuleTradeStatus.IDLE &&
                                     muleServer.getClientUsername() != null;

        return isActive || needsInitialHandling;
    }

    /**
     * Checks if the current state has timed out and resets if necessary
     * Also verifies that the state matches the actual game state
     */
    private void checkStateTimeout() {
        // Check for timeout
        long currentTime = System.currentTimeMillis();
        long timeInState = currentTime - stateChangeTime;

        if (timeInState > STATE_TIMEOUT) {
            Logger.warn("MuleTradeNode: State " + tradeStatus + " has timed out after " + (timeInState / 1000) + " seconds");
            resetState("State timeout");
            return;
        }

        // Verify state matches game state
        switch (tradeStatus) {
            case SENDING_READY_SIGNAL:
                // Special handling for SENDING_READY_SIGNAL state
                // This state should be very short-lived - just send the message and move on
                // If we're stuck here for more than 5 seconds, force transition to WAITING_FOR_TRADE_INIT
                if (timeInState > 5000) {
                    Logger.warn("MuleTradeNode: Stuck in SENDING_READY_SIGNAL state for " + (timeInState / 1000) + " seconds");
                    Logger.log("MuleTradeNode: Forcing transition to WAITING_FOR_TRADE_INIT state");

                    // Send the MULE_READY message again just to be sure
                    muleServer.queueOutgoingMessage("MULE_READY");

                    // Force transition to next state
                    setTradeStatus(MuleTradeStatus.WAITING_FOR_TRADE_INIT);
                }
                break;

            case TRADING_SCREEN_1:
                if (!Trade.isOpen(1)) {
                    Logger.warn("MuleTradeNode: State is TRADING_SCREEN_1 but trade screen 1 is not open");
                    if (Trade.isOpen(2)) {
                        Logger.log("MuleTradeNode: Trade screen 2 is open, updating state");
                        setTradeStatus(MuleTradeStatus.TRADING_SCREEN_2);
                    } else if (!Trade.isOpen()) {
                        Logger.warn("MuleTradeNode: No trade screen is open, resetting state");
                        resetState("Trade screen closed unexpectedly");
                    }
                }
                break;

            case TRADING_SCREEN_2:
                if (!Trade.isOpen(2)) {
                    Logger.warn("MuleTradeNode: State is TRADING_SCREEN_2 but trade screen 2 is not open");
                    if (Trade.isOpen(1)) {
                        Logger.log("MuleTradeNode: Trade screen 1 is open, updating state");
                        setTradeStatus(MuleTradeStatus.TRADING_SCREEN_1);
                    } else if (!Trade.isOpen()) {
                        Logger.warn("MuleTradeNode: No trade screen is open, resetting state");
                        resetState("Trade screen closed unexpectedly");
                    }
                }
                break;

            case WAITING_FOR_COMPLETION:
                // If we've been waiting for completion for more than 10 seconds and trade is not open,
                // assume it's complete
                if (!Trade.isOpen() && timeInState > 10000) {
                    Logger.log("MuleTradeNode: Trade appears to be complete");
                    setTradeStatus(MuleTradeStatus.TRADE_COMPLETE);
                }
                break;

            case WAITING_FOR_TRADE_INIT:
                // If we've been waiting for trade init for more than 30 seconds, check if client is still nearby
                if (timeInState > 30000) {
                    Player clientPlayer = Players.closest(p -> p != null &&
                                                   p.getName() != null &&
                                                   p.getName().equalsIgnoreCase(currentTrader) &&
                                                   p.distance() <= 15);

                    if (clientPlayer == null) {
                        Logger.warn("MuleTradeNode: Client player not found after waiting for trade init for 30 seconds");
                        resetState("Client player not found after timeout");
                    }
                }
                break;
        }
    }

    /**
     * Resets the state machine to IDLE
     * @param reason The reason for the reset
     */
    private void resetState(String reason) {
        Logger.warn("MuleTradeNode: Resetting state machine. Reason: " + reason);
        Logger.warn("MuleTradeNode: Previous state: " + tradeStatus + ", Trader: " + currentTrader);

        // Send a message to the client if connected
        if (muleServer.isClientConnected()) {
            muleServer.queueOutgoingMessage("STATE_RESET:" + reason);
        }

        // Reset state
        this.currentTrader = null;
        setTradeStatus(MuleTradeStatus.IDLE);

        // If trade is open, decline it
        if (Trade.isOpen()) {
            Logger.log("MuleTradeNode: Declining open trade during reset");
            Trade.declineTrade();
            Sleep.sleepUntil(() -> !Trade.isOpen(), 3000);
        }
    }

    private void registerInventoryGainListener() {
        if (inventoryListenerRegistered) return;
        inventoryListenerRegistered = true;
        ScriptContext context = getContext();
        if (context == null) {
            Logger.error("MuleTradeNode: ScriptContext is null, cannot register inventory event listener");
            return;
        }
        // Listen for incoming items (wealth in)
        context.getEventManager().addEventListener(EventType.ITEM_GAINED, event -> {
            if (tradeStatus != MuleTradeStatus.TRADING_SCREEN_1 && tradeStatus != MuleTradeStatus.TRADING_SCREEN_2 && tradeStatus != MuleTradeStatus.WAITING_FOR_COMPLETION) return;
            String itemName = (String) event.getAttribute("name");
            int quantity = (int) event.getAttribute("quantity");
            int price = LivePrices.get(itemName);
            long value = (itemName.equalsIgnoreCase("Coins") || itemName.equalsIgnoreCase("Coin")) ? quantity : (long) price * quantity;
            if (muleOverlay != null) muleOverlay.addIncomingGP(value);
        });
        // Listen for outgoing items (wealth out)
        context.getEventManager().addEventListener(EventType.ITEM_LOST, event -> {
            if (tradeStatus != MuleTradeStatus.TRADING_SCREEN_1 && tradeStatus != MuleTradeStatus.TRADING_SCREEN_2 && tradeStatus != MuleTradeStatus.WAITING_FOR_COMPLETION) return;
            String itemName = (String) event.getAttribute("name");
            int quantity = (int) event.getAttribute("quantity");
            int price = LivePrices.get(itemName);
            long value = (itemName.equalsIgnoreCase("Coins") || itemName.equalsIgnoreCase("Coin")) ? quantity : (long) price * quantity;
            if (muleOverlay != null) muleOverlay.addOutgoingGP(value);
        });
        Logger.log("MuleTradeNode: Registered inventory ITEM_GAINED/ITEM_LOST event listeners for muling wealth tracking");
    }

    @Override
    protected int onExecute() {
        // FIX: Only process messages in handleIncomingMessages
        handleIncomingMessages();

        // --- FIX: If in WAITING_FOR_CLIENT_CONFIRM and trade window opens with correct client, transition to TRADING_SCREEN_1 ---
        if (tradeStatus == MuleTradeStatus.WAITING_FOR_CLIENT_CONFIRM && Trade.isOpen()) {
            String tradePartner = Trade.getTradingWith();
            if (tradePartner != null && currentTrader != null && tradePartner.equalsIgnoreCase(currentTrader)) {
                Logger.log("MuleTradeNode: Trade initiated by client while waiting for confirm. Accepting trade.");
                setTradeStatus(MuleTradeStatus.TRADING_SCREEN_1);
                return handleTradeAccept();
            }
        }
        // --- END FIX ---

        // Update meeting area to ensure it's current (only if no client-specified location)
        // This is now handled by client communication

        // Check for state timeout and verify state
        checkStateTimeout();

        // Log current state for debugging
        Logger.log("MuleTradeNode: Current state: " + tradeStatus + ", Trader: " + currentTrader + ", Meeting spot: " + currentMeetingSpotName);

        // First check if a trade is open and handle it immediately with highest priority
        if (Trade.isOpen()) {
            // If we're in any trade screen, handle it first
            return handleTradeAccept();
        }

        // Execute based on current status
        switch (tradeStatus) {
            case WAITING_FOR_CLIENT_CONFIRM:
                // Check if we're at the meeting spot
                if (!currentMeetingArea.contains(Players.getLocal())) {
                    Logger.log("MuleTradeNode: Walking to meeting spot...");
                    if (Walking.shouldWalk() && Walking.walk(currentMeetingArea.getCenter())) {
                        Sleep.sleepUntil(() -> currentMeetingArea.contains(Players.getLocal()), 8000);
                    }
                    return 600;
                }
                // We're at the meeting spot, just wait for client
                Logger.log("MuleTradeNode: At meeting spot, waiting for client...");
                return 1000;

            case SENDING_READY_SIGNAL:
                return handleSendingReady();

            case WAITING_FOR_TRADE_INIT:
                return handleWaitForTrade();

            case TRADING_SCREEN_1:
            case TRADING_SCREEN_2:
                return handleTradeAccept();

            case WAITING_FOR_COMPLETION:
                if (!Trade.isOpen()) {
                    Logger.log("MuleTradeNode: Trade finished.");
                    setTradeStatus(MuleTradeStatus.TRADE_COMPLETE);
                    muleServer.queueOutgoingMessage("TRADE_COMPLETE"); // Inform client
                }
                Sleep.sleep(300, 300);
                return 300;

            case TRADE_COMPLETE:
                Logger.log("MuleTradeNode: Trade sequence complete. Resetting.");
                // Reset for next trade
                this.currentTrader = null;
                setTradeStatus(MuleTradeStatus.IDLE);
                return 500;

            case ERROR:
                Logger.warn("MuleTradeNode: In error state. Resetting.");
                this.currentTrader = null;
                setTradeStatus(MuleTradeStatus.IDLE);
                Sleep.sleep(2000);
                return 1000;

            case IDLE:
                // If client is connected but we are idle, means we are waiting for initial confirm msg
                if (muleServer.isClientConnected()) {
                    setTradeStatus(MuleTradeStatus.WAITING_FOR_CLIENT_CONFIRM);
                    Logger.log("MuleTradeNode: Client connected, moving to WAITING_FOR_CLIENT_CONFIRM state");
                }
                return 1000;

            default:
                return 600;
        }
    }

    private void handleIncomingMessages() {
        String message;
        while ((message = muleServer.pollIncomingMessage()) != null) {
            Logger.log("MuleTradeNode: Processing message: " + message + " | currentTrader: " + currentTrader + " | tradeStatus: " + tradeStatus);
            // Handle ITEM_LIST message
            if (message.startsWith("ITEM_LIST:")) {
                String json = message.substring("ITEM_LIST:".length());
                try {
                    JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
                    expectedItemsToGain.clear();
                    gainedItems.clear();
                    for (String key : obj.keySet()) {
                        expectedItemsToGain.put(key, obj.get(key).getAsInt());
                    }
                    Logger.log("MuleTradeNode: Received expected item list from client: " + expectedItemsToGain);
                    registerInventoryGainListener();
                } catch (Exception e) {
                    Logger.error("MuleTradeNode: Failed to parse ITEM_LIST JSON: " + e.getMessage());
                }
                continue;
            }
            // Handle initial connection
            if (message.startsWith("CONNECT")) {
                Logger.log("MuleTradeNode: Client connected, waiting for trader name");
                tradeStatus = MuleTradeStatus.WAITING_FOR_CLIENT_CONFIRM;
                muleServer.setTradeStatus("CONNECTED");
                continue;
            }
            // Auto-detect trader name from first trade or message
            if (message.startsWith("TRADER_NAME:") || message.startsWith("TRADER:")) {
                String prefix = message.startsWith("TRADER_NAME:") ? "TRADER_NAME:" : "TRADER:";
                String traderName = message.substring(prefix.length()).trim();
                Logger.log("MuleTradeNode: Received trader name: " + traderName);
                this.currentTrader = traderName;
                Logger.log("MuleTradeNode: Set currentTrader to " + this.currentTrader);
                setTradeStatus(MuleTradeStatus.WAITING_FOR_CLIENT_CONFIRM);
                continue;
            }
            // Handle meeting spot message
            if (message.startsWith("CLIENT_WAITING_AT_") || message.startsWith("MEETING_SPOT:")) {
                String meetingSpot = null;
                if (message.startsWith("CLIENT_WAITING_AT_")) {
                    meetingSpot = message.substring("CLIENT_WAITING_AT_".length()).trim();
                } else if (message.startsWith("MEETING_SPOT:")) {
                    meetingSpot = message.substring("MEETING_SPOT:".length()).trim();
                }

                if (meetingSpot != null && !meetingSpot.isEmpty()) {
                    Logger.log("MuleTradeNode: Received meeting spot from client: " + meetingSpot);
                    updateMeetingArea(meetingSpot);
                }
                continue;
            }

            // Handle reset command
            if (message.equals("RESET") || message.startsWith("RESET:")) {
                String reason = message.contains(":") ? message.substring(message.indexOf(":") + 1) : "Client requested reset";
                Logger.log("MuleTradeNode: Client requested state reset: " + reason);
                resetState(reason);
                continue;
            }

            if ("PLAYER_FOUND_CONFIRM_READY".equals(message) ||
                "MULE_FOUND".equals(message) ||
                "CLIENT_READY".equals(message)) {
                if (currentTrader != null) {
                    if (tradeStatus == MuleTradeStatus.WAITING_FOR_CLIENT_CONFIRM || tradeStatus == MuleTradeStatus.IDLE) {
                        Logger.log("MuleTradeNode: Client " + currentTrader + " found us, preparing to trade");
                        setTradeStatus(MuleTradeStatus.WAITING_FOR_TRADE_INIT);
                    } else {
                        Logger.warn("MuleTradeNode: Received " + message + " in unexpected state: " + tradeStatus);
                        setTradeStatus(MuleTradeStatus.WAITING_FOR_TRADE_INIT);
                    }
                }
            } else if (message.startsWith("TRADE_COMPLETE")) {
                Logger.log("MuleTradeNode: Client confirmed trade complete.");
                if (tradeStatus == MuleTradeStatus.WAITING_FOR_COMPLETION || tradeStatus == MuleTradeStatus.TRADING_SCREEN_1
                    || tradeStatus == MuleTradeStatus.TRADING_SCREEN_2) {
                    tradeStatus = MuleTradeStatus.TRADE_COMPLETE;
                }
            } else if (message.startsWith("WAITING_FOR_MULE_ACCEPT_1") || message.startsWith("WAITING_FOR_MULE_ACCEPT_2")) {
                // Client is waiting for us to accept the trade
                Logger.log("MuleTradeNode: Client is waiting for us to accept the trade");
                if (Trade.isOpen()) {
                    if (Trade.isOpen(1)) {
                        tradeStatus = MuleTradeStatus.TRADING_SCREEN_1;
                    } else if (Trade.isOpen(2)) {
                        tradeStatus = MuleTradeStatus.TRADING_SCREEN_2;
                    }
                    muleServer.setTradeStatus("TRADING");
                }
            } else if ("TRADE_INITIATION_FAILED".equals(message)) {
                Logger.warn("MuleTradeNode: Client failed to initiate trade. Attempting to initiate from mule side.");
                // Try to initiate trade from mule side as a fallback
                Player clientPlayer = Players.closest(p -> p != null &&
                                                  p.getName() != null &&
                                                  p.getName().equalsIgnoreCase(currentTrader) &&
                                                  p.distance() <= 15);
                if (clientPlayer != null && clientPlayer.distance() <= 2) {
                    Logger.log("MuleTradeNode: Attempting to initiate trade with client as fallback");
                    muleServer.queueOutgoingMessage("MULE_INITIATING_TRADE");
                    Trade.tradeWithPlayer(clientPlayer);
                    Sleep.sleepUntil(Trade::isOpen, 3000);
                }
            } else if (message.startsWith("ERROR:")) {
                Logger.error("MuleTradeNode: Received error from client: " + message.substring(6));
                // Don't immediately set to error state, try to recover
                if (Trade.isOpen()) {
                    Logger.log("MuleTradeNode: Trade is open, trying to recover...");
                    // Continue with the trade if possible
                } else {
                    // If not in trade, reset to waiting
                    tradeStatus = MuleTradeStatus.WAITING_FOR_TRADE_INIT;
                    muleServer.setTradeStatus("WAITING_FOR_TRADE");
                }
            } else if ("CLIENT_INITIATING_TRADE".equals(message)) {
                Logger.log("MuleTradeNode: Client is initiating trade. Acknowledging.");
                setTradeStatus(MuleTradeStatus.WAITING_FOR_TRADE_INIT);
                muleServer.queueOutgoingMessage("MULE_READY_TO_ACCEPT");
                continue;
            }
        }
    }

     private int handleSendingReady() {
         // Ensure we are at the meeting spot
        if (!currentMeetingArea.contains(Players.getLocal())) {
            setStatus("Walking to meeting spot before sending ready signal...");
            if (Walking.shouldWalk() && Walking.walk(currentMeetingArea.getCenter())) {
                 Sleep.sleepUntil(() -> currentMeetingArea.contains(Players.getLocal()), 8000);
            }
            Sleep.sleep(600, 600);
            return 600; // Return fixed sleep time
        }

         // Send ready signal
         Logger.log("MuleTradeNode: Sending MULE_READY to client.");
         muleServer.queueOutgoingMessage("MULE_READY");
         setTradeStatus(MuleTradeStatus.WAITING_FOR_TRADE_INIT);
         Sleep.sleep(200, 300);
         return 300; // Return fixed sleep time
     }

     private int handleWaitForTrade() {
        if (currentTrader == null) {
            Logger.warn("MuleTradeNode: No client username available while waiting for trade");
            return 500;
        }

        setStatus("Waiting for " + currentTrader + " to initiate trade...");
        if (Players.getLocal().distance(Players.closest(currentTrader)) <= 2){
            Trade.tradeWithPlayer(currentTrader);
            Sleep.sleepUntil(Trade::isOpen, 3000);
        }
        // If client opened the trade window, handle it
        if (Trade.isOpen()) {
            String tradePartner = Trade.getTradingWith();
            if (tradePartner != null && tradePartner.equalsIgnoreCase(currentTrader)) {
                Logger.log("MuleTradeNode: Trade initiated by " + currentTrader);
                setTradeStatus(MuleTradeStatus.TRADING_SCREEN_1);
                return handleTradeAccept();
            } else {
                Logger.warn("MuleTradeNode: Unexpected trader '" + tradePartner + "', declining");
                Trade.declineTrade();
                Sleep.sleepUntil(() -> !Trade.isOpen(), 3000);
                setTradeStatus(MuleTradeStatus.WAITING_FOR_TRADE_INIT);
                return 500;
            }
        }

        // Still waiting for the client to open the trade interface
        return 500;
    }


    private int handleTradeAccept() {
        if (!Trade.isOpen()) {
            Logger.warn("MuleTradeNode: Trade closed unexpectedly during accept phase.");
            setTradeStatus(MuleTradeStatus.WAITING_FOR_TRADE_INIT);
            return 500;
        }
        String tradePartner = Trade.getTradingWith();
        if (tradePartner == null || !tradePartner.equalsIgnoreCase(currentTrader)) {
            Logger.warn("MuleTradeNode: Trade partner mismatch. Expected: " + currentTrader + ", Got: " + tradePartner);
            Trade.declineTrade();
            Sleep.sleepUntil(() -> !Trade.isOpen(), 3000);
            setTradeStatus(MuleTradeStatus.WAITING_FOR_TRADE_INIT);
            return 500;
        }
        // --- Overlay trade increment: only increment once per trade session ---
        if (Trade.isOpen(1) && muleOverlay != null && tradeStatus == MuleTradeStatus.TRADING_SCREEN_1) {
            muleOverlay.incrementTrades();
        }
        // Handle second trade screen
        if (Trade.isOpen(2)) {
            Logger.log("MuleTradeNode: Currently on trade screen 2");
            setTradeStatus(MuleTradeStatus.TRADING_SCREEN_2);
            setStatus("Accepting trade (screen 2)...");

            // Always accept second screen immediately without checking anything
            if (!Trade.hasAcceptedTrade(TradeUser.US)) {
                Logger.log("MuleTradeNode: Accepting second trade screen");

                // Just accept the trade, don't verify items
                boolean accepted = false;
                for (int i = 0; i < 3; i++) {  // Try up to 3 times
                    if (Trade.acceptTrade(2)) {
                        accepted = true;
                        Logger.log("MuleTradeNode: Successfully called acceptTrade(2) on attempt " + (i+1));
                        break;
                    } else {
                        Logger.warn("MuleTradeNode: Failed to call acceptTrade(2) on attempt " + (i+1));
                        Sleep.sleep(400, 600);
                    }
                }

                if (accepted) {
                    // Wait for our acceptance to register
                    if (Sleep.sleepUntil(() -> Trade.hasAcceptedTrade(TradeUser.US) || !Trade.isOpen(), 5000)) {
                        if (Trade.hasAcceptedTrade(TradeUser.US)) {
                            Logger.log("MuleTradeNode: Successfully accepted second trade screen");
                        } else if (!Trade.isOpen()) {
                            Logger.log("MuleTradeNode: Trade completed immediately after accepting");
                            tradeStatus = MuleTradeStatus.WAITING_FOR_COMPLETION;
                        }
                    } else {
                        Logger.warn("MuleTradeNode: Failed to verify our acceptance on second screen");
                        // Try again instead of erroring
                    }
                }
            } else {
                // We've accepted, waiting for client
                Logger.log("MuleTradeNode: Already accepted second screen, waiting for client");
                if (Trade.hasAcceptedTrade(TradeUser.THEM)) {
                    Logger.log("MuleTradeNode: Both parties accepted second screen");
                    // Wait for trade to complete
                    Sleep.sleepUntil(() -> !Trade.isOpen(), 3000);
                    setTradeStatus(MuleTradeStatus.WAITING_FOR_COMPLETION);
                    return 600;
                }
            }
        }
        // Handle first trade screen
        else if (Trade.isOpen(1)) {
            Logger.log("MuleTradeNode: Currently on trade screen 1");
            setTradeStatus(MuleTradeStatus.TRADING_SCREEN_1);
            setStatus("Accepting trade (screen 1)...");

            // Always accept first screen immediately
            if (!Trade.hasAcceptedTrade(TradeUser.US)) {
                Logger.log("MuleTradeNode: Accepting first trade screen");

                boolean accepted = false;
                for (int i = 0; i < 3; i++) {  // Try up to 3 times
                    if (Trade.acceptTrade(1)) {
                        accepted = true;
                        Logger.log("MuleTradeNode: Successfully called acceptTrade(1) on attempt " + (i+1));
                        break;
                    } else {
                        Logger.warn("MuleTradeNode: Failed to call acceptTrade(1) on attempt " + (i+1));
                        Sleep.sleep(400, 600);
                    }
                }

                if (accepted) {
                    // Wait for our acceptance to register
                    if (Sleep.sleepUntil(() -> Trade.hasAcceptedTrade(TradeUser.US) || !Trade.isOpen(), 5000)) {
                        if (Trade.hasAcceptedTrade(TradeUser.US)) {
                            Logger.log("MuleTradeNode: Successfully accepted first trade screen");
                        } else if (!Trade.isOpen()) {
                            Logger.warn("MuleTradeNode: Trade window closed unexpectedly");
                            setTradeStatus(MuleTradeStatus.WAITING_FOR_TRADE_INIT);
                            return 500;
                        }
                    } else {
                        Logger.warn("MuleTradeNode: Failed to verify our acceptance on first screen");
                        // Try again instead of erroring
                    }
                }
            } else {
                // We've accepted, waiting for client
                Logger.log("MuleTradeNode: Already accepted first screen, waiting for client");
                if (Trade.hasAcceptedTrade(TradeUser.THEM)) {
                    Logger.log("MuleTradeNode: Both parties accepted first screen");
                    if (Sleep.sleepUntil(() -> Trade.isOpen(2), 5000)) {
                        Logger.log("MuleTradeNode: Second trade screen opened");
                        return 300; // Quick return to handle second screen
                    }
                }
            }
        } else {
            // Not in a recognized trade screen but Trade.isOpen() is true
            Logger.warn("MuleTradeNode: In unrecognized trade screen state");
            // Try to accept whatever screen we're on
            Trade.acceptTrade();
            return 600;
        }

        // For any case not handled above, return a short sleep
        Sleep.sleep(300, 400);
        return 300;
    }


    // Public getter for status (used in paint)
    public String getStatus() {
        return tradeStatus.name() + (currentTrader != null ? " (" + currentTrader + ")" : "");
    }


    @Override
    public void cleanup() {
        Logger.log("MuleTradeNode cleanup.");
        // Handle any open trades before resetting
        if (Trade.isOpen()) {
            Logger.log("MuleTradeNode: Closing open trade during cleanup");
            Trade.close();
            Sleep.sleepUntil(() -> !Trade.isOpen(), 3000);
        }
        // Reset state if script stops mid-trade
        this.currentTrader = null;
        this.tradeStatus = MuleTradeStatus.IDLE;
        // Server cleanup should happen in MuleServerScript.onStop()
    }

    /**
     * Called after a trade completes to update overlay GP stats
     */
    private void updateOverlayGPStats() {
        if (muleOverlay == null) return;
        // Incoming GP: sum coins received
        long incoming = 0;
        long outgoing = 0;
        for (Map.Entry<String, Integer> entry : gainedItems.entrySet()) {
            String item = entry.getKey();
            int qty = entry.getValue();
            int price = LivePrices.get(item); // Use main game prices
            if (item.equalsIgnoreCase("Coins") || item.equalsIgnoreCase("Coin")) {
                incoming += qty;
            } else {
                incoming += (long) price * qty;
            }
        }
        for (Map.Entry<String, Integer> entry : expectedItemsToGain.entrySet()) {
            String item = entry.getKey();
            int qty = entry.getValue();
            int price = LivePrices.get(item);
            if (item.equalsIgnoreCase("Coins") || item.equalsIgnoreCase("Coin")) {
                outgoing += qty;
            } else {
                outgoing += (long) price * qty;
            }
        }
        muleOverlay.addIncomingGP(incoming);
        muleOverlay.addOutgoingGP(outgoing);
    }
}