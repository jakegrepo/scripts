package scripts.Mule.gui;

import core.context.ScriptContext;
import core.gui.AbstractSettingsTab;
import core.gui.ScriptGUI;
import core.base.ScarScript;
import org.dreambot.api.utilities.Logger;
import scripts.Herb.MixologyScript;
import scripts.Mule.MuleServerScript;
import scripts.Mule.config.MuleConfig;

import javax.swing.*;
import java.awt.*;
import java.io.File;

/**
 * The main settings tab for the Mule Server script.
 * It wraps the MuleSettingsPanel.
 */
public class MuleSettingsTab extends AbstractSettingsTab {

    private MuleSettingsPanel settingsPanel;
    private final MuleConfig config;

    public MuleSettingsTab(ScriptContext context) {
        super(context);
        MuleServerScript script = (MuleServerScript) context.getScript();
        this.config = script.getConfig();
        // Initialize will call createComponents()
    }

    @Override
    public void createComponents() {
        // Create the settings panel if not already created
        if (this.settingsPanel == null) {
            this.settingsPanel = new MuleSettingsPanel(config);
        }

        // Add to the settings tab using the proper method
        // The duplicate section issue needs to be fixed in MuleSettingsPanel
        addSection("Server Configuration", settingsPanel);

        // Load current settings
        loadSettings();
    }

    @Override
    public String getTitle() {
        return "Mule Server";
    }

    @Override
    public void saveSettings() {
        if (settingsPanel != null) {
            if (settingsPanel.saveSettings()) {
                // If save was successful, also save to config file
                config.saveConfig();
                Logger.log("Mule settings saved successfully");
            }
        }
    }

    @Override
    public void resetToDefaults() {
        if (config != null) {
            config.reset();
            if (settingsPanel != null) {
                settingsPanel.loadSettings(); // Reload UI with default values
            }
        }
    }

    /**
     * Loads settings from the config into the UI
     */
    public void loadSettings() {
        if (settingsPanel != null) {
            settingsPanel.loadSettings();
        }
    }

    /**
     * Handle saving a profile with the current settings
     */
    public void handleSaveProfile() {
        String profileName = JOptionPane.showInputDialog(
                getPanel(),
                "Enter profile name:",
                "Save Profile",
                JOptionPane.PLAIN_MESSAGE
        );

        if (profileName != null && !profileName.trim().isEmpty()) {
            try {
                Logger.log("=== SAVING PROFILE: " + profileName + " ===");

                // First save current settings from UI
                saveSettings();

                // Now save to profile
                config.saveProfile(profileName.trim());

                Logger.log("=== PROFILE SAVED SUCCESSFULLY ===");
                JOptionPane.showMessageDialog(
                        getPanel(),
                        "Profile saved successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE
                );
            } catch (Exception e) {
                Logger.error("Error saving profile: " + e.getMessage());
                JOptionPane.showMessageDialog(
                        getPanel(),
                        "Error saving profile: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }

    /**
     * Handle loading a saved profile
     */
    public void handleLoadProfile() {
        String selectedProfile = (String) JOptionPane.showInputDialog(
                getPanel(),
                "Select a profile to load:",
                "Load Profile",
                JOptionPane.PLAIN_MESSAGE,
                null,
                config.getAvailableProfiles().toArray(),
                null
        );

        if (selectedProfile != null) {
            try {
                Logger.log("=== LOADING PROFILE: " + selectedProfile + " ===");

                // Load the profile
                config.loadProfile(selectedProfile);

                // Update UI with loaded settings
                loadSettings();

                Logger.log("=== PROFILE LOADED SUCCESSFULLY ===");
                JOptionPane.showMessageDialog(
                        getPanel(),
                        "Profile loaded successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE
                );
            } catch (Exception e) {
                Logger.error("Error loading profile: " + e.getMessage());
                JOptionPane.showMessageDialog(
                        getPanel(),
                        "Error loading profile: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }

    /**
     * Handle removing a saved profile
     */
    public void handleRemoveProfile() {
        String selectedProfile = (String) JOptionPane.showInputDialog(
                getPanel(),
                "Select a profile to remove:",
                "Remove Profile",
                JOptionPane.WARNING_MESSAGE,
                null,
                config.getAvailableProfiles().toArray(),
                null
        );

        if (selectedProfile != null) {
            try {
                int confirm = JOptionPane.showConfirmDialog(
                        getPanel(),
                        "Are you sure you want to remove the profile '" + selectedProfile + "'?",
                        "Confirm Removal",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (confirm == JOptionPane.YES_OPTION) {
                    config.deleteProfile(selectedProfile);
                    JOptionPane.showMessageDialog(
                            getPanel(),
                            "Profile removed successfully!",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }
            } catch (Exception e) {
                Logger.error("Error removing profile: " + e.getMessage());
                JOptionPane.showMessageDialog(
                        getPanel(),
                        "Error removing profile: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
}