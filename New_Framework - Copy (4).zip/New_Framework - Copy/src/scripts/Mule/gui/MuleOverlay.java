package scripts.Mule.gui;

import core.paint.debug.DebugOverlayInterface;
import core.context.ScriptContext;
import scripts.Mule.MuleServerScript;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * Overlay for displaying Mule script statistics in a visually appealing way.
 */
public class MuleOverlay implements DebugOverlayInterface {
    private final ScriptContext context;
    private final MuleServerScript script;
    private boolean enabled = true;

    // Stats tracking
    private long startTime;
    private int totalTrades = 0;
    private long incomingGP = 0;
    private long outgoingGP = 0;
    private String currentStatus = "Starting...";

    // UI colors & fonts
    private static final Color PRIMARY_COLOR     = new Color(20,22,28,225);
    private static final Color SECONDARY_COLOR   = new Color(25,28,34,180);
    private static final Color ACCENT_COLOR      = new Color(110,140,255,255);
    private static final Color TEXT_COLOR        = new Color(255,255,255,255);
    private static final Color MUTED_TEXT_COLOR  = new Color(180,185,200,255);
    private static final Color SUCCESS_COLOR     = new Color(85,230,130,255);
    private static final Color BORDER_COLOR      = new Color(60,70,120,120);
    private static final Color DIVIDER_COLOR     = new Color(90,100,160,100);

    private static final int PANEL_PADDING         = 12;
    private static final int CORNER_RADIUS         = 12;
    private static final int SECTION_CORNER_RADIUS = 8;
    private static final Font REGULAR_FONT    = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font SMALL_FONT      = new Font("Segoe UI", Font.PLAIN, 11);
    private static final Font ROW_HEADER_FONT = new Font("Segoe UI", Font.BOLD, 12);
    private static final Font HEADER_FONT     = new Font("Segoe UI", Font.BOLD, 14);

    // Icons (placeholder for now)
    private static final Map<String,String> ICON_URLS = new HashMap<>();
    private static final Map<String,BufferedImage> ICONS = new HashMap<>();
    private static boolean iconsLoaded = false;
    private static boolean isLoadingIcons = false;
    static {
        ICON_URLS.put("TRADE", "https://i.ibb.co/0j1n6kF/trade-icon.png");
        ICON_URLS.put("COINS", "https://i.ibb.co/Tq8rRjkF/Coins-detail.png");
        preloadIcons();
    }

    private static void preloadIcons() {
        if (isLoadingIcons) return;
        isLoadingIcons = true;
        new Thread(() -> {
            Map<String,BufferedImage> cache = new HashMap<>();
            ICON_URLS.forEach((key,url) -> {
                try {
                    BufferedImage img = ImageIO.read(new URL(url));
                    BufferedImage scaled = new BufferedImage(14,14,BufferedImage.TYPE_INT_ARGB);
                    Graphics2D g2 = scaled.createGraphics();
                    g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                    g2.drawImage(img,0,0,14,14,null);
                    g2.dispose();
                    cache.put(key,scaled);
                } catch (IOException e) {
                    cache.put(key, generatePlaceholderIcon(key));
                }
            });
            synchronized(ICONS) {
                ICONS.putAll(cache);
                iconsLoaded = true;
                isLoadingIcons = false;
            }
        }, "MuleIconLoader").start();
    }

    private static BufferedImage generatePlaceholderIcon(String key) {
        BufferedImage icon = new BufferedImage(14,14,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = icon.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(ACCENT_COLOR);
        g.fillOval(0,0,14,14);
        g.setColor(PRIMARY_COLOR);
        g.drawString(key.substring(0,1),4,10);
        g.dispose();
        return icon;
    }

    public MuleOverlay(ScriptContext context, MuleServerScript script) {
        this.context = context;
        this.script  = script;
        this.startTime = System.currentTimeMillis();
    }

    @Override
    public void render(Graphics2D g) {
        if (!enabled) return;
        renderPanel(g);
    }

    private void renderPanel(Graphics2D g) {
        Rectangle panelBounds = new Rectangle(7, 300, 400, 160);
        Paint orig = g.getPaint();
        GradientPaint bg = new GradientPaint(
                panelBounds.x, panelBounds.y,
                new Color(18,20,32,220),
                panelBounds.x, panelBounds.y + panelBounds.height,
                new Color(25,28,40,235)
        );
        g.setPaint(bg);
        g.fillRoundRect(panelBounds.x, panelBounds.y, panelBounds.width, panelBounds.height, CORNER_RADIUS, CORNER_RADIUS);
        g.setPaint(orig);

        g.setColor(BORDER_COLOR);
        g.setStroke(new BasicStroke(1.5f));
        g.drawRoundRect(panelBounds.x, panelBounds.y, panelBounds.width, panelBounds.height, CORNER_RADIUS, CORNER_RADIUS);

        int titleY = panelBounds.y + PANEL_PADDING;
        GradientPaint hdr = new GradientPaint(
                panelBounds.x, titleY,
                new Color(40,45,80,180),
                panelBounds.x + panelBounds.width, titleY,
                new Color(60,65,100,120)
        );
        g.setPaint(hdr);
        g.fillRoundRect(panelBounds.x + 5, titleY - 2, panelBounds.width - 10, 22, 8, 8);
        g.setPaint(orig);

        // Title
        g.setFont(new Font("Segoe UI", Font.BOLD, 16));
        g.setColor(new Color(140,170,255,90));
        for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++) {
            if (i != 0 || j != 0) g.drawString("ScarMule", panelBounds.x + 10 + i, titleY + 17 + j);
        }
        g.setColor(Color.black);
        g.drawString("ScarMule", panelBounds.x + 10, titleY + 18);
        g.setColor(TEXT_COLOR);
        g.drawString("ScarMule", panelBounds.x + 10, titleY + 17);

        // Runtime clock
        g.setFont(SMALL_FONT);
        g.setColor(ACCENT_COLOR);
        String runtime = formatTime(System.currentTimeMillis() - startTime);
        int rtW = g.getFontMetrics().stringWidth(runtime);
        drawClockIcon(g,
                panelBounds.x + panelBounds.width - PANEL_PADDING - rtW - 18,
                titleY + 10
        );
        g.drawString(runtime,
                panelBounds.x + panelBounds.width - PANEL_PADDING - rtW,
                titleY + 12
        );

        // Divider
        g.setColor(DIVIDER_COLOR);
        g.setStroke(new BasicStroke(1f));
        g.drawLine(
                panelBounds.x + PANEL_PADDING, titleY + 22,
                panelBounds.x + panelBounds.width - PANEL_PADDING, titleY + 22
        );

        // Status box
        int sx = panelBounds.x + PANEL_PADDING;
        int sy = titleY + 24;
        int sw = panelBounds.width - PANEL_PADDING * 2;
        int sh = 32;
        g.setColor(SECONDARY_COLOR);
        g.fillRoundRect(sx, sy, sw, sh, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);
        g.setColor(BORDER_COLOR);
        g.drawRoundRect(sx, sy, sw, sh, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);
        g.setFont(ROW_HEADER_FONT);
        g.setColor(TEXT_COLOR);
        g.drawString(currentStatus, sx + 10, sy + g.getFontMetrics().getAscent() + 12);

        // Content sections
        int contentY = sy + sh + PANEL_PADDING;
        int sectionW = (panelBounds.width - PANEL_PADDING * 3) / 2;
        int sectionH = 60;
        drawTradeSection(g, sx, contentY, sectionW, sectionH);
        drawGPSection(g, sx + PANEL_PADDING + sectionW, contentY, sectionW, sectionH);
    }

    private void drawTradeSection(Graphics2D g, int x, int y, int w, int h) {
        Paint orig = g.getPaint();
        g.setPaint(new GradientPaint(x, y, new Color(30,35,50,140), x, y + h, new Color(25,28,34,160)));
        g.fillRoundRect(x, y, w, h, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);
        g.setPaint(orig);

        // Header
        g.setFont(HEADER_FONT);
        g.setColor(new Color(140,170,255,90));
        g.drawString("Trades", x + 26, y + 17);
        drawIcon(g, "TRADE", x + 8, y + 5);

        // Content
        g.setFont(ROW_HEADER_FONT);
        g.setColor(MUTED_TEXT_COLOR);
        g.drawString("Total Trades:", x + 10, y + 38);
        g.setFont(REGULAR_FONT);
        g.setColor(SUCCESS_COLOR);
        g.drawString(String.valueOf(totalTrades), x + w - g.getFontMetrics().stringWidth(String.valueOf(totalTrades)) - 10, y + 38);
    }

    private void drawGPSection(Graphics2D g, int x, int y, int w, int h) {
        Paint orig = g.getPaint();
        g.setPaint(new GradientPaint(x, y, new Color(30,35,50,140), x, y + h, new Color(25,30,45,160)));
        g.fillRoundRect(x, y, w, h, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);
        g.setPaint(orig);

        // Header
        g.setFont(HEADER_FONT);
        g.setColor(new Color(140,170,255,90));
        g.drawString("GP Flow", x + 26, y + 17);
        drawIcon(g, "COINS", x + 8, y + 5);

        // Content
        g.setFont(ROW_HEADER_FONT);
        g.setColor(MUTED_TEXT_COLOR);
        g.drawString("Incoming GP:", x + 10, y + 38);
        g.setFont(REGULAR_FONT);
        g.setColor(SUCCESS_COLOR);
        g.drawString(formatNumber(incomingGP), x + w - g.getFontMetrics().stringWidth(formatNumber(incomingGP)) - 10, y + 38);

        g.setFont(ROW_HEADER_FONT);
        g.setColor(MUTED_TEXT_COLOR);
        g.drawString("Outgoing GP:", x + 10, y + 56);
        g.setFont(REGULAR_FONT);
        g.setColor(Color.ORANGE);
        g.drawString(formatNumber(outgoingGP), x + w - g.getFontMetrics().stringWidth(formatNumber(outgoingGP)) - 10, y + 56);
    }

    private void drawIcon(Graphics2D g, String key, int x, int y) {
        BufferedImage icon;
        synchronized(ICONS) {
            icon = ICONS.getOrDefault(key, generatePlaceholderIcon(key));
        }
        g.setColor(new Color(120,140,200,60));
        g.fillOval(x - 1, y - 1, 16, 16);
        g.drawImage(icon, x, y, null);
    }

    private void drawClockIcon(Graphics2D g, int x, int y) {
        g.setColor(TEXT_COLOR);
        g.fillOval(x, y - 10, 15, 15);
        g.setColor(PRIMARY_COLOR);
        g.fillOval(x + 2, y - 8, 11, 11);
        g.setColor(TEXT_COLOR);
        g.drawLine(x + 7, y - 7, x + 7, y - 3);
        g.drawLine(x + 7, y - 7, x + 10, y - 4);
    }

    private String formatTime(long ms) {
        long s = ms / 1000, m = s / 60, h = m / 60;
        return String.format("%02d:%02d:%02d", h, m % 60, s % 60);
    }

    private String formatNumber(long n) {
        if (n < 1000) return String.valueOf(n);
        if (n < 1_000_000) return String.format("%.1fk", n / 1000.0).replace(".0k", "k");
        return String.format("%.2fm", n / 1_000_000.0).replace(".00m", "m");
    }

    // --- Stat update methods ---
    public void setStatus(String status) {
        if (status != null && !status.isEmpty()) {
            this.currentStatus = status;
        }
    }
    public void incrementTrades() { this.totalTrades++; }
    public void addIncomingGP(long gp) { this.incomingGP += gp; }
    public void addOutgoingGP(long gp) { this.outgoingGP += gp; }
    public void resetStats() {
        this.totalTrades = 0;
        this.incomingGP = 0;
        this.outgoingGP = 0;
        this.startTime = System.currentTimeMillis();
    }
    @Override public String getName()        { return "MuleStats"; }
    @Override public void setEnabled(boolean e) { this.enabled = e; }
    @Override public boolean isEnabled()        { return enabled; }
} 