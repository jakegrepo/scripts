package scripts.Mule.gui;

import org.dreambot.api.Client;
import org.dreambot.api.randoms.RandomEvent;
import org.dreambot.api.randoms.RandomManager;
import org.dreambot.api.utilities.Logger;
import scripts.Mule.MuleServerScript;
import scripts.Mule.config.MuleConfig;

import javax.swing.*;
import java.awt.*;

/**
 * GUI Panel for configuring Mule script settings.
 */
public class MuleSettingsPanel extends JPanel {

    private JTextField portField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JCheckBox autoLogoutCheckbox;
    private final MuleConfig config;
    private boolean previousAutoLogoutState;
    private MuleServerScript script;

    public MuleSettingsPanel(MuleConfig config) {
        this.config = config;
        this.previousAutoLogoutState = config.isAutoLogout();
        
        // Try to get the script instance if this panel was created from the script context
        if (config.getContext() != null && config.getContext().getScript() instanceof MuleServerScript) {
            script = (MuleServerScript) config.getContext().getScript();
        }
        
        initComponents();
        loadSettings(); // Load existing settings into fields
    }

    private void initComponents() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // --- SERVER SETTINGS SECTION ---
        JPanel serverPanel = new JPanel(new GridBagLayout());
        serverPanel.setBorder(BorderFactory.createTitledBorder("Server Settings"));
        GridBagConstraints serverGbc = new GridBagConstraints();
        serverGbc.insets = new Insets(2, 5, 2, 5);
        serverGbc.fill = GridBagConstraints.HORIZONTAL;
        serverGbc.anchor = GridBagConstraints.WEST;
        
        // Port Setting
        serverGbc.gridx = 0;
        serverGbc.gridy = 0;
        serverPanel.add(new JLabel("Server Port:"), serverGbc);

        portField = new JTextField(5); // Small field for port number
        portField.setToolTipText("The port the mule server will listen on (e.g., 61616)");
        serverGbc.gridx = 1;
        serverGbc.weightx = 1.0; // Allow field to expand horizontally
        serverPanel.add(portField, serverGbc);
        
        // Add server panel to main panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        add(serverPanel, gbc);
        
        // --- AUTO-LOGIN SETTINGS SECTION ---
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBorder(BorderFactory.createTitledBorder("Auto-Login Settings (Required for AFK Muling)"));
        GridBagConstraints loginGbc = new GridBagConstraints();
        loginGbc.insets = new Insets(2, 5, 2, 5);
        loginGbc.fill = GridBagConstraints.HORIZONTAL;
        loginGbc.anchor = GridBagConstraints.WEST;
        
        // Username Setting
        loginGbc.gridx = 0;
        loginGbc.gridy = 0;
        loginPanel.add(new JLabel("Username:"), loginGbc);

        usernameField = new JTextField(15);
        usernameField.setToolTipText("Account username for auto-login when a client connects");
        loginGbc.gridx = 1;
        loginGbc.weightx = 1.0;
        loginPanel.add(usernameField, loginGbc);
        
        // Password Setting
        loginGbc.gridx = 0;
        loginGbc.gridy = 1;
        loginGbc.weightx = 0.0;
        loginPanel.add(new JLabel("Password:"), loginGbc);

        passwordField = new JPasswordField(15);
        passwordField.setToolTipText("Account password for auto-login when a client connects");
        loginGbc.gridx = 1;
        loginGbc.weightx = 1.0;
        loginPanel.add(passwordField, loginGbc);
        
        // Auto-Logout Setting
        loginGbc.gridx = 0;
        loginGbc.gridy = 2;
        loginGbc.gridwidth = 2;
        autoLogoutCheckbox = new JCheckBox("Auto-Logout When Inactive");
        autoLogoutCheckbox.setToolTipText("Automatically log out when no mule client is connected");
        loginPanel.add(autoLogoutCheckbox, loginGbc);

        // Add login panel to main panel
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        add(loginPanel, gbc);
        
        // --- HOW TO USE SECTION ---
        JPanel howToUsePanel = new JPanel();
        howToUsePanel.setLayout(new BorderLayout());
        howToUsePanel.setBorder(BorderFactory.createTitledBorder("How to Use Auto-Logout Feature"));
        
        JTextArea howToUseText = new JTextArea(
            "1. Enter your login credentials above\n" +
            "2. Make sure Auto-Logout is checked\n" +
            "3. Start the script - it will automatically:\n" +
            "   • Log out when no clients are connected\n" +
            "   • Log in when a client connects for trading\n" +
            "   • Return to idle state after completing trades\n\n" +
            "Note: For this feature to work, you MUST provide valid login credentials."
        );
        howToUseText.setEditable(false);
        howToUseText.setBackground(new Color(240, 240, 240));
        howToUseText.setFont(new Font("SansSerif", Font.PLAIN, 11));
        howToUseText.setLineWrap(true);
        howToUseText.setWrapStyleWord(true);
        
        JScrollPane scrollPane = new JScrollPane(howToUseText);
        scrollPane.setPreferredSize(new Dimension(300, 120));
        howToUsePanel.add(scrollPane, BorderLayout.CENTER);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(howToUsePanel, gbc);

        // --- WARNING MESSAGE ---
        JPanel warningPanel = new JPanel();
        warningPanel.setLayout(new BorderLayout());
        JLabel warningLabel = new JLabel("<html><body style='width: 250px'><b>Important:</b> Credentials are stored locally and used only for auto-login. For security, use a unique password for this account.</body></html>");
        warningLabel.setForeground(Color.RED);
        warningPanel.add(warningLabel, BorderLayout.CENTER);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        add(warningPanel, gbc);

        // --- Filler ---
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.weighty = 1.0; // Push components to the top
        add(new JPanel(), gbc); // Add an empty panel to take up remaining vertical space
    }

    public void loadSettings() {
        if (config != null) {
            portField.setText(String.valueOf(config.getServerPort()));
            usernameField.setText(config.getUsername());
            passwordField.setText(config.getPassword());
            autoLogoutCheckbox.setSelected(config.isAutoLogout());
            previousAutoLogoutState = config.isAutoLogout();
        } else {
             Logger.warn("MuleSettingsPanel: Config was null during loadSettings.");
             // Set defaults in UI anyway?
             portField.setText("61616"); // Default port
             usernameField.setText("");
             passwordField.setText("");
             autoLogoutCheckbox.setSelected(true);
             previousAutoLogoutState = true;
        }
    }

    public boolean saveSettings() {
        if (config == null) {
            Logger.error("MuleSettingsPanel: Cannot save settings, config is null.");
            return false;
        }
        try {
            // Validate and save port setting
            int port = Integer.parseInt(portField.getText().trim());
            if (port < 1024 || port > 65535) {
                JOptionPane.showMessageDialog(this,
                        "Invalid Port Number. Please enter a value between 1024 and 65535.",
                        "Configuration Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
            config.setServerPort(port);
            
            // Save auto-login settings
            config.setUsername(usernameField.getText().trim());
            config.setPassword(new String(passwordField.getPassword()));
            
            // Check if auto-logout setting has changed
            boolean newAutoLogoutState = autoLogoutCheckbox.isSelected();
            if (previousAutoLogoutState != newAutoLogoutState) {
                Logger.log("Auto-logout setting changed from " + previousAutoLogoutState + " to " + newAutoLogoutState);
                
                // Update RandomManager - use the script's instance if available, otherwise get directly
                try {
                    RandomManager randomManager = null;
                    
                    // First try to get from the script instance to avoid circular reference
                    if (script != null) {
                        randomManager = script.getRandomManager();
                        Logger.log("Using RandomManager from script instance");
                    } 
                    // If that fails or script is null, get directly from Client
                    else {
                        randomManager = Client.getInstance().getRandomManager();
                        Logger.log("Using RandomManager directly from Client");
                    }
                    
                    if (randomManager != null) {
                        // Update DreamBot's random event handling based on new auto-logout setting
                        if (newAutoLogoutState) {
                            // Auto-logout enabled - disable DreamBot's LOGIN handler
                            Logger.log("Disabling DreamBot's LOGIN random handler (auto-logout enabled)");
                            randomManager.disableSolver(RandomEvent.LOGIN);
                            randomManager.disableSolver(RandomEvent.WELCOME_SCREEN);
                        } else {
                            // Auto-logout disabled - re-enable DreamBot's LOGIN handler
                            Logger.log("Enabling DreamBot's LOGIN random handler (auto-logout disabled)");
                            randomManager.enableSolver(RandomEvent.LOGIN);
                            randomManager.enableSolver(RandomEvent.WELCOME_SCREEN);
                        }
                    } else {
                        Logger.warn("MuleSettingsPanel: Could not get RandomManager instance");
                    }
                } catch (Exception e) {
                    Logger.warn("Error updating RandomManager: " + e.getMessage());
                }
                
                // Update the state
                previousAutoLogoutState = newAutoLogoutState;
            }
            
            // Save the new auto-logout state to config
            config.setAutoLogout(newAutoLogoutState);

            // FIXED: Explicitly mark the configuration as dirty
            config.markDirty();
            
            // FIXED: Explicitly save configuration to ensure it's persisted
            config.saveConfig();

            Logger.info("Mule settings saved: Port=" + config.getServerPort() + 
                        ", Username=" + (config.getUsername().isEmpty() ? "Not Set" : "Set") +
                        ", Password=" + (config.getPassword().isEmpty() ? "Not Set" : "Set") +
                        ", Auto-Logout=" + config.isAutoLogout());

            return true;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                    "Invalid Port Number. Please enter a valid integer.",
                    "Configuration Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } catch (Exception e) {
             Logger.error("MuleSettingsPanel: Error saving settings: " + e.getMessage(), e);
             JOptionPane.showMessageDialog(this,
                     "An unexpected error occurred while saving settings:\n" + e.getMessage(),
                     "Save Error", JOptionPane.ERROR_MESSAGE);
             return false;
        }
    }
} 