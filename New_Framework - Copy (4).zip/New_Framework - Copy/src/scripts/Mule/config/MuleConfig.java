// src/scripts/Mule/config/MuleConfig.java
package scripts.Mule.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;
import core.config.ScriptConfig;
import core.context.ScriptContext;
import org.dreambot.api.settings.ScriptSettings;
import org.dreambot.api.utilities.Logger;
import scripts.Herb.utils.ConfigUtil; // Assuming this utility is accessible or copied

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MuleConfig extends ScriptConfig {

    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .excludeFieldsWithoutExposeAnnotation()
            .serializeNulls()
            .create();

    @Expose private int serverPort = 61616; // Default port, should match client config
    @Expose private String username = ""; // Account username for auto-login
    @Expose private String password = ""; // Account password for auto-login
    @Expose private boolean autoLogout = true; // Whether to auto-logout when inactive

    private boolean dirty = false;

    public MuleConfig(ScriptContext context) {
        super(context, "mule_config");
        setDefaults();
        loadConfig();
    }

     public MuleConfig() {
        super(null, "mule_config");
        setDefaults();
    }

    @Override
    public void setDefaults() {
        this.serverPort = 61616;
        this.username = "";
        this.password = "";
        this.autoLogout = true;
        markDirty();
    }

    @Override
    public void loadConfig() {
        try {
            ConfigData data = ScriptSettings.load(ConfigData.class, "ScarMule", "mule_config.json");
            if (data != null) {
                this.serverPort = data.serverPort;
                this.username = data.username;
                this.password = data.password;
                this.autoLogout = data.autoLogout;
                Logger.log("MuleConfig loaded successfully.");
            } else {
                Logger.log("No existing MuleConfig found, using defaults.");
                setDefaults();
            }
            markClean();
        } catch (Exception e) {
            Logger.error("Error loading MuleConfig: " + e.getMessage());
            setDefaults();
        }
    }

    @Override
    public void saveConfig() {
         if (!dirty) {
            return;
        }
        try {
            ConfigData data = new ConfigData();
            data.serverPort = this.serverPort;
            data.username = this.username;
            data.password = this.password;
            data.autoLogout = this.autoLogout;

            ConfigUtil.safeSave(data, "ScarMule", "mule_config.json");
            Logger.log("MuleConfig saved successfully.");
            markClean();
        } catch (Exception e) {
            Logger.error("Error saving MuleConfig: " + e.getMessage());
        }
    }

    /**
     * Save current configuration as a profile
     * @param profileName The name of the profile
     */
    public void saveProfile(String profileName) {
        try {
            // Prepare data for saving
            ConfigData data = new ConfigData();
            data.serverPort = this.serverPort;
            data.username = this.username;
            data.password = this.password;
            data.autoLogout = this.autoLogout;

            // Ensure profiles directory exists
            File profilesDir = getProfilesDirectory();

            // Create profile file
            File profileFile = new File(profilesDir, profileName + ".json");

            // Save profile
            try (FileWriter writer = new FileWriter(profileFile)) {
                GSON.toJson(data, writer);
            }

            Logger.log("Profile saved: " + profileName);
        } catch (Exception e) {
            Logger.error("Error saving profile: " + e.getMessage());
            throw new RuntimeException("Failed to save profile: " + e.getMessage(), e);
        }
    }

    /**
     * Load a saved profile
     * @param profileName The name of the profile to load
     */
    public void loadProfile(String profileName) {
        try {
            File profilesDir = getProfilesDirectory();
            File profileFile = new File(profilesDir, profileName + ".json");

            if (!profileFile.exists()) {
                throw new IllegalArgumentException("Profile not found: " + profileName);
            }

            try (FileReader reader = new FileReader(profileFile)) {
                ConfigData data = GSON.fromJson(reader, ConfigData.class);

                if (data != null) {
                    // Update current configuration with profile data
                    this.serverPort = data.serverPort;
                    this.username = data.username;
                    this.password = data.password;
                    this.autoLogout = data.autoLogout;
                    markDirty();
                    Logger.log("Profile loaded: " + profileName);
                } else {
                    Logger.error("Profile data invalid: " + profileName);
                    throw new IllegalStateException("Invalid profile data");
                }
            }
        } catch (Exception e) {
            Logger.error("Error loading profile: " + e.getMessage());
            throw new RuntimeException("Failed to load profile: " + e.getMessage(), e);
        }
    }

    /**
     * Get a list of available profile names
     * @return List of profile names (without .json extension)
     */
    public List<String> getAvailableProfiles() {
        List<String> profiles = new ArrayList<>();

        try {
            File profilesDir = getProfilesDirectory();
            if (profilesDir.exists() && profilesDir.isDirectory()) {
                File[] files = profilesDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".json"));

                if (files != null) {
                    for (File file : files) {
                        String filename = file.getName();
                        // Remove .json extension
                        String profileName = filename.substring(0, filename.length() - 5);
                        profiles.add(profileName);
                    }
                }
            }
        } catch (Exception e) {
            Logger.error("Error listing profiles: " + e.getMessage());
        }

        return profiles;
    }

    /**
     * Delete a profile
     * @param profileName The name of the profile to delete
     */
    public void deleteProfile(String profileName) {
        try {
            File profilesDir = getProfilesDirectory();
            File profileFile = new File(profilesDir, profileName + ".json");

            if (profileFile.exists()) {
                if (profileFile.delete()) {
                    Logger.log("Profile deleted: " + profileName);
                } else {
                    throw new IOException("Failed to delete profile file");
                }
            } else {
                Logger.warn("Profile not found for deletion: " + profileName);
            }
        } catch (Exception e) {
            Logger.error("Error deleting profile: " + e.getMessage());
            throw new RuntimeException("Failed to delete profile: " + e.getMessage(), e);
        }
    }

    /**
     * Get or create the profiles directory
     * @return File object representing the profiles directory
     */
    private File getProfilesDirectory() {
        String scriptDir = System.getProperty("user.home") + File.separator +
                "DreamBot" + File.separator +
                "Scripts" + File.separator +
                "ScarMule" + File.separator +
                "profiles";

        File dir = new File(scriptDir);
        if (!dir.exists()) {
            if (!dir.mkdirs()) {
                Logger.error("Failed to create profiles directory: " + scriptDir);
                throw new RuntimeException("Failed to create profiles directory");
            }
        }
        return dir;
    }

     private static class ConfigData {
        public int serverPort;
        public String username;
        public String password;
        public boolean autoLogout;
    }

    // --- Getters and Setters ---

    public int getServerPort() {
        return serverPort;
    }

    public void setServerPort(int serverPort) {
        if (this.serverPort != serverPort) {
            this.serverPort = serverPort;
            markDirty();
        }
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        if (this.username == null || !this.username.equals(username)) {
            this.username = username;
            markDirty();
        }
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        if (this.password == null || !this.password.equals(password)) {
            this.password = password;
            markDirty();
        }
    }
    
    public boolean isAutoLogout() {
        return autoLogout;
    }
    
    public void setAutoLogout(boolean autoLogout) {
        if (this.autoLogout != autoLogout) {
            this.autoLogout = autoLogout;
            markDirty();
        }
    }

    @Override
    public boolean isDirty() {
        return dirty;
    }

    @Override
    public void markDirty() {
        this.dirty = true;
    }

    @Override
    public void markClean() {
        this.dirty = false;
    }

    @Override
    public void reset() {
        setDefaults();
    }
    
    @Override
    public void copyConfigValues(ScriptConfig other) {
        if (!(other instanceof MuleConfig)) {
            return;
        }
        
        MuleConfig config = (MuleConfig) other;
        this.serverPort = config.serverPort;
        this.username = config.username;
        this.password = config.password;
        this.autoLogout = config.autoLogout;
        markDirty();
    }
}