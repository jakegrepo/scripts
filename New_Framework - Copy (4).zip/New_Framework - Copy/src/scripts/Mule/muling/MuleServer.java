package scripts.Mule.muling;

import org.dreambot.api.utilities.Logger;
import org.dreambot.api.methods.interactive.Players;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Handles the server-side socket communication for the Mule script.
 * Runs in its own thread to listen for client connections.
 */
public class MuleServer implements Runnable {

    private final int port;
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicBoolean clientConnected = new AtomicBoolean(false);
    private final AtomicReference<String> connectedClientUsername = new AtomicReference<>(null);
    private final AtomicReference<String> tradeStatus = new AtomicReference<>("WAITING"); // WAITING, READY, TRADING, COMPLETE, ERROR

    // Queues for message passing between server thread and script thread
    private final BlockingQueue<String> incomingMessages = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> outgoingMessages = new LinkedBlockingQueue<>();

    public MuleServer(int port) {
        this.port = port;
    }

    @Override
    public void run() {
        running.set(true);
        try {
            serverSocket = new ServerSocket(port);
            Logger.log("MuleServer: Listening on port " + port);

            while (running.get()) {
                try {
                    // Accept client connection (blocking call)
                    clientSocket = serverSocket.accept();
                    Logger.log("MuleServer: Client connected from " + clientSocket.getInetAddress());

                    // Setup streams
                    out = new PrintWriter(clientSocket.getOutputStream(), true);
                    in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                    clientConnected.set(true);
                    // Start message handling loops in this thread after connection
                    handleClient();

                } catch (SocketException se) {
                    if (running.get()) { // Ignore if stopping
                         Logger.warn("MuleServer: SocketException during accept/read (server likely stopping): " + se.getMessage());
                    }
                } catch (IOException e) {
                    if (running.get()) {
                         Logger.error("MuleServer: IOException during client connection/handling: " + e.getMessage());
                    }
                    // Reset connection state if error occurs during handling
                     closeClientConnection();
                } finally {
                    // Ensure client connection is closed if handleClient loop exits
                    closeClientConnection();
                }
            }
        } catch (IOException e) {
             if (running.get()) { // Only log error if we weren't intentionally stopped
                 Logger.error("MuleServer: Could not listen on port " + port + ": " + e.getMessage());
             }
        } finally {
            stopServerInternal(); // Ensure server socket is closed on exit
        }
        Logger.log("MuleServer: Thread finished.");
    }

    private void handleClient() {
        Logger.log("MuleServer: Starting client handler.");
        Thread messageSender = new Thread(this::processOutgoingMessages);
        messageSender.start();

        try {
            String inputLine;
            while (clientConnected.get() && (inputLine = in.readLine()) != null) {
                Logger.debug("MuleServer: Received raw: " + inputLine);
                // Handle initial connection message
                if (inputLine.startsWith("CONNECT:")) {
                    String clientUser = inputLine.substring(8).trim();
                    connectedClientUsername.set(clientUser);
                    Logger.log("MuleServer: Received CONNECT from user: " + clientUser);
                    // Immediately send the mule's username to the client
                    String muleName = null;
                    try {
                        muleName = Players.getLocal() != null ? Players.getLocal().getName() : null;
                    } catch (Exception e) {
                        Logger.error("MuleServer: Could not get mule username: " + e.getMessage());
                    }
                    if (muleName != null) {
                        sendMessageInternal("MULE_NAME:" + muleName);
                        Logger.log("MuleServer: Sent MULE_NAME:" + muleName + " to client");
                    } else {
                        Logger.warn("MuleServer: Mule username is null, not sending MULE_NAME message");
                    }
                    // Optionally send an ACK or just continue
                    continue; // Wait for further messages
                }

                // Put other messages into the queue for the main script thread
                try {
                    incomingMessages.put(inputLine); // Put message for MuleTradeNode etc. to read
                } catch (InterruptedException e) {
                    Logger.warn("MuleServer: Interrupted while queuing incoming message.");
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        } catch (SocketException se) {
            Logger.warn("MuleServer: Client disconnected ("+se.getMessage()+").");
        } catch (IOException e) {
             if (clientConnected.get()) { // Only log if we expected connection
                 Logger.error("MuleServer: IOException reading from client: " + e.getMessage());
             }
        } finally {
             Logger.log("MuleServer: Client handler loop finished.");
             closeClientConnection();
             messageSender.interrupt(); // Stop the sender thread
        }
    }

     private void processOutgoingMessages() {
         Logger.log("MuleServer: Starting outgoing message processor.");
         while (!Thread.currentThread().isInterrupted() && clientConnected.get()) {
             try {
                 String message = outgoingMessages.take(); // Blocks until a message is available
                 sendMessageInternal(message);
             } catch (InterruptedException e) {
                 Logger.log("MuleServer: Outgoing message processor interrupted.");
                 Thread.currentThread().interrupt();
                 break;
             }
         }
         Logger.log("MuleServer: Outgoing message processor finished.");
     }

      // Internal method to send message directly, used by handler threads
    private boolean sendMessageInternal(String message) {
        if (clientConnected.get() && out != null) {
            Logger.debug("MuleServer: Sending raw: " + message);
            out.println(message);
            if (out.checkError()) {
                Logger.error("MuleServer: PrintWriter error sending message.");
                closeClientConnection();
                return false;
            }
            return true;
        }
        return false;
    }

    // Public method for other threads (like MuleTradeNode) to queue messages
    public void queueOutgoingMessage(String message) {
         if (!clientConnected.get()) {
             Logger.warn("MuleServer: Cannot queue message, client not connected: " + message);
             return;
         }
        try {
            outgoingMessages.put(message);
        } catch (InterruptedException e) {
            Logger.warn("MuleServer: Interrupted while queuing outgoing message.");
            Thread.currentThread().interrupt();
        }
    }

    // Public method for other threads to read incoming messages
    public String pollIncomingMessage() {
        return incomingMessages.poll(); // Non-blocking read
    }


    private void closeClientConnection() {
        if (!clientConnected.get()) return;

        Logger.log("MuleServer: Closing client connection...");
        clientConnected.set(false);
        connectedClientUsername.set(null);
        incomingMessages.clear(); // Clear queues on disconnect
        outgoingMessages.clear();
        tradeStatus.set("WAITING"); // Reset trade status

        try {
            if (out != null) out.close();
            if (in != null) in.close();
            if (clientSocket != null && !clientSocket.isClosed()) clientSocket.close();
        } catch (IOException e) {
            Logger.error("MuleServer: Error closing client socket resources: " + e.getMessage());
        } finally {
            clientSocket = null;
            out = null;
            in = null;
             Logger.log("MuleServer: Client connection closed.");
        }
    }

    public void stopServer() {
        Logger.log("MuleServer: Stopping server...");
        running.set(false);
        closeClientConnection(); // Close any active client connection
        stopServerInternal(); // Close the server socket
         Logger.log("MuleServer: Stop request processed.");
    }

     private void stopServerInternal() {
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
                 Logger.log("MuleServer: Server socket closed.");
            }
        } catch (IOException e) {
            Logger.error("MuleServer: Error closing server socket: " + e.getMessage());
        } finally {
            serverSocket = null; // Ensure it's null after closing
        }
    }


    // --- Status methods for script/GUI ---
    public boolean isRunning() {
        return running.get() && serverSocket != null && !serverSocket.isClosed();
    }

    public boolean isClientConnected() {
        return clientConnected.get();
    }

    public String getClientUsername() {
        return connectedClientUsername.get();
    }

     public String getTradeStatus() {
         return tradeStatus.get();
     }

     public void setTradeStatus(String status) {
         // Basic validation could be added here
         Logger.log("MuleServer: Trade status updated to: " + status);
         this.tradeStatus.set(status);
         // Optionally notify client if needed, e.g., queueOutgoingMessage("STATUS:"+status);
     }
} 