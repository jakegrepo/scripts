// src/scripts/Mule/MuleServerScript.java
package scripts.Mule;

import core.base.ScarScript; // Assuming ScarScript is your base
import core.gui.AbstractSettingsTab;
import core.state.ScriptState;
import org.dreambot.api.Client;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.randoms.RandomEvent;
import org.dreambot.api.randoms.RandomManager;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.utilities.Logger;
import scripts.Mule.config.MuleConfig;
import scripts.Mule.gui.MuleSettingsTab; // To be created
import scripts.Mule.muling.MuleServer; // To be created
import scripts.Mule.nodes.MuleTradeNode; // To be created
import scripts.Mule.nodes.MuleIdleNode; // New import for idle node
import scripts.Mule.gui.MuleOverlay;
// import scripts.Mule.nodes.MuleBankNode; // Optional: For banking after trade - To be implemented later

import java.awt.*;

@ScriptManifest(
        name = "Scar Mule Server",
        author = "Scarfade",
        version = 1.0,
        description = "Handles receiving items from other scripts via sockets.",
        category = Category.UTILITY // Or MONEYMAKING if it fits
)
public class MuleServerScript extends ScarScript<MuleConfig> { // Use MuleConfig

    private MuleServer muleServer;
    private MuleTradeNode tradeNode; // Example node
    private MuleIdleNode idleNode; // New idle node for logout functionality
    public MuleOverlay muleOverlay;
    private RandomManager randomManager;

    @Override
    protected void onScriptStart() {
        Logger.log("=== MULE SERVER SCRIPT STARTING ===");
        try {
             // Initialize framework context if needed (adapt to your framework)
            context.initialize();

            // FIXED: Use getConfig() for properly typed config access
            this.config = getScriptConfig(); // Load/initialize MuleConfig
            MuleConfig muleConfig = getConfig();

            // Start the Mule Server
            muleServer = new MuleServer(muleConfig.getServerPort());
            new Thread(muleServer).start(); // Run server in its own thread

            // Get RandomManager instance - direct access to avoid circular reference
            try {
                randomManager = Client.getInstance().getRandomManager();
                Logger.log("Successfully retrieved RandomManager instance");
            } catch (Exception e) {
                Logger.error("Error getting RandomManager directly: " + e.getMessage());
                randomManager = null;
            }

            // Disable DreamBot's LOGIN random event handler if auto-login is enabled
            if (muleConfig.isAutoLogout()) {
                Logger.log("Auto-logout feature is enabled - disabling DreamBot's LOGIN random handler");
                if (randomManager != null) {
                    randomManager.disableSolver(RandomEvent.LOGIN);
                    // Also disable welcome screen handling to ensure our login process is uninterrupted
                    randomManager.disableSolver(RandomEvent.WELCOME_SCREEN);
                    Logger.log("DreamBot's LOGIN random handler disabled. Our custom login/logout will be used instead.");
                } else {
                    Logger.warn("Could not get RandomManager instance - cannot disable LOGIN random event");
                }
            } else {
                Logger.log("Auto-logout feature is disabled - DreamBot's default LOGIN handler will be used");
                // If auto-logout is later enabled during runtime, we'll need to handle this in the settings
            }

            // Initialize Nodes
            initializeNodes();

            // Initialize and register overlay
            muleOverlay = new MuleOverlay(context, this);
            context.getDebugOverlayManager().registerOverlay(muleOverlay);

            setState(ScriptState.RUNNING);
            Logger.log("Mule Server Script started successfully on port " + muleConfig.getServerPort());
        } catch (Exception e) {
             Logger.error("Error during Mule Server Script startup: " + e.getMessage(), e);
             setState(ScriptState.ERROR);
             getScriptManager().stop(); // Stop script on error
        }
        Logger.log("===================================");
    }

    private void initializeNodes() {
        Logger.info("=== INITIALIZING MULE NODES ===");
        clearNodes(); // Clear any default nodes if necessary

        try {
            // FIXED: Use getConfig() for properly typed config access
            MuleConfig muleConfig = getConfig();

            // Pass MuleServer instance to nodes that need to interact with it
            tradeNode = new MuleTradeNode(muleConfig, muleServer);
            Logger.info("Created MuleTradeNode successfully");
            addNode(tradeNode);
            
            // Add the idle node with lower priority for logout functionality
            idleNode = new MuleIdleNode(muleConfig, muleServer);
            Logger.info("Created MuleIdleNode successfully");
            addNode(idleNode);
            
            // Explicitly log each node that was added
            Logger.info("Node collection now contains:");
            context.tasks().getNodes().forEach(node -> 
                Logger.info(" - " + node.getClass().getSimpleName() + " (Priority: " + node.getPriority() + ")")
            );

            // Banking node to be implemented later
            // addNode(new MuleBankNode(muleConfig, muleServer));
        } catch (Exception e) {
            Logger.error("Error initializing nodes: " + e.getMessage(), e);
        }

        Logger.info("Mule nodes initialized. Total: " + context.tasks().getNodes().size());
    }


    @Override
    protected AbstractSettingsTab getScriptTab() {
         // Create and return the GUI tab for mule settings
         return new MuleSettingsTab(getContext());
    }

    @Override
    protected int onScriptLoop() {
        if (getState().isRunnable()) {
            // Primary loop logic - execute nodes
             return context.tasks().execute();
        }
        // Handle non-runnable states (PAUSED, ERROR)
        return 600; // Default sleep for non-runnable states
    }

    @Override
    public void onPaint(Graphics2D g) {
        // Use the modular overlay if available
        if (muleOverlay != null && muleOverlay.isEnabled()) {
            muleOverlay.render(g);
        } else if (muleServer != null) {
            // FIXED: Use getConfig() for properly typed config access
            MuleConfig muleConfig = getConfig();
            
            g.setColor(Color.CYAN);
            g.drawString("Mule Server Status: " + (muleServer.isRunning() ? "Running" : "Stopped"), 10, 50);
            g.drawString("Port: " + muleConfig.getServerPort(), 10, 65);
            g.drawString("Connected Client: " + (muleServer.isClientConnected() ? muleServer.getClientUsername() : "None"), 10, 80);
             
            // Show both node statuses
            if (tradeNode != null) {
                g.drawString("Trade Node: " + tradeNode.getStatus(), 10, 95);
            }
            if (idleNode != null) {
                boolean isLoggedIn = Players.getLocal() != null && Players.getLocal().exists();
                String idleStatus = isLoggedIn ? "Active (Logged In)" : "Waiting (Logged Out)";
                g.drawString("Idle Node: " + idleStatus, 10, 110);
                g.drawString("Auto-Logout: " + (muleConfig.isAutoLogout() ? "Enabled" : "Disabled"), 10, 125);
                // Show login random status - check if random manager exists
                g.drawString("Login Auto-Handler: " + (muleConfig.isAutoLogout() ? "Enabled" : "Disabled"), 10, 140);
            }
        }
    }

    @Override
    protected void onScriptStop() {
        Logger.log("=== MULE SERVER SCRIPT STOPPING ===");
        if (muleServer != null) {
            muleServer.stopServer(); // Gracefully stop the server socket
        }
        
        // Re-enable DreamBot's LOGIN random event handler when script stops
        if (randomManager != null) {
            randomManager.enableSolver(RandomEvent.LOGIN);
            randomManager.enableSolver(RandomEvent.WELCOME_SCREEN);
            Logger.log("DreamBot's LOGIN random handler re-enabled.");
        }
        
        context.shutdown(); // Shutdown framework context
        Logger.log("===================================");
    }

    @Override
    public MuleConfig getScriptConfig() {
        // Load or create the MuleConfig
        if (config == null) {
            config = new MuleConfig(getContext());
            // FIXED: Load config explicitly to ensure it's properly loaded on startup
            config.loadConfig();
        }
        return config;
    }
    
    // FIXED: Add helper method to access config as the correct type
    public MuleConfig getConfig() {
        return (MuleConfig) config;
    }

    @Override
    public boolean requiresGUI() {
        return true; // Mule script likely needs a simple GUI
    }
    
    /**
     * Returns the RandomManager instance for other components.
     * This is stored as a class field to avoid circular references.
     */
    public RandomManager getRandomManager() {
        return this.randomManager;
    }
} 