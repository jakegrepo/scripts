package scripts.Herb.gui;

import core.context.ScriptContext;
import core.gui.SettingsPanel;
import core.gui.style.StyleManager;
import org.dreambot.api.utilities.Logger;
import scripts.Herb.config.HerbConfig;
import scripts.Herb.config.MixologyConfig;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Settings panel for Mastering Mixology configuration
 */
public class MixologySettingsPanel extends SettingsPanel {
    private final ScriptContext context;
    private final HerbConfig herbConfig;
    private final MixologyConfig mixologyConfig;

    // Components
    private JCheckBox collectDigweedCheckbox;
    private JCheckBox useDigweedOnMixalotCheckbox;
    private JCheckBox activeRefiningCheckbox;
    private JCheckBox activeProcessingCheckbox;
    private JCheckBox prioritizeOrdersCheckbox;
    private JCheckBox useUnfinishedPotionsCheckbox;
    private JComboBox<String> transportMethodComboBox;
    private JSpinner minHerbCountSpinner;
    private JCheckBox buyAldariumCheckBox;
private JSpinner  aldariumBatchSpinner;
private JCheckBox buyBarrelCheckBox;
    // Herb selection components
    private final Map<String, JCheckBox> herbCheckboxes = new HashMap<>();

    // Potion priority components
    private final Map<String, JSpinner> potionSpinners = new HashMap<>();

    /**
     * Create a new MixologySettingsPanel
     * @param context The script context
     * @param herbConfig The main HerbConfig instance
     */
    public MixologySettingsPanel(ScriptContext context, HerbConfig herbConfig) {
        super();
        this.context = context;
        this.herbConfig = herbConfig;
        this.mixologyConfig = herbConfig.getMixologyConfig();

        initializeComponents();
        loadSettings();
    }

    /**
     * Initialize all UI components
     */
    private void initializeComponents() {
        // Create main panel with GridBagLayout for precise control
        JPanel mainPanel = new JPanel(new GridBagLayout());
        StyleManager.applyStyle(mainPanel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Processing options section
        JLabel processingLabel = new JLabel("Processing Options");
        processingLabel.setFont(StyleManager.SECTION_HEADER_FONT);
        mainPanel.add(processingLabel, gbc);

        // Add checkboxes
        gbc.gridy++;
        collectDigweedCheckbox = new JCheckBox("Collect Digweed");
        StyleManager.styleCheckBox(collectDigweedCheckbox);
        mainPanel.add(collectDigweedCheckbox, gbc);

        gbc.gridy++;
        useDigweedOnMixalotCheckbox = new JCheckBox("Use Digweed on MixALot");
        StyleManager.styleCheckBox(useDigweedOnMixalotCheckbox);
        mainPanel.add(useDigweedOnMixalotCheckbox, gbc);

        gbc.gridy++;
        activeRefiningCheckbox = new JCheckBox("Active Refining (click spam)");
        StyleManager.styleCheckBox(activeRefiningCheckbox);
        mainPanel.add(activeRefiningCheckbox, gbc);

        gbc.gridy++;
        activeProcessingCheckbox = new JCheckBox("Active Processing (click spam)");
        StyleManager.styleCheckBox(activeProcessingCheckbox);
        mainPanel.add(activeProcessingCheckbox, gbc);

        gbc.gridy++;
        prioritizeOrdersCheckbox = new JCheckBox("Prioritize Order Board Potions");
        StyleManager.styleCheckBox(prioritizeOrdersCheckbox);
        mainPanel.add(prioritizeOrdersCheckbox, gbc);

        gbc.gridy++;
        useUnfinishedPotionsCheckbox = new JCheckBox("Use Unfinished Potions");
        StyleManager.styleCheckBox(useUnfinishedPotionsCheckbox);
        mainPanel.add(useUnfinishedPotionsCheckbox, gbc);

        // Transport method
        gbc.gridy++;
        gbc.gridwidth = 1;
        mainPanel.add(new JLabel("Transport Method:"), gbc);

        gbc.gridx = 1;
        String[] transportMethods = {"Fairy Ring", "Teleport Tab", "House Portal"};
        transportMethodComboBox = new JComboBox<>(transportMethods);
        StyleManager.styleComboBox(transportMethodComboBox);
        mainPanel.add(transportMethodComboBox, gbc);

        // Min herb count
        gbc.gridy++;
        gbc.gridx = 0;
        mainPanel.add(new JLabel("Minimum Herb Count:"), gbc);

        gbc.gridx = 1;
        minHerbCountSpinner = new JSpinner(new SpinnerNumberModel(10, 1, 100, 1));
        StyleManager.styleSpinner(minHerbCountSpinner);
        mainPanel.add(minHerbCountSpinner, gbc);

        // Add the main panel to a scroll pane
        JScrollPane scrollPane = new JScrollPane(mainPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        // Add scroll pane to this panel using BorderLayout
        add(scrollPane, BorderLayout.CENTER);

        // Add listeners
        addListeners();
    }

    /**
     * Add event listeners to components
     */
    private void addListeners() {
        collectDigweedCheckbox.addActionListener(e -> saveSettings());
        useDigweedOnMixalotCheckbox.addActionListener(e -> saveSettings());
        activeRefiningCheckbox.addActionListener(e -> saveSettings());
        activeProcessingCheckbox.addActionListener(e -> saveSettings());
        prioritizeOrdersCheckbox.addActionListener(e -> saveSettings());
        useUnfinishedPotionsCheckbox.addActionListener(e -> saveSettings());
        transportMethodComboBox.addActionListener(e -> saveSettings());
        minHerbCountSpinner.addChangeListener(e -> saveSettings());
    }

    /**
     * Load settings from config
     */
    public void loadSettings() {
        collectDigweedCheckbox.setSelected(mixologyConfig.isCollectDigweed());
        useDigweedOnMixalotCheckbox.setSelected(mixologyConfig.isUseDigweedOnMixalot());
        activeRefiningCheckbox.setSelected(mixologyConfig.isActiveRefining());
        activeProcessingCheckbox.setSelected(mixologyConfig.isActiveProcessing());
        prioritizeOrdersCheckbox.setSelected(mixologyConfig.isPrioritizeOrders());
        useUnfinishedPotionsCheckbox.setSelected(mixologyConfig.isUseUnfinishedPotions());
        transportMethodComboBox.setSelectedItem(mixologyConfig.getTransportMethod());
        minHerbCountSpinner.setValue(mixologyConfig.getMinHerbCount());
    }

    /**
     * Save settings to config
     */
    public void saveSettings() {
        // Log before saving
        Logger.info("Saving MixologySettingsPanel settings");

        mixologyConfig.setCollectDigweed(collectDigweedCheckbox.isSelected());
        mixologyConfig.setUseDigweedOnMixalot(useDigweedOnMixalotCheckbox.isSelected());
        mixologyConfig.setActiveRefining(activeRefiningCheckbox.isSelected());
        mixologyConfig.setActiveProcessing(activeProcessingCheckbox.isSelected());
        mixologyConfig.setPrioritizeOrders(prioritizeOrdersCheckbox.isSelected());
        mixologyConfig.setUseUnfinishedPotions(useUnfinishedPotionsCheckbox.isSelected());
        mixologyConfig.setTransportMethod((String) transportMethodComboBox.getSelectedItem());
        mixologyConfig.setMinHerbCount((int) minHerbCountSpinner.getValue());

        // Make sure to mark the config as dirty
        mixologyConfig.markDirty();
        herbConfig.markDirty();

        // Save config to file
        herbConfig.saveConfig();

        // Log after saving
        Logger.info("MixologySettingsPanel settings saved successfully");
    }
}
