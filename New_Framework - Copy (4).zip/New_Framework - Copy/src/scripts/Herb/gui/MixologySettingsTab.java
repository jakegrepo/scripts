package scripts.Herb.gui;

import core.base.ScarScript;
import core.context.ScriptContext;
import core.gui.AbstractSettingsTab;
import core.gui.ScriptGUI;
import core.gui.SettingsPanel;
import core.gui.components.Icons;
import core.gui.style.StyleManager;
import org.dreambot.api.utilities.Logger;
import scripts.Herb.MixologyScript;
import scripts.Herb.config.HerbConfig;
import scripts.Herb.config.MixologyConfig;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Settings tab for the Mixology script
 * Provides configuration options for the Mixology minigame
 */
public class MixologySettingsTab extends AbstractSettingsTab {
    private final HerbConfig config;
    private MixologyGeneralPanel generalPanel;
    private MixologyHerbsPanel herbsPanel;
    private MixologySettingsPanel settingsPanel;

    private static final String SCRIPT_NAME = "ScarHerb";

    public MixologySettingsTab(ScriptContext context) {
        super(context);
        MixologyScript script = (MixologyScript) context.getScript();
        this.config = script.getScriptConfig();

        // Initialize all panels
        this.generalPanel = new MixologyGeneralPanel(config);
        this.herbsPanel = new MixologyHerbsPanel(config);
        this.settingsPanel = new MixologySettingsPanel(context, config);

        // Ensure we start with default settings
        refreshAllDisplays();
    }

    @Override
    public void createComponents() {
        // Create a tabbed pane for sub-tabs
        JTabbedPane subTabs = new JTabbedPane();
        StyleManager.styleTabbedPane(subTabs);

        // Add panels to sub-tabs
        subTabs.addTab("General", generalPanel);
        subTabs.addTab("Herbs", herbsPanel);
        subTabs.addTab("Processing", settingsPanel);

        // Add the tabbed pane to this tab
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        getPanel().add(subTabs, gbc);
    }

    @Override
    public String getTitle() {
        return "Mixology";
    }

    public void handleLoadProfile() {
        String selectedProfile = (String) JOptionPane.showInputDialog(
                this.getPanel(),
                "Select a profile to load:",
                "Load Profile",
                JOptionPane.PLAIN_MESSAGE,
                Icons.LOAD,
                config.getAvailableProfiles().toArray(),
                null
        );

        if (selectedProfile != null) {
            try {
                Logger.info("=== LOADING PROFILE: " + selectedProfile + " ===");

                // Log current settings before loading
                MixologyConfig mixCfg = config.getMixologyConfig();
                Logger.info("Current settings before loading profile:");
                Logger.info("Buy Aldarium: " + mixCfg.isBuyAldarium());
                Logger.info("Buy Barrel: " + mixCfg.isBuyBarrel());
                Logger.info("Transport Method: " + mixCfg.getTransportMethod());

                // Load the profile (this will override all current settings)
                config.loadProfile(selectedProfile);

                // Log settings after loading profile
                Logger.info("Settings after loading profile:");
                Logger.info("Buy Aldarium: " + mixCfg.isBuyAldarium());
                Logger.info("Buy Barrel: " + mixCfg.isBuyBarrel());
                Logger.info("Transport Method: " + mixCfg.getTransportMethod());

                // Force refresh all panels with the new settings
                Logger.info("=== UPDATING PANELS WITH LOADED SETTINGS ===");

                // Force refresh by recreating the panels
                refreshAllDisplays();

                // Update UI to reflect changes
                SwingUtilities.invokeLater(() -> {
                    getPanel().revalidate();
                    getPanel().repaint();
                });

                Logger.info("=== PROFILE LOADED SUCCESSFULLY ===");
                JOptionPane.showMessageDialog(this.getPanel(),
                        "Profile '" + selectedProfile + "' loaded successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                Logger.error("ERROR loading profile: " + e.getMessage());
                e.printStackTrace();
                JOptionPane.showMessageDialog(this.getPanel(),
                        "Error loading profile: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void handleRemoveProfile() {
        String selectedProfile = (String) JOptionPane.showInputDialog(
                this.getPanel(),
                "Select a profile to remove:",
                "Remove Profile",
                JOptionPane.WARNING_MESSAGE,
                Icons.DELETE,
                config.getAvailableProfiles().toArray(),
                null
        );

        if (selectedProfile != null) {
            try {
                int confirm = JOptionPane.showConfirmDialog(
                        this.getPanel(),
                        "Are you sure you want to remove the profile '" + selectedProfile + "'?",
                        "Confirm Removal",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (confirm == JOptionPane.YES_OPTION) {
                    config.deleteProfile(selectedProfile);
                    JOptionPane.showMessageDialog(this.getPanel(),
                            "Profile removed successfully!",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Exception e) {
                Logger.log("Error removing profile: " + e.getMessage());
                JOptionPane.showMessageDialog(this.getPanel(),
                        "Error removing profile: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void handleSaveProfile() {
        String profileName = JOptionPane.showInputDialog(
                this.getPanel(),
                "Enter profile name:",
                "Save Profile",
                JOptionPane.PLAIN_MESSAGE
        );

        if (profileName != null && !profileName.trim().isEmpty()) {
            try {
                Logger.log("=== SAVING PROFILE: " + profileName + " ===");

                // Save all panel settings first
                saveAllPanelSettings();

                // Save to profile
                config.saveProfile(profileName.trim());

                Logger.log("=== PROFILE SAVED SUCCESSFULLY ===");
                JOptionPane.showMessageDialog(this.getPanel(),
                        "Profile saved successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                Logger.log("ERROR saving profile: " + e.getMessage());
                e.printStackTrace();
                JOptionPane.showMessageDialog(this.getPanel(),
                        "Error saving profile: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    @Override
    public void saveSettings() {
        Logger.info("=== SAVING ALL MIXOLOGY SETTINGS ===");
        saveAllPanelSettings();
        Logger.info("=== ALL MIXOLOGY SETTINGS SAVED ===");
    }

    @Override
    public void updateFromConfig() {
        // Update all panels with the latest config
        generalPanel.loadSettings();
        herbsPanel.loadSettings();
        settingsPanel.loadSettings();
    }

    public void resetToDefaults() {
        // Reset config to defaults
        config.getMixologyConfig().setDefaults();
        generalPanel.loadSettings();
        herbsPanel.loadSettings();
    }

    public File getProfilesDirectory() {
        // Check if the profiles directory exists
        String scriptDir = System.getProperty("user.home") + File.separator +
                         "DreamBot" + File.separator +
                         "Scripts" + File.separator +
                         "ScarHerb" + File.separator +
                         "profiles";

        File dir = new File(scriptDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    private void refreshAllDisplays() {
        try {
            Logger.info("=== REFRESHING ALL PANELS ===");

            // Get the current config values
            MixologyConfig mixCfg = config.getMixologyConfig();
            Logger.info("Current config values:");
            Logger.info("Buy Aldarium: " + mixCfg.isBuyAldarium());
            Logger.info("Buy Barrel: " + mixCfg.isBuyBarrel());
            Logger.info("Transport Method: " + mixCfg.getTransportMethod());

            // Load current settings into all panels
            Logger.info("Loading General Panel settings...");
            generalPanel.loadSettings();

            Logger.info("Loading Herbs Panel settings...");
            herbsPanel.loadSettings();

            Logger.info("Loading Processing Panel settings...");
            settingsPanel.loadSettings();

            // Force UI update
            SwingUtilities.invokeLater(() -> {
                // Revalidate and repaint all panels
                generalPanel.revalidate();
                generalPanel.repaint();

                herbsPanel.revalidate();
                herbsPanel.repaint();

                settingsPanel.revalidate();
                settingsPanel.repaint();

                // Revalidate and repaint the main panel
                getPanel().revalidate();
                getPanel().repaint();
            });

            Logger.info("=== ALL PANELS REFRESHED ===");
        } catch (Exception e) {
            Logger.error("ERROR refreshing panels: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void saveAllPanelSettings() {
        try {
            Logger.info("=== SAVING PANEL SETTINGS ===");

            Logger.info("Saving General Panel settings...");
            generalPanel.saveSettings();

            Logger.info("Saving Herbs Panel settings...");
            herbsPanel.saveSettings();

            Logger.info("Saving Processing Panel settings...");
            settingsPanel.saveSettings();

            // Make sure to mark the config as dirty
            config.markDirty();

            // Save the config to file
            config.saveConfig();

            // Verify the config was saved
            Logger.info("Config dirty after saving: " + config.isDirty());
            Logger.info("MixologyConfig dirty after saving: " + config.getMixologyConfig().isDirty());
            Logger.info("=== ALL PANEL SETTINGS SAVED ===");
        } catch (Exception e) {
            Logger.error("ERROR saving panel settings: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

/** "General" sub-panel – now includes Rewards Settings */
class MixologyGeneralPanel extends SettingsPanel {

    private final HerbConfig      config;
    private final MixologyConfig  mixologyCfg;

    /* existing controls */
    private JCheckBox collectDigweedCheckBox;
    private JCheckBox useDigweedOnMixalotCheckBox;
    private JCheckBox activeRefiningCheckBox;
    private JCheckBox activeProcessingCheckBox;
    private JCheckBox useUnfinishedPotionsCheckBox;
    private JCheckBox prioritizeOrdersCheckBox;
    private JCheckBox strictProcessingMethodsCheckBox;
    private JSpinner  minHerbCountSpinner;
    private JSpinner  minResinAmountSpinner;
    private JComboBox<String> transportMethodComboBox;

    /* ─── NEW Rewards controls ─── */
    private JCheckBox buyAldariumCheckBox;
    private JSpinner  aldariumPointsThresholdSpinner;
    private JCheckBox buyBarrelCheckBox;

    private boolean isLoading = false;

    MixologyGeneralPanel(HerbConfig cfg){
        this.config      = cfg;
        this.mixologyCfg = cfg.getMixologyConfig();
        initComponents();
        loadSettings();
    }

    /* ---------- layout ---------- */
    private void initComponents() {

        setLayout(new BorderLayout());
        JPanel main = new JPanel(new GridBagLayout());
        main.setOpaque(false);
        main.setBorder(BorderFactory.createEmptyBorder(10,15,15,15));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.fill   = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(2,5,2,5);
        gbc.weightx = 1;

        /* SECTION ▸ General settings (existing checkboxes)… */
        gbc.gridx=0;gbc.gridy=0;gbc.gridwidth=2;
        addHeader("General Settings", main, gbc);

        gbc.gridwidth=1;
        collectDigweedCheckBox      = addCheck("Collect Digweed spawns"          , main, gbc, 1);
        useDigweedOnMixalotCheckBox = addCheck("Use Digweed on MixALot potions"  , main, gbc, 1);
        activeRefiningCheckBox      = addCheck("Enable herb refining"            , main, gbc, 1);
        activeProcessingCheckBox    = addCheck("Enable potion processing"        , main, gbc, 1);
        useUnfinishedPotionsCheckBox= addCheck("Use unfinished potions"          , main, gbc, 1);
        prioritizeOrdersCheckBox    = addCheck("Prioritise customer orders"      , main, gbc, 1);
        strictProcessingMethodsCheckBox = addCheck("Strict processing methods"   , main, gbc, 1);

        /* SECTION ▸ Resource Settings */
        gbc.gridx=0; gbc.gridy++;
        gbc.gridwidth=2;
        addHeader("Resource Settings", main, gbc);

        gbc.gridwidth=1;
        minHerbCountSpinner  = addLabeledSpinner("Min herb count:",   10,1,100,1, main, gbc);
        minResinAmountSpinner= addLabeledSpinner("Min resin amount:", 50,10,1000,10, main, gbc);

        /* SECTION ▸ Transportation */
        gbc.gridx=0; gbc.gridy++;
        gbc.gridwidth=2;
        addHeader("Transportation", main, gbc);

        gbc.gridwidth=1;
        transportMethodComboBox = addLabeledCombo("Transport method:",
                new String[]{"Fairy Ring","Spirit Tree","Teleport Tab","Glory Amulet"},
                main, gbc);

        /* ───────────────────────────────────────────────────────── */
        /* SECTION ▸ Rewards Settings (NEW) */
        gbc.gridx=0; gbc.gridy++;
        gbc.gridwidth=2;
        addHeader("Rewards Settings", main, gbc);

        /* Auto-buy Aldarium + batch spinner */
        gbc.gridwidth=1;
        buyAldariumCheckBox = addCheck("Auto-buy Aldarium", main, gbc, 1);

        // Aldarium Points Threshold spinner
        JLabel thresholdLabel = new JLabel("Aldarium Points Threshold:");
        StyleManager.styleLabel(thresholdLabel);
        main.add(thresholdLabel, gbc);
        gbc.gridx=1;
        aldariumPointsThresholdSpinner = addSpinner(0,0,10000,1, main, gbc);
        gbc.gridx=0; gbc.gridy++;

        /* Auto-buy Barrel */
        gbc.gridx=0; gbc.gridy++;
        gbc.gridwidth=2;
        buyBarrelCheckBox = addCheck("Auto-buy Chugging barrel (disassembled)", main, gbc, 2);

        /* glue */
        gbc.gridy++;
        gbc.weighty = 1;
        main.add(Box.createVerticalGlue(), gbc);

        JScrollPane scroll = new JScrollPane(main);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        /* listeners → saveSettings() */
        addListeners();
    }

    /* helper to add section header */
    private void addHeader(String title, JPanel p, GridBagConstraints gbc){
        JPanel h = new JPanel(new BorderLayout(0,2));
        h.setOpaque(false);
        h.setBorder(BorderFactory.createEmptyBorder(5,0,2,0));
        JLabel l = new JLabel(title.toUpperCase());
        l.setFont(new Font(StyleManager.SECTION_HEADER_FONT.getName(), Font.BOLD, 12));
        l.setForeground(StyleManager.ACCENT);
        h.add(l,BorderLayout.NORTH);
        JPanel line = new JPanel(); line.setOpaque(false);
        line.setBorder(BorderFactory.createMatteBorder(0,0,1,0,StyleManager.BORDER_COLOR));
        h.add(line,BorderLayout.CENTER);
        p.add(h, gbc);
        gbc.gridy++;
    }

    private JCheckBox addCheck(String txt, JPanel p, GridBagConstraints gbc, int gridw){
        JCheckBox c = new JCheckBox(txt);
        StyleManager.styleCheckBox(c);
        gbc.gridwidth = gridw;
        p.add(c, gbc);
        gbc.gridy++;
        return c;
    }
    private JSpinner addSpinner(int val,int min,int max,int step,JPanel p,GridBagConstraints gbc){
        JSpinner sp = new JSpinner(new SpinnerNumberModel(val,min,max,step));
        StyleManager.styleSpinner(sp);
        p.add(sp, gbc);
        return sp;
    }
    private JSpinner addLabeledSpinner(String label,int val,int min,int max,int step,
                                       JPanel p, GridBagConstraints gbc){
        JLabel l = new JLabel(label);
        StyleManager.styleLabel(l);
        p.add(l, gbc);
        gbc.gridx=1;
        JSpinner sp = addSpinner(val,min,max,step,p,gbc);
        gbc.gridx=0; gbc.gridy++;
        return sp;
    }
    private JComboBox<String> addLabeledCombo(String label,String[] opts,
                                              JPanel p,GridBagConstraints gbc){
        JLabel l = new JLabel(label);
        StyleManager.styleLabel(l);
        p.add(l, gbc);
        gbc.gridx=1;
        JComboBox<String> cb = new JComboBox<>(opts);
        StyleManager.styleComboBox(cb);
        p.add(cb, gbc);
        gbc.gridx=0; gbc.gridy++;
        return cb;
    }

    /* ---------- listeners ---------- */
    private void addListeners(){
        JCheckBox[] boxes = {
                collectDigweedCheckBox, useDigweedOnMixalotCheckBox,
                activeRefiningCheckBox, activeProcessingCheckBox,
                useUnfinishedPotionsCheckBox, prioritizeOrdersCheckBox,
                strictProcessingMethodsCheckBox, buyAldariumCheckBox,
                buyBarrelCheckBox
        };
        for (JCheckBox b: boxes) b.addActionListener(e->{ if(!isLoading) saveSettings(); });

        minHerbCountSpinner.addChangeListener(e->{ if(!isLoading) saveSettings(); });
        minResinAmountSpinner.addChangeListener(e->{ if(!isLoading) saveSettings(); });
        aldariumPointsThresholdSpinner.addChangeListener(e->{ if(!isLoading) saveSettings(); });
        transportMethodComboBox.addActionListener(e->{ if(!isLoading) saveSettings(); });
    }

    /* ---------- load / save ---------- */
    void loadSettings(){
        isLoading = true;
        try{
            // Log values from config before updating UI
            Logger.info("Loading MixologyGeneralPanel settings from config:");
            Logger.info("collectDigweed: " + mixologyCfg.isCollectDigweed());
            Logger.info("useDigweedOnMixalot: " + mixologyCfg.isUseDigweedOnMixalot());
            Logger.info("activeRefining: " + mixologyCfg.isActiveRefining());
            Logger.info("activeProcessing: " + mixologyCfg.isActiveProcessing());
            Logger.info("useUnfinishedPotions: " + mixologyCfg.isUseUnfinishedPotions());
            Logger.info("prioritizeOrders: " + mixologyCfg.isPrioritizeOrders());
            Logger.info("strictProcessingMethods: " + mixologyCfg.isStrictProcessingMethods());
            Logger.info("minHerbCount: " + mixologyCfg.getMinHerbCount());
            Logger.info("minResinAmount: " + mixologyCfg.getMinResinAmount());
            Logger.info("transportMethod: " + mixologyCfg.getTransportMethod());
            Logger.info("buyAldarium: " + mixologyCfg.isBuyAldarium());
            Logger.info("aldariumPointsThreshold: " + mixologyCfg.getAldariumPointsThreshold());
            Logger.info("buyBarrel: " + mixologyCfg.isBuyBarrel());

            // Update UI components with values from config
            collectDigweedCheckBox     .setSelected(mixologyCfg.isCollectDigweed());
            useDigweedOnMixalotCheckBox.setSelected(mixologyCfg.isUseDigweedOnMixalot());
            activeRefiningCheckBox     .setSelected(mixologyCfg.isActiveRefining());
            activeProcessingCheckBox   .setSelected(mixologyCfg.isActiveProcessing());
            useUnfinishedPotionsCheckBox.setSelected(mixologyCfg.isUseUnfinishedPotions());
            prioritizeOrdersCheckBox   .setSelected(mixologyCfg.isPrioritizeOrders());
            strictProcessingMethodsCheckBox.setSelected(mixologyCfg.isStrictProcessingMethods());

            minHerbCountSpinner .setValue(mixologyCfg.getMinHerbCount());
            minResinAmountSpinner.setValue(mixologyCfg.getMinResinAmount());
            transportMethodComboBox.setSelectedItem(mixologyCfg.getTransportMethod());

            /* new */
            buyAldariumCheckBox.setSelected(mixologyCfg.isBuyAldarium());
            aldariumPointsThresholdSpinner.setValue(mixologyCfg.getAldariumPointsThreshold());
            buyBarrelCheckBox.setSelected(mixologyCfg.isBuyBarrel());

            // Log values after updating UI to verify
            Logger.info("UI components updated with config values:");
            Logger.info("buyAldariumCheckBox: " + buyAldariumCheckBox.isSelected());
            Logger.info("aldariumPointsThresholdSpinner: " + aldariumPointsThresholdSpinner.getValue());
            Logger.info("buyBarrelCheckBox: " + buyBarrelCheckBox.isSelected());
            Logger.info("transportMethodComboBox: " + transportMethodComboBox.getSelectedItem());
        } finally {
            isLoading=false;
            Logger.info("MixologyGeneralPanel settings loaded successfully");
        }
    }

    void saveSettings(){
        // Log before saving
        Logger.info("Saving MixologyGeneralPanel settings");
        Logger.info("Buy Aldarium: " + buyAldariumCheckBox.isSelected());
        Logger.info("Aldarium Points Threshold: " + aldariumPointsThresholdSpinner.getValue());
        Logger.info("Buy Barrel: " + buyBarrelCheckBox.isSelected());

        mixologyCfg.setCollectDigweed         (collectDigweedCheckBox.isSelected());
        mixologyCfg.setUseDigweedOnMixalot    (useDigweedOnMixalotCheckBox.isSelected());
        mixologyCfg.setActiveRefining         (activeRefiningCheckBox.isSelected());
        mixologyCfg.setActiveProcessing       (activeProcessingCheckBox.isSelected());
        mixologyCfg.setUseUnfinishedPotions   (useUnfinishedPotionsCheckBox.isSelected());
        mixologyCfg.setPrioritizeOrders       (prioritizeOrdersCheckBox.isSelected());
        mixologyCfg.setStrictProcessingMethods(strictProcessingMethodsCheckBox.isSelected());

        mixologyCfg.setMinHerbCount   ((Integer)minHerbCountSpinner.getValue());
        mixologyCfg.setMinResinAmount ((Integer)minResinAmountSpinner.getValue());
        mixologyCfg.setTransportMethod((String) transportMethodComboBox.getSelectedItem());

        /* new */
        mixologyCfg.setBuyAldarium   (buyAldariumCheckBox.isSelected());
        mixologyCfg.setAldariumPointsThreshold((Integer)aldariumPointsThresholdSpinner.getValue());
        mixologyCfg.setBuyBarrel     (buyBarrelCheckBox.isSelected());

        // Mark the config as dirty to ensure it's saved
        mixologyCfg.markDirty();
        config.markDirty();

        // Save the config to file
        config.saveConfig();

        // Log after saving
        Logger.info("MixologyGeneralPanel settings saved successfully");
    }
}




class MixologyHerbsPanel extends SettingsPanel {
    private final HerbConfig config;
    private final MixologyConfig mixologyConfig;
    private JList<String> herbSelectionList;
    private boolean isLoading = false;

    public MixologyHerbsPanel(HerbConfig config) {
        super();
        this.config = config;
        this.mixologyConfig = config.getMixologyConfig();
        initializeComponents();
        loadSettings();
    }

    private void initializeComponents() {
        setLayout(new BorderLayout());

        // Create a main panel with BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setOpaque(false);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 15));

        // Header
        JLabel headerLabel = new JLabel("SELECT HERBS TO REFINE");
        headerLabel.setFont(new Font(StyleManager.SECTION_HEADER_FONT.getName(), Font.BOLD, 14));
        headerLabel.setForeground(StyleManager.ACCENT);
        headerLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        mainPanel.add(headerLabel, BorderLayout.NORTH);

        // Herb selection list
        DefaultListModel<String> herbListModel = new DefaultListModel<>();
        String[] availableHerbs = {"Guam", "Marrentill", "Tarromin", "Harralander",
                                  "Ranarr", "Toadflax", "Irit", "Avantoe",
                                  "Kwuarm", "Snapdragon", "Cadantine", "Lantadyme",
                                  "Dwarf weed", "Torstol"};
        for (String herb : availableHerbs) {
            herbListModel.addElement(herb);
        }

        herbSelectionList = new JList<>(herbListModel);
        herbSelectionList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        StyleManager.styleList(herbSelectionList);

        JScrollPane herbScrollPane = new JScrollPane(herbSelectionList);
        herbScrollPane.setBorder(BorderFactory.createLineBorder(StyleManager.BORDER_COLOR));
        mainPanel.add(herbScrollPane, BorderLayout.CENTER);

        // Instructions
        JLabel instructionsLabel = new JLabel("<html>Select the herbs you want to process.<br>Hold Ctrl to select multiple herbs.</html>");
        StyleManager.styleLabel(instructionsLabel);
        instructionsLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        mainPanel.add(instructionsLabel, BorderLayout.SOUTH);

        // Add the main panel to the tab
        add(mainPanel, BorderLayout.CENTER);

        // Add listener
        herbSelectionList.addListSelectionListener(e -> {
            if (!isLoading && !e.getValueIsAdjusting()) {
                saveSettings();
            }
        });
    }

    public void loadSettings() {
        isLoading = true;
        try {
            // Log values from config before updating UI
            Logger.info("Loading MixologyHerbsPanel settings from config:");
            Logger.info("MixologyConfig instance: " + mixologyConfig);

            List<String> selectedHerbs = mixologyConfig.getSelectedHerbs();
            Logger.info("Selected herbs after getSelectedHerbs(): " + selectedHerbs);

            if (selectedHerbs == null) {
                selectedHerbs = new ArrayList<>();
                Logger.info("No selected herbs found in config, using empty list");
            } else if (selectedHerbs.isEmpty()) {
                Logger.info("Selected herbs list is EMPTY - this is likely the issue");
                // Force some default herbs if the list is empty
                selectedHerbs = Arrays.asList("Kwuarm", "Lantadyme", "Tarromin");
                Logger.info("Forcing default herbs: " + selectedHerbs);
                mixologyConfig.setSelectedHerbs(selectedHerbs);
            } else {
                Logger.info("Selected herbs in config: " + String.join(", ", selectedHerbs));
            }

            // Select current herbs
            ListModel<String> model = herbSelectionList.getModel();
            Logger.info("Herb list model size: " + model.getSize());
            for (int i = 0; i < model.getSize(); i++) {
                Logger.info("Herb at index " + i + ": " + model.getElementAt(i));
            }

            int[] selectedIndices = new int[selectedHerbs.size()];
            int count = 0;

            for (int i = 0; i < model.getSize(); i++) {
                String herb = model.getElementAt(i);
                if (selectedHerbs.contains(herb)) {
                    selectedIndices[count++] = i;
                    Logger.info("Found herb in list: " + herb + " at index " + i);
                }
            }

            // Update UI component
            herbSelectionList.setSelectedIndices(selectedIndices);

            // Log selected indices after updating UI
            Logger.info("Set selected indices: " + Arrays.toString(selectedIndices));
            Logger.info("Current selection in UI: " + Arrays.toString(herbSelectionList.getSelectedIndices()));
        } finally {
            isLoading = false;
            Logger.info("MixologyHerbsPanel settings loaded successfully");
        }
    }

    public void saveSettings() {
        // Log before saving
        Logger.info("Saving MixologyHerbsPanel settings");

        List<String> selectedHerbs = new ArrayList<>();
        for (int index : herbSelectionList.getSelectedIndices()) {
            selectedHerbs.add(herbSelectionList.getModel().getElementAt(index));
        }

        // Log before setting
        Logger.info("Current selectedHerbs in config before setting: " +
                   (mixologyConfig.getSelectedHerbs() == null ? "NULL" : mixologyConfig.getSelectedHerbs()));

        // Set the selected herbs
        mixologyConfig.setSelectedHerbs(selectedHerbs);

        // Log after setting
        Logger.info("Current selectedHerbs in config after setting: " +
                   (mixologyConfig.getSelectedHerbs() == null ? "NULL" : mixologyConfig.getSelectedHerbs()));

        // Make sure to mark the config as dirty
        mixologyConfig.markDirty();
        config.markDirty();

        // Save config to file
        config.saveConfig();

        // Log after saving
        Logger.info("MixologyHerbsPanel settings saved successfully");
        Logger.info("Selected herbs: " + String.join(", ", selectedHerbs));
    }
}