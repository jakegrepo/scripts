package scripts.Herb.gui;

import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import scripts.Herb.config.MixologyConfig;
import core.context.ScriptContext;
import core.paint.debug.DebugOverlayInterface;
import scripts.Herb.MixologyScript;
import core.node.TaskNode;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * Enhanced overlay for displaying Mixology script statistics with a polished UI
 */
public class MixologyOverlay implements DebugOverlayInterface {
    private final MixologyConfig config;
    private final Rectangle panelBounds = new Rectangle(7, 300, 515, 220); // Moved up by another 20 pixels
    private final ScriptContext context;
    private final MixologyScript script;
    private boolean enabled = true;

    // Stats tracking
    private long startTime;
    private int startXp;
    private int startMoxPoints;
    private int startLyePoints;
    private int startAgaPoints;
    private int totalOrders = 0;
    private final Map<String,Integer> potionCounts = new HashMap<>();
    private int digweedMixalotUses = 0;

    // Current values
    private String currentStatus = "Starting...";
    private String currentNode   = "None";
    private int storedResin      = 0;
    private String currentOrder  = "";

    // Point config keys
    private static final int LYE_POINTS_CONFIG = 4414;
    private static final int AGA_POINTS_CONFIG = 4415;
    private static final int MOX_POINTS_CONFIG = 4416;

    // UI colors & fonts
    private static final Color PRIMARY_COLOR     = new Color(20,22,28,225);
    private static final Color SECONDARY_COLOR   = new Color(25,28,34,180);
    private static final Color ACCENT_COLOR      = new Color(110,140,255,255);
    private static final Color TEXT_COLOR        = new Color(255,255,255,255);
    private static final Color MUTED_TEXT_COLOR  = new Color(180,185,200,255);
    private static final Color SUCCESS_COLOR     = new Color(85,230,130,255);
    private static final Color BORDER_COLOR      = new Color(60,70,120,120);
    private static final Color DIVIDER_COLOR     = new Color(90,100,160,100);

    private static final int PANEL_PADDING         = 12;
    private static final int CORNER_RADIUS         = 12;
    private static final int SECTION_CORNER_RADIUS = 8;
    private static final Font REGULAR_FONT    = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font SMALL_FONT      = new Font("Segoe UI", Font.PLAIN, 11);
    private static final Font ROW_HEADER_FONT = new Font("Segoe UI", Font.BOLD, 12);
    private static final Font HEADER_FONT     = new Font("Segoe UI", Font.BOLD, 14);

    // Icons
    private static final Map<String,String> ICON_URLS = new HashMap<>();
    private static final Map<String,BufferedImage> ICONS = new HashMap<>();
    private static boolean iconsLoaded = false;
    private static boolean isLoadingIcons = false;
    static {
        ICON_URLS.put("STATUS", "https://i.ibb.co/gMvKLHf4/Stats-icon.png");
        ICON_URLS.put("MOX",    "https://i.ibb.co/WN9Kgt2K/Mox.png");
        ICON_URLS.put("LYE",    "https://i.ibb.co/ksXp5Bmf/Lye.png");
        ICON_URLS.put("AGA",    "https://i.ibb.co/gF7d75sr/Aga.png");
        ICON_URLS.put("POINTS", "https://i.ibb.co/Tq8rRjkF/Coins-detail.png");
        ICON_URLS.put("XP",     "https://i.ibb.co/sd6MCkgr/Herblore.png");
        preloadIcons();
    }

    private static void preloadIcons() {
        if (isLoadingIcons) return;
        isLoadingIcons = true;
        new Thread(() -> {
            Map<String,BufferedImage> cache = new HashMap<>();
            ICON_URLS.forEach((key,url) -> {
                try {
                    BufferedImage img = ImageIO.read(new URL(url));
                    BufferedImage scaled = new BufferedImage(14,14,BufferedImage.TYPE_INT_ARGB);
                    Graphics2D g2 = scaled.createGraphics();
                    g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                    g2.drawImage(img,0,0,14,14,null);
                    g2.dispose();
                    cache.put(key,scaled);
                } catch (IOException e) {
                    cache.put(key, generatePlaceholderIcon(key));
                }
            });
            synchronized(ICONS) {
                ICONS.putAll(cache);
                iconsLoaded = true;
                isLoadingIcons = false;
            }
        }, "MixologyIconLoader").start();
    }

    private static BufferedImage generatePlaceholderIcon(String key) {
        BufferedImage icon = new BufferedImage(14,14,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = icon.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(ACCENT_COLOR);
        g.fillOval(0,0,14,14);
        g.setColor(PRIMARY_COLOR);
        g.drawString(key.substring(0,1),4,10);
        g.dispose();
        return icon;
    }

    public MixologyOverlay(ScriptContext context, MixologyScript script) {
        this.context = context;
        this.script  = script;
        this.config  = null;
        this.startTime     = System.currentTimeMillis();
        this.startXp       = Skills.getExperience(Skill.HERBLORE);
        this.startMoxPoints= PlayerSettings.getConfig(MOX_POINTS_CONFIG);
        this.startLyePoints= PlayerSettings.getConfig(LYE_POINTS_CONFIG);
        this.startAgaPoints= PlayerSettings.getConfig(AGA_POINTS_CONFIG);
    }

    private boolean isCurrentlyRendering = false;

    @Override
    public void render(Graphics2D g) {
        if (!enabled || isCurrentlyRendering) return;
        isCurrentlyRendering = true;
        try {
            Object origAA = g.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            renderPanel(g);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, origAA);
        } finally {
            isCurrentlyRendering = false;
        }
    }

    private void renderPanel(Graphics2D g) {
        Paint orig = g.getPaint();
        GradientPaint bg = new GradientPaint(
                panelBounds.x, panelBounds.y,
                new Color(18,20,32,220),
                panelBounds.x, panelBounds.y + panelBounds.height,
                new Color(25,28,40,235)
        );
        g.setPaint(bg);
        g.fillRoundRect(panelBounds.x, panelBounds.y, panelBounds.width, panelBounds.height, CORNER_RADIUS, CORNER_RADIUS);
        g.setPaint(orig);

        g.setColor(BORDER_COLOR);
        g.setStroke(new BasicStroke(1.5f));
        g.drawRoundRect(panelBounds.x, panelBounds.y, panelBounds.width, panelBounds.height, CORNER_RADIUS, CORNER_RADIUS);

        int titleY = panelBounds.y + PANEL_PADDING;
        GradientPaint hdr = new GradientPaint(
                panelBounds.x, titleY,
                new Color(40,45,80,180),
                panelBounds.x + panelBounds.width, titleY,
                new Color(60,65,100,120)
        );
        g.setPaint(hdr);
        g.fillRoundRect(panelBounds.x + 5, titleY - 2, panelBounds.width - 10, 22, 8, 8);
        g.setPaint(orig);

        // Title
        g.setFont(new Font("Segoe UI", Font.BOLD, 16));
        g.setColor(new Color(140,170,255,90));
        for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++) {
            if (i != 0 || j != 0) g.drawString("ScarMixology", panelBounds.x + 10 + i, titleY + 17 + j);
        }
        g.setColor(Color.black);
        g.drawString("ScarMixology", panelBounds.x + 10, titleY + 18);
        g.setColor(TEXT_COLOR);
        g.drawString("ScarMixology", panelBounds.x + 10, titleY + 17);

        // Runtime clock
        g.setFont(SMALL_FONT);
        g.setColor(ACCENT_COLOR);
        String runtime = formatTime(System.currentTimeMillis() - startTime);
        int rtW = g.getFontMetrics().stringWidth(runtime);
        drawClockIcon(g,
                panelBounds.x + panelBounds.width - PANEL_PADDING - rtW - 18,
                titleY + 10
        );
        g.drawString(runtime,
                panelBounds.x + panelBounds.width - PANEL_PADDING - rtW,
                titleY + 12
        );

        // Divider
        g.setColor(DIVIDER_COLOR);
        g.setStroke(new BasicStroke(1f));
        g.drawLine(
                panelBounds.x + PANEL_PADDING, titleY + 22,
                panelBounds.x + panelBounds.width - PANEL_PADDING, titleY + 22
        );

        // Status box
        int sx = panelBounds.x + PANEL_PADDING;
        int sy = titleY + 24;
        int sw = panelBounds.width - PANEL_PADDING * 2;
        int sh = 40;
        g.setColor(SECONDARY_COLOR);
        g.fillRoundRect(sx, sy, sw, sh, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);
        g.setColor(BORDER_COLOR);
        g.drawRoundRect(sx, sy, sw, sh, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);
        g.setFont(ROW_HEADER_FONT);
        g.setColor(TEXT_COLOR);
        wrapText(g, currentStatus, sx + 10, sy + g.getFontMetrics().getAscent() + 2, sw - 20, g.getFontMetrics().getHeight());

        // Content sections
        int contentY = sy + sh + PANEL_PADDING;
        int sectionW = (panelBounds.width - PANEL_PADDING * 3) / 2;
        int sectionH = 90; // Reduced from 100 to prevent cutoff
        drawXpSection(g, sx, contentY, sectionW, sectionH);
        drawPointsSection(g, sx + PANEL_PADDING + sectionW, contentY, sectionW, sectionH);
    }

    private void wrapText(Graphics2D g, String text, int x, int y, int maxW, int lh) {
        FontMetrics fm = g.getFontMetrics();
        String[] words = text.split(" ");
        String line = "";
        for (String w : words) {
            String test = line.isEmpty() ? w : line + " " + w;
            if (fm.stringWidth(test) > maxW) {
                g.drawString(line, x, y);
                line = w;
                y += lh;
            } else {
                line = test;
            }
        }
        if (!line.isEmpty()) g.drawString(line, x, y);
    }

    private void drawXpSection(Graphics2D g, int x, int y, int w, int h) {
        Paint orig = g.getPaint();
        g.setPaint(new GradientPaint(x, y, new Color(30,35,50,140), x, y + h, new Color(25,28,34,160)));
        g.fillRoundRect(x, y, w, h, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);
        g.setPaint(orig);

        // Unified header style
        g.setPaint(new GradientPaint(x, y, new Color(40,45,70,220), x + w, y, new Color(50,60,100,180)));
        g.fillRoundRect(x, y, w, 24, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);
        g.setColor(new Color(60,80,160,150));
        g.fillRect(x + 2, y + 23, w - 4, 2);
        g.setColor(new Color(80,90,140,100));
        g.drawRoundRect(x, y, w, h, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);

        // Header text & icon
        g.setFont(HEADER_FONT);
        g.setColor(new Color(140,170,255,90));
        for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++) {
            if (i != 0 || j != 0) g.drawString("Herblore", x + 26 + i, y + 17 + j);
        }
        g.setColor(Color.black);
        g.drawString("Herblore", x + 26, y + 18);
        g.setColor(TEXT_COLOR);
        g.drawString("Herblore", x + 26, y + 17);
        drawIcon(g, "XP", x + 8, y + 5);

        // Content rows
        int rowY = y + 36;
        int rowH = 16;

        g.setFont(ROW_HEADER_FONT);
        g.setColor(ACCENT_COLOR);
        g.drawString("Current Node:", x + 10, rowY);
        g.setFont(REGULAR_FONT);
        g.setColor(TEXT_COLOR);
        g.drawString(currentNode, x + 110, rowY);

        rowY += rowH;
        long xpG = Skills.getExperience(Skill.HERBLORE) - startXp;
        g.setFont(ROW_HEADER_FONT);
        g.setColor(ACCENT_COLOR);
        g.drawString("XP Gained:", x + 10, rowY);
        g.setFont(REGULAR_FONT);
        g.setColor(TEXT_COLOR);
        g.drawString(formatNumber(xpG), x + 110, rowY);

        rowY += rowH;
        double xpH = xpG * 3600000.0 / Math.max(1, System.currentTimeMillis() - startTime);
        g.setFont(ROW_HEADER_FONT);
        g.setColor(ACCENT_COLOR);
        g.drawString("XP/hr:", x + 10, rowY);
        g.setFont(REGULAR_FONT);
        g.setColor(SUCCESS_COLOR);
        g.drawString(formatNumber((long)xpH), x + 110, rowY);

        // Digweed on Mixalot tracker
        rowY += rowH;
        g.setFont(ROW_HEADER_FONT);
        g.setColor(ACCENT_COLOR);
        g.drawString("Digweed->Mixalot:", x + 10, rowY);
        g.setFont(REGULAR_FONT);
        g.setColor(TEXT_COLOR);
        g.drawString(String.valueOf(digweedMixalotUses), x + 110, rowY);
    }

    private void drawPointsSection(Graphics2D g, int x, int y, int w, int h) {
        Paint orig = g.getPaint();
        g.setPaint(new GradientPaint(x, y, new Color(30,35,50,140), x, y + h, new Color(25,30,45,160)));
        g.fillRoundRect(x, y, w, h, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);
        g.setPaint(orig);

        // Unified header style
        g.setPaint(new GradientPaint(x, y, new Color(40,45,70,220), x + w, y, new Color(50,60,100,180)));
        g.fillRoundRect(x, y, w, 24, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);
        g.setColor(new Color(60,80,160,150));
        g.fillRect(x + 2, y + 23, w - 4, 2);
        g.setColor(new Color(80,90,140,100));
        g.drawRoundRect(x, y, w, h, SECTION_CORNER_RADIUS, SECTION_CORNER_RADIUS);

        // Header text & icon
        g.setFont(HEADER_FONT);
        g.setColor(new Color(140,170,255,90));
        for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++) {
            if (i != 0 || j != 0) g.drawString("Points", x + 26 + i, y + 17 + j);
        }
        g.setColor(Color.black);
        g.drawString("Points", x + 26, y + 18);
        g.setColor(TEXT_COLOR);
        g.drawString("Points", x + 26, y + 17);
        drawIcon(g, "POINTS", x + 8, y + 5);

        // Content rows
        int rowY = y + 38;
        int spacing = 18;

        // Mox
        drawIcon(g, "MOX", x + 10, rowY - 10);
        g.setFont(ROW_HEADER_FONT);
        g.setColor(MUTED_TEXT_COLOR);
        g.drawString("Mox:", x + 30, rowY);
        g.setFont(REGULAR_FONT);
        g.setColor(new Color(255,180,180));
        long mox = PlayerSettings.getConfig(MOX_POINTS_CONFIG) - startMoxPoints;
        g.drawString(formatNumber(mox), x + w - g.getFontMetrics().stringWidth(formatNumber(mox)) - 10, rowY);

        // Lye
        rowY += spacing;
        drawIcon(g, "LYE", x + 10, rowY - 10);
        g.setFont(ROW_HEADER_FONT);
        g.setColor(MUTED_TEXT_COLOR);
        g.drawString("Lye:", x + 30, rowY);
        g.setFont(REGULAR_FONT);
        g.setColor(new Color(180,255,180));
        long lye = PlayerSettings.getConfig(LYE_POINTS_CONFIG) - startLyePoints;
        g.drawString(formatNumber(lye), x + w - g.getFontMetrics().stringWidth(formatNumber(lye)) - 10, rowY);

        // Aga
        rowY += spacing;
        drawIcon(g, "AGA", x + 10, rowY - 10);
        g.setFont(ROW_HEADER_FONT);
        g.setColor(MUTED_TEXT_COLOR);
        g.drawString("Aga:", x + 30, rowY);
        g.setFont(REGULAR_FONT);
        g.setColor(new Color(180,200,255));
        long aga = PlayerSettings.getConfig(AGA_POINTS_CONFIG) - startAgaPoints;
        g.drawString(formatNumber(aga), x + w - g.getFontMetrics().stringWidth(formatNumber(aga)) - 10, rowY);

        // Points/hr
        rowY += spacing;
        g.setFont(ROW_HEADER_FONT);
        g.setColor(MUTED_TEXT_COLOR);
        g.drawString("Pts/Hr:", x + 10, rowY);
        g.setFont(REGULAR_FONT);
        g.setColor(SUCCESS_COLOR);
        long total = mox + lye + aga;
        double phr = total * 3600000.0 / Math.max(1, System.currentTimeMillis() - startTime);
        String ptsH = formatNumber((long)phr);
        g.drawString(ptsH, x + w - g.getFontMetrics().stringWidth(ptsH) - 10, rowY);
    }

    private void drawIcon(Graphics2D g, String key, int x, int y) {
        BufferedImage icon;
        synchronized(ICONS) {
            icon = ICONS.getOrDefault(key, generatePlaceholderIcon(key));
        }
        g.setColor(new Color(120,140,200,60));
        g.fillOval(x - 1, y - 1, 16, 16);
        g.drawImage(icon, x, y, null);
    }

    private void drawClockIcon(Graphics2D g, int x, int y) {
        g.setColor(TEXT_COLOR);
        g.fillOval(x, y - 10, 15, 15);
        g.setColor(PRIMARY_COLOR);
        g.fillOval(x + 2, y - 8, 11, 11);
        g.setColor(TEXT_COLOR);
        g.drawLine(x + 7, y - 7, x + 7, y - 3);
        g.drawLine(x + 7, y - 7, x + 10, y - 4);
    }

    private String formatTime(long ms) {
        long s = ms / 1000, m = s / 60, h = m / 60;
        return String.format("%02d:%02d:%02d", h, m % 60, s % 60);
    }

    private String formatNumber(long n) {
        if (n < 1000) return String.valueOf(n);
        if (n < 1_000_000) return String.format("%.1fk", n / 1000.0).replace(".0k", "k");
        return String.format("%.2fm", n / 1_000_000.0).replace(".00m", "m");
    }

    // --- Compatibility methods ---
    public void setStatus(String status) {
        if (status != null && !status.isEmpty()) {
            this.currentStatus = status;
            
            if (context != null && context.tasks() != null) {
                TaskNode activeNode = context.tasks().getActiveNode();
                if (activeNode != null) {
                    String nodeStatus = activeNode.getStatus();
                    if (nodeStatus != null && !nodeStatus.isEmpty()) {
                        this.currentStatus = nodeStatus;
                    }
                }
            }
        }
    }

    public void updatePasteAmounts(int mox, int lye, int aga) { }

    public void updateStoredResin(int resin) {
        this.storedResin = resin;
    }

    public void updateActivePotion(String potion) { }

    public void updateCurrentOrder(String order) {
        if (order != null) this.currentOrder = order;
    }

    public void recordPointsGained(int redPoints, int greenPoints, int bluePoints) { }

    public void recordCompletedOrder() {
        this.totalOrders++;
    }

    public void incrementPotionCount(String potionName) {
        if (potionName != null && !potionName.isEmpty()) {
            potionCounts.put(potionName, potionCounts.getOrDefault(potionName, 0) + 1);
            recordCompletedOrder();
        }
    }

    public void updateCurrentNode(String node) {
        this.currentNode = node;
    }

    public void incrementDigweedMixalotUses() {
        digweedMixalotUses++;
    }

    @Override public String getName()        { return "MixologyStats"; }
    @Override public void setEnabled(boolean e) { this.enabled = e; }
    @Override public boolean isEnabled()        { return enabled; }
}
