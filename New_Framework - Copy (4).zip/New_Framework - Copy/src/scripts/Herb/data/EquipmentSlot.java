package scripts.Herb.data;

public enum EquipmentSlot {
    HEAD("Helmet"),
    CAPE("Cape"),
    NECK("Necklace"),
    WEAPON("Weapon"),
    BODY("Body"),
    SHIELD("Shield"),
    LEGS("Legs"),
    HANDS("Gloves"),
    FEET("Boots"),
    RING("Ring"),
    AMMO("Ammo");

    private final String displayName;

    EquipmentSlot(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
} 