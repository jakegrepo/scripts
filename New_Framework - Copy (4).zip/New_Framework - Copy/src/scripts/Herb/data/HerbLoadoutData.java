package scripts.Herb.data;

import java.util.HashMap;
import java.util.Map;

public class HerbLoadoutData {
    private Map<String, String> equipment = new HashMap<>();
    private Map<String, Integer> supplies = new HashMap<>();
    private String name;
    private String combatStyle;
    private int ammoQuantity;
    private boolean isDefault;

    public HerbLoadoutData() {
        // Default constructor
    }

    public boolean isDefault() {
        return isDefault;
    }

    public void setDefault(boolean isDefault) {
        this.isDefault = isDefault;
    }

    public Map<String, String> getEquipment() {
        return equipment;
    }

    public void setEquipment(Map<String, String> equipment) {
        this.equipment = new HashMap<>(equipment);
    }

    public Map<String, Integer> getSupplies() {
        return supplies;
    }

    public void setSupplies(Map<String, Integer> supplies) {
        this.supplies = new HashMap<>(supplies);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCombatStyle() {
        return combatStyle;
    }

    public void setCombatStyle(String combatStyle) {
        this.combatStyle = combatStyle;
    }

    public int getAmmoQuantity() {
        return ammoQuantity;
    }

    public void setAmmoQuantity(int ammoQuantity) {
        this.ammoQuantity = ammoQuantity;
    }

    public boolean isValid() {
        // Check if equipment is not empty
        if (equipment == null || equipment.isEmpty()) {
            return false;
        }

        // Check if name is set
        if (name == null || name.trim().isEmpty()) {
            return false;
        }

        // Check if combat style is set
        if (combatStyle == null || combatStyle.trim().isEmpty()) {
            return false;
        }

        // Check if ammo quantity is set when ammo is present
        if (equipment.containsKey("ammo") && !equipment.get("ammo").isEmpty() && ammoQuantity <= 0) {
            return false;
        }

        return true;
    }
} 