package scripts.Herb.data;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProfileData {
    private String foodType;
    private int healthThreshold;
    private int ammoQuantity;
    private Map<String, String> gearLoadoutAssignments = new HashMap<>();
    private boolean useGrandExchange = false;
    private List<String> foodNames = new ArrayList<>();
    private int suppliesMultiplier = 1;
    private boolean alchemyEnabled = false;
    private int targetFoodCount = 0;
    private List<String> quickPrayers = new ArrayList<>();
    private Map<String, String> equipment = new HashMap<>();
    private Map<String, Integer> supplies = new HashMap<>();
    private String name;
    private String defaultLoadout;
    
    // Party Panel Settings
    private boolean duoMode = false;
    private boolean isLeader = false;
    private int serverPort = 25565;
    private int clientPort = 25565;
    private int syncDelay = 2;

    // Getters and setters


    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public int getHealthThreshold() {
        return healthThreshold;
    }

    public void setHealthThreshold(int healthThreshold) {
        this.healthThreshold = healthThreshold;
    }

    public int getAmmoQuantity() {
        return ammoQuantity;
    }

    public void setAmmoQuantity(int ammoQuantity) {
        this.ammoQuantity = ammoQuantity;
    }



    public Map<String, String> getGearLoadoutAssignments() {
        return new HashMap<>(gearLoadoutAssignments);
    }

    public void setGearLoadoutAssignments(Map<String, String> assignments) {
        this.gearLoadoutAssignments = new HashMap<>(assignments);
    }


    public boolean isUseGrandExchange() {
        return useGrandExchange;
    }

    public void setUseGrandExchange(boolean useGrandExchange) {
        this.useGrandExchange = useGrandExchange;
    }

    public List<String> getFoodNames() {
        return foodNames;
    }

    public void setFoodNames(List<String> foodNames) {
        this.foodNames = new ArrayList<>(foodNames);
    }

    public int getSuppliesMultiplier() {
        return suppliesMultiplier;
    }

    public void setSuppliesMultiplier(int suppliesMultiplier) {
        this.suppliesMultiplier = suppliesMultiplier;
    }

    public boolean isAlchemyEnabled() {
        return alchemyEnabled;
    }

    public void setAlchemyEnabled(boolean alchemyEnabled) {
        this.alchemyEnabled = alchemyEnabled;
    }

    public int getTargetFoodCount() {
        return targetFoodCount;
    }

    public void setTargetFoodCount(int targetFoodCount) {
        this.targetFoodCount = targetFoodCount;
    }

    public List<String> getQuickPrayers() {
        return quickPrayers;
    }

    public void setQuickPrayers(List<String> quickPrayers) {
        this.quickPrayers = new ArrayList<>(quickPrayers);
    }

    public Map<String, String> getEquipment() {
        return equipment;
    }

    public void setEquipment(Map<String, String> equipment) {
        this.equipment = new HashMap<>(equipment);
    }

    public Map<String, Integer> getSupplies() {
        return supplies;
    }

    public void setSupplies(Map<String, Integer> supplies) {
        this.supplies = new HashMap<>(supplies);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDefaultLoadout() {
        return defaultLoadout;
    }

    public void setDefaultLoadout(String defaultLoadout) {
        this.defaultLoadout = defaultLoadout;
    }

    // Party Panel Getters/Setters
    public boolean isDuoMode() {
        return duoMode;
    }

    public void setDuoMode(boolean duoMode) {
        this.duoMode = duoMode;
    }

    public boolean isLeader() {
        return isLeader;
    }

    public void setLeader(boolean leader) {
        isLeader = leader;
    }

    public int getServerPort() {
        return serverPort;
    }

    public void setServerPort(int serverPort) {
        this.serverPort = serverPort;
    }

    public int getClientPort() {
        return clientPort;
    }

    public void setClientPort(int clientPort) {
        this.clientPort = clientPort;
    }

    public int getSyncDelay() {
        return syncDelay;
    }

    public void setSyncDelay(int syncDelay) {
        this.syncDelay = syncDelay;
    }

    @Override
    public String toString() {
        return name != null ? name : "Unnamed Profile";
    }
}