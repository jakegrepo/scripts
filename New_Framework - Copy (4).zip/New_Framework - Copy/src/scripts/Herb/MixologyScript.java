package scripts.Herb;

import core.base.ScarScript;
import core.config.RestockConfig;
import core.grandexchange.RestockGrandExchangeNode;
import core.gui.AbstractSettingsTab;
import core.node.TaskNode;
import core.paint.PaintBuilder;
import core.paint.ScriptPaint;
import core.state.ScriptState;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.script.listener.ItemContainerListener;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Timer;
import scripts.Herb.config.HerbConfig;
import scripts.Herb.config.MixologyConfig;
import scripts.Herb.enums.NavigationDestination;
import scripts.Herb.gui.MixologyOverlay;
import scripts.Herb.gui.MixologySettingsTab;
import scripts.Herb.listeners.PotionItemListener;
import scripts.Herb.nodes.*;
import scripts.Herb.utils.MixologyUtils;
import scripts.Herb.webnodes.MixologistLabWeb;
import scripts.Herb.muling.MulingNode;

import java.awt.*;
import java.util.List;

@ScriptManifest(
        name = "Mixology_May20th",
        author = "Scarfade",
        version = 1.0,
        description = "Completes the Mastering Mixology minigame",
        category = Category.MINIGAME
)
public class MixologyScript extends ScarScript<HerbConfig> {

    private MixologyConfig mixologyConfig;
    private ScriptPaint paint;
    private MixologyOverlay statsOverlay;
    private Timer scriptTimer;
    private boolean restockTriggered = false;        // ← NEW

    private RestockGrandExchangeNode restockNode;

    private int startHerbXp;
    private int startLevel;
    private int potionsCreated = 0;
    private ItemContainerListener potionItemListener;
    private long startTime;
    private long startXp;

    @Override
    protected void onScriptStart() {
        try {
            startTime = System.currentTimeMillis();
            startXp = Skills.getExperience(Skill.HERBLORE);
            Logger.info("Starting Mixology script initialization...");

            configureRestockItems();
            initializeRestockComponents();
            initializeNodes();
            initializeScriptListeners();

            if (this.paint == null) {
                this.paint = new PaintBuilder(getContext())
                        .setTitle("ScarMixology")
                        .addRuntime()
                        .addState()
                        .addRow("Potions Created", () -> String.valueOf(potionsCreated))
                        .addXpTracker(Skill.HERBLORE)
                        .addPerHour("XP", () -> Skills.getExperience(Skill.HERBLORE) - startXp)
                        .build();
            }

            if (statsOverlay == null) {
                statsOverlay = new MixologyOverlay(context, this);
                statsOverlay.setEnabled(true);
                context.getDebugOverlayManager().registerOverlay(statsOverlay);
            }

            MixologistLabWeb.addMixologistLabNodes();
            logSettings();
            setState(ScriptState.RUNNING);
            Logger.info("Mixology script started successfully!");
        } catch (Exception e) {
            Logger.error("Error during script start: " + e.getMessage(), e);
            setState(ScriptState.ERROR);
        }
    }

    private void logSettings() {
        Logger.info("=== MIXOLOGY SCRIPT SETTINGS ===");
        Logger.info("Selected herbs: " + getMixologyConfig().getSelectedHerbs());
        Logger.info("=== PURCHASE REWARDS NODE SETTINGS ===");
        Logger.info("Buy Aldarium: " + getMixologyConfig().isBuyAldarium());
        Logger.info("Buy Barrel: " + getMixologyConfig().isBuyBarrel());
        Logger.info("Current Points - Mox: " + PlayerSettings.getConfig(4416));
        Logger.info("Current Points - Lye: " + PlayerSettings.getConfig(4414));
        Logger.info("Current Points - Aga: " + PlayerSettings.getConfig(4415));
        Logger.info("===================================");
    }

    private void configureRestockItems() {
        Logger.info("Configuring restock settings...");
        RestockConfig restockConfig = config.getRestockConfig();
        restockConfig.setEnabled(true);
        List<String> items = restockConfig.getInventoryItemsToRestock();
        Logger.info("Restock items (from GUI): " + items);
        for (String item : items) {
            int minQty = restockConfig.getInventoryItemMinimumQuantity(item);
            int buyQty = restockConfig.getInventoryItemDesiredQuantity(item);
            boolean selling = restockConfig.isSelling(item);
            int sellQty = restockConfig.getSellQuantity(item);
            Logger.info(String.format(" - %s: Min=%d, Buy=%d, Selling=%s, SellQty=%d",
                    item, minQty, buyQty, selling, sellQty));
        }
    }

    private void initializeRestockComponents() {
        Logger.info("Initializing restock components...");
        if (restockNode == null) {
            restockNode = new RestockGrandExchangeNode("RestockGE", 0, config);
        }
        restockNode.getRestockCheck().logRestockConfig();
        Logger.info("RestockGrandExchangeNode initialized with priority " + restockNode.getPriority());
    }

    private void initializeScriptListeners() {
        Logger.info("Initializing script listeners...");
    }

    private void initializeNodes() {
        Logger.info("=== INITIALIZING NODES ===");
        mixologyConfig = getMixologyConfig();
        clearNodes();

        // Add Restock node first
        addNode(restockNode);
        addNode(new MulingNode(config, this));
        addNode(new PurchaseRewardsNode(config, mixologyConfig, this));
        addNode(new MovementNode(mixologyConfig, this));
        addNode(new DigweedNode(config, mixologyConfig, this));
        addNode(new SimpleRefineHerbNode(config, mixologyConfig, this));
        addNode(new MixPotionNode(config, mixologyConfig, this));
        addNode(new ProcessPotionNode(config, mixologyConfig, this));
        addNode(new DepositPotionNode(config, mixologyConfig, this));

        Logger.info("Total nodes initialized: " + context.tasks().getNodes().size());
    }

    public RestockGrandExchangeNode getRestockNode() {
        if (restockNode == null) {
            initializeRestockComponents();
        }
        return restockNode;
    }

    @Override
    protected AbstractSettingsTab getScriptTab() {
        return new MixologySettingsTab(getContext());
    }

    @Override
    protected int onScriptLoop() {
        try {
            if (!getState().isRunnable()) {
                statsOverlay.updateCurrentNode("N/A");
                statsOverlay.setStatus(getState().name());
                return 600;
            }

            // ——— CENTRALIZED RESTOCK CHECK ———
            if (restockTriggered && !getRestockNode().getRestockCheck().needsRestock()) {
                Logger.info("[SCRIPT] Restock completed, clearing trigger flag.");
                restockTriggered = false;
            }

            // Only fire once per restock cycle
            if (!restockTriggered && getRestockNode().getRestockCheck().needsRestock()) {
                Logger.info("[SCRIPT] Restock needed—forcing GE node to take over.");
                getRestockNode().forceExecute();
                restockTriggered = true;
                return 0;
            }

            // Ensure nodes exist
            if (context.tasks().getNodes().isEmpty()) {
                Logger.error("No nodes available - reinitializing...");
                initializeNodes();
                return 600;
            }

            // Execute whichever node is valid
            int sleep = context.tasks().execute();

            // Update overlay
            TaskNode active = context.tasks().getActiveNode();
            statsOverlay.updateCurrentNode(active != null ? active.getName() : "None");
            statsOverlay.setStatus(active != null ? active.getName() : "Idle");

            return sleep == 0 ? 600 : sleep;
        } catch (Exception e) {
            Logger.error("Error in script loop: " + e.getMessage(), e);
            setState(ScriptState.ERROR);
            return 1000;
        }
    }

    @Override
    public void onPaint(Graphics2D g) {
        if (statsOverlay != null && statsOverlay.isEnabled()) {
            statsOverlay.render(g);
        }
    }

    @Override
    protected void onScriptStop() throws InterruptedException {
        Logger.info("Stopping Mixology script...");
        if (Bank.isOpen()) Bank.close();
        if (GrandExchange.isOpen()) GrandExchange.close();
        Logger.info("=== FINAL STATS ===");
        Logger.info("Runtime: " + formatTime(System.currentTimeMillis() - startTime));
        Logger.info("XP Gained: " + (Skills.getExperience(Skill.HERBLORE) - startXp));
        Logger.info("Potions Created: " + potionsCreated);
        restockNode = null;
    }

    private String formatTime(long ms) {
        long s = ms / 1000, m = s / 60, h = m / 60;
        return String.format("%02d:%02d:%02d", h, m % 60, s % 60);
    }

    @Override
    public HerbConfig getScriptConfig() {
        if (config == null) config = new HerbConfig(getContext());
        return config;
    }

    @Override
    public boolean requiresGUI() {
        return true;
    }

    public MixologyConfig getMixologyConfig() {
        if (mixologyConfig == null || mixologyConfig.getContext() == null) {
            mixologyConfig = config.getMixologyConfig();
            if (mixologyConfig == null) {
                mixologyConfig = new MixologyConfig(getContext());
            }
        }
        return mixologyConfig;
    }

    public MixologyOverlay getOverlay() {
        return statsOverlay;
    }

    public double getVersion() {
        return getClass().getAnnotation(ScriptManifest.class).version();
    }

    public void incrementPotionsCreated() {
        potionsCreated++;
        if (statsOverlay != null) {
            statsOverlay.incrementPotionCount("Potion");
        }
    }

    /** For testing only */
    public void forceRestockCheck() {
        if (restockNode != null) restockNode.forceExecute();
    }
}
