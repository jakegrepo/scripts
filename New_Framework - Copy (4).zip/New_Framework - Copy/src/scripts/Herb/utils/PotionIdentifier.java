package scripts.Herb.utils;

import org.checkerframework.checker.nullness.qual.Nullable;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.widget.Widget;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.items.Item;
import org.dreambot.api.wrappers.widgets.WidgetChild;
import scripts.Herb.HerbGlobalState;

import java.util.HashMap;
import java.util.Map;

/**
 * Utility class for identifying potions and their processing methods
 * This centralizes all the potion identification logic to ensure consistent behavior
 */
public class PotionIdentifier {
    // Widget IDs for order interface
    private static final int ORDER_WIDGET_ID = 882;
    private static final int ORDER_WIDGET_CHILD_ID = 2;
    
    // Texture IDs for processing methods
    private static final int CRYSTALLIZE_TEXTURE_ID = 5673;
    private static final int CONCENTRATE_TEXTURE_ID = 5672;
    private static final int HOMOGENIZE_TEXTURE_ID = 5674;
    
    /**
     * Checks if an item is an unprocessed potion by its name
     * 
     * @param itemName The name of the item to check
     * @return true if it's an unprocessed potion, false otherwise
     */
    public static boolean isUnprocessedPotion(String itemName) {
        if (itemName == null || itemName.isEmpty()) {
            return false;
        }
        
        // Get the item from inventory
        Item item = Inventory.get(itemName);
        
        if (item == null) {
            return false;
        }
        
        // Use MixologyUtils helper method which checks against item IDs directly
        return MixologyUtils.isUnprocessedPotion(item.getID());
    }
    
    /**
     * Checks if an item ID is that of a processed potion
     * 
     * @param itemId The item ID to check
     * @return true if it's a processed potion, false otherwise
     */
    public static boolean isProcessedPotion(int itemId) {
        for (int potionId : MixologyConstants.PROCESSED_POTION_IDS) {
            if (itemId == potionId) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Finds a potion in the inventory and identifies its order index and processing method
     * Uses multiple identification methods in order of reliability
     * 
     * @return A map containing information about the identified potion
     *         - orderIndex: The index of the order this potion belongs to
     *         - processingMethod: The character representing the processing method
     *         - potionName: The name of the potion
     *         - inventorySlot: The inventory slot of the potion
     *         - itemId: The item ID of the potion
     */
    public static Map<String, Object> identifyPotion() {
        Map<String, Object> result = new HashMap<>();
        result.put("orderIndex", -1);
        result.put("processingMethod", null);
        
        // Check if we're in the Mixology area
        if (!MixologyConstants.MIXOLOGY_AREA.contains(Players.getLocal())) {
            return result;
        }
        
        // Find the unprocessed potion in inventory with direct item ID check (most reliable)
        Item potionItem = Inventory.get(item -> MixologyUtils.isUnprocessedPotion(item.getID()));
        
        if (potionItem == null) {
            Logger.log("No unprocessed potion found using direct ID check");
            // Try fallback method with name
            potionItem = Inventory.get(item -> isUnprocessedPotion(item.getName()));
            
            if (potionItem == null) {
                Logger.log("No unprocessed potion found");
                return result;
            }
        }
        
        // Extract the potion name and track important data
        String potionName = potionItem.getName();
        String lowerPotionName = potionName.toLowerCase();
        int inventorySlot = potionItem.getSlot();
        int itemId = potionItem.getID();
        
        Logger.log("Found unprocessed potion: " + potionName + " (ID: " + itemId + ") in slot " + inventorySlot);
        
        // Store the basic data
        result.put("potionName", potionName);
        result.put("inventorySlot", inventorySlot);
        result.put("itemId", itemId);
        
        // FIRST PRIORITY: Use inventory slot mapping (most reliable)
        int orderIndex = HerbGlobalState.findOrderIndexByInventorySlot(inventorySlot);
        
        if (orderIndex >= 0 && HerbGlobalState.isPotionCreated(orderIndex) && !HerbGlobalState.isPotionProcessed(orderIndex)) {
            Logger.log("DIRECT MATCH: Found potion order at index " + orderIndex + " using inventory slot " + inventorySlot);
            result.put("orderIndex", orderIndex);
            
            // Retrieve processing method if available
            Character processingMethod = HerbGlobalState.getPotionProcessingMethod(orderIndex);
            if (processingMethod != null) {
                Logger.log("Using stored processing method from global state: " + processingMethod);
                result.put("processingMethod", processingMethod);
                return result;
            }
        }
        
        // SECOND PRIORITY: Try to extract order position from the potion name
        int orderPosition = extractOrderPosition(potionName);
        if (orderPosition > 0) {
            // Convert 1-based position to 0-based index
            int positionBasedIndex = orderPosition - 1;
            
            // If we have a valid order index by position, use it
            if (positionBasedIndex >= 0 && 
                positionBasedIndex < HerbGlobalState.getCurrentOrders().size() && 
                !HerbGlobalState.isPotionProcessed(positionBasedIndex)) {
                
                // Update order index if we got a valid one
                orderIndex = positionBasedIndex;
                Logger.log("Updated order index to " + orderIndex + " based on position " + orderPosition);
                result.put("orderIndex", orderIndex);
                
                // Try to get processing method using order position
                Character processingMethod = getProcessingMethodForOrderPosition(orderPosition);
                if (processingMethod != null) {
                    Logger.log("Determined processing method by order position: " + processingMethod);
                    result.put("processingMethod", processingMethod);
                    return result;
                }
            }
        }
        
        // THIRD PRIORITY: If we couldn't get order position, use the item ID
        if (orderIndex < 0) {
            orderIndex = HerbGlobalState.findOrderIndexByItemId(itemId);
            if (orderIndex >= 0 && !HerbGlobalState.isPotionProcessed(orderIndex)) {
                Logger.log("Found order at index " + orderIndex + " using item ID " + itemId);
                result.put("orderIndex", orderIndex);
            }
        }
        
        // FOURTH PRIORITY: If we still don't have an order index, try text matching
        if (orderIndex < 0) {
            orderIndex = findOrderIndexByName(potionName);
            if (orderIndex >= 0) {
                Logger.log("Found order at index " + orderIndex + " using name matching");
                result.put("orderIndex", orderIndex);
            }
        }
        
        // If we have a valid order index now, try to determine processing method
        if (orderIndex >= 0) {
            // First check if we already have a processing method stored
            Character processingMethod = HerbGlobalState.getPotionProcessingMethod(orderIndex);
            
            if (processingMethod != null) {
                Logger.log("Using stored processing method from global state for order " + 
                          (orderIndex + 1) + ": " + processingMethod);
                result.put("processingMethod", processingMethod);
                return result;
            }
            
            // Try widget-based detection
            processingMethod = getProcessingMethodFromWidget(potionName);
            if (processingMethod != null) {
                Logger.log("Determined processing method from widget: " + processingMethod);
                result.put("processingMethod", processingMethod);
                return result;
            }
            
            // Last resort - direct keyword matching
            processingMethod = getProcessingMethodFromStaticMap(potionName);
            if (processingMethod != null) {
                Logger.log("Determined processing method from static mapping: " + processingMethod);
                result.put("processingMethod", processingMethod);
                return result;
            }
        }
        
        // If we still don't have a processing method, try direct matching
        if (result.get("processingMethod") == null) {
            // Map of keywords to processing methods
            Map<String, Character> methodMap = new HashMap<>();
            methodMap.put("alco", 'C');
            methodMap.put("mammoth", 'H');
            methodMap.put("liplack", 'C');
            methodMap.put("mystic", 'C');
            methodMap.put("marley", 'H');
            methodMap.put("azure", 'Y');
            methodMap.put("aqualux", 'C');
            methodMap.put("megalite", 'H');
            methodMap.put("anti-leech", 'Y');
            methodMap.put("mixalot", 'C');
            
            // Check each keyword
            for (Map.Entry<String, Character> entry : methodMap.entrySet()) {
                if (lowerPotionName.contains(entry.getKey())) {
                    Character processingMethod = entry.getValue();
                    Logger.log("DIRECT KEYWORD MATCH: Determined processing method for " + 
                              potionName + " is " + processingMethod);
                    
                    result.put("processingMethod", processingMethod);
                    return result;
                }
            }
        }
        
        return result;
    }
    
    /**
     * Extracts the order position from a potion name
     * 
     * @param potionName The potion name that might contain an order position
     * @return The order position (1-based) or -1 if not found
     */
    public static int extractOrderPosition(String potionName) {
        int orderPosition = -1;
        if (potionName != null && potionName.contains(" (order:")) {
            try {
                int startPos = potionName.indexOf(" (order:") + 8;
                int endPos = potionName.indexOf(")", startPos);
                if (endPos > startPos) {
                    String posStr = potionName.substring(startPos, endPos);
                    orderPosition = Integer.parseInt(posStr);
                    Logger.log("Extracted order position " + orderPosition + " from potion name: " + potionName);
                }
            } catch (Exception e) {
                Logger.log("Error extracting order position: " + e.getMessage());
            }
        }
        return orderPosition;
    }
    
    /**
     * Finds the order index for a potion by its name
     * 
     * @param potionName The name of the potion to find
     * @return The order index or -1 if not found
     */
    public static int findOrderIndexByName(String potionName) {
        if (potionName == null || potionName.isEmpty()) {
            return -1;
        }
        
        String lowerPotionName = potionName.toLowerCase();
        
        // Strip position markers if present
        if (lowerPotionName.contains(" (order:")) {
            int posMarker = lowerPotionName.indexOf(" (order:");
            lowerPotionName = lowerPotionName.substring(0, posMarker);
        }
        
        // Check each order for a match
        for (int i = 0; i < HerbGlobalState.getCurrentOrders().size(); i++) {
            String order = HerbGlobalState.getCurrentOrders().get(i);
            
            // Convert order to lowercase for case-insensitive comparison
            String lowerOrder = order.toLowerCase();
            
            // Check if this order contains the potion name
            if (lowerOrder.contains(lowerPotionName) || lowerPotionName.contains(lowerOrder)) {
                if (HerbGlobalState.isPotionCreated(i) && !HerbGlobalState.isPotionProcessed(i)) {
                    return i;
                }
            }
        }
        
        return -1;
    }
    
    /**
     * Gets the processing method for a specific order position using widget information
     * 
     * @param orderPosition The 1-based order position (1, 2, or 3)
     * @return The processing method character ('C', 'H', 'Y') or null if not found
     */
    public static Character getProcessingMethodForOrderPosition(int orderPosition) {
        // Direct widget path mapping based on order position
        int childId;
        switch (orderPosition) {
            case 1: 
                childId = 1; // For first order
                break;
            case 2: 
                childId = 3; // For second order
                break;
            case 3: 
                childId = 5; // For third order
                break;
            default:
                return null;
        }
        
        // Get the texture ID from the widget
        @Nullable WidgetChild orderWidget = Widgets.get(882, 2);
        if (orderWidget == null) return null;
        
        WidgetChild processingChild = orderWidget.getChild(childId);
        if (processingChild == null) return null;
        
        int textureId = processingChild.getTextureId();
        
        // Map texture ID to processing method
        switch (textureId) {
            case 5672: 
                return 'C'; // Concentrate (Retort)
            case 5673: 
                return 'Y'; // Crystallize (Alembic)
            case 5674: 
                return 'H'; // Homogenize (Agitator)
            default:
                return null;
        }
    }
    
    /**
     * Gets the processing method from the widget directly based on order position
     * This is the most reliable way to determine processing methods
     *
     * @param orderPosition The order position (1-based)
     * @return The character representing the processing method, or null if not found
     */
    public static Character getProcessingMethodByOrderPosition(int orderPosition) {
        // Only process valid order positions
        if (orderPosition < 1 || orderPosition > 3) {
            Logger.log("Invalid order position: " + orderPosition);
            return null;
        }
        
        // Get the main widget for orders
        Widget orderWidget = Widgets.getWidget(ORDER_WIDGET_ID);
        if (orderWidget == null) {
            Logger.log("Order widget not found");
            return null;
        }
        
        // Get the container child that holds the order entries
        WidgetChild orderContainer = orderWidget.getChild(ORDER_WIDGET_CHILD_ID);
        if (orderContainer == null) {
            Logger.log("Order container not found");
            return null;
        }
        
        // Get the children to check widget indices
        WidgetChild[] children = orderContainer.getChildren();
        if (children == null || children.length < 7) {
            Logger.log("Not enough order widgets found");
            return null;
        }
        
        // Map order position to widget indices - FIXED MAPPING
        // Order 1 -> index 1 (processing method)
        // Order 2 -> index 3 (processing method)
        // Order 3 -> index 5 (processing method)
        int processingMethodIndex;
        switch (orderPosition) {
            case 1:
                processingMethodIndex = 1;
                break;
            case 2:
                processingMethodIndex = 3;
                break;
            case 3:
                processingMethodIndex = 5;
                break;
            default:
                return null;
        }
        
        // Get the widget at the processing method index
        WidgetChild processingWidget = children[processingMethodIndex];
        if (processingWidget == null) {
            Logger.log("Processing widget not found at index " + processingMethodIndex);
            return null;
        }
        
        // Get the texture ID to determine processing method
        int textureId = processingWidget.getTextureId();
        
        // Log what we found
        Logger.log("Order position " + orderPosition + " -> Widget index " + processingMethodIndex + 
                  " has texture ID " + textureId);
        
        // Convert texture ID to processing method
        Character method = getProcessingMethodFromTextureId(textureId);
        
        if (method != null) {
            Logger.log("Order " + orderPosition + " requires processing method: " + method);
        } else {
            Logger.log("Failed to determine processing method for order " + orderPosition + " from texture ID " + textureId);
        }
        
        return method;
    }
    
    /**
     * Gets the processing method required for a given order
     * 
     * @param potionName The potion name to find in the orders
     * @return 'C' for Concentrate, 'H' for Homogenize, 'Y' for Crystallize, or null if not found
     */
    public static Character getProcessingMethodFromWidget(String potionName) {
        // Get the main widget for orders
        Widget orderWidget = Widgets.getWidget(ORDER_WIDGET_ID);
        if (orderWidget == null) {
            Logger.log("Order widget not found");
            return null;
        }
        
        // Get the container child that holds the order entries
        WidgetChild orderContainer = orderWidget.getChild(ORDER_WIDGET_CHILD_ID);
        if (orderContainer == null) {
            Logger.log("Order container not found");
            return null;
        }
        
        // Find the widget child for this potion
        WidgetChild[] children = orderContainer.getChildren();
        if (children == null) {
            Logger.log("Order children not found");
            return null;
        }
        
        Logger.log("Processing: Found " + children.length + " widget children to check for " + potionName);
        
        // Extract order position from the potion name for direct mapping
        int orderPosition = extractOrderPosition(potionName);
        
        // If we have a valid order position, use it for direct widget mapping
        if (orderPosition > 0 && orderPosition <= 3) {
            // CRITICAL FIX: Direct mapping between order position and widget indices
            // Order 1 -> widget indices [2,1] (potion at 2, processing method at 1)
            // Order 2 -> widget indices [4,3] (potion at 4, processing method at 3)
            // Order 3 -> widget indices [6,5] (potion at 6, processing method at 5)
            int processingMethodIndex;
            int potionTextIndex;
            
            switch (orderPosition) {
                case 1:
                    potionTextIndex = 2;
                    processingMethodIndex = 1;
                    break;
                case 2:
                    potionTextIndex = 4;
                    processingMethodIndex = 3;
                    break;
                case 3:
                    potionTextIndex = 6;
                    processingMethodIndex = 5;
                    break;
                default:
                    return null;
            }
            
            if (children.length > potionTextIndex && children[potionTextIndex] != null &&
                children.length > processingMethodIndex && children[processingMethodIndex] != null) {
                // Verify the text matches what we expect
                if (children[potionTextIndex].getText() != null) {
                    // Get the processing method texture ID
                    int textureId = children[processingMethodIndex].getTextureId();
                    Logger.log("Order " + orderPosition + " maps to widget indices [" + potionTextIndex + "," + 
                               processingMethodIndex + "], processing method texture: " + textureId);
                    
                    Character method = getProcessingMethodFromTextureId(textureId);
                    if (method != null) {
                        Logger.log("Using direct widget mapping for order " + orderPosition + 
                                  ": " + method + " (texture ID: " + textureId + ")");
                        return method;
                    }
                }
            }
        }
        
        // Convert potionName to lowercase for case-insensitive comparison
        String lowerPotionName = potionName.toLowerCase();
        
        // Strip position markers if present
        if (lowerPotionName.contains(" (order:")) {
            int posMarker = lowerPotionName.indexOf(" (order:");
            lowerPotionName = lowerPotionName.substring(0, posMarker);
            Logger.log("Stripped position marker from potion name for comparison: " + lowerPotionName);
        }
        
        // As a fallback, check each of the potion widgets (indices 2, 4, 6) and their corresponding 
        // processing method widgets (indices 1, 3, 5) to find a match by name
        if (children.length >= 7) {
            Logger.log("Falling back to name-based widget search for: " + lowerPotionName);
            
            // Check the first potion-processing pair (Order 1)
            if (children[2] != null && children[2].getText() != null && 
                !children[2].getText().isEmpty() &&
                children[2].getText().toLowerCase().contains(lowerPotionName) && 
                children[1] != null) {
                
                int textureId = children[1].getTextureId();
                Logger.log("Found matching potion at index 2, processing method texture: " + textureId + 
                          " - this is Order 1");
                
                // Store the order position for future reference
                if (orderPosition == -1) {
                    orderPosition = 1;
                    Logger.log("Determined this is order position 1 based on widget index");
                }
                
                return getProcessingMethodFromTextureId(textureId);
            }
            
            // Check the second potion-processing pair (Order 2)
            if (children[4] != null && children[4].getText() != null && 
                !children[4].getText().isEmpty() &&
                children[4].getText().toLowerCase().contains(lowerPotionName) && 
                children[3] != null) {
                
                int textureId = children[3].getTextureId();
                Logger.log("Found matching potion at index 4, processing method texture: " + textureId + 
                          " - this is Order 2");
                
                // Store the order position for future reference
                if (orderPosition == -1) {
                    orderPosition = 2;
                    Logger.log("Determined this is order position 2 based on widget index");
                }
                
                return getProcessingMethodFromTextureId(textureId);
            }
            
            // Check the third potion-processing pair (Order 3)
            if (children[6] != null && children[6].getText() != null && 
                !children[6].getText().isEmpty() &&
                children[6].getText().toLowerCase().contains(lowerPotionName) && 
                children[5] != null) {
                
                int textureId = children[5].getTextureId();
                Logger.log("Found matching potion at index 6, processing method texture: " + textureId + 
                          " - this is Order 3");
                
                // Store the order position for future reference
                if (orderPosition == -1) {
                    orderPosition = 3;
                    Logger.log("Determined this is order position 3 based on widget index");
                }
                
                return getProcessingMethodFromTextureId(textureId);
            }
        }
        
        // Fallback to static mapping
        Logger.log("Falling back to static mapping for potion: " + potionName);
        return getProcessingMethodFromStaticMap(potionName);
    }
    
    /**
     * Determines the processing method based on the texture ID
     * 
     * @param textureId The texture ID from the widget
     * @return Processing method character
     */
    public static Character getProcessingMethodFromTextureId(int textureId) {
        if (textureId == CRYSTALLIZE_TEXTURE_ID) {
            return 'Y'; // Crystallize
        } else if (textureId == CONCENTRATE_TEXTURE_ID) {
            return 'C'; // Concentrate 
        } else if (textureId == HOMOGENIZE_TEXTURE_ID) {
            return 'H'; // Homogenize
        }
        return null;
    }
    
    /**
     * Gets the processing method from the static map in MixologyConstants
     * 
     * @param potionName The potion name
     * @return Processing method character or null
     */
    public static Character getProcessingMethodFromStaticMap(String potionName) {
        if (potionName == null || potionName.isEmpty()) {
            return null;
        }
        
        String lowerPotionName = potionName.toLowerCase();
        
        // Define direct mapping for processing methods
        Map<String, Character> processingMethodMap = new HashMap<>();
        processingMethodMap.put("alco", MixologyConstants.ALCO_AUGMENTATOR_PROCESS);
        processingMethodMap.put("mammoth", MixologyConstants.MAMMOTH_MIGHT_PROCESS);
        processingMethodMap.put("liplack", MixologyConstants.LIPLACK_LIQUOR_PROCESS);
        processingMethodMap.put("mystic", MixologyConstants.MYSTIC_MANA_PROCESS);
        processingMethodMap.put("marley", MixologyConstants.MARLEYS_MOONLIGHT_PROCESS);
        processingMethodMap.put("azure", MixologyConstants.AZURE_AURA_PROCESS);
        processingMethodMap.put("aqualux", MixologyConstants.AQUALUX_PROCESS);
        processingMethodMap.put("megalite", MixologyConstants.MEGALITE_PROCESS);
        processingMethodMap.put("anti-leech", MixologyConstants.ANTI_LEECH_PROCESS);
        processingMethodMap.put("mixalot", MixologyConstants.MIXALOT_PROCESS);
        
        for (Map.Entry<String, Character> entry : processingMethodMap.entrySet()) {
            if (lowerPotionName.contains(entry.getKey())) {
                return entry.getValue();
            }
        }
        
        return null;
    }

    // Direct mapping of order position (1,2,3) to inventory slot (0,1,2)
    public static int getInventorySlotForOrderPosition(int orderPosition) {
        return orderPosition - 1; // Simple 1:1 mapping with zero-based adjustment
    }
} 