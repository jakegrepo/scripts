package scripts.Herb.utils;

import org.dreambot.api.methods.map.Area;

import java.util.HashMap;
import java.util.Map;

/**
 * Constants for Mastering Mixology minigame
 */
public class MixologyConstants {
    // Areas
    public static final Area MIXOLOGY_AREA = new Area(1384, 9335, 1402, 9306); // Main Mixology area
    public static final Area REFINER_AREA = new Area(1381, 9321, 1403, 9305); // Refiner area
    public static final Area MIXING_AREA = new Area(1385, 9335, 1403, 9319); // Mixing area
    public static final Area STORAGE_AREA = new Area(1387, 9325, 1402, 9317); // Storage area
    public static final Area PROCESSING_AREA = new Area(1384, 9336, 1403, 9319); // Same as mixing area
    public static final Area CONVEYOR_AREA = new Area(1384, 9325, 1402, 9317); // Same as storage area
    public static final Area BANK_AREA = new Area(3765, 3850, 3770, 3845); // Bank area outside Mixology
    public static final int LYE_POINTS_CONFIG = 4414;
    public static final int AGA_POINTS_CONFIG = 4415;
    public static final int MOX_POINTS_CONFIG = 4416;
    public static final int BARREL_COST_MOX = 17250;
    public static final int BARREL_COST_LYE = 18600;
    public static final int BARREL_COST_AGA = 14000; // Replace with actual ID
// Replace with actual ID
// Replace with actual ID

    // Object IDs
    public static final int REFINER_ID = 51365; // Replace with actual ID
    public static final int HOPPER_ID = 51366; // Replace with actual ID
    public static final int MOX_LEVER_ID = 51367; // Replace with actual ID
    public static final int LYE_LEVER_ID = 51368; // Replace with actual ID
    public static final int AGA_LEVER_ID = 54867; // Replace with actual ID
    public static final int MIXING_VESSEL_ID = 51370; // Replace with actual ID
    public static final int RETORT_ID = 55389; // Replace with actual ID
    public static final int AGITATOR_ID = 55390; // Replace with actual ID
    public static final int ALEMBIC_ID = 55391; // Replace with actual ID
    public static final int CONVEYOR_BELT_ID = 54917; // Replace with actual ID
    public static final int DIGWEED_ID = 51375; // Replace with actual ID

    // Potion recipes - M=Mox, L=Lye, A=Aga
    public static final String ALCO_AUGMENTATOR_RECIPE = "AAA";
    public static final String MAMMOTH_MIGHT_RECIPE = "MMM";
    public static final String LIPLACK_LIQUOR_RECIPE = "LLL";
    public static final String MYSTIC_MANA_RECIPE = "MMA";
    public static final String MARLEYS_MOONLIGHT_RECIPE = "MML";
    public static final String AZURE_AURA_RECIPE = "AAM";
    public static final String AQUALUX_RECIPE = "ALA";
    public static final String MEGALITE_RECIPE = "MLL";
    public static final String ANTI_LEECH_RECIPE = "ALL";
    public static final String MIXALOT_RECIPE = "MAL";

    // Animation IDs
    public static final int RETORT_BUSY_ANIMATION_ID = 11643;
    public static final int ALEMBIC_BUSY_ANIMATION_ID = 11638;
    public static final int AGITATOR_BUSY_ANIMATION_ID = 11633;



    // Processing methods - C=Concentrate, H=Homogenise, Y=Crystallise
    public static final char ALCO_AUGMENTATOR_PROCESS = 'C';
    public static final char MAMMOTH_MIGHT_PROCESS = 'H';
    public static final char LIPLACK_LIQUOR_PROCESS = 'C';
    public static final char MYSTIC_MANA_PROCESS = 'C';
    public static final char MARLEYS_MOONLIGHT_PROCESS = 'H';
    public static final char AZURE_AURA_PROCESS = 'Y';
    public static final char AQUALUX_PROCESS = 'C';
    public static final char MEGALITE_PROCESS = 'H';
    public static final char ANTI_LEECH_PROCESS = 'Y';
    public static final char MIXALOT_PROCESS = 'C';

    // Map for potion processing methods
    public static final Map<String, Character> PROCESSING_METHODS = new HashMap<>();
    static {
        PROCESSING_METHODS.put("alco-augmentator", ALCO_AUGMENTATOR_PROCESS);
        PROCESSING_METHODS.put("mammoth-might mix", MAMMOTH_MIGHT_PROCESS);
        PROCESSING_METHODS.put("liplack liquor", LIPLACK_LIQUOR_PROCESS);
        PROCESSING_METHODS.put("mystic mana amalgam", MYSTIC_MANA_PROCESS);
        PROCESSING_METHODS.put("marley's moonlight", MARLEYS_MOONLIGHT_PROCESS);
        PROCESSING_METHODS.put("azure aura mix", AZURE_AURA_PROCESS);
        PROCESSING_METHODS.put("aqualux amalgam", AQUALUX_PROCESS);
        PROCESSING_METHODS.put("megalite liquid", MEGALITE_PROCESS);
        PROCESSING_METHODS.put("anti-leech lotion", ANTI_LEECH_PROCESS);
        PROCESSING_METHODS.put("mixalot", MIXALOT_PROCESS);
    }
    public static final int[] PROCESSED_POTION_IDS = {
            MixologyConstants.ALCO_AUGMENTATOR_ID,
            MixologyConstants.MAMMOTH_MIGHT_ID,
            MixologyConstants.LIPLACK_LIQUOR_ID,
            MixologyConstants.MYSTIC_MANA_ID,
            MixologyConstants.MARLEYS_MOONLIGHT_ID,
            MixologyConstants.AZURE_AURA_ID,
            MixologyConstants.AQUALUX_ID,
            MixologyConstants.MEGALITE_ID,
            MixologyConstants.ANTI_LEECH_ID,
            MixologyConstants.MIXALOT_ID
    };

    // Name to ID mapping for identifying completed potions
    public static final Map<String, Integer> POTION_NAME_TO_ID = new HashMap<>();
    static {
        POTION_NAME_TO_ID.put("alco-augmentator", MixologyConstants.ALCO_AUGMENTATOR_ID);
        POTION_NAME_TO_ID.put("mammoth-might mix", MixologyConstants.MAMMOTH_MIGHT_ID);
        POTION_NAME_TO_ID.put("liplack liquor", MixologyConstants.LIPLACK_LIQUOR_ID);
        POTION_NAME_TO_ID.put("mystic mana amalgam", MixologyConstants.MYSTIC_MANA_ID);
        POTION_NAME_TO_ID.put("marley's moonlight", MixologyConstants.MARLEYS_MOONLIGHT_ID);
        POTION_NAME_TO_ID.put("azure aura mix", MixologyConstants.AZURE_AURA_ID);
        POTION_NAME_TO_ID.put("aqualux amalgam", MixologyConstants.AQUALUX_ID);
        POTION_NAME_TO_ID.put("megalite liquid", MixologyConstants.MEGALITE_ID);
        POTION_NAME_TO_ID.put("anti-leech lotion", MixologyConstants.ANTI_LEECH_ID);
        POTION_NAME_TO_ID.put("mixalot", MixologyConstants.MIXALOT_ID);
    }
    // Herb paste yields
    public static final int GUAM_MOX_YIELD = 10;
    public static final int MARRENTILL_MOX_YIELD = 13;
    public static final int TARROMIN_MOX_YIELD = 15;
    public static final int HARRALANDER_MOX_YIELD = 20;
    public static final int RANARR_LYE_YIELD = 26;
    public static final int TOADFLAX_LYE_YIELD = 32;
    public static final int IRIT_AGA_YIELD = 30;
    public static final int AVANTOE_LYE_YIELD = 30;
    public static final int KWUARM_LYE_YIELD = 33;
    public static final int HUASCA_AGA_YIELD = 20;
    public static final int SNAPDRAGON_LYE_YIELD = 40;
    public static final int CADANTINE_AGA_YIELD = 34;
    public static final int LANTADYME_AGA_YIELD = 40;
    public static final int DWARF_WEED_AGA_YIELD = 42;
    public static final int TORSTOL_AGA_YIELD = 44;

    // Map of herb names to paste yields
    public static final Map<String, Integer> HERB_PASTE_YIELDS = new HashMap<>();
    static {
        HERB_PASTE_YIELDS.put("Guam leaf", GUAM_MOX_YIELD);
        HERB_PASTE_YIELDS.put("Marrentill", MARRENTILL_MOX_YIELD);
        HERB_PASTE_YIELDS.put("Tarromin", TARROMIN_MOX_YIELD);
        HERB_PASTE_YIELDS.put("Harralander", HARRALANDER_MOX_YIELD);
        HERB_PASTE_YIELDS.put("Ranarr weed", RANARR_LYE_YIELD);
        HERB_PASTE_YIELDS.put("Toadflax", TOADFLAX_LYE_YIELD);
        HERB_PASTE_YIELDS.put("Irit leaf", IRIT_AGA_YIELD);
        HERB_PASTE_YIELDS.put("Avantoe", AVANTOE_LYE_YIELD);
        HERB_PASTE_YIELDS.put("Kwuarm", KWUARM_LYE_YIELD);
        HERB_PASTE_YIELDS.put("Huasca", HUASCA_AGA_YIELD);
        HERB_PASTE_YIELDS.put("Snapdragon", SNAPDRAGON_LYE_YIELD);
        HERB_PASTE_YIELDS.put("Cadantine", CADANTINE_AGA_YIELD);
        HERB_PASTE_YIELDS.put("Lantadyme", LANTADYME_AGA_YIELD);
        HERB_PASTE_YIELDS.put("Dwarf weed", DWARF_WEED_AGA_YIELD);
        HERB_PASTE_YIELDS.put("Torstol", TORSTOL_AGA_YIELD);
    }

    // Map of herb names to paste types
    public static final Map<String, String> HERB_PASTE_TYPES = new HashMap<>();
    static {
        HERB_PASTE_TYPES.put("Guam leaf", "Mox");
        HERB_PASTE_TYPES.put("Marrentill", "Mox");
        HERB_PASTE_TYPES.put("Tarromin", "Mox");
        HERB_PASTE_TYPES.put("Harralander", "Mox");
        HERB_PASTE_TYPES.put("Ranarr weed", "Lye");
        HERB_PASTE_TYPES.put("Toadflax", "Lye");
        HERB_PASTE_TYPES.put("Irit leaf", "Aga");
        HERB_PASTE_TYPES.put("Avantoe", "Lye");
        HERB_PASTE_TYPES.put("Kwuarm", "Lye");
        HERB_PASTE_TYPES.put("Huasca", "Aga");
        HERB_PASTE_TYPES.put("Snapdragon", "Lye");
        HERB_PASTE_TYPES.put("Cadantine", "Aga");
        HERB_PASTE_TYPES.put("Lantadyme", "Aga");
        HERB_PASTE_TYPES.put("Dwarf weed", "Aga");
        HERB_PASTE_TYPES.put("Torstol", "Aga");
    }

    // Level requirements
    public static final int ALCO_AUGMENTATOR_LEVEL = 60;
    public static final int MAMMOTH_MIGHT_LEVEL = 60;
    public static final int LIPLACK_LIQUOR_LEVEL = 60;
    public static final int MYSTIC_MANA_LEVEL = 63;
    public static final int MARLEYS_MOONLIGHT_LEVEL = 66;
    public static final int AZURE_AURA_LEVEL = 69;
    public static final int AQUALUX_LEVEL = 72;
    public static final int MEGALITE_LEVEL = 75;
    public static final int ANTI_LEECH_LEVEL = 78;
    public static final int MIXALOT_LEVEL = 81;

    // Fairy ring code for Aldarin
    public static final String FAIRY_RING_CODE = "CKQ";

    // Paste storage varbits
    public static final int MOX_PASTE_VARBIT = 11431;
    public static final int AGA_PASTE_VARBIT = 11432;
    public static final int LYE_PASTE_VARBIT = 11433;
    public static final int MAX_PASTE_STORAGE = 3000;

    // Unprocessed potion IDs
    public static final int UNPROCESSED_ALCO_AUGMENTATOR_ID = 30014;
    public static final int UNPROCESSED_MAMMOTH_MIGHT_ID = 30011;
    public static final int UNPROCESSED_LIPLACK_LIQUOR_ID = 30017;
    public static final int UNPROCESSED_MYSTIC_MANA_ID = 30012;
    public static final int UNPROCESSED_MARLEYS_MOONLIGHT_ID = 30013;
    public static final int UNPROCESSED_AZURE_AURA_ID = 30016;
    public static final int UNPROCESSED_AQUALUX_ID = 30015;
    public static final int UNPROCESSED_MEGALITE_ID = 30018;
    public static final int UNPROCESSED_ANTI_LEECH_ID = 30019;
    public static final int UNPROCESSED_MIXALOT_ID = 30020;

    // Array of all unprocessed potion IDs for easier checking
    public static final int[] UNPROCESSED_POTION_IDS = {
        UNPROCESSED_ALCO_AUGMENTATOR_ID,
        UNPROCESSED_MAMMOTH_MIGHT_ID,
        UNPROCESSED_LIPLACK_LIQUOR_ID,
        UNPROCESSED_MYSTIC_MANA_ID,
        UNPROCESSED_MARLEYS_MOONLIGHT_ID,
        UNPROCESSED_AZURE_AURA_ID,
        UNPROCESSED_AQUALUX_ID,
        UNPROCESSED_MEGALITE_ID,
        UNPROCESSED_ANTI_LEECH_ID,
        UNPROCESSED_MIXALOT_ID
    };

    // Processed potion IDs
    public static final int ALCO_AUGMENTATOR_ID = 30024;
    public static final int MAMMOTH_MIGHT_ID = 30021;
    public static final int LIPLACK_LIQUOR_ID = 30027;
    public static final int MYSTIC_MANA_ID = 30022;
    public static final int MARLEYS_MOONLIGHT_ID = 30023;
    public static final int AZURE_AURA_ID = 30026;
    public static final int AQUALUX_ID = 30025;
    public static final int MEGALITE_ID = 30029;
    public static final int ANTI_LEECH_ID = 30028;
    public static final int MIXALOT_ID = 30030;
}
