package scripts.Herb.utils;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.dreambot.api.Client;
import org.dreambot.api.utilities.Logger;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Utility class for handling safe serialization with GSON.
 * Prevents serialization errors for Thread and UI objects.
 */
public class ConfigUtil {

    /**
     * Get a GSON instance with exclusion strategy for Thread and UI classes
     * @return A configured GSON instance
     */
    public static Gson getSafeGson() {
        return new GsonBuilder()
            .setPrettyPrinting()
            .disableJdkUnsafe() // Prevent access to inaccessible fields
            .excludeFieldsWithoutExposeAnnotation() // Only serialize fields with @Expose annotation
            .create();
    }

    /**
     * Safely save an object to file using our own file saving mechanism
     * @param object The object to save
     * @param paths The paths to save to (relative to DreamBot Scripts directory)
     */
    public static void safeSave(Object object, String... paths) {
        try {
            // Use the first path as the base directory and the rest as file parts
            if (paths.length == 0) {
                Logger.error("No paths provided for safeSave");
                return;
            }

            String baseDir = paths[0];
            String[] fileParts = new String[paths.length - 1];
            System.arraycopy(paths, 1, fileParts, 0, paths.length - 1);

            // Get the full path using our createPath method
            String fullPath = createPath(baseDir, fileParts);
            Path filePath = Paths.get(fullPath);

            // Create parent directories if they don't exist
            Files.createDirectories(filePath.getParent());

            // Convert object to JSON
            String json = getSafeGson().toJson(object);

            // Save to file
            Logger.info("Saving script settings to file " + filePath);
            try (FileWriter writer = new FileWriter(filePath.toFile())) {
                writer.write(json);
            }
        } catch (IOException e) {
            Logger.error("Failed writing script settings to file");
            e.printStackTrace();
        }
    }

    /**
     * Safely load and deserialize a JSON configuration file
     * @param classOfT The class type to deserialize to
     * @param baseDir The base directory
     * @param fileParts Parts of the file path
     * @param <T> The type of class to deserialize to
     * @return The deserialized object, or null if there was an error
     */
    public static <T> T safeLoad(Class<T> classOfT, String baseDir, String... fileParts) {
        try {
            String path = createPath(baseDir, fileParts);
            File file = new File(path);

            if (!file.exists()) {
                Logger.error("Config file not found: " + path);
                Logger.error("Absolute path: " + file.getAbsolutePath());
                Logger.error("Directory exists: " + file.getParentFile().exists());
                if (file.getParentFile().exists()) {
                    Logger.info("Files in directory: ");
                    File[] files = file.getParentFile().listFiles();
                    if (files != null) {
                        for (File f : files) {
                            Logger.info("  - " + f.getName());
                        }
                    } else {
                        Logger.info("  No files found");
                    }
                }
                return null;
            }

            Logger.info("Loading config from file: " + path);
            String json = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);

            // Special handling for MixologyConfig to avoid constructor issues
            if (classOfT.getName().contains("MixologyConfig") ||
                (classOfT.getName().contains("ConfigData") && json.contains("mixologyConfig"))) {
                Logger.info("Detected MixologyConfig, using custom deserialization");
                // Use a custom deserialization approach
                return loadWithCustomDeserializer(classOfT, json);
            }

            return getSafeGson().fromJson(json, classOfT);
        } catch (Exception e) {
            Logger.error("Error loading configuration: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Custom deserialization for classes that may contain MixologyConfig
     * @param classOfT The class type to deserialize to
     * @param json The JSON string
     * @param <T> The type of class to deserialize to
     * @return The deserialized object
     */
    private static <T> T loadWithCustomDeserializer(Class<T> classOfT, String json) {
        try {
            // Create a custom Gson instance with a type adapter factory for MixologyConfig
            Gson customGson = new GsonBuilder()
                .setPrettyPrinting()
                .excludeFieldsWithoutExposeAnnotation()
                .registerTypeAdapter(scripts.Herb.config.MixologyConfig.class,
                    new com.google.gson.JsonDeserializer<scripts.Herb.config.MixologyConfig>() {
                        @Override
                        public scripts.Herb.config.MixologyConfig deserialize(
                                com.google.gson.JsonElement json,
                                java.lang.reflect.Type typeOfT,
                                com.google.gson.JsonDeserializationContext context) {
                            // Create a fresh instance without using constructor
                            scripts.Herb.config.MixologyConfig config = new scripts.Herb.config.MixologyConfig();

                            // Manually extract fields we need
                            if (json.isJsonObject()) {
                                com.google.gson.JsonObject obj = json.getAsJsonObject();

                                // Extract fields and set them on the config object
                                try {
                                    if (obj.has("collectDigweed"))
                                        config.setCollectDigweed(obj.get("collectDigweed").getAsBoolean());
                                    if (obj.has("useDigweedOnMixalot"))
                                        config.setUseDigweedOnMixalot(obj.get("useDigweedOnMixalot").getAsBoolean());
                                    if (obj.has("activeRefining"))
                                        config.setActiveRefining(obj.get("activeRefining").getAsBoolean());
                                    if (obj.has("activeProcessing"))
                                        config.setActiveProcessing(obj.get("activeProcessing").getAsBoolean());
                                    if (obj.has("useUnfinishedPotions"))
                                        config.setUseUnfinishedPotions(obj.get("useUnfinishedPotions").getAsBoolean());
                                    if (obj.has("prioritizeOrders"))
                                        config.setPrioritizeOrders(obj.get("prioritizeOrders").getAsBoolean());
                                    if (obj.has("strictProcessingMethods"))
                                        config.setStrictProcessingMethods(obj.get("strictProcessingMethods").getAsBoolean());
                                    if (obj.has("minHerbCount"))
                                        config.setMinHerbCount(obj.get("minHerbCount").getAsInt());
                                    if (obj.has("minResinAmount"))
                                        config.setMinResinAmount(obj.get("minResinAmount").getAsInt());
                                    if (obj.has("transportMethod") && !obj.get("transportMethod").isJsonNull())
                                        config.setTransportMethod(obj.get("transportMethod").getAsString());
                                    if (obj.has("buyAldarium"))
                                        config.setBuyAldarium(obj.get("buyAldarium").getAsBoolean());
                                    if (obj.has("buyBarrel"))
                                        config.setBuyBarrel(obj.get("buyBarrel").getAsBoolean());
                                } catch (Exception e) {
                                    Logger.error("Error deserializing MixologyConfig field: " + e.getMessage());
                                }
                            }

                            return config;
                        }
                    })
                .create();

            return customGson.fromJson(json, classOfT);
        } catch (Exception e) {
            Logger.error("Error in custom deserialization: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    private static String createPath(String baseDir, String... fileParts) {
        // Get the full path in the DreamBot Scripts directory
        String scriptsDir = System.getProperty("user.home") + "/DreamBot/Scripts";

        // Create a Path object starting with the scripts directory
        Path path = Paths.get(scriptsDir, baseDir);

        // Add each file part to the path
        for (String part : fileParts) {
            path = path.resolve(part);
        }

        String fullPath = path.toString();
        Logger.info("Full path for file operation: " + fullPath);
        return fullPath;
    }
}