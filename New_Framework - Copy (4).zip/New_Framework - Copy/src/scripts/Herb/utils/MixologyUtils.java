package scripts.Herb.utils;

import core.node.TaskNode;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.widget.Widget;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.script.ScriptManager;
import org.dreambot.api.wrappers.interactive.Player;
import scripts.Herb.MixologyScript;
import scripts.Herb.gui.MixologyOverlay;

import java.util.HashMap;
import java.util.Map;

public class MixologyUtils {

    // Areas
    public static final Area MIXOLOGY_AREA = new Area(1384, 9335, 1402, 9306);
    public static final Area MIXING_AREA = new Area(1384, 9336, 1403, 9319);
    public static final Area REFINER_AREA = new Area(1381, 9321, 1403, 9305);
    public static final Area STORAGE_AREA = new Area(1387, 9325, 1402, 9317);
    public static final Area ALDARIN = new Area(1358, 2986, 1456, 2891);

    // Object IDs
    public static final int ENTRANCE_PORTAL_ID = 43766;
    public static final int EXIT_PORTAL_ID = 43767;
    public static final int RETORT_ID = 43768;
    public static final int ALEMBIC_ID = 43769;
    public static final int AGITATOR_ID = 43770;
    public static final int GRINDER_ID = 43771;
    public static final int STORAGE_CABINET_ID = 54903;
    public static final int HERB_BOX_ID = 43773;
    public static final int DIGWEED_PLANT_ID = 43774;
    public static final int REFINER_ID = 43775;
    public static final int CONVEYOR_BELT_ID = 43776;

    // NPC IDs
    public static final int MIXOLOGY_MASTER_ID = 14099;

    // Widget IDs
    public static final int MIXOLOGY_INTERFACE_ID = 756;
    public static final int PASTE_AMOUNT_CHILD_ID = 11;
    public static final int STORED_RESIN_CHILD_ID = 12;
    public static final int ACTIVE_POTION_CHILD_ID = 13;
    public static final int CURRENT_ORDER_CHILD_ID = 14;
    public static final int CURRENT_STATUS_CHILD_ID = 15;

    // Paste Types
    public enum PasteType {
        RED(1),
        GREEN(2),
        BLUE(3);

        private final int leverId;

        PasteType(int leverId) {
            this.leverId = leverId;
        }

        public int getLeverId() {
            return leverId;
        }
    }


    // Potion recipes - Map<PotionName, Map<PasteType, Amount>>
    private static final Map<String, Map<PasteType, Integer>> POTION_RECIPES = new HashMap<>();

    static {
        // Initialize potion recipes
        Map<PasteType, Integer> healthPotionRecipe = new HashMap<>();
        healthPotionRecipe.put(PasteType.RED, 3);
        healthPotionRecipe.put(PasteType.GREEN, 1);
        healthPotionRecipe.put(PasteType.BLUE, 0);
        POTION_RECIPES.put("Health Potion", healthPotionRecipe);

        Map<PasteType, Integer> energyPotionRecipe = new HashMap<>();
        energyPotionRecipe.put(PasteType.RED, 1);
        energyPotionRecipe.put(PasteType.GREEN, 3);
        energyPotionRecipe.put(PasteType.BLUE, 0);
        POTION_RECIPES.put("Energy Potion", energyPotionRecipe);

        Map<PasteType, Integer> magicPotionRecipe = new HashMap<>();
        magicPotionRecipe.put(PasteType.RED, 0);
        magicPotionRecipe.put(PasteType.GREEN, 1);
        magicPotionRecipe.put(PasteType.BLUE, 3);
        POTION_RECIPES.put("Magic Potion", magicPotionRecipe);
    }

    /**
     * Checks if the player is in the Mixology minigame area
     * @return true if in Mixology area
     */
    public static boolean isInMixologyArea() {
        Player player = Players.getLocal();
        return player != null && MIXOLOGY_AREA.contains(player);
    }

    /**
     * Checks if the player is in the mixing area
     * @return true if in mixing area
     */
    public static boolean isInMixingArea() {
        Player player = Players.getLocal();
        return player != null && MIXING_AREA.contains(player);
    }

    /**
     * Checks if the player is in the refiner area
     * @return true if in refiner area
     */
    public static boolean isInRefinerArea() {
        Player player = Players.getLocal();
        return player != null && REFINER_AREA.contains(player);
    }

    /**
     * Checks if the player is in the storage area
     * @return true if in storage area
     */
    public static boolean isInStorageArea() {
        Player player = Players.getLocal();
        return player != null && STORAGE_AREA.contains(player);
    }

    /**
     * Gets the recipe for a specific potion
     * @param potionName name of the potion
     * @return Map of paste types and amounts
     */
    public static Map<PasteType, Integer> getPotionRecipe(String potionName) {
        return POTION_RECIPES.getOrDefault(potionName, new HashMap<>());
    }

    /**
     * Gets the current amount of paste for a specific type
     * @param type the paste type
     * @return amount of paste, or 0 if not available
     */
    public static int getCurrentPasteAmount(PasteType type) {
        Widget widget =
                Widgets.getWidget(MIXOLOGY_INTERFACE_ID);
        if (widget != null && widget.isVisible()) {
            String text = widget.toString();
            if (text != null && !text.isEmpty()) {
                try {
                    String[] parts = text.split(",");
                    if (parts.length >= 3) {
                        switch (type) {
                            case RED:
                                return Integer.parseInt(parts[0].trim());
                            case GREEN:
                                return Integer.parseInt(parts[1].trim());
                            case BLUE:
                                return Integer.parseInt(parts[2].trim());
                        }
                    }
                } catch (NumberFormatException e) {
                    return 0;
                }
            }
        }
        return 0;
    }

    /**
     * Gets the amount of stored resin
     * @return stored resin amount, or 0 if not available
     */
    public static int getStoredResinAmount() {
        Widget widget = Widgets.getWidget(MIXOLOGY_INTERFACE_ID);
        if (widget != null && widget.isVisible()) {
            String text = widget.toString();
            if (text != null && !text.isEmpty()) {
                try {
                    return Integer.parseInt(text);
                } catch (NumberFormatException e) {
                    return 0;
                }
            }
        }
        return 0;
    }

    /**
     * Gets the current active potion
     * @return potion name, or empty string if not available
     */
    public static String getActivePotion() {
        Widget widget = Widgets.getWidget(MIXOLOGY_INTERFACE_ID);
        if (widget != null && widget.isVisible()) {
            String text = widget.toString();
            return text != null ? text : "";
        }
        return "";
    }

    /**
     * Gets the current order
     * @return order name, or empty string if not available
     */
    public static String getCurrentOrder() {
        Widget widget = Widgets.getWidget(MIXOLOGY_INTERFACE_ID);
        if (widget != null && widget.isVisible()) {
            String text = widget.toString();
            return text != null ? text : "";
        }
        return "";
    }

    /**
     * Gets the current status
     * @return status text, or empty string if not available
     */
    public static String getCurrentStatus() {
        Widget widget = Widgets.getWidget(MIXOLOGY_INTERFACE_ID);
        if (widget != null && widget.isVisible()) {
            String text = widget.toString();
            return text != null ? text : "";
        }
        return "";
    }

    /**
     * Updates script status in overlay
     * @param status new status
     */
    public static void updateStatus(String status) {
        MixologyScript script = (MixologyScript) ScriptManager.getScriptManager().getCurrentScript();
        if (script != null && script.getOverlay() != null) {
            script.getOverlay().setStatus(status);
        }
    }

    /**
     * Updates all overlay values with current data
     * @param overlay the overlay to update
     */
    public static void updateOverlayValues(MixologyOverlay overlay) {
        if (overlay == null) {
            return;
        }

        // Update paste amounts
        int redPaste = getCurrentPasteAmount(PasteType.RED);
        int greenPaste = getCurrentPasteAmount(PasteType.GREEN);
        int bluePaste = getCurrentPasteAmount(PasteType.BLUE);

        overlay.updatePasteAmounts(redPaste, greenPaste, bluePaste);

        // Update stored resin
        int storedResin = getStoredResinAmount();
        overlay.updateStoredResin(storedResin);

        // Update active potion
        String activePotion = getActivePotion();
        overlay.updateActivePotion(activePotion);

        // Update current order
        String currentOrder = getCurrentOrder();
        overlay.updateCurrentOrder(currentOrder);

        // Update current node status using ScriptContext
        MixologyScript script = (MixologyScript) ScriptManager.getScriptManager().getCurrentScript();
        if (script != null && script.getContext() != null) {
            try {
                TaskNode activeNode = script.getContext().tasks().getActiveNode();
                String nodeStatus = activeNode != null ? activeNode.getStatus() : "Idle - No Valid Node";
                overlay.updateCurrentNode(nodeStatus);
            } catch (Exception e) {
                // Handle the case when activeNode is null or there's an error getting status
                overlay.updateCurrentNode("Idle - Error Getting Node Status");
            }
        } else {
            overlay.updateCurrentNode("Idle - Script Not Ready");
        }
    }

    /**
     * Records points gained in the overlay
     * @param overlay the overlay to update
     * @param redPoints amount of red points gained
     * @param greenPoints amount of green points gained
     * @param bluePoints amount of blue points gained
     */
    public static void recordPointsGained(MixologyOverlay overlay, int redPoints, int greenPoints, int bluePoints) {
        if (overlay == null) {
            return;
        }

        overlay.recordPointsGained(redPoints, greenPoints, bluePoints);
    }

    /**
     * Records a completed order
     * @param overlay the overlay to update
     * @param potionName the name of the completed potion
     */
    public static void recordCompletedOrder(MixologyOverlay overlay, String potionName) {
        if (overlay == null || potionName == null || potionName.isEmpty()) {
            return;
        }

        overlay.incrementPotionCount(potionName);
    }

    /**
     * Checks if an item ID corresponds to a processed potion
     * @param itemId The item ID to check
     * @return true if it's a processed potion, false otherwise
     */
    public static boolean isProcessedPotion(int itemId) {
        for (int id : MixologyConstants.PROCESSED_POTION_IDS) {
            if (itemId == id) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if an item ID corresponds to an unprocessed potion
     * @param itemId The item ID to check
     * @return true if it's an unprocessed potion, false otherwise
     */
    public static boolean isUnprocessedPotion(int itemId) {
        for (int id : MixologyConstants.UNPROCESSED_POTION_IDS) {
            if (itemId == id) {
                return true;
            }
        }
        return false;
    }
}