package scripts.Herb.config;

import com.google.gson.annotations.Expose;
import core.config.AntiBanConfig;
import core.config.BreakConfig;
import core.config.MulingConfig;
import core.config.RestockConfig;
import core.config.ScriptConfig;
import core.context.ScriptContext;
import org.dreambot.api.settings.ScriptSettings;
import org.dreambot.api.utilities.Logger;
import scripts.Herb.gui.MixologyOverlay;
import scripts.Herb.nodes.ProcessPotionNode;
import scripts.Herb.utils.ConfigUtil;

import java.io.File;

/**
 * Configuration class for the Herb script.
 * Extends ScriptConfig to provide base functionality.
 */
public class HerbConfig extends ScriptConfig {

    // Main configuration for Mixology
    @Expose private MixologyConfig mixologyConfig;

    // Reference to the overlay for updating display values
    private MixologyOverlay mixologyOverlay;

    // Dirty flag to track if the configuration has been modified
    private boolean dirty = false;

    /**
     * Default constructor for HerbConfig.
     * Initializes with default values.
     */
    public HerbConfig() {
        super(null, "herb_config");
        setDefaults();
    }

    /**
     * Constructor with context.
     * @param context The script context.
     */
    public HerbConfig(ScriptContext context) {
        super(context, "herb_config");
        // Initialize MixologyConfig with the context first
        this.mixologyConfig = new MixologyConfig(context);
        setDefaults();
        loadConfig();
    }

    /**
     * Sets the default values for the configuration.
     */
    @Override
    public void setDefaults() {
        // Only create a new MixologyConfig if one doesn't exist
        if (this.mixologyConfig == null) {
            this.mixologyConfig = new MixologyConfig(getContext());
        }

        // Ensure the MixologyConfig has the correct context
        if (this.mixologyConfig.getContext() == null && getContext() != null) {
            this.mixologyConfig = new MixologyConfig(getContext());
        }

        this.dirty = true;
    }

    /**
     * Loads configuration from file.
     */
    @Override
    public void loadConfig() {
        try {
            // Load main configuration data using our safe utility method
            ConfigData data = ConfigUtil.safeLoad(ConfigData.class, "ScarHerb", "herb_config.json");

            if (data != null) {
                // If MixologyConfig is null in the data, create a new one
                if (data.mixologyConfig == null) {
                    Logger.info("MixologyConfig is null in loaded data, creating new instance");
                    this.mixologyConfig = new MixologyConfig(getContext());
                } else {
                    Logger.info("Loaded MixologyConfig from file");
                    Logger.info("Selected herbs in loaded config: " +
                              (data.mixologyConfig.getSelectedHerbs() == null ? "NULL" : data.mixologyConfig.getSelectedHerbs()));
                    this.mixologyConfig = data.mixologyConfig;

                    // Ensure the context is set
                    if (this.mixologyConfig.getContext() == null && getContext() != null) {
                        Logger.info("Setting context on loaded MixologyConfig");
                        this.mixologyConfig.setContext(getContext());
                    }
                }

                // Load framework-level configurations if they exist
                if (data.restockConfig != null) {
                    this.setRestockConfig(data.restockConfig);
                }
                if (data.mulingConfig != null) {
                    this.setMulingConfig(data.mulingConfig);
                }
                if (data.breakConfig != null) {
                    this.setBreakConfig(data.breakConfig);
                }
                if (data.antiBanConfig != null) {
                    this.setAntiBanConfig(data.antiBanConfig);
                }

                Logger.info("HerbConfig loaded successfully");
            } else {
                Logger.info("No existing HerbConfig found, using defaults");
                setDefaults();
            }

            markClean();
        } catch (Exception e) {
            Logger.error("Error loading HerbConfig: " + e.getMessage());
            e.printStackTrace();
            setDefaults();
        }
    }

    /**
     * Saves configuration to file.
     */
    @Override
    public void saveConfig() {
        if (!dirty) {
            return; // Only save if changes were made
        }

        try {
            // Create config data for saving
            ConfigData data = new ConfigData();
            data.mixologyConfig = this.mixologyConfig;

            // Include framework-level configurations
            data.restockConfig = this.getRestockConfig();
            data.mulingConfig = this.getMulingConfig();
            data.breakConfig = this.getBreakConfig();
            data.antiBanConfig = this.getAntiBanConfig();

            // Save using our safe utility method
            ConfigUtil.safeSave(data, "ScarHerb", "herb_config.json");
            Logger.log("HerbConfig saved successfully");

            markClean();
        } catch (Exception e) {
            Logger.log("Error saving HerbConfig: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Inner class to hold serializable data
     */
    public static class ConfigData {
        @Expose public MixologyConfig mixologyConfig;

        // Framework-level configurations
        @Expose public RestockConfig restockConfig;
        @Expose public MulingConfig mulingConfig;
        @Expose public BreakConfig breakConfig;
        @Expose public AntiBanConfig antiBanConfig;

        // Default constructor required for Gson
        public ConfigData() {}
    }

    /**
     * Get the Mixology configuration.
     * @return The Mixology configuration.
     */
    public MixologyConfig getMixologyConfig() {
        Logger.info("HerbConfig.getMixologyConfig() called");

        if (mixologyConfig == null) {
            Logger.info("mixologyConfig is null, creating new instance");
            mixologyConfig = new MixologyConfig(getContext());
        }

        // Ensure the MixologyConfig has the correct context
        if (mixologyConfig.getContext() == null && getContext() != null) {
            Logger.info("mixologyConfig has null context, creating new instance with context");
            mixologyConfig = new MixologyConfig(getContext());
        }

        // Log the selected herbs
        Logger.info("Selected herbs in getMixologyConfig: " +
                  (mixologyConfig.getSelectedHerbs() == null ? "NULL" : mixologyConfig.getSelectedHerbs()));

        return mixologyConfig;
    }

    /**
     * Set the Mixology configuration.
     * @param mixologyConfig The Mixology configuration to set.
     */
    public void setMixologyConfig(MixologyConfig mixologyConfig) {
        Logger.info("HerbConfig.setMixologyConfig() called");

        if (mixologyConfig == null) {
            Logger.warn("Attempted to set mixologyConfig to null, creating new instance instead");
            this.mixologyConfig = new MixologyConfig(getContext());
        } else {
            Logger.info("Setting mixologyConfig to: " + mixologyConfig);
            Logger.info("Selected herbs in new config: " +
                      (mixologyConfig.getSelectedHerbs() == null ? "NULL" : mixologyConfig.getSelectedHerbs()));
            this.mixologyConfig = mixologyConfig;
        }

        markDirty();
    }

    /**
     * Get the Mixology overlay.
     * @return The Mixology overlay.
     */
    public MixologyOverlay getMixologyOverlay() {
        return mixologyOverlay;
    }

    /**
     * Set the Mixology overlay.
     * @param mixologyOverlay The Mixology overlay to set.
     */
    public void setMixologyOverlay(MixologyOverlay mixologyOverlay) {
        this.mixologyOverlay = mixologyOverlay;
    }

    /**
     * Checks if the configuration has been modified since the last save.
     * @return true if the configuration has been modified, false otherwise.
     */
    @Override
    public boolean isDirty() {
        return dirty || (mixologyConfig != null && mixologyConfig.isDirty());
    }

    /**
     * Marks the configuration as dirty (modified).
     */
    @Override
    public void markDirty() {
        this.dirty = true;
    }

    /**
     * Marks the configuration as clean (saved).
     */
    @Override
    public void markClean() {
        this.dirty = false;
        if (mixologyConfig != null) {
            mixologyConfig.markClean();
        }
    }

    /**
     * Reset the configuration to default values.
     */
    @Override
    public void reset() {
        setDefaults();
    }

    /**
     * Copy configuration values from another ScriptConfig.
     * @param other The ScriptConfig to copy from.
     */
    @Override
    protected void copyConfigValues(ScriptConfig other) {
        // Call the parent implementation to copy framework-level configs
        super.copyConfigValues(other);
        if (other instanceof HerbConfig) {
            HerbConfig otherConfig = (HerbConfig) other;
            if (otherConfig.getMixologyConfig() != null) {
                // Create a new MixologyConfig with the context
                if (this.context != null) {
                    this.mixologyConfig = new MixologyConfig(this.context);
                } else {
                    this.mixologyConfig = new MixologyConfig();
                }

                // Copy values from the other config
                this.mixologyConfig.copyConfigValues(otherConfig.getMixologyConfig());
            }
            markDirty();
        }
    }

    /**
     * Save configuration to a profile file
     * @param name The profile name
     */
    public void saveProfile(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }

        try {
            // Create config data for saving
            ConfigData data = new ConfigData();
            data.mixologyConfig = this.mixologyConfig;

            // Include framework-level configurations directly
            data.restockConfig = this.getRestockConfig();
            data.mulingConfig = this.getMulingConfig();
            data.breakConfig = this.getBreakConfig();
            data.antiBanConfig = this.getAntiBanConfig();

            // Save using our safe utility method
            ConfigUtil.safeSave(data, "ScarHerb", "profiles", name + ".json");
            Logger.info("Herb profile saved: " + name);
            Logger.info("Profile saved to: " + System.getProperty("user.home") + "/DreamBot/Scripts/ScarHerb/profiles/" + name + ".json");
        } catch (Exception e) {
            Logger.error("Error saving Herb profile: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Load configuration from a profile file
     * @param name The profile name
     */
    public void loadProfile(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }

        try {
            Logger.info("Attempting to load profile: " + name);
            Logger.info("Expected profile path: " + System.getProperty("user.home") + "/DreamBot/Scripts/ScarHerb/profiles/" + name + ".json");

            // Load from profiles directory
            ConfigData data = ConfigUtil.safeLoad(ConfigData.class, "ScarHerb", "profiles", name + ".json");

            if (data != null) {
                // Handle MixologyConfig - create a new instance with the current context
                if (data.mixologyConfig != null) {
                    // Create a new instance with the current context
                    MixologyConfig newConfig = new MixologyConfig(getContext());

                    // Copy values from the loaded config to the new one
                    // This avoids the null context issue
                    newConfig.setCollectDigweed(data.mixologyConfig.isCollectDigweed());
                    newConfig.setUseDigweedOnMixalot(data.mixologyConfig.isUseDigweedOnMixalot());
                    newConfig.setActiveRefining(data.mixologyConfig.isActiveRefining());
                    newConfig.setActiveProcessing(data.mixologyConfig.isActiveProcessing());
                    newConfig.setUseUnfinishedPotions(data.mixologyConfig.isUseUnfinishedPotions());
                    newConfig.setPrioritizeOrders(data.mixologyConfig.isPrioritizeOrders());
                    newConfig.setStrictProcessingMethods(data.mixologyConfig.isStrictProcessingMethods());
                    newConfig.setMinHerbCount(data.mixologyConfig.getMinHerbCount());
                    newConfig.setMinResinAmount(data.mixologyConfig.getMinResinAmount());
                    newConfig.setTransportMethod(data.mixologyConfig.getTransportMethod());
                    newConfig.setSelectedHerbs(data.mixologyConfig.getSelectedHerbs());
                    newConfig.setPotionPriorities(data.mixologyConfig.getPotionPriorities());
                    // Make sure to copy the new fields
                    newConfig.setBuyAldarium(data.mixologyConfig.isBuyAldarium());
                    newConfig.setBuyBarrel(data.mixologyConfig.isBuyBarrel());

                    // Log the values to verify they're being loaded correctly
                    Logger.info("Loaded buyAldarium: " + data.mixologyConfig.isBuyAldarium());
                    Logger.info("Loaded buyBarrel: " + data.mixologyConfig.isBuyBarrel());

                    // Set the new config
                    this.mixologyConfig = newConfig;

                    // Ensure the context is set
                    if (this.mixologyConfig != null && this.mixologyConfig.getContext() == null) {
                        this.mixologyConfig.setContext(getContext());
                    }
                } else {
                    // If no mixology config was found, create a new one
                    this.mixologyConfig = new MixologyConfig(getContext());
                }

                // Load framework-level configurations directly
                if (data.restockConfig != null) {
                    this.setRestockConfig(data.restockConfig);
                }
                if (data.mulingConfig != null) {
                    this.setMulingConfig(data.mulingConfig);
                }
                if (data.breakConfig != null) {
                    this.setBreakConfig(data.breakConfig);
                }
                if (data.antiBanConfig != null) {
                    this.setAntiBanConfig(data.antiBanConfig);
                }

                Logger.info("Herb profile loaded: " + name);
                Logger.info("Profile loaded from: " + System.getProperty("user.home") + "/DreamBot/Scripts/ScarHerb/profiles/" + name + ".json");
                Logger.info("MixologyConfig context after loading: " + (this.mixologyConfig.getContext() != null ? "Set" : "NULL"));
                markDirty();
                saveConfig();
            } else {
                Logger.warn("Profile not found: " + name);
                throw new RuntimeException("Profile not found: " + name);
            }
        } catch (Exception e) {
            Logger.error("Error loading Herb profile: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /**
     * Delete a profile
     * @param name The profile name
     * @return true if successful
     */
    public boolean deleteProfile(String name) {
        if (name == null || name.isEmpty()) {
            return false;
        }

        try {
            File profileFile = new File(getProfilesDirectory(), name + ".json");
            boolean deleted = profileFile.delete();
            if (deleted) {
                Logger.log("Deleted Herb profile: " + name);
            } else {
                Logger.log("Failed to delete Herb profile: " + name);
            }
            return deleted;
        } catch (Exception e) {
            Logger.log("Error deleting Herb profile: " + e.getMessage());
            return false;
        }
    }

    /**
     * Get available profiles
     * @return List of profile names
     */
    public java.util.List<String> getAvailableProfiles() {
        java.util.List<String> profiles = new java.util.ArrayList<>();
        File profilesDir = getProfilesDirectory();

        if (profilesDir.exists() && profilesDir.isDirectory()) {
            File[] files = profilesDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".json"));
            if (files != null) {
                for (File file : files) {
                    String name = file.getName();
                    profiles.add(name.substring(0, name.lastIndexOf('.')));
                }
            }
        }

        return profiles;
    }

    /**
     * Get the profiles directory
     * @return The profiles directory
     */
    private File getProfilesDirectory() {
        String baseDir = System.getProperty("user.home") + File.separator +
                        "DreamBot" + File.separator +
                        "Scripts" + File.separator +
                        "ScarHerb";

        File profilesDir = new File(baseDir + File.separator + "profiles");
        if (!profilesDir.exists()) {
            profilesDir.mkdirs();
        }

        return profilesDir;
    }

    // Getter for the ProcessPotionNode
    public ProcessPotionNode getPotionProcessor() {
        // processPotionNode doesn't exist here, so we need to get it from the script context
        if (context.tasks().getNodes() == null) {
            Logger.log("ERROR: Unable to access script context for potion processor");
            return null;
        }

        // Look through the nodes to find the ProcessPotionNode
        for (var node : context.tasks().getNodes()) {
            if (node instanceof ProcessPotionNode) {
                return (ProcessPotionNode) node;
            }
        }

        Logger.log("ERROR: ProcessPotionNode not found in script nodes");
        return null;
    }
}