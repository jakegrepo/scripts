package scripts.Herb.config;

import com.google.gson.annotations.Expose;
import core.config.ScriptConfig;
import core.context.ScriptContext;
import org.dreambot.api.settings.ScriptSettings;
import org.dreambot.api.utilities.Logger;
import scripts.Herb.enums.NavigationDestination;
import scripts.Herb.utils.ConfigUtil;

import java.io.File;
import java.util.*;

/**
 * Configuration class for Mastering Mixology minigame
 */
public class MixologyConfig extends ScriptConfig {
    private static final String DEFAULT_TRANSPORT_METHOD = "Fairy Ring";
    private static final int DEFAULT_MIN_HERB_COUNT = 10;
    private static final int DEFAULT_MIN_RESIN_AMOUNT = 50;
    @Expose private boolean buyAldarium;
    @Expose private boolean buyBarrel;
    @Expose private int aldariumPointsThreshold = 150;
    // Settings
    public boolean isBuyAldarium(){ return buyAldarium; }
    public void    setBuyAldarium(boolean b){ this.buyAldarium = b; }

    public boolean isBuyBarrel(){ return buyBarrel; }
    public void    setBuyBarrel(boolean b){ this.buyBarrel = b; }
    @Expose private boolean collectDigweed = true;
    @Expose private boolean useDigweedOnMixalot = true;
    @Expose private boolean activeRefining = true;
    @Expose private boolean activeProcessing = true;
    @Expose private boolean useUnfinishedPotions = false;
    @Expose private boolean prioritizeOrders = true;
    @Expose private int minHerbCount = DEFAULT_MIN_HERB_COUNT;
    @Expose private int minResinAmount = DEFAULT_MIN_RESIN_AMOUNT;
    @Expose private String transportMethod = DEFAULT_TRANSPORT_METHOD;

    // Current navigation destination
    private NavigationDestination currentDestination = null;

    // Selected herbs for refining
    @Expose private List<String> selectedHerbs = Arrays.asList("Harralander", "Avantoe", "Dwarf weed");

    // Potion priorities (name -> priority value, higher is more important)
    @Expose private Map<String, Integer> potionPriorities = new HashMap<>();

    // Flag to track if settings have been modified
    private boolean dirty = false;

    // Track completed orders for batch processing
    private List<String> completedPotions = new ArrayList<>();
    private List<String> currentBatchOrders = new ArrayList<>();

    // Add the strictProcessingMethods field
    @Expose private boolean strictProcessingMethods = false;

    // Muling Configuration is now handled by the framework in ScriptConfig

    // Framework-level configurations are inherited from ScriptConfig

    // Add transient fields if ScriptContext is needed but not saved
    @Expose private transient ScriptContext context;

    // Purchase settings

    /**
     * Constructor with context
     */
    public MixologyConfig(ScriptContext context) {
        super(context, "mixology_config");
        this.context = context;
        setDefaults();
    }

    /**
     * Default constructor with default values (for Gson deserialization)
     */
    public MixologyConfig() {
        // Don't call this(null) which would trigger an exception in ScriptConfig
        // Instead, use a special constructor for deserialization
        super(); // Call the no-arg constructor of ScriptConfig
        // Initialize collections to avoid NPEs
        selectedHerbs = new ArrayList<>();
        potionPriorities = new HashMap<>();
        completedPotions = new ArrayList<>();
        currentBatchOrders = new ArrayList<>();
    }

    /**
     * Special constructor for ScriptConfig to avoid IllegalArgumentException
     */
    protected MixologyConfig(boolean forDeserialization) {
        super(forDeserialization);
    }

    @Override
    public void setDefaults() {
        // Reset to default values
        collectDigweed = true;
        useDigweedOnMixalot = true;
        activeRefining = true;
        activeProcessing = true;
        useUnfinishedPotions = false;
        prioritizeOrders = true;
        strictProcessingMethods = true;
        minHerbCount = DEFAULT_MIN_HERB_COUNT;
        minResinAmount = DEFAULT_MIN_RESIN_AMOUNT;
        transportMethod = DEFAULT_TRANSPORT_METHOD;
        selectedHerbs = Arrays.asList("Kwuarm", "Lantadyme", "Tarromin");
        Logger.info("Set default selectedHerbs in setDefaults(): " + selectedHerbs);

        // Set default potion priorities
        potionPriorities = new HashMap<>();
        potionPriorities.put("Alco-AugmentAtor", 5);
        potionPriorities.put("Mammoth-Might Mix", 4);
        potionPriorities.put("LipLack Liquor", 3);
        potionPriorities.put("Mystic Mana Amalgam", 2);
        potionPriorities.put("Marley's MoonLight", 2);
        potionPriorities.put("Azure Aura Mix", 1);
        potionPriorities.put("AquaLux Amalgam", 1);
        potionPriorities.put("MegaLite Liquid", 1);
        potionPriorities.put("Anti-Leech Lotion", 1);
        potionPriorities.put("MixALot", 1);

        // Log buy-related settings
        Logger.info("=== Mixology Buy Settings (Defaults) ===");
        Logger.info("Buy Aldarium: " + this.buyAldarium);
        Logger.info("Aldarium Points Threshold: " + this.aldariumPointsThreshold);
        Logger.info("Buy Barrel: " + this.buyBarrel);
        Logger.info("=======================================");

        // Mark as dirty to ensure it's saved
        markDirty();
    }

    @Override
    public void saveConfig() {
        if (!dirty) {
            return;  // Only save if changes were made
        }

        try {
            // Create config data for saving
            ConfigData data = new ConfigData();
            data.collectDigweed = this.collectDigweed;
            data.useDigweedOnMixalot = this.useDigweedOnMixalot;
            data.activeRefining = this.activeRefining;
            data.activeProcessing = this.activeProcessing;
            data.useUnfinishedPotions = this.useUnfinishedPotions;
            data.prioritizeOrders = this.prioritizeOrders;
            data.strictProcessingMethods = this.strictProcessingMethods;
            data.minHerbCount = this.minHerbCount;
            data.minResinAmount = this.minResinAmount;
            data.transportMethod = this.transportMethod;
            data.selectedHerbs = new ArrayList<>(this.selectedHerbs);
            data.potionPriorities = new HashMap<>(this.potionPriorities);
            data.buyAldarium = this.buyAldarium;
            data.buyBarrel = this.buyBarrel;
            data.aldariumPointsThreshold = this.aldariumPointsThreshold;

            // Include framework-level configurations
            data.mulingConfig = this.getMulingConfig();
            data.breakConfig = this.getBreakConfig();
            data.antiBanConfig = this.getAntiBanConfig();

            // Save using our safe utility method
            ConfigUtil.safeSave(data, "ScarHerb", "mixology_config.json");
            Logger.info("Mixology config saved successfully");

            markClean();
        } catch (Exception e) {
            Logger.info("Error saving Mixology config: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void loadConfig() {
        try {
            // Load from script settings using ConfigUtil for consistency
            ConfigData data = ConfigUtil.safeLoad(ConfigData.class, "ScarHerb", "mixology_config.json");

            if (data != null) {
                this.collectDigweed = data.collectDigweed;
                this.useDigweedOnMixalot = data.useDigweedOnMixalot;
                this.activeRefining = data.activeRefining;
                this.activeProcessing = data.activeProcessing;
                this.useUnfinishedPotions = data.useUnfinishedPotions;
                this.prioritizeOrders = data.prioritizeOrders;
                this.strictProcessingMethods = data.strictProcessingMethods;
                this.minHerbCount = data.minHerbCount;
                this.minResinAmount = data.minResinAmount;
                this.transportMethod = data.transportMethod;
                this.selectedHerbs = new ArrayList<>(data.selectedHerbs);
                this.potionPriorities = new HashMap<>(data.potionPriorities);
                this.buyAldarium = data.buyAldarium;
                this.buyBarrel = data.buyBarrel;
                this.aldariumPointsThreshold = data.aldariumPointsThreshold;

                // Load framework-level configurations
                if (data.mulingConfig != null) {
                    this.setMulingConfig(data.mulingConfig);
                }
                if (data.breakConfig != null) {
                    this.setBreakConfig(data.breakConfig);
                }
                if (data.antiBanConfig != null) {
                    this.setAntiBanConfig(data.antiBanConfig);
                }

                Logger.info("Mixology config loaded successfully");
                // Log buy-related settings
                Logger.info("=== Mixology Buy Settings (Loaded) ===");
                Logger.info("Buy Aldarium: " + this.buyAldarium);
                Logger.info("Aldarium Points Threshold: " + this.aldariumPointsThreshold);
                Logger.info("Buy Barrel: " + this.buyBarrel);
                Logger.info("=====================================");
            } else {
                Logger.info("No existing Mixology config found, using defaults");
                setDefaults();
            }

            markClean();
        } catch (Exception e) {
            Logger.info("Error loading Mixology config: " + e.getMessage());
            e.printStackTrace();
            setDefaults();  // Fall back to defaults if loading fails
        }
    }

    /**
     * Inner class to hold serializable data
     */
    private static class ConfigData {
        public boolean collectDigweed = true;
        public boolean useDigweedOnMixalot = true;
        public boolean activeRefining = true;
        public boolean activeProcessing = true;
        public boolean useUnfinishedPotions = false;
        public boolean prioritizeOrders = true;
        public boolean strictProcessingMethods = false;
        public int minHerbCount = DEFAULT_MIN_HERB_COUNT;
        public int minResinAmount = DEFAULT_MIN_RESIN_AMOUNT;
        public String transportMethod = DEFAULT_TRANSPORT_METHOD;
        public List<String> selectedHerbs = new ArrayList<>();
        public Map<String, Integer> potionPriorities = new HashMap<>();
        public boolean buyAldarium = false;
        public boolean buyBarrel = false;
        public int aldariumPointsThreshold = 150;

        // Framework-level configurations
        public core.config.MulingConfig mulingConfig = new core.config.MulingConfig();
        public core.config.BreakConfig breakConfig = new core.config.BreakConfig();
        public core.config.AntiBanConfig antiBanConfig = new core.config.AntiBanConfig();
    }

    /**
     * Save configuration to a profile file
     * @param name The profile name
     */
    public void saveProfile(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }

        try {
            // Create config data for saving
            ConfigData data = new ConfigData();
            data.collectDigweed = this.collectDigweed;
            data.useDigweedOnMixalot = this.useDigweedOnMixalot;
            data.activeRefining = this.activeRefining;
            data.activeProcessing = this.activeProcessing;
            data.useUnfinishedPotions = this.useUnfinishedPotions;
            data.prioritizeOrders = this.prioritizeOrders;
            data.strictProcessingMethods = this.strictProcessingMethods;
            data.minHerbCount = this.minHerbCount;
            data.minResinAmount = this.minResinAmount;
            data.transportMethod = this.transportMethod;
            data.selectedHerbs = new ArrayList<>(this.selectedHerbs);
            data.potionPriorities = new HashMap<>(this.potionPriorities);

            // Save the new fields
            data.buyAldarium = this.buyAldarium;
            data.buyBarrel = this.buyBarrel;
            data.aldariumPointsThreshold = this.aldariumPointsThreshold;

            // Include framework-level configurations
            data.mulingConfig = this.getMulingConfig();
            data.breakConfig = this.getBreakConfig();
            data.antiBanConfig = this.getAntiBanConfig();

            // Save using our safe utility method
            ConfigUtil.safeSave(data, "ScarHerb", "profiles", name + ".json");
            Logger.info("Mixology profile saved: " + name);
            Logger.info("Profile saved to: " + System.getProperty("user.home") + "/DreamBot/Scripts/ScarHerb/profiles/" + name + ".json");
            Logger.info("=== Mixology Buy Settings (Saved to Profile) ===");
            Logger.info("Buy Aldarium: " + this.buyAldarium);
            Logger.info("Aldarium Points Threshold: " + this.aldariumPointsThreshold);
            Logger.info("Buy Barrel: " + this.buyBarrel);
            Logger.info("================================================");
        } catch (Exception e) {
            Logger.error("Error saving Mixology profile: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /**
     * Load configuration from a profile file
     * @param name The profile name
     */
    public void loadProfile(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }

        try {
            Logger.info("Attempting to load profile: " + name);
            Logger.info("Expected profile path: " + System.getProperty("user.home") + "/DreamBot/Scripts/ScarHerb/profiles/" + name + ".json");

            // Load from profiles directory using ConfigUtil for consistency
            ConfigData data = ConfigUtil.safeLoad(ConfigData.class, "ScarHerb", "profiles", name + ".json");

            if (data != null) {
                this.collectDigweed = data.collectDigweed;
                this.useDigweedOnMixalot = data.useDigweedOnMixalot;
                this.activeRefining = data.activeRefining;
                this.activeProcessing = data.activeProcessing;
                this.useUnfinishedPotions = data.useUnfinishedPotions;
                this.prioritizeOrders = data.prioritizeOrders;
                this.strictProcessingMethods = data.strictProcessingMethods;
                this.minHerbCount = data.minHerbCount;
                this.minResinAmount = data.minResinAmount;
                this.transportMethod = data.transportMethod;
                this.selectedHerbs = new ArrayList<>(data.selectedHerbs);
                this.potionPriorities = new HashMap<>(data.potionPriorities);

                // Load the new fields
                this.buyAldarium = data.buyAldarium;
                this.buyBarrel = data.buyBarrel;
                this.aldariumPointsThreshold = data.aldariumPointsThreshold;

                // Load framework-level configurations
                if (data.mulingConfig != null) {
                    this.setMulingConfig(data.mulingConfig);
                }
                if (data.breakConfig != null) {
                    this.setBreakConfig(data.breakConfig);
                }
                if (data.antiBanConfig != null) {
                    this.setAntiBanConfig(data.antiBanConfig);
                }

                Logger.info("Mixology profile loaded: " + name);
                Logger.info("Profile loaded from: " + System.getProperty("user.home") + "/DreamBot/Scripts/ScarHerb/profiles/" + name + ".json");
                Logger.info("=== Mixology Buy Settings (Loaded from Profile) ===");
                Logger.info("Buy Aldarium: " + this.buyAldarium);
                Logger.info("Aldarium Points Threshold: " + this.aldariumPointsThreshold);
                Logger.info("Buy Barrel: " + this.buyBarrel);
                Logger.info("=================================================");

                markDirty();
            } else {
                Logger.warn("Profile not found: " + name);
                throw new RuntimeException("Profile not found: " + name);
            }
        } catch (Exception e) {
            Logger.error("Error loading Mixology profile: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /**
     * Delete a profile
     * @param name The profile name
     * @return true if successful
     */
    public boolean deleteProfile(String name) {
        if (name == null || name.isEmpty()) {
            return false;
        }

        try {
            File profileFile = new File(getProfilesDirectory(), name + ".json");
            boolean deleted = profileFile.delete();
            if (deleted) {
                Logger.log("Deleted Mixology profile: " + name);
            } else {
                Logger.log("Failed to delete Mixology profile: " + name);
            }
            return deleted;
        } catch (Exception e) {
            Logger.log("Error deleting Mixology profile: " + e.getMessage());
            return false;
        }
    }

    /**
     * Get available profiles
     * @return List of profile names
     */
    public List<String> getAvailableProfiles() {
        List<String> profiles = new ArrayList<>();
        File profilesDir = getProfilesDirectory();

        if (profilesDir.exists() && profilesDir.isDirectory()) {
            File[] files = profilesDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".json"));
            if (files != null) {
                for (File file : files) {
                    String name = file.getName();
                    profiles.add(name.substring(0, name.lastIndexOf('.')));
                }
            }
        }

        return profiles;
    }

    /**
     * Get the profiles directory
     * @return The profiles directory
     */
    private File getProfilesDirectory() {
        String baseDir = System.getProperty("user.home") + File.separator +
                        "DreamBot" + File.separator +
                        "Scripts" + File.separator +
                        "ScarHerb";

        File profilesDir = new File(baseDir + File.separator + "profiles");
        if (!profilesDir.exists()) {
            profilesDir.mkdirs();
        }

        return profilesDir;
    }

    // Mark config as dirty (changed)
    @Override
    public void markDirty() {
        this.dirty = true;
    }

    // Mark config as clean (saved)
    @Override
    public void markClean() {
        this.dirty = false;
    }

    // Check if config is dirty
    @Override
    public boolean isDirty() {
        return this.dirty;
    }

    // Getters and setters

    public List<String> getSelectedHerbs() {
        // Ensure we never return null
        if (selectedHerbs == null) {
            Logger.info("selectedHerbs was null, initializing with default values");
            selectedHerbs = Arrays.asList("Kwuarm", "Lantadyme", "Tarromin");
            markDirty();
        } else if (selectedHerbs.isEmpty()) {
            Logger.info("selectedHerbs was empty, initializing with default values");
            selectedHerbs = Arrays.asList("Kwuarm", "Lantadyme", "Tarromin");
            markDirty();
        }
        return selectedHerbs;
    }

    public void setSelectedHerbs(List<String> selectedHerbs) {
        // Ensure we never set null or empty list
        if (selectedHerbs == null) {
            Logger.info("Attempted to set selectedHerbs to null, using default values instead");
            this.selectedHerbs = Arrays.asList("Kwuarm", "Lantadyme", "Tarromin");
        } else if (selectedHerbs.isEmpty()) {
            Logger.info("Attempted to set selectedHerbs to empty list, using default values instead");
            this.selectedHerbs = Arrays.asList("Kwuarm", "Lantadyme", "Tarromin");
        } else {
            this.selectedHerbs = selectedHerbs;
        }
        Logger.info("selectedHerbs set to: " + this.selectedHerbs);
        markDirty();
    }

    public Map<String, Integer> getPotionPriorities() {
        return potionPriorities;
    }

    public void setPotionPriorities(Map<String, Integer> potionPriorities) {
        this.potionPriorities = potionPriorities;
        markDirty();
    }

    public boolean isActiveRefining() {
        return activeRefining;
    }

    public void setActiveRefining(boolean activeRefining) {
        this.activeRefining = activeRefining;
        markDirty();
    }

    public boolean isActiveProcessing() {
        return activeProcessing;
    }

    public void setActiveProcessing(boolean activeProcessing) {
        this.activeProcessing = activeProcessing;
        markDirty();
    }

    public boolean isPrioritizeOrders() {
        return prioritizeOrders;
    }

    public void setPrioritizeOrders(boolean prioritizeOrders) {
        this.prioritizeOrders = prioritizeOrders;
        markDirty();
    }

    public boolean isUseUnfinishedPotions() {
        return useUnfinishedPotions;
    }

    public void setUseUnfinishedPotions(boolean useUnfinishedPotions) {
        this.useUnfinishedPotions = useUnfinishedPotions;
        markDirty();
    }

    public int getMinHerbCount() {
        return minHerbCount;
    }

    public void setMinHerbCount(int minHerbCount) {
        if (minHerbCount > 0) {
            this.minHerbCount = minHerbCount;
            markDirty();
        }
    }

    public int getMinResinAmount() {
        return minResinAmount;
    }

    public void setMinResinAmount(int minResinAmount) {
        this.minResinAmount = minResinAmount;
        markDirty();
    }

    public boolean isCollectDigweed() {
        return collectDigweed;
    }

    public void setCollectDigweed(boolean collectDigweed) {
        this.collectDigweed = collectDigweed;
        markDirty();
    }

    public boolean isUseDigweedOnMixalot() {
        return useDigweedOnMixalot;
    }

    public void setUseDigweedOnMixalot(boolean useDigweedOnMixalot) {
        this.useDigweedOnMixalot = useDigweedOnMixalot;
        markDirty();
    }

    public String getTransportMethod() {
        return transportMethod;
    }

    public void setTransportMethod(String transportMethod) {
        this.transportMethod = transportMethod;
        markDirty();
    }

    public NavigationDestination getCurrentDestination() {
        return currentDestination;
    }

    public void setCurrentDestination(NavigationDestination currentDestination) {
        this.currentDestination = currentDestination;
    }

    /**
     * Gets the priority of a specific potion
     * @param potionName the name of the potion
     * @return the priority value (higher is more important)
     */
    public int getPotionPriority(String potionName) {
        return potionPriorities.getOrDefault(potionName, 0);
    }

    /**
     * Sets the priority of a specific potion
     * @param potionName the name of the potion
     * @param priority the priority value (higher is more important)
     */
    public void setPotionPriority(String potionName, int priority) {
        potionPriorities.put(potionName, priority);
        markDirty();
    }

    @Override
    protected void copyConfigValues(ScriptConfig other) {
        // Call the parent implementation to copy framework-level configs
        super.copyConfigValues(other);
        if (other instanceof MixologyConfig) {
            MixologyConfig otherConfig = (MixologyConfig) other;
            this.collectDigweed = otherConfig.collectDigweed;
            this.useDigweedOnMixalot = otherConfig.useDigweedOnMixalot;
            this.activeRefining = otherConfig.activeRefining;
            this.activeProcessing = otherConfig.activeProcessing;
            this.useUnfinishedPotions = otherConfig.useUnfinishedPotions;
            this.prioritizeOrders = otherConfig.prioritizeOrders;
            this.minHerbCount = otherConfig.minHerbCount;
            this.minResinAmount = otherConfig.minResinAmount;
            this.transportMethod = otherConfig.transportMethod;
            this.selectedHerbs = new ArrayList<>(otherConfig.selectedHerbs);
            this.potionPriorities = new HashMap<>(otherConfig.potionPriorities);
            this.strictProcessingMethods = otherConfig.strictProcessingMethods;
            this.aldariumPointsThreshold = otherConfig.aldariumPointsThreshold;

            // Muling settings are now handled by the framework

            // Framework-level configurations are copied by the parent class

            markDirty();
        }
    }

    @Override
    public void reset() {
        setDefaults();
    }

    // Getters and setters for the new fields

    /**
     * Gets the list of potions that have been completed but not yet deposited
     * @return List of completed potion names
     */
    public List<String> getCompletedPotions() {
        return completedPotions;
    }

    /**
     * Add a potion to the completed potions list
     * @param potionName Name of the completed potion
     */
    public void addCompletedPotion(String potionName) {
        if (potionName != null && !potionName.isEmpty()) {
            completedPotions.add(potionName);
        }
    }

    /**
     * Clears the list of completed potions
     */
    public void clearCompletedPotions() {
        completedPotions.clear();
    }

    /**
     * Gets the current batch of orders to process
     * @return List of order names
     */
    public List<String> getCurrentBatchOrders() {
        return currentBatchOrders;
    }

    /**
     * Sets the current batch of orders to process
     * @param orders List of order names
     */
    public void setCurrentBatchOrders(List<String> orders) {
        currentBatchOrders.clear();
        if (orders != null) {
            currentBatchOrders.addAll(orders);
        }
    }

    /**
     * Checks if we have completed all orders in the current batch
     * @return true if all orders completed, false otherwise
     */
    public boolean hasCompletedAllOrders() {
        if (currentBatchOrders.isEmpty()) {
            return false;
        }

        // Make a case-insensitive comparison
        for (String order : currentBatchOrders) {
            boolean found = false;
            for (String completed : completedPotions) {
                if (order.toLowerCase().contains(completed.toLowerCase()) ||
                    completed.toLowerCase().contains(order.toLowerCase())) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }

        return true;
    }

    /**
     * Checks if strict processing methods are enabled
     * When enabled, potions will only be processed with the correct equipment
     * @return true if strict processing methods are enabled
     */
    public boolean isStrictProcessingMethods() {
        return strictProcessingMethods;
    }

    /**
     * Sets whether strict processing methods should be used
     * @param strictProcessingMethods true to only use correct equipment for each potion
     */
    public void setStrictProcessingMethods(boolean strictProcessingMethods) {
        this.strictProcessingMethods = strictProcessingMethods;
        markDirty();
    }

    // Muling functionality is now handled by the framework

    // Framework-level configuration getters and setters are inherited from ScriptConfig

    // Add explicit methods to ensure proper serialization
    @Override
    public core.config.MulingConfig getMulingConfig() {
        return super.getMulingConfig();
    }

    @Override
    public void setMulingConfig(core.config.MulingConfig mulingConfig) {
        super.setMulingConfig(mulingConfig);
    }

    @Override
    public core.config.BreakConfig getBreakConfig() {
        return super.getBreakConfig();
    }

    @Override
    public void setBreakConfig(core.config.BreakConfig breakConfig) {
        super.setBreakConfig(breakConfig);
    }

    @Override
    public core.config.AntiBanConfig getAntiBanConfig() {
        return super.getAntiBanConfig();
    }

    @Override
    public void setAntiBanConfig(core.config.AntiBanConfig antiBanConfig) {
        super.setAntiBanConfig(antiBanConfig);
    }

    /**
     * Get the script context.
     * @return The script context.
     */
    public ScriptContext getContext() {
        return context;
    }

    /**
     * Set the script context.
     * @param context The script context.
     */
    public void setContext(ScriptContext context) {
        this.context = context;
    }

    public int getAldariumPointsThreshold() { 
        return aldariumPointsThreshold;
    }

    public void setAldariumPointsThreshold(int threshold) { 
        this.aldariumPointsThreshold = threshold;
        this.markDirty(); // Make sure to mark as dirty when changing
    }

    // Add a helper method to get caller information
    private String getCallerInfo() {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        if (stackTrace.length >= 4) {
            StackTraceElement caller = stackTrace[3]; // Index 3 is typically the caller of the current method
            return caller.getClassName() + "." + caller.getMethodName() + ":" + caller.getLineNumber();
        }
        return "Unknown caller";
    }

    @Override
    public String toString() {
        return "MixologyConfig{" +
               "buyAldarium=" + buyAldarium +
               ", buyBarrel=" + buyBarrel +
               ", aldariumPointsThreshold=" + aldariumPointsThreshold +
               ", collectDigweed=" + collectDigweed +
               ", useDigweedOnMixalot=" + useDigweedOnMixalot +
               ", activeRefining=" + activeRefining +
               ", activeProcessing=" + activeProcessing +
               ", useUnfinishedPotions=" + useUnfinishedPotions +
               ", prioritizeOrders=" + prioritizeOrders +
               ", minHerbCount=" + minHerbCount +
               ", minResinAmount=" + minResinAmount +
               ", transportMethod='" + transportMethod + '\'' +
               ", currentDestination=" + currentDestination +
               ", selectedHerbs=" + selectedHerbs +
               '}';
    }
}