package scripts.Herb.webnodes; // Or your relevant package

import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.pathfinding.impl.web.WebFinder;
import org.dreambot.api.methods.walking.web.node.AbstractWebNode;
import org.dreambot.api.methods.walking.web.node.impl.BasicWebNode;
import org.dreambot.api.methods.walking.web.node.impl.EntranceWebNode;
import org.dreambot.api.utilities.Logger; // Optional: for logging messages

import java.util.ArrayList;
import java.util.List;

public class MixologistLabWeb {

    // Define the rectangular area for downstairs coverage
    // Using new Area(minX, minY, maxX, maxY, plane) is often simpler for rectangles
    private static final Area DOWNSTAIRS_AREA = new Area(1360, 9300, 1402, 9334, 0);
    private static final int GRID_STEP = 5; // How far apart grid nodes are placed

    public static void addMixologistLabNodes() {
        Logger.info("[WebNode] Attempting to add Mixologist Lab nodes...");

        // 1. Get the existing global web node to connect to
        AbstractWebNode globalNode = WebFinder.getWebFinder().get(12200); // Your specified global node ID

        if (globalNode == null) {
            Logger.log("[WebNode] Could not find global node 12200 to connect Mixologist Lab.");
            return;
        }
        Logger.info("[WebNode] Found global node: " + globalNode.getTile());

        // 2. Create Entrance/Exit nodes for the Staircase
        EntranceWebNode staircaseUp = new EntranceWebNode(1388, 2915, 0, "Staircase", "Climb-down") {
            @Override
            public boolean forceNext() {
                return true; // Force interaction when pathing requires it
            }
        };
        EntranceWebNode staircaseDown = new EntranceWebNode(1388, 9314, 0, "Staircase", "Climb-up") {
            @Override
            public boolean forceNext() {
                return true; // Force interaction when pathing requires it
            }
        };

        // 3. Create the Bank Chest node (using EntranceWebNode to mark specific interaction tile)
        EntranceWebNode bankChestNode = new EntranceWebNode(1399, 9313, 0, "Bank chest", "Use") {
            // ID: 54933 - Name is usually preferred for EntranceWebNode unless ambiguous
            @Override
            public boolean forceNext() {
                // Usually false for terminal interactions, but true won't hurt if pathing aims exactly here.
                // Set to false if you only want pathfinding *near* it, true if you want pathfinding *to* interact.
                return true;
            }
        };

        // 4. Add the entrance/exit and bank nodes to the WebFinder
        WebFinder.getWebFinder().addWebNode(staircaseUp);
        WebFinder.getWebFinder().addWebNode(staircaseDown);
        WebFinder.getWebFinder().addWebNode(bankChestNode);
        Logger.info("[WebNode] Added Staircase and Bank Chest nodes.");

        // 5. Connect the global node to the upstairs staircase entrance
        //    Use dual connections for two-way pathing.
        globalNode.addDualConnections(staircaseUp);
        Logger.info("[WebNode] Connected global node <-> " + staircaseUp.getTile());


        // 6. Connect the two staircase nodes together (upstairs <-> downstairs)
        staircaseUp.addDualConnections(staircaseDown);
        Logger.info("[WebNode] Connected " + staircaseUp.getTile() + " <-> " + staircaseDown.getTile());


        // 7. Create grid coverage for the downstairs mixology area
        List<AbstractWebNode> coverageNodesDownstairs = new ArrayList<>();
        Logger.info("[WebNode] Generating grid for area: " + DOWNSTAIRS_AREA);
        java.awt.Rectangle bounds = DOWNSTAIRS_AREA.getBoundingBox(); // Get the bounding box
        for (int x = bounds.x; x <= bounds.x + bounds.width; x += GRID_STEP) { // Use bounds.x and bounds.width
            for (int y = bounds.y; y <= bounds.y + bounds.height; y += GRID_STEP) { // Use bounds.y and bounds.height
                // Optional: Check if the tile is actually within the precise area polygon if needed,
                // but for rectangular grid generation, this is fine.
                Tile currentTile = new Tile(x, y, DOWNSTAIRS_AREA.getZ());
                // Optional: Add a check here to ensure the tile is actually walkable if needed
                // e.g., if (!currentTile.isWalkable()) continue; (needs Region data)

                BasicWebNode node = new BasicWebNode(x, y, DOWNSTAIRS_AREA.getZ());
                coverageNodesDownstairs.add(node);
                WebFinder.getWebFinder().addWebNode(node); // Add each grid node
            }
        }
        Logger.info("[WebNode] Generated " + coverageNodesDownstairs.size() + " grid nodes for downstairs.");

        // 8. Connect nodes within the downstairs grid area to their neighbors
        int gridConnections = 0;
        for (int i = 0; i < coverageNodesDownstairs.size(); i++) {
            AbstractWebNode currentNode = coverageNodesDownstairs.get(i);
            for (int j = i + 1; j < coverageNodesDownstairs.size(); j++) {
                AbstractWebNode otherNode = coverageNodesDownstairs.get(j);
                // Connect if nodes are reasonably close (e.g., within 1.5 * GRID_STEP)
                // Using a slightly larger distance than GRID_STEP helps connect diagonally adjacent grid points.
                int distThreshold = (int) (GRID_STEP * 1.5);
                // Check distance based on coordinates first (faster)
                if (Math.abs(currentNode.getX() - otherNode.getX()) <= distThreshold &&
                        Math.abs(currentNode.getY() - otherNode.getY()) <= distThreshold) {
                    // Check tile distance to avoid overly long straight connections across obstacles
                    if (currentNode.distance(otherNode.getTile()) <= distThreshold + 2) { // Use .getTile() here
                        currentNode.addDualConnections(otherNode);
                        gridConnections++;
                    }
                }
            }
        }
        Logger.info("[WebNode] Added " + gridConnections + " connections within the downstairs grid.");


        // 9. Connect the downstairs staircase exit to the nearest node in the grid
        AbstractWebNode nearestToStairs = findNearestNode(staircaseDown, coverageNodesDownstairs);
        if (nearestToStairs != null) {
            staircaseDown.addDualConnections(nearestToStairs);
            Logger.info("[WebNode] Connected " + staircaseDown.getTile() + " <-> nearest grid node " + nearestToStairs.getTile());
        } else {
            Logger.log("[WebNode] Could not find a nearby grid node to connect downstairs staircase!");
        }

        // 10. Connect the Bank Chest node to the nearest node in the grid
        AbstractWebNode nearestToBank = findNearestNode(bankChestNode, coverageNodesDownstairs);
        if (nearestToBank != null) {
            bankChestNode.addDualConnections(nearestToBank);
            Logger.info("[WebNode] Connected " + bankChestNode.getTile() + " <-> nearest grid node " + nearestToBank.getTile());
        } else {
            Logger.log("[WebNode] Could not find a nearby grid node to connect Bank Chest!");
        }

        Logger.info("[WebNode] Mixologist Lab node addition complete.");
    }

    /**
     * Finds the nearest AbstractWebNode from a list to a target AbstractWebNode based on tile distance.
     *
     * @param target The node to find the nearest neighbor for.
     * @param nodes  The list of nodes to search within.
     * @return The nearest node from the list, or null if the list is empty.
     */
    private static AbstractWebNode findNearestNode(AbstractWebNode target, List<AbstractWebNode> nodes) {
        AbstractWebNode nearestNode = null;
        double minDistance = Double.MAX_VALUE; // Use double for Tile.distance

        if (nodes == null || nodes.isEmpty()) {
            return null;
        }

        Tile targetTile = target.getTile(); // Get Tile for accurate distance calculation

        for (AbstractWebNode node : nodes) {
            // Ensure nodes are on the same plane before calculating distance
            if (node.getZ() != target.getZ()) {
                continue;
            }

            double distance = targetTile.distance(node.getTile()); // Use Tile distance
            if (distance < minDistance) {
                minDistance = distance;
                nearestNode = node;
            }
        }
        return nearestNode;
    }
}
