package scripts.Herb.webnodes;

import org.dreambot.api.methods.walking.pathfinding.impl.web.WebFinder;
import org.dreambot.api.methods.walking.web.node.AbstractWebNode;
import org.dreambot.api.methods.walking.web.node.impl.BasicWebNode;
import org.dreambot.api.methods.walking.web.node.impl.EntranceWebNode;

import java.util.ArrayList;
import java.util.List;

public class AncientPrison {

    public static void AncientPrisonNode() {
        // Get the existing web node to connect to
        AbstractWebNode node12291 = WebFinder.getWebFinder().get(12291); // Tile 1388,9569,0

        if (node12291 != null) {
            // Create entry point node slightly inside the prison area
            BasicWebNode prisonEntry = new BasicWebNode(1388, 9570, 0);

            // Entrance nodes for the obstacle
            EntranceWebNode entrance1 = new EntranceWebNode(1345, 9590, 0, "Entrance", "Pass-through") {
                @Override
                public boolean forceNext() {
                    return true;
                }
            };

            EntranceWebNode entrance2 = new EntranceWebNode(1373, 9664, 0, "Entrance", "Pass-through") {
                @Override
                public boolean forceNext() {
                    return true;
                }
            };

            // Connect entry to existing web
            node12291.addDualConnections(prisonEntry);

            // Add initial nodes to web finder
            WebFinder.getWebFinder().addWebNode(prisonEntry);
            WebFinder.getWebFinder().addWebNode(entrance1);
            WebFinder.getWebFinder().addWebNode(entrance2);

            // Connect entrances to each other (two-way passage)
            entrance1.addConnections(entrance2);
            entrance2.addConnections(entrance1);

            // Create grid coverage for first area (1343, 9597, 1392, 9536, 0)
            List<AbstractWebNode> coverageNodesArea1 = new ArrayList<>();
            for (int x = 1343; x <= 1392; x += 5) {
                for (int y = 9536; y <= 9597; y += 5) {
                    BasicWebNode node = new BasicWebNode(x, y, 0);
                    coverageNodesArea1.add(node);
                    WebFinder.getWebFinder().addWebNode(node);
                }
            }

            // Create grid coverage for second area (1362, 9691, 1406, 9666, 0)
            List<AbstractWebNode> coverageNodesArea2 = new ArrayList<>();
            for (int x = 1362; x <= 1406; x += 5) {
                for (int y = 9666; y <= 9691; y += 5) {
                    BasicWebNode node = new BasicWebNode(x, y, 0);
                    coverageNodesArea2.add(node);
                    WebFinder.getWebFinder().addWebNode(node);
                }
            }

            // Connect nodes within each area to their neighbors
            for (List<AbstractWebNode> areaNodes : List.of(coverageNodesArea1, coverageNodesArea2)) {
                for (int i = 0; i < areaNodes.size(); i++) {
                    AbstractWebNode currentNode = areaNodes.get(i);
                    for (int j = i + 1; j < areaNodes.size(); j++) {
                        AbstractWebNode otherNode = areaNodes.get(j);
                        if (Math.abs(currentNode.getX() - otherNode.getX()) <= 7 &&
                                Math.abs(currentNode.getY() - otherNode.getY()) <= 7) {
                            currentNode.addDualConnections(otherNode);
                        }
                    }
                }
            }

            // Connect prison entry to nearest node in first area
            AbstractWebNode nearestEntryNode = findNearestNode(prisonEntry, coverageNodesArea1);
            if (nearestEntryNode != null) {
                prisonEntry.addDualConnections(nearestEntryNode);
            }

            // Connect entrance1 to nearest node in first area
            AbstractWebNode nearestEntrance1 = findNearestNode(entrance1, coverageNodesArea1);
            if (nearestEntrance1 != null) {
                entrance1.addDualConnections(nearestEntrance1);
            }

            // Connect entrance2 to nearest node in second area
            AbstractWebNode nearestEntrance2 = findNearestNode(entrance2, coverageNodesArea2);
            if (nearestEntrance2 != null) {
                entrance2.addDualConnections(nearestEntrance2);
            }
        }
    }

    private static AbstractWebNode findNearestNode(AbstractWebNode target, List<AbstractWebNode> nodes) {
        AbstractWebNode nearestNode = null;
        int minDistance = Integer.MAX_VALUE;
        for (AbstractWebNode node : nodes) {
            int distance = Math.abs(node.getX() - target.getX()) +
                    Math.abs(node.getY() - target.getY());
            if (distance < minDistance) {
                minDistance = distance;
                nearestNode = node;
            }
        }
        return nearestNode;
    }
}