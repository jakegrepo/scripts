package scripts.Herb.network;

public final class ProtocolConstants {
    public static final String COMMAND_HEADER = "Herb_CMD";
    public static final String EVENT_HEADER = "Herb_EVT";
    public static final String ACK_HEADER = "Herb_ACK";
    public static final int PRIORITY_HIGH = 3;
    public static final int PRIORITY_NORMAL = 2;
    public static final int PRIORITY_LOW = 1;
}
