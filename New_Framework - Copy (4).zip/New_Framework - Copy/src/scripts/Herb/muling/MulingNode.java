package scripts.Herb.muling;

import com.google.gson.JsonObject;
import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.grandexchange.LivePrices;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.trade.Trade;
import org.dreambot.api.methods.trade.TradeUser;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.world.Worlds;
import org.dreambot.api.methods.worldhopper.WorldHopper;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.Player;
import org.dreambot.api.wrappers.items.Item;
import scripts.Herb.HerbGlobalState; // Assuming state exists for pausing other activities
import scripts.Herb.MixologyScript;
import scripts.Herb.config.HerbConfig;
import scripts.Herb.config.MixologyConfig;

import java.io.IOException;
import java.net.Socket;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


/**
 * Handles the process of meeting and trading items with a mule account.
 */
public class MulingNode extends SimpleNode<HerbConfig> {

    private final MixologyScript script;
    private final MuleClient muleClient;
    private MuleStatus status = MuleStatus.IDLE;
    private long lastStatusChangeTime = 0;
    private final long STATUS_TIMEOUT = 180_000; // 3 minutes timeout for most states
    private String muleUsername = null;
    private long muleUsernameLastRequested = 0;

    // Define meeting areas
    private static final Area FEROX_ENCLAVE_BANK = new Area(3134, 3632, 3139, 3627);
    private static final Area GRAND_EXCHANGE_AREA = new Area(3158, 3494, 3171, 3483); // Example GE area
    private Area currentMeetingArea = GRAND_EXCHANGE_AREA; // Default

    public MulingNode(HerbConfig config, MixologyScript script) {
        super("Muling", -15, config); // Highest priority (0)
        this.script = script;
        this.muleClient = new MuleClient(config);
        updateMeetingArea();
    }

    private void updateMeetingArea() {
        String spot = config.getMulingConfig().getMeetingSpot();
        if ("Ferox Enclave".equals(spot)) {
            currentMeetingArea = FEROX_ENCLAVE_BANK;
        } else if ("Grand Exchange".equals(spot)) {
            currentMeetingArea = GRAND_EXCHANGE_AREA;
        } else {
            Logger.warn("MulingNode: Unknown meeting spot '" + spot + "', defaulting to Grand Exchange.");
            currentMeetingArea = GRAND_EXCHANGE_AREA;
        }
        Logger.log("MulingNode: Meeting area set to " + spot);
    }

    private void setStatus(MuleStatus newStatus) {
        if (this.status != newStatus) {
            Logger.log("Mule Status: " + this.status + " -> " + newStatus);
            this.status = newStatus;
            this.lastStatusChangeTime = System.currentTimeMillis();
            // Potentially pause other script activities when muling starts
            if (newStatus != MuleStatus.IDLE && newStatus != MuleStatus.CHECK_CONDITIONS) {
                HerbGlobalState.setMulingInProgress(true);
            } else {
                 HerbGlobalState.setMulingInProgress(false);
            }
        }
    }

     private boolean hasTimedOut() {
        if (status == MuleStatus.IDLE || status == MuleStatus.CHECK_CONDITIONS || status == MuleStatus.COMPLETE) {
            return false; // No timeout for these states
        }
        boolean timedOut = System.currentTimeMillis() - lastStatusChangeTime > STATUS_TIMEOUT;
        if (timedOut) {
            Logger.warn("MuleStatus " + status + " timed out after " + (STATUS_TIMEOUT / 1000) + " seconds.");
            setStatus(MuleStatus.ERROR);
        }
        return timedOut;
    }

    @Override
    public boolean validate() {
        if (!config.getMulingConfig().isEnabled()) {
             if (status != MuleStatus.IDLE) {
                 // If muling was active but now disabled, clean up
                 cleanupMuleConnection();
                 setStatus(MuleStatus.IDLE);
             }
            return false;
        }

        // If already in a muling process, this node should run
        if (status != MuleStatus.IDLE && status != MuleStatus.CHECK_CONDITIONS) {
            return true;
        }

        // Per-item threshold logic, with special handling for coins
        List<String> itemsToMule = config.getMulingConfig().getItemsToMule();
        java.util.Map<String, Integer> itemThresholds = config.getMulingConfig().getItemThresholds();
        boolean thresholdMet = false;
        for (String item : itemsToMule) {
            if ("Coins".equals(item)) {
                int currentCoins = Inventory.count("Coins");
                int coinsToKeep = config.getMulingConfig().getCoinsToKeep();
                int triggerValue = config.getMulingConfig().getTriggerValue();
                if (currentCoins > triggerValue) {
                    Logger.log("MulingNode: Threshold met for coins: " + currentCoins + " > trigger " + triggerValue);
                    thresholdMet = true;
                    break;
                } else {
                    continue;
                }
            }
            int threshold = itemThresholds.getOrDefault(item, 1);
            int count = Inventory.count(item);
            if (count >= threshold) {
                Logger.log("MulingNode: Threshold met for item: " + item + " (" + count + "/" + threshold + ")");
                thresholdMet = true;
                break;
            }
        }
        if (thresholdMet) {
            setStatus(MuleStatus.CHECK_CONDITIONS);
            return true;
        }
        return false;
    }

    @Override
    protected int onExecute() {
        if (hasTimedOut()) {
            handleError("Muling state timed out.");
            return 1000;
        }

        updateMeetingArea(); // Ensure meeting area is up-to-date

        switch (status) {
            case CHECK_CONDITIONS:
                return handleCheckConditions();
            case WALKING_TO_MEET:
                return handleWalkingToMeet();
            case HOPPING_WORLD:
                return handleHoppingWorld();
            case CONNECTING_TO_MULE:
                return handleConnecting();
            case WAITING_FOR_MULE:
                return handleWaitingForMule();
            case TRADING:
                return handleTrading();
             case TRADE_ACCEPTED_NEED_CONFIRM:
                 return handleWaitingForMuleConfirm();
            case WAITING_FOR_COMPLETION:
                 return handleWaitForCompletion();
            case COMPLETE:
                 return handleComplete();
            case DISCONNECTING:
                 return handleDisconnecting();
            case ERROR:
                 return handleError("Muling process encountered an error."); // Fallback error handling
            case IDLE:
            default:
                 // Should not happen if validate() is correct, but good to have a default
                 setStatus(MuleStatus.IDLE);
                 return 1000;
        }
    }

    private int handleCheckConditions() {
        // Double-check conditions before proceeding
        List<String> itemsToMule = config.getMulingConfig().getItemsToMule();
        java.util.Map<String, Integer> itemThresholds = config.getMulingConfig().getItemThresholds();
        boolean thresholdMet = false;
        for (String item : itemsToMule) {
            int threshold = itemThresholds.getOrDefault(item, 1);
            int count = Inventory.count(item);
            if (count >= threshold) {
                Logger.log("MulingNode: Threshold met for item: " + item + " (" + count + "/" + threshold + ")");
                thresholdMet = true;
                break;
            }
        }
        if (thresholdMet) {
            // Close bank if open
            if (Bank.isOpen()) {
                 Logger.log("MulingNode: Closing bank before starting mule process.");
                 Bank.close();
                 Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
                 return 600;
            }
            // Proceed to next step
            Logger.log("MulingNode: Conditions verified. Starting muling process.");
            setStatus(MuleStatus.WALKING_TO_MEET);
            return 100;
        } else {
            // Conditions no longer met
            Logger.log("MulingNode: Conditions no longer met. Returning to IDLE.");
            setStatus(MuleStatus.IDLE);
            return 500;
        }
    }


    private int handleWalkingToMeet() {
        if (currentMeetingArea.contains(Players.getLocal())) {
            Logger.log("MulingNode: Arrived at meeting area.");
            setStatus(MuleStatus.HOPPING_WORLD);
            return 100;
        }

        Logger.log("Walking to " + config.getMulingConfig().getMeetingSpot() + "...");
        if (Walking.shouldWalk(6) && Walking.walk(currentMeetingArea.getCenter())) {
            Sleep.sleepUntil(() -> currentMeetingArea.contains(Players.getLocal()) || !Players.getLocal().isMoving(), 8000, 600);
        }
        Sleep.sleep(600, 800);
        return 600; // Return fixed sleep time
    }

    private int handleHoppingWorld() {
        int targetWorld = config.getMulingConfig().getMuleWorld();
        if (Worlds.getCurrentWorld() == targetWorld) {
            Logger.log("MulingNode: Already in correct world (" + targetWorld + ").");
            setStatus(MuleStatus.CONNECTING_TO_MULE);
            return 100;
        }

        Logger.log("Hopping to world " + targetWorld + "...");
        if (WorldHopper.quickHop(targetWorld)) {
            Logger.log("MulingNode: Hop initiated, waiting for world change...");
            if (Sleep.sleepUntil(() -> Worlds.getCurrentWorld() == targetWorld, 15000, 1000)) {
                Logger.log("MulingNode: Successfully hopped to world " + targetWorld);

                // Add stabilization delay after world hop before attempting to connect
                Logger.log("MulingNode: Adding stabilization delay after world hop (3 seconds)...");
                Sleep.sleep(3000);

                // Verify player state is ready for connection
                if (Players.getLocal() != null && Players.getLocal().exists()) {
                    Logger.log("MulingNode: Player stabilized after world hop, proceeding to connection");
                    setStatus(MuleStatus.CONNECTING_TO_MULE);
                } else {
                    Logger.warn("MulingNode: Player not fully loaded after world hop, adding more delay");
                    Sleep.sleep(2000);
                    if (Players.getLocal() != null && Players.getLocal().exists()) {
                        setStatus(MuleStatus.CONNECTING_TO_MULE);
                    } else {
                        Logger.error("MulingNode: Player failed to stabilize after world hop");
                        setStatus(MuleStatus.ERROR);
                    }
                }
            } else {
                Logger.warn("MulingNode: Failed to confirm world hop.");
                // Consider adding retry logic or error state
                setStatus(MuleStatus.ERROR); // Go to error state on hop fail
            }
        } else {
            Logger.error("MulingNode: WorldHopper.quickHop returned false for world " + targetWorld);
            setStatus(MuleStatus.ERROR); // Go to error state on hop fail
        }
        return 1000; // Return fixed sleep time
    }


    private int handleConnecting() {
        Logger.log("Connecting to mule...");

        // First check if we're in the correct world
        int targetWorld = config.getMulingConfig().getMuleWorld();
        if (Worlds.getCurrentWorld() != targetWorld) {
            Logger.error("MulingNode: World mismatch detected before connection attempt. Current: "
                + Worlds.getCurrentWorld() + ", Target: " + targetWorld);

            // If we're somehow in the wrong world, go back to hopping
            setStatus(MuleStatus.HOPPING_WORLD);
            return 100;
        }

        // Verify settings first
        if (!verifyMuleSettings()) {
            return handleError("Mule settings verification failed - check logs for details");
        }

        // Check if we're already connected first
        if (muleClient.isConnected()) {
            Logger.log("MulingNode: Already connected to mule server");

            // Send our username as the trader
            String traderName = Players.getLocal().getName();
            Logger.log("MulingNode: Sending trader name after (re)connect: " + traderName);
            boolean messageSent = muleClient.sendMessage("TRADER_NAME:" + traderName);
            if (messageSent) {
                setStatus(MuleStatus.WAITING_FOR_MULE);
                return 100;
            } else {
                Logger.error("MulingNode: Failed to send trader name message");
                // Force disconnect and try again
                muleClient.disconnect();
                // Don't immediately return error - fall through to reconnect attempt
            }
        }

        // Add retry logic for connection
        int maxRetries = 3;
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                Logger.log("Connection attempt " + attempt + "/" + maxRetries);

                // Ensure we're disconnected before trying to connect
                if (muleClient.isConnected()) {
                    muleClient.disconnect();
                    Sleep.sleep(1000);
                }

                Logger.log("MulingNode: Attempting to connect to mule server...");
                if (muleClient.connect()) {
                    Logger.log("MulingNode: Successfully connected to mule server");

                    // Wait a moment to ensure the connection is established
                    Sleep.sleep(1000);

                    // Send our username as the trader
                    String traderName = Players.getLocal().getName();
                    Logger.log("MulingNode: Sending trader name after (re)connect: " + traderName);
                    boolean messageSent = muleClient.sendMessage("TRADER_NAME:" + traderName);
                    if (messageSent) {
                        setStatus(MuleStatus.WAITING_FOR_MULE);
                        return 100;
                    } else {
                        Logger.error("MulingNode: Failed to send trader name message");
                        if (attempt == maxRetries) {
                            return handleError("Failed to send message to mule");
                        }
                        // Try again
                        continue;
                    }
                } else {
                    Logger.error("MulingNode: Failed to connect to mule server (attempt " + attempt + "/" + maxRetries + ")");

                    if (attempt == maxRetries) {
                        return handleError("Failed to connect to mule: " + muleClient.getLastError());
                    }

                    // Wait before retrying with increasing backoff
                    int waitTime = 3000 * attempt;
                    Logger.log("MulingNode: Waiting " + (waitTime/1000) + " seconds before retry...");
                    Sleep.sleep(waitTime);
                }
            } catch (Exception e) {
                Logger.error("MulingNode: Exception during connection: " + e.getMessage());

                if (attempt == maxRetries) {
                    return handleError("Exception during mule connection: " + e.getMessage());
                }

                // Wait before retrying with increasing backoff
                int waitTime = 3000 * attempt;
                Logger.log("MulingNode: Waiting " + (waitTime/1000) + " seconds before retry...");
                Sleep.sleep(waitTime);
            }
        }

        // If we get here, all retries failed
        return handleError("Failed to connect to mule after " + maxRetries + " attempts");
    }

    /**
     * Verifies that the mule settings are properly configured
     * @return true if settings appear valid, false otherwise
     */
    private boolean verifyMuleSettings() {
        Logger.info("===============================");
        Logger.info("VERIFYING MULE SETTINGS");
        Logger.info("===============================");

        boolean allValid = true;

        // Get the framework-level muling configuration
        core.config.MulingConfig mulingConfig = config.getMulingConfig();

        // Check port
        int port = mulingConfig.getPort();
        if (port <= 0 || port > 65535) {
            Logger.error("INVALID PORT: " + port + " (must be between 1-65535)");
            allValid = false;
        } else {
            Logger.info("Port setting: " + port + " ✓");
        }

        // Check world
        int world = mulingConfig.getMuleWorld();
        if (world <= 0) {
            Logger.error("INVALID WORLD: " + world);
            allValid = false;
        } else {
            Logger.info("World setting: " + world + " ✓");
        }

        // Check items to mule
        List<String> itemsToMule = mulingConfig.getItemsToMule();
        if (itemsToMule == null || itemsToMule.isEmpty()) {
            Logger.error("NO ITEMS CONFIGURED FOR MULING");
            allValid = false;
        } else {
            Logger.info("Items to mule: " + String.join(", ", itemsToMule) + " ✓");
        }

        // Check if mule server is running on specified port
        try (Socket testSocket = new Socket()) {
            testSocket.connect(new java.net.InetSocketAddress("127.0.0.1", port), 3000);
            Logger.info("Mule server is running and listening on port " + port + " ✓");
        } catch (IOException e) {
            Logger.error("MULE SERVER NOT RUNNING ON PORT " + port);
            Logger.error("Make sure the mule script is running and correctly configured");
            allValid = false;
        }

        Logger.info("===============================");
        if (allValid) {
            Logger.info("Mule settings verification PASSED ✓");
        } else {
            Logger.error("Mule settings verification FAILED ✗");
        }
        Logger.info("===============================");

        return allValid;
    }

    private int handleWaitingForMule() {
        // Check for messages from the mule server
        String message = muleClient.readMessage();
        if (message != null) {
            Logger.log("MulingNode: Received message from mule server: " + message);
            if (message.startsWith("MULE_NAME:")) {
                muleUsername = message.substring("MULE_NAME:".length()).trim();
                Logger.log("MulingNode: Stored mule username: " + muleUsername);
                muleUsernameLastRequested = System.currentTimeMillis();
            }
            // Handle specific messages
            if (message.contains("MULE_READY") || message.contains("READY_TO_TRADE") ||
                message.contains("TRADE_INIT") || message.contains("INITIATE_TRADE") ||
                message.contains("MULE_READY_FOR_TRADE") || message.contains("CLIENT_SHOULD_INITIATE") ||
                message.contains("PLEASE_INITIATE_TRADE")) {
                Logger.log("MulingNode: Mule is ready to trade. Proceeding to trading state.");
                java.util.Map<String, Integer> itemThresholds = config.getMulingConfig().getItemThresholds();
                java.util.List<String> itemsToMule = config.getMulingConfig().getItemsToMule();
                JsonObject json = new JsonObject();
                for (String item : itemsToMule) {
                    json.addProperty(item, itemThresholds.getOrDefault(item, 1));
                }
                muleClient.sendMessage("ITEM_LIST:" + json.toString());
                muleClient.sendMessage("READY_TO_TRADE");
                muleClient.sendMessage("CLIENT_WILL_INITIATE");
                setStatus(MuleStatus.TRADING);
                return 100;
            }
            if (message.contains("STATE_RESET")) {
                Logger.warn("MulingNode: Received STATE_RESET message from mule server: " + message);
                return handleError("Mule server reset its state: " + message);
            }
        }

        // Enhanced stuck/fallback logging
        if (muleUsername == null) {
            Logger.warn("MulingNode: muleUsername is null, cannot proceed. Logging all nearby players:");
            for (Player p : Players.all()) {
                Logger.log("Nearby player: " + p.getName());
            }
            // Fallback: if we've been waiting >10s, log a warning
            if (muleUsernameLastRequested == 0) muleUsernameLastRequested = System.currentTimeMillis();
            if (System.currentTimeMillis() - muleUsernameLastRequested > 10000) {
                Logger.warn("MulingNode: Still have not received muleUsername after 10 seconds. Retrying handshake.");
                muleClient.sendMessage("CONNECT:" + Players.getLocal().getName());
                muleUsernameLastRequested = System.currentTimeMillis();
            }
        }

        if (muleUsername != null) {
            Player mulePlayer = Players.closest(p -> p != null && p.getName().equals(muleUsername));
            if (mulePlayer != null) {
                Logger.log("Mule player found by username. Sending confirmation and initiating trade.");
                muleClient.sendMessage("MULE_FOUND");
                muleClient.sendMessage("READY_TO_TRADE");
                setStatus(MuleStatus.TRADING);
                return 100;
            } else {
                Logger.warn("MulingNode: muleUsername known (" + muleUsername + ") but player not found nearby. Logging all players:");
                for (Player p : Players.all()) {
                    Logger.log("Nearby player: " + p.getName());
                }
            }
        }
        return 1000;
    }

    private int handleTrading() {
        // First check if we're already in a trade
        if (!Trade.isOpen()) {
            // Find the mule player with exact name match and distance check
            if (muleUsername != null) {
                Player mule = Players.closest(p -> p != null && p.getName() != null && p.getName().equals(muleUsername) && p.distance() <= 15);
                if (mule != null) {
                    Logger.log("MulingNode: Found mule by username: " + mule.getName());
                    // Make sure we're close enough to trade
                    if (mule.distance() > 2) {
                        Logger.log("Walking closer to mule for trade...");
                        Walking.walk(mule.getTile());
                        Sleep.sleepUntil(() -> mule.distance() <= 2, 5000);
                        return 600;
                    }

                    Logger.log("Initiating trade with " + mule.getName() + " (distance: " + mule.distance() + ")");

                    // Send message to mule that we're initiating trade
                    muleClient.sendMessage("CLIENT_INITIATING_TRADE");

                    // Try multiple times to initiate trade
                    boolean tradeInitiated = false;
                    int maxAttempts = 5; // Number of trade initiation attempts
                    for (int attempt = 1; attempt <= maxAttempts; attempt++) {
                        Logger.log("Trade attempt " + attempt + "/5");

                        if (Trade.tradeWithPlayer(mule)) {
                            // Wait for trade window to open
                            if (Sleep.sleepUntil(Trade::isOpen, 3000)) {
                                Logger.log("Trade window opened successfully on attempt " + attempt);
                                tradeInitiated = true;
                                break;
                            } else {
                                Logger.warn("Trade window failed to open on attempt " + attempt);
                            }
                        } else {
                            Logger.warn("Failed to initiate trade with " + mule.getName() + " on attempt " + attempt);
                        }

                        // Short delay between attempts
                        Sleep.sleep(300, 500);
                    }

                    if (tradeInitiated) {
                        // Successfully initiated trade
                        return 600;
                    } else {
                        // All attempts failed - escalate to error and abort muling
                        Logger.error("Failed to initiate trade after " + maxAttempts + " attempts");
                        muleClient.sendMessage("TRADE_INITIATION_FAILED");
                        return handleError("Failed to initiate trade after " + maxAttempts + " attempts");
                    }
                } else {
                    Logger.warn("Mule player not found nearby or too far away (by username)");
                    // Check if connection is still active
                    if (!muleClient.isConnected()) {
                        Logger.error("Lost connection to mule server while trying to trade");
                        return handleError("Lost connection to mule server");
                    }
                    // Try to re-establish connection with mule
                    return 2000;
                }
            } else {
                Logger.warn("Mule username not known yet, cannot initiate trade");
                return 1000;
            }
        }

        // At this point, we should be in a trade screen
        if (!Trade.isOpen()) {
            Logger.warn("Expected trade to be open but it's not!");
            return 1000;
        }

        // Get items to trade
        List<String> itemsToMuleNames = config.getMulingConfig().getItemsToMule();

        // Log what we're trying to mule
        Logger.log("Items to mule: " + String.join(", ", itemsToMuleNames));

        // If first screen, offer items
        if (Trade.isOpen(1)) {
            // Get inventory items that match our mule list
            List<Item> itemsToTrade = Inventory.all(item ->
                item != null &&
                itemsToMuleNames.contains(item.getName()));

            Logger.log("Found " + itemsToTrade.size() + " items in inventory to trade");

            // Check if all items have been offered
            boolean allItemsOffered = true;

            for (Item item : itemsToTrade) {
                // Special handling for coins
                if (item.getName().equals("Coins")) {
                    int coinsToKeep = config.getMulingConfig().getCoinsToKeep();
                    int currentCoins = item.getAmount();
                    int coinsToTrade = Math.max(0, currentCoins - coinsToKeep);
                    
                    if (coinsToTrade > 0) {
                        Logger.log("Trading " + coinsToTrade + " coins (keeping " + coinsToKeep + ")");
                        if (Trade.addItem(item.getID(), coinsToTrade)) {
                            Sleep.sleepUntil(() -> {
                                Item updated = Trade.getItem(true, item.getID());
                                return updated != null && updated.getAmount() >= coinsToTrade;
                            }, 3000);
                            return 800;
                        } else {
                            Logger.warn("Failed to add coins to trade");
                        }
                    } else {
                        Logger.log("Not trading coins - keeping " + currentCoins + " (threshold: " + coinsToKeep + ")");
                    }
                    continue;
                }

                // Check if this item is fully offered
                Item offeredItem = Trade.getItem(true, item.getID());
                int offeredAmount = (offeredItem != null) ? offeredItem.getAmount() : 0;

                if (offeredAmount < item.getAmount()) {
                    allItemsOffered = false;
                    int amountToAdd = item.getAmount() - offeredAmount;

                    Logger.log("Adding " + amountToAdd + "x " + item.getName() + " to trade");

                    if (Trade.addItem(item.getID(), amountToAdd)) {
                        Sleep.sleepUntil(() -> {
                            Item updated = Trade.getItem(true, item.getID());
                            return updated != null && updated.getAmount() >= item.getAmount();
                        }, 3000);

                        return 800; // Short delay after adding an item
                    } else {
                        Logger.warn("Failed to add " + item.getName() + " to trade");
                    }

                    // Only try to add one item at a time to avoid issues
                    break;
                }
            }

            // If all items are offered, accept the trade
            if (allItemsOffered) {
                if (!Trade.hasAcceptedTrade(TradeUser.US)) {
                    Logger.log("All items offered, accepting first trade screen");
                    if (Trade.acceptTrade(1)) {
                        Sleep.sleepUntil(() -> Trade.hasAcceptedTrade(TradeUser.US) || Trade.isOpen(2), 5000);
                        return 600;
                    }
                } else {
                    Logger.log("Waiting for mule to accept first screen");
                }
            }
        }
        // If second trade screen is open, accept and complete immediately
        else if (Trade.isOpen(2)) {
            if (!Trade.hasAcceptedTrade(TradeUser.US)) {
                Logger.log("Accepting second trade screen");
                if (Trade.acceptTrade(2)) {
                    // Wait until our acceptance is registered
                    Sleep.sleepUntil(() -> Trade.hasAcceptedTrade(TradeUser.US), 5000);
                    // Complete the muling process now
                    setStatus(MuleStatus.COMPLETE);
                    return 600;
                }
            } else {
                Logger.log("Waiting for mule to accept second screen");
                // Once mule has accepted, complete the process
                if (Trade.hasAcceptedTrade(TradeUser.THEM)) {
                    Logger.log("Both accepted second screen");
                    setStatus(MuleStatus.COMPLETE);
                    return 600;
                }
            }
        }

        return 600;
    }

     private int handleWaitingForMuleConfirm() {
         // Ensure the second trade screen is open
        if (!Trade.isOpen(2)) {
             // If trade closed or went back to first screen, handle appropriately
            if (!Trade.isOpen()) {
                 setStatus(MuleStatus.ERROR); // Trade closed unexpectedly
                 Logger.warn("Trade closed while waiting for second screen confirmation.");
            } else {
                 // Check if it's the first screen (Trade.isOpen(true))
                 if (Trade.isOpen(1)) {
                      setStatus(MuleStatus.TRADING); // Went back to first screen? Re-evaluate trade.
                      Logger.warn("Returned to first trade screen unexpectedly.");
                 } else {
                      // Still on second screen, but perhaps something else went wrong?
                      // Or maybe isOpen(false) briefly returned false. Wait and re-evaluate.
                      Logger.debug("handleWaitingForMuleConfirm: Trade.isOpen(false) returned false, but Trade.isOpen() is true. Re-evaluating...");
                 }
            }
            return 1000; // Return int
         }

        // Check if we have already accepted the second screen
        if (Trade.hasAcceptedTrade(TradeUser.US)) {
             // If we've accepted, check if the mule has too
             if (Trade.hasAcceptedTrade(TradeUser.THEM)) {
                 // Trade should complete shortly after both accept second screen
                 Logger.log("Both accepted second screen. Waiting for trade completion.");
                 setStatus(MuleStatus.WAITING_FOR_COMPLETION);
                 return 1000; // Return int
             } else {
                 // We've accepted, waiting for mule
                 Logger.log("Waiting for mule to accept second screen.");
                 return 1500; // Return int, wait a bit longer
             }
         } else {
            // We haven't accepted the second screen yet, accept it.
            Logger.log("Accepting second trade screen.");
            if (Trade.acceptTrade()) {
                 Sleep.sleepUntil(() -> Trade.hasAcceptedTrade(TradeUser.US), 3000); // Wait for our confirmation
                 return 600; // Return int after accepting
             } else {
                  Logger.warn("Failed to accept second trade screen.");
                  return 1000; // Return int
             }
         }
     }

      private int handleWaitForCompletion() {
           // Wait for trade window to close
           Logger.log("Waiting for trade window to close...");
           if (Sleep.sleepUntil(() -> !Trade.isOpen(), 10000)) {
                Logger.log("Trade completed successfully.");
                setStatus(MuleStatus.COMPLETE);
           } else {
                Logger.warn("Trade window did not close after accepting. Assuming completion.");
                // Force close the trade if it's still open
                if (Trade.isOpen()) {
                    Logger.log("Forcibly closing trade window that didn't close automatically");
                    Trade.close();
                    Sleep.sleepUntil(() -> !Trade.isOpen(), 3000);
                }
                setStatus(MuleStatus.COMPLETE);
           }
           return 600; // Return int
       }

      private int handleComplete() {
           Logger.log("Muling process complete.");

           // Make sure trade is closed
           if (Trade.isOpen()) {
               Trade.close();
               Sleep.sleepUntil(() -> !Trade.isOpen(), 3000);
           }

           // Send trade complete message to mule
           if (muleClient.isConnected()) {
               Logger.log("Sending TRADE_COMPLETE to mule");
               muleClient.sendMessage("TRADE_COMPLETE");
           }

           // Clean up connection
           cleanupMuleConnection();

           // Clear muling in progress flag
           HerbGlobalState.setMulingInProgress(false);

           // Reset state
           setStatus(MuleStatus.IDLE);

           // Log completion for verification
           Logger.info("=============================================");
           Logger.info("MULING COMPLETED SUCCESSFULLY");
           Logger.info("=============================================");

           return 500;
       }

      private int handleDisconnecting() {
            Logger.log("Disconnecting from mule service...");
            muleClient.disconnect();
            setStatus(MuleStatus.IDLE); // Or ERROR depending on context
            return 500; // Return int
      }

      private int handleError(String message) {
          Logger.error("Muling Error: " + message);

          // Close any open trade windows
          if (Trade.isOpen()) {
              Logger.log("Closing trade window due to error");
              Trade.close();
              Sleep.sleepUntil(() -> !Trade.isOpen(), 3000);
          }

          // Try to send error message to mule
          try {
              if (muleClient.isConnected()) {
                  Logger.log("Sending ERROR message to mule");
                  muleClient.sendMessage("ERROR:" + message);
              }
          } catch (Exception e) {
              Logger.error("Failed to send error message to mule: " + e.getMessage());
          }

          // Clean up resources
          cleanupMuleConnection();

          // Clear muling flag
          HerbGlobalState.setMulingInProgress(false);

          // Reset state
          Logger.log("Muling Error. Resetting to IDLE state.");
          setStatus(MuleStatus.IDLE);

          // Log error for visibility
          Logger.info("======================================");
          Logger.info("MULING ERROR: " + message);
          Logger.info("======================================");

          return 3000;
      }

      private void cleanupMuleConnection() {
          try {
              if (muleClient != null) {
                  if (muleClient.isConnected()) {
                      Logger.log("Disconnecting from mule service...");
                      muleClient.disconnect();
                      Logger.log("Successfully disconnected from mule service");
                  }
              }
          } catch (Exception e) {
              Logger.error("Error while disconnecting from mule: " + e.getMessage());
          }
      }


    /**
     * Calculates the estimated GP value of all items in the inventory.
     * Uses Grand Exchange prices for estimation.
     *
     * @return Estimated GP value.
     */
    private long calculateInventoryValue() {
        long totalValue = 0;

        // Count everything in inventory
        Logger.log("MulingNode: Calculating inventory value for all items");

        // Get all inventory items
        List<Item> itemsToValue = Inventory.all();

        Logger.log("MulingNode: Found " + itemsToValue.size() + " items in inventory");

        for (Item item : itemsToValue) {
            if (item != null) {
                int price = LivePrices.getLow(item.getID());
                if (price > 0) { // Ensure GE price is valid
                    long itemValue = (long) price * item.getAmount();
                    totalValue += itemValue;
                    Logger.log("MulingNode: Item " + item.getName() + " x" + item.getAmount() +
                            " = " + itemValue + " gp (price: " + price + ")");
                }
            }
        }

        Logger.log("MulingNode: Total inventory value = " + totalValue + " gp");
        return totalValue;
    }

    @Override
    public void cleanup() {
         Logger.log("MulingNode cleanup called. Current status: " + status);

         // Make sure trade is closed if script stops during trading
         if (Trade.isOpen()) {
             Logger.log("Closing trade window during cleanup");
             Trade.close();
             Sleep.sleepUntil(() -> !Trade.isOpen(), 3000);
         }

         // Ensure connection is closed if script stops during muling
         cleanupMuleConnection();

         // Reset status
         status = MuleStatus.IDLE;

         // Always make sure the muling flag is cleared
         HerbGlobalState.setMulingInProgress(false);

         Logger.log("MulingNode cleanup completed");
    }
}