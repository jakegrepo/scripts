package scripts.Herb.muling;

import org.dreambot.api.utilities.Logger;
import scripts.Herb.config.HerbConfig;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Handles socket communication with the Mule script.
 */
public class MuleClient {
    private final HerbConfig config;
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;
    private boolean connected = false;
    private String lastError = null;

    public MuleClient(HerbConfig config) {
        this.config = config;
    }

    /**
     * Attempts to establish a connection with the mule server.
     *
     * @return true if connection is successful, false otherwise.
     */
    public boolean connect() {
        if (connected) {
            Logger.log("MuleClient: Already connected.");
            return true;
        }
        if (!config.getMulingConfig().isEnabled()) {
             Logger.log("MuleClient: Muling is disabled in config.");
             lastError = "Muling disabled";
             return false;
        }

        String host = "127.0.0.1"; // Assuming mule runs on the same machine for now
        int port = config.getMulingConfig().getPort();

        // Validate port
        if (port <= 0 || port > 65535) {
            lastError = "Invalid port number: " + port;
            Logger.error("MuleClient: " + lastError);
            return false;
        }

        // Log current world for debugging
        int currentWorld = org.dreambot.api.methods.world.Worlds.getCurrentWorld();
        int configWorld = config.getMulingConfig().getMuleWorld();
        Logger.log("MuleClient: Current world: " + currentWorld + ", Config world: " + configWorld);

        if (currentWorld != configWorld) {
            Logger.warn("MuleClient: World mismatch detected. Current: " + currentWorld + ", Expected: " + configWorld);
            Logger.warn("MuleClient: Will attempt connection anyway, but this might cause issues");
        }

        // First verify the server is running
        if (!verifyServerRunning(host, port)) {
            return false;
        }

        Logger.log("MuleClient: Attempting to connect to mule server at " + host + ":" + port);

        try {
            // Log more detailed information for debugging
            Logger.log("MuleClient: Using mule username: " + config.getMulingConfig().getMuleUsername());
            Logger.log("MuleClient: Using mule world: " + config.getMulingConfig().getMuleWorld());
            Logger.log("MuleClient: Using mule meeting spot: " + config.getMulingConfig().getMeetingSpot());

            // Close any existing connection first
            if (clientSocket != null) {
                try {
                    clientSocket.close();
                } catch (Exception e) {
                    // Ignore
                }
                clientSocket = null;
            }

            // Create a new socket with timeout
            clientSocket = new Socket();
            clientSocket.setSoTimeout(10000); // 10 second read timeout
            clientSocket.connect(new java.net.InetSocketAddress(host, port), 5000); // 5 second connection timeout

            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            connected = true;
            lastError = null;
            Logger.log("MuleClient: Connection established successfully.");

            // Send initial greeting or status
            String localPlayerName = org.dreambot.api.methods.interactive.Players.getLocal().getName();
            if (!sendMessage("CONNECT:" + localPlayerName)) {
                Logger.error("MuleClient: Failed to send initial connection message");
                disconnect();
                lastError = "Failed to send initial connection message";
                return false;
            }

            // Send trader name message - this helps mule identify who to trade with
            if (!sendMessage("TRADER_NAME:" + org.dreambot.api.methods.interactive.Players.getLocal().getName())) {
                Logger.error("MuleClient: Failed to send trader name message");
                // Don't disconnect, might still work without it
            }

            // Send meeting spot message - crucial for location synchronization
            if (!sendMessage("MEETING_SPOT:" + config.getMulingConfig().getMeetingSpot())) {
                Logger.error("MuleClient: Failed to send meeting spot message");
                // Don't disconnect, might still work without it
            }

            // Wait for and verify connection acknowledgment
            Logger.log("MuleClient: Waiting for connection acknowledgment...");
            long startTime = System.currentTimeMillis();
            long timeout = 5000; // 5 second timeout

            while (System.currentTimeMillis() - startTime < timeout) {
                String response = readMessage();
                if (response != null) {
                    if (response.contains("CONNECTED") || response.contains("ACK")) {
                        Logger.log("MuleClient: Connection acknowledged by server");
                        break;
                    }
                }
                org.dreambot.api.utilities.Sleep.sleep(100);
            }

            Logger.log("MuleClient: Initial connection message sent successfully");
            return true;
        } catch (UnknownHostException e) {
            lastError = "Unknown host: " + host;
            Logger.error("MuleClient: Connection failed - " + lastError);
            connected = false;
            return false;
        } catch (IOException e) {
            lastError = "I/O error connecting to " + host + ":" + port + " - Is the mule script running?";
            Logger.error("MuleClient: Connection failed - " + lastError + " (" + e.getMessage() + ")");

            // Additional helpful error messages
            if (e.getMessage() != null && e.getMessage().contains("Connection refused")) {
                Logger.error("MuleClient: Connection refused - Ensure the mule script is running and listening on port " + port);
                Logger.error("MuleClient: Also verify no firewall is blocking the connection");
            }

            connected = false;
            return false;
        } catch (Exception e) {
            lastError = "Unexpected error: " + e.getMessage();
            Logger.error("MuleClient: Connection failed with unexpected error - " + lastError);
            e.printStackTrace();
            connected = false;
            return false;
        }
    }

    /**
     * Verifies if the mule server is running and listening on the specified port.
     *
     * @param host The hostname to check
     * @param port The port to check
     * @return true if server appears to be running, false otherwise
     */
    private boolean verifyServerRunning(String host, int port) {
        Logger.log("MuleClient: Verifying server at " + host + ":" + port);

        // Try multiple times with increasing delays
        int retryCount = 3;
        for (int attempt = 1; attempt <= retryCount; attempt++) {
            Socket testSocket = null;
            try {
                Logger.log("MuleClient: Server verification attempt " + attempt + "/" + retryCount);

                testSocket = new Socket();
                // Increase timeout for each retry
                int timeout = 3000 * attempt; // 3, 6, 9 seconds
                testSocket.connect(new java.net.InetSocketAddress(host, port), timeout);

                // If we got here, the connection succeeded
                Logger.log("MuleClient: Server verification successful - port " + port + " is open and accepting connections");
                return true;
            } catch (IOException e) {
                String errorMsg = e.getMessage();
                Logger.error("MuleClient: Server verification attempt " + attempt + " failed: " + errorMsg);

                if (attempt < retryCount) {
                    int backoffTime = 2000 * attempt; // 2, 4, 6 seconds
                    Logger.log("MuleClient: Waiting " + (backoffTime/1000) + " seconds before retry...");
                    org.dreambot.api.utilities.Sleep.sleep(backoffTime);
                } else {
                    // Final attempt failed
                    lastError = "Server verification failed - port " + port + " is not accepting connections";
                    Logger.error("MuleClient: " + lastError);

                    // Provide helpful suggestions
                    Logger.error("MuleClient: Make sure the mule script is running");
                    Logger.error("MuleClient: Verify port " + port + " is correctly configured on both scripts");
                    Logger.error("MuleClient: Check for any firewall blocking the connection");
                    Logger.error("MuleClient: Try restarting both client and mule scripts");

                    // Log current system info
                    Logger.info("MuleClient: Current world: " + org.dreambot.api.methods.world.Worlds.getCurrentWorld());
                    Logger.info("MuleClient: System info: " + System.getProperty("os.name") + " " + System.getProperty("os.version"));

                    return false;
                }
            } finally {
                if (testSocket != null) {
                    try {
                        testSocket.close();
                    } catch (IOException e) {
                        // Ignore
                    }
                }
            }
        }

        // Should never reach here, but just in case
        return false;
    }

    /**
     * Sends a message to the mule server.
     *
     * @param msg The message to send.
     * @return true if the message was sent successfully, false otherwise.
     */
    public boolean sendMessage(String msg) {
        if (!connected || out == null) {
            Logger.warn("MuleClient: Cannot send message, not connected.");
            lastError = "Not connected";
            return false;
        }
        try {
            Logger.debug("MuleClient: Sending message: " + msg);
            out.println(msg);
            return true;
        } catch (Exception e) {
            lastError = "Error sending message: " + e.getMessage();
            Logger.error("MuleClient: " + lastError);
            disconnect(); // Disconnect on send error
            return false;
        }
    }

    /**
     * Reads a message from the mule server (non-blocking).
     *
     * @return The message received, or null if no message is available or not connected.
     */
    public String readMessage() {
        if (!connected || in == null) {
            // Logger.debug("MuleClient: Cannot read message, not connected or reader is null.");
            return null;
        }
        try {
            if (in.ready()) {
                String msg = in.readLine();
                if (msg != null) {
                    Logger.debug("MuleClient: Received message: " + msg);
                }
                return msg;
            }
            return null; // No message available yet
        } catch (IOException e) {
            lastError = "Error reading message: " + e.getMessage();
            Logger.error("MuleClient: " + lastError);
            disconnect(); // Disconnect on read error
            return null;
        }
    }

    /**
     * Disconnects from the mule server.
     */
    public void disconnect() {
        if (!connected) {
            return;
        }
        Logger.log("MuleClient: Disconnecting from mule server...");
        try {
            if (out != null) out.close();
            if (in != null) in.close();
            if (clientSocket != null) clientSocket.close();
        } catch (IOException e) {
            Logger.error("MuleClient: Error closing socket resources: " + e.getMessage());
        } finally {
            connected = false;
            clientSocket = null;
            out = null;
            in = null;
            Logger.log("MuleClient: Disconnected.");
        }
    }

    public boolean isConnected() {
        // Additionally check if socket is actually still valid
         if (connected && clientSocket != null) {
            return !clientSocket.isClosed() && clientSocket.isConnected();
         }
        return false;
    }

    public String getLastError() {
        return lastError;
    }
}