package scripts.Herb;

import org.dreambot.api.methods.grandexchange.LivePrices;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.interactive.GameObject;
import scripts.Herb.nodes.ProcessPotionNode;
import scripts.Herb.utils.MixologyConstants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public class HerbGlobalState {

    // Mixology processing state tracking
    private static final Map<Integer, Boolean> processedPotions = new ConcurrentHashMap<>();
    private static final Map<Integer, Boolean> createdPotions = new ConcurrentHashMap<>();
    private static final Map<Integer, Integer> potionInventorySlots = new ConcurrentHashMap<>(); // Order index -> inventory slot
    private static final Map<Integer, Character> potionProcessingMethods = new ConcurrentHashMap<>(); // Order index -> processing method
    private static final AtomicBoolean readyToDeposit = new AtomicBoolean(false);
    private static List<String> currentOrders = new ArrayList<>();
    private static int totalOrdersToProcess = 0;
    private static boolean processingPhase = false;
    private static final AtomicBoolean mulingInProgress = new AtomicBoolean(false); // Flag for muling
    private static final int RETORT_BUSY_ANIM = MixologyConstants.RETORT_BUSY_ANIMATION_ID;
    private static final int AGITATOR_BUSY_ANIM = MixologyConstants.AGITATOR_BUSY_ANIMATION_ID;
    private static final int ALEMBIC_BUSY_ANIM = MixologyConstants.ALEMBIC_BUSY_ANIMATION_ID;
    private static final AtomicBoolean refineInProgress = new AtomicBoolean(false); // Flag for muling

    // Add tracking for interrupted processing
    private static final Map<Integer, Character> interruptedProcessing = new ConcurrentHashMap<>(); // Order index -> processing method
    private static final Map<Integer, Long> processingStartTime = new ConcurrentHashMap<>(); // Order index -> start time
    private static final Map<Integer, String> processingStation = new ConcurrentHashMap<>(); // Order index -> station name

    // Flag to track when buying rewards is in progress
    private static boolean buyingRewardsInProgress = false;

    /**
     * Set the processing phase flag to indicate transition from mixing to processing
     * 
     * @param active Whether the processing phase is active
     */
    public static void setProcessingPhase(boolean active) {
        processingPhase = active;
    }
    
    /**
     * Check if we're in the processing phase
     * 
     * @return true if in processing phase, false if in mixing phase
     */
    public static boolean isProcessingPhase() {
        return processingPhase;
    }
    
    /**
     * Initialize the potion tracking system for a new set of orders
     * 
     * @param orders List of potion orders to track
     */
    public static void resetTracking(List<String> orders) {
        // Reset all tracking
        processedPotions.clear();
        createdPotions.clear();
        potionInventorySlots.clear();
        potionProcessingMethods.clear();
        potionItemIds.clear(); // Also clear item ID tracking
        readyToDeposit.set(false);
        processingPhase = false; // Reset processing phase
        currentOrders = new ArrayList<>(orders);
        totalOrdersToProcess = orders.size();

        // Initialize each order as not processed and not created
        for (int i = 0; i < orders.size(); i++) {
            processedPotions.put(i, false);
            createdPotions.put(i, false);
        }

    }

    /**
     * Mark a specific potion as processed
     * 
     * @param orderIndex The index of the order (0-based)
     * @param potionName The name of the processed potion
     */
    public static void markPotionProcessed(int orderIndex, String potionName) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            processedPotions.put(orderIndex, true);

            // Check if all potions are processed
            checkAllPotionsProcessed();
        } else {
        }
    }
    
    /**
     * Check if a specific potion has been processed
     * 
     * @param orderIndex The index of the order (0-based)
     * @return true if the potion has been processed, false otherwise
     */
    public static boolean isPotionProcessed(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            return processedPotions.getOrDefault(orderIndex, false);
        }
        return false;
    }
    
    /**
     * Check if all potions have been processed
     * 
     * @return true if all potions are processed, false otherwise
     */
    public static boolean areAllPotionsProcessed() {
        // If there are no orders, return false
        if (totalOrdersToProcess == 0) {
            return false;
        }
        
        // Check each order
        for (int i = 0; i < totalOrdersToProcess; i++) {
            if (!processedPotions.getOrDefault(i, false)) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Check if all potions are processed and set readyToDeposit flag if they are
     */
    private static void checkAllPotionsProcessed() {
        if (areAllPotionsProcessed()) {
            readyToDeposit.set(true);
        }
    }
    
    /**
     * Check if the potions are ready to be deposited
     * 
     * @return true if all potions are processed and ready to deposit, false otherwise
     */
    public static boolean isReadyToDeposit() {
        return readyToDeposit.get();
    }
    
    /**
     * Reset the ready to deposit flag after depositing
     */
    public static void resetDepositState() {
        readyToDeposit.set(false);
        processedPotions.clear();
        createdPotions.clear();
        potionInventorySlots.clear();
        potionProcessingMethods.clear();
        currentOrders.clear();
        totalOrdersToProcess = 0;
        Logger.log("Reset potion deposit state");
    }
    
    /**
     * Get the current list of orders being tracked
     * 
     * @return List of current orders
     */
    public static List<String> getCurrentOrders() {
        return new ArrayList<>(currentOrders);
    }
    
    /**
     * Get the total number of orders being tracked
     * 
     * @return Total number of orders
     */
    public static int getTotalOrdersToProcess() {
        return totalOrdersToProcess;
    }



    private static final Map<Integer, Integer> lootHistory = new ConcurrentHashMap<>();
    private static long totalLootValue = 0;
    
    public static void addLootItem(int itemId, int quantity) {
        int price = LivePrices.getLow(itemId); // Use low price for conservative estimates
        lootHistory.merge(itemId, quantity, Integer::sum);
        totalLootValue += quantity * price;
    }
    
    public static long getTotalLootValue() {
        return totalLootValue;
    }
    
    public static Map<Integer, Integer> getLootHistory() {
        return new HashMap<>(lootHistory);
    }

    /**
     * Mark a specific potion as created
     * 
     * @param orderIndex The index of the order (0-based)
     * @param potionName The name of the created potion
     * @param inventorySlot The inventory slot where the potion is located
     */
    public static void markPotionCreated(int orderIndex, String potionName, int inventorySlot) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            createdPotions.put(orderIndex, true);
            potionInventorySlots.put(orderIndex, inventorySlot);
        } else {
        }
    }
    
    /**
     * Mark a specific potion as created with its processing method
     * 
     * @param orderIndex The index of the order (0-based)
     * @param potionName The name of the created potion
     * @param inventorySlot The inventory slot where the potion is located
     * @param processingMethod The processing method for this potion ('C', 'H', 'Y')
     */
    public static void markPotionCreated(int orderIndex, String potionName, int inventorySlot, Character processingMethod) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            createdPotions.put(orderIndex, true);
            potionInventorySlots.put(orderIndex, inventorySlot);
            if (processingMethod != null) {
                potionProcessingMethods.put(orderIndex, processingMethod);
                Logger.log("Marked potion at index " + orderIndex + " (" + potionName + 
                          ") as created in slot " + inventorySlot + 
                          " with processing method: " + processingMethod);
            } else {
                Logger.log("Marked potion at index " + orderIndex + " (" + potionName + 
                          ") as created in slot " + inventorySlot + 
                          " (no processing method)");
            }
        } else {
            Logger.log("Invalid order index for markPotionCreated: " + orderIndex);
        }
    }
    
    /**
     * Mark a specific potion as created (backward compatibility method)
     * 
     * @param orderIndex The index of the order (0-based)
     * @param potionName The name of the created potion
     */
    public static void markPotionCreated(int orderIndex, String potionName) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            createdPotions.put(orderIndex, true);
            Logger.log("Marked potion at index " + orderIndex + " (" + potionName + ") as created");
        } else {
            Logger.log("Invalid order index for markPotionCreated: " + orderIndex);
        }
    }

    /**
     * Get the inventory slot for a specific potion order
     * 
     * @param orderIndex The index of the order (0-based)
     * @return The inventory slot or -1 if not found
     */
    public static int getPotionInventorySlot(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            return potionInventorySlots.getOrDefault(orderIndex, -1);
        }
        return -1;
    }
    
    /**
     * Get the processing method for a specific potion order
     * 
     * @param orderIndex The index of the order (0-based)
     * @return The processing method character ('C', 'H', 'Y') or null if not found
     */
    public static Character getPotionProcessingMethod(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            return potionProcessingMethods.get(orderIndex);
        }
        return null;
    }
    
    /**
     * Set the processing method for a specific potion order
     * 
     * @param orderIndex The index of the order (0-based)
     * @param processingMethod The processing method character ('C', 'H', 'Y')
     */
    public static void setPotionProcessingMethod(int orderIndex, Character processingMethod) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            potionProcessingMethods.put(orderIndex, processingMethod);
        } else {
        }
    }
    
    /**
     * Checks if we have the inventory slot information for a specific potion order
     * 
     * @param orderIndex The index of the order (0-based)
     * @return true if we have slot information, false otherwise
     */
    public static boolean hasPotionInventorySlot(int orderIndex) {
        return potionInventorySlots.containsKey(orderIndex) && potionInventorySlots.get(orderIndex) >= 0;
    }
    
    /**
     * Check if a specific potion has been created
     * 
     * @param orderIndex The index of the order (0-based)
     * @return true if the potion has been created, false otherwise
     */
    public static boolean isPotionCreated(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            return createdPotions.getOrDefault(orderIndex, false);
        }
        return false;
    }
 
    /**
     * Check if a specific potion is ready to be processed
     * (created but not yet processed)
     * 
     * @param orderIndex The index of the order (0-based)
     * @return true if the potion is ready for processing, false otherwise
     */
    public static boolean isPotionReadyForProcessing(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            return createdPotions.getOrDefault(orderIndex, false) && 
                   !processedPotions.getOrDefault(orderIndex, false);
        }
        return false;
    }

    /**
     * Set the inventory slot for a specific potion order
     * This can be used to track potion positions without marking them as created
     * 
     * @param orderIndex The index of the order (0-based)
     * @param inventorySlot The inventory slot where the potion is located
     */
    public static void setPotionInventorySlot(int orderIndex, int inventorySlot) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            potionInventorySlots.put(orderIndex, inventorySlot);
            Logger.log("Set inventory slot for order #" + (orderIndex + 1) + " to slot " + inventorySlot);
        } else {
            Logger.log("Invalid order index for setPotionInventorySlot: " + orderIndex);
        }
    }

    /**
     * Check if all potions have been created but not all have been processed
     * This is useful to determine if we should switch from the creation phase to the processing phase
     * 
     * @return true if all potions are created but not all processed, false otherwise
     */
    public static boolean areAllPotionsCreatedButNotProcessed() {
        // If there are no orders, return false
        if (totalOrdersToProcess == 0) {
            return false;
        }
        
        boolean allCreated = true;
        boolean allProcessed = true;
        
        // Check each order
        for (int i = 0; i < totalOrdersToProcess; i++) {
            if (!createdPotions.getOrDefault(i, false)) {
                allCreated = false;
            }
            if (!processedPotions.getOrDefault(i, false)) {
                allProcessed = false;
            }
        }
        
        // Return true if all are created but not all are processed
        return allCreated && !allProcessed;
    }

    /**
     * Get detailed information about a specific order's state
     * 
     * @param orderIndex The index of the order (0-based)
     * @return String with detailed information about the order
     */
    public static String getOrderStateInfo(int orderIndex) {
        if (orderIndex < 0 || orderIndex >= totalOrdersToProcess) {
            return "Invalid order index: " + orderIndex;
        }
        
        String orderName = orderIndex < currentOrders.size() ? currentOrders.get(orderIndex) : "unknown";
        boolean isCreated = createdPotions.getOrDefault(orderIndex, false);
        boolean isProcessed = processedPotions.getOrDefault(orderIndex, false);
        int inventorySlot = potionInventorySlots.getOrDefault(orderIndex, -1);
        int itemId = potionItemIds.getOrDefault(orderIndex, -1);
        Character processingMethod = potionProcessingMethods.get(orderIndex);
        
        return String.format("Order #%d: %s - Created: %s, Processed: %s, Inventory Slot: %d, Item ID: %d, Processing Method: %s",
            orderIndex + 1, orderName, isCreated, isProcessed, inventorySlot, itemId,
            processingMethod != null ? processingMethod : "unknown");
    }
    
    /**
     * Log the state of all current orders - useful for debugging
     */
    public static void logAllOrdersState() {

        for (int i = 0; i < totalOrdersToProcess; i++) {
        }
        
    }

    private static final Map<Integer, Integer> potionItemIds = new ConcurrentHashMap<>(); // Order index -> item ID
    
    /**
     * Track an inventory item ID for a specific order
     * This helps with reliable tracking of potions with the same name
     * 
     * @param orderIndex The index of the order (0-based)
     * @param itemId The item ID in inventory
     */
    public static void trackPotionItemId(int orderIndex, int itemId) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            potionItemIds.put(orderIndex, itemId);
        } else {
        }
    }
    
    /**
     * Get the item ID for a specific order
     * 
     * @param orderIndex The index of the order (0-based)
     * @return The item ID or -1 if not found
     */
    public static int getPotionItemId(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            return potionItemIds.getOrDefault(orderIndex, -1);
        }
        return -1;
    }
    
    /**
     * Find an order index by item ID
     * 
     * @param itemId The item ID to search for
     * @return The order index or -1 if not found
     */
    public static int findOrderIndexByItemId(int itemId) {
        for (Map.Entry<Integer, Integer> entry : potionItemIds.entrySet()) {
            if (entry.getValue() == itemId) {
                return entry.getKey();
            }
        }
        return -1;
    }
    
    /**
     * Find the next unprocessed order for a potion name
     * 
     * @param potionName The potion name to match
     * @return The order index or -1 if not found
     */
    public static int findNextUnprocessedOrderForPotion(String potionName) {
        List<String> orders = getCurrentOrders();
        
        for (int i = 0; i < orders.size(); i++) {
            String order = orders.get(i);
            // Check if the potion name matches the order name and it's created but not processed
            if (potionMatchesOrder(potionName, order) && 
                isPotionCreated(i) && 
                !isPotionProcessed(i)) {
                
                return i;
            }
        }
        
        return -1;
    }
    
    /**
     * Find the next uncreated order for a potion name
     * 
     * @param potionName The potion name to match
     * @return The order index or -1 if not found
     */
    public static int findNextUncreatedOrderForPotion(String potionName) {
        List<String> orders = getCurrentOrders();

        // Extract position from potionName if present
        int targetPosition = -1;
        if (potionName.contains(" (order:")) {
            try {
                int startPos = potionName.indexOf(" (order:") + 8;
                int endPos = potionName.indexOf(")", startPos);
                targetPosition = Integer.parseInt(potionName.substring(startPos, endPos));
            } catch (Exception e) {
            }
        }

        // If we have a target position, prioritize it
        if (targetPosition > 0) {
            int index = targetPosition - 1;
            if (index < orders.size() && potionMatchesOrder(potionName, orders.get(index)) && !isPotionCreated(index)) {
                return index;
            }
        }

        // Fallback to first uncreated match
        for (int i = 0; i < orders.size(); i++) {
            if (potionMatchesOrder(potionName, orders.get(i)) && !isPotionCreated(i)) {
                return i;
            }
        }

        return -1;
    }
    
    /**
     * Check if a potion name matches an order string
     */
    public static boolean potionMatchesOrder(String potionName, String orderText) {
        if (potionName == null || orderText == null) {
            return false;
        }

        // Strip position markers for base comparison
        String cleanPotionName = potionName;
        String cleanOrderText = orderText;
        int potionPosMarker = potionName.indexOf(" (order:");
        int orderPosMarker = orderText.indexOf(" (order:");
        String potionPosition = "";
        String orderPosition = "";

        if (potionPosMarker > 0) {
            cleanPotionName = potionName.substring(0, potionPosMarker);
            potionPosition = potionName.substring(potionPosMarker);
        }
        if (orderPosMarker > 0) {
            cleanOrderText = orderText.substring(0, orderPosMarker);
            orderPosition = orderText.substring(orderPosMarker);
        }

        String lowerPotionName = cleanPotionName.toLowerCase();
        String lowerOrderText = cleanOrderText.toLowerCase();

        // If positions are specified, they must match exactly
        if (!potionPosition.isEmpty() && !orderPosition.isEmpty()) {
            return potionName.equals(orderText); // Exact match including position
        }

        // Otherwise, fall back to base name matching
        return lowerPotionName.contains(lowerOrderText) ||
                lowerOrderText.contains(lowerPotionName);
    }

    /**
     * Reset the creation status of an order
     * This is used when an inventory slot has been reused, meaning a previously created
     * potion has been overwritten or replaced
     * 
     * @param orderIndex The index of the order (0-based)
     */
    public static void resetOrderCreationStatus(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            createdPotions.put(orderIndex, false);
            processedPotions.put(orderIndex, false);
            potionInventorySlots.remove(orderIndex);
            potionItemIds.remove(orderIndex);
            potionProcessingMethods.remove(orderIndex);
        } else {
        }
    }
    
    /**
     * Verify that the inventory slot mapping matches the expected strict order-to-slot mapping.
     * In the strict mapping, Order 1 (index 0) should be in slot 0, Order 2 (index 1) in slot 1, etc.
     * 
     * @return true if all mappings are correct, false if any discrepancies were found
     */
    public static boolean verifyStrictInventorySlotMapping() {
        if (totalOrdersToProcess == 0) {
            return true; // No orders to verify
        }
        
        boolean allCorrect = true;
        

        for (int i = 0; i < totalOrdersToProcess; i++) {
            if (createdPotions.getOrDefault(i, false)) {
                int expectedSlot = i; // Strict mapping: index 0 -> slot 0, index 1 -> slot 1, etc.
                int actualSlot = potionInventorySlots.getOrDefault(i, -1);
                
                if (actualSlot != expectedSlot) {
                    allCorrect = false;
                } else {
                }
            }
        }
        
        if (allCorrect) {
        } else {
        }
        
        return allCorrect;
    }
    
    /**
     * Attempt to fix any discrepancies in the inventory slot mapping.
     * This should be called after verifyStrictInventorySlotMapping() has detected issues.
     * 
     * @return true if all discrepancies were fixed or none existed, false if some could not be fixed
     */
    public static boolean fixInventorySlotMapping() {
        if (totalOrdersToProcess == 0) {
            return true; // No orders to fix
        }
        
        boolean allFixed = true;
        

        // First, create a map of current assignments
        Map<Integer, Integer> slotToOrderMap = new HashMap<>(); // slot -> order index
        
        for (int i = 0; i < totalOrdersToProcess; i++) {
            if (createdPotions.getOrDefault(i, false)) {
                int currentSlot = potionInventorySlots.getOrDefault(i, -1);
                
                if (currentSlot >= 0) {
                    slotToOrderMap.put(currentSlot, i);
                }
            }
        }
        
        // Now attempt to fix any discrepancies
        for (int i = 0; i < totalOrdersToProcess; i++) {
            if (createdPotions.getOrDefault(i, false)) {
                int expectedSlot = i; // Strict mapping
                int currentSlot = potionInventorySlots.getOrDefault(i, -1);
                
                if (currentSlot != expectedSlot) {

                    // Check if the expected slot is already taken by another order
                    Integer otherOrderIndex = slotToOrderMap.get(expectedSlot);
                    
                    if (otherOrderIndex != null) {
                        allFixed = false;
                    } else {
                        // Update the mapping
                        potionInventorySlots.put(i, expectedSlot);
                        slotToOrderMap.remove(currentSlot); // Remove the old mapping
                        slotToOrderMap.put(expectedSlot, i); // Add the new mapping
                    }
                }
            }
        }
        
        if (allFixed) {
        } else {
        }
        
        return allFixed;
    }
    
    /**
     * Find an order index by inventory slot
     * 
     * @param inventorySlot The inventory slot to search for
     * @return The order index or -1 if not found
     */
    public static int findOrderIndexByInventorySlot(int inventorySlot) {
        for (Map.Entry<Integer, Integer> entry : potionInventorySlots.entrySet()) {
            if (entry.getValue() == inventorySlot) {
                return entry.getKey();
            }
        }
        return -1;
    }
    
    /**
     * Check if we should use the strict inventory slot mapping
     * In the strict mapping, Order 1 (index 0) should be in slot 0, Order 2 (index 1) in slot 1, etc.
     * This should almost always return true.
     * 
     * @return true if we should use strict slot mapping, false if we should allow flexible mapping
     */
    public static boolean useStrictInventorySlotMapping() {
        return true; // Enforce strict mapping by default
    }
    
    /**
     * Get the expected inventory slot for an order index based on strict mapping
     * 
     * @param orderIndex The index of the order (0-based)
     * @return The expected inventory slot
     */
    public static int getExpectedInventorySlot(int orderIndex) {
        return orderIndex; // Strict mapping: index 0 -> slot 0, index 1 -> slot 1, etc.
    }
    
    /**
     * Log the item IDs in the inventory slots that should contain our potions
     * This is useful for debugging issues with inventory slot mapping
     */
    public static void logInventorySlotContents() {

        for (int i = 0; i < totalOrdersToProcess; i++) {
            int expectedSlot = getExpectedInventorySlot(i);
            org.dreambot.api.wrappers.items.Item item = org.dreambot.api.methods.container.impl.Inventory.getItemInSlot(expectedSlot);
            
            if (item != null) {

            } else {
            }
        }
        
    }

    /**
     * Marks a potion as impossible to make (e.g., due to insufficient level)
     * 
     * @param orderIndex The index of the order to mark as impossible
     */
    public static void markPotionImpossible(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            // Mark as both created and processed to skip it entirely
            createdPotions.put(orderIndex, true);
            processedPotions.put(orderIndex, true);
            impossiblePotions.put(orderIndex, true);
            
        } else {
            Logger.log("Invalid order index for markPotionImpossible: " + orderIndex);
        }
    }

    // Add new map to track impossible potions
    private static final Map<Integer, Boolean> impossiblePotions = new ConcurrentHashMap<>();

    /**
     * Check if a specific potion is marked as impossible to create
     * 
     * @param orderIndex The index of the order (0-based)
     * @return true if the potion is marked as impossible, false otherwise
     */
    public static boolean isPotionImpossible(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            return impossiblePotions.getOrDefault(orderIndex, false);
        }
        return false;
    }

    /**
     * Check if all potions have been created
     * 
     * @return true if all potions are created, false otherwise
     */
    public static boolean areAllPotionsCreated() {
        // If there are no orders, return false
        if (totalOrdersToProcess == 0) {
            return false;
        }
        
        // Check each order
        for (int i = 0; i < totalOrdersToProcess; i++) {
            if (!createdPotions.getOrDefault(i, false) && !impossiblePotions.getOrDefault(i, false)) {
                return false;
            }
        }
        
        return true;
    }

    /**
     * Set the muling in progress flag.
     *
     * @param inProgress true if muling is active, false otherwise.
     */
    public static void setMulingInProgress(boolean inProgress) {
        if (mulingInProgress.get() != inProgress) {
            mulingInProgress.set(inProgress);
            Logger.log("Muling In Progress set to: " + inProgress);
        }
    }

    /**
     * Check if the muling process is currently active.
     *
     * @return true if muling is in progress, false otherwise.
     */
    public static boolean isMulingInProgress() {
        return mulingInProgress.get();
    }

    /**
     * Checks if the script is currently in the mixing phase (actively pulling levers or taking potion).
     * NOTE: This is a placeholder. Needs proper implementation based on MixPotionNode state.
     * For now, we can check if processingPhase is false AND muling is not in progress.
     *
     * @return true if considered to be in the mixing phase.
     */
    public static boolean isMixingPhase() {
        // Placeholder implementation - Needs refinement
        // A better approach might be to have MixPotionNode set a specific state flag here.
        return !isProcessingPhase() && !isMulingInProgress();
    }
    private static boolean isRetortBusy() {
        GameObject retort = GameObjects.closest(obj -> obj != null && obj.getName().contains("Retort"));

        if (retort != null) {
            int anim = retort.getAnimationID();
            if (anim == RETORT_BUSY_ANIM) {
                }
                return true;
                // Reset tracking when animation ends
            }
        return false;
    }
    private static boolean isAgitatorBusy() {
        GameObject agitator = GameObjects.closest(obj -> obj != null && obj.getName().contains("Agitator"));

        if (agitator != null) {
            int anim = agitator.getAnimationID();
            if (anim == AGITATOR_BUSY_ANIM) {
                return true;
            }
        }

        return false;
    }
    private static boolean isAlembicBusy() {
        GameObject alembic = GameObjects.closest(obj -> obj != null && obj.getName().contains("Alembic"));

        if (alembic != null) {
            int anim = alembic.getAnimationID();
            if (anim == ALEMBIC_BUSY_ANIM) {
                }
                return true;
                // Reset state when animation ends
            }
        return false;
    }
    public static boolean isAnyStationBusy() {
        GameObject retort = GameObjects.closest(obj -> obj != null && obj.getName().contains("Retort"));
        GameObject agitator = GameObjects.closest(obj -> obj != null && obj.getName().contains("Agitator"));
        GameObject alembic = GameObjects.closest(obj -> obj != null && obj.getName().contains("Alembic"));

        return (retort != null && retort.getAnimationID() == RETORT_BUSY_ANIM) ||
               (agitator != null && agitator.getAnimationID() == AGITATOR_BUSY_ANIM) ||
               (alembic != null && alembic.getAnimationID() == ALEMBIC_BUSY_ANIM);
    }

    // Method to check if any critical action prevents muling
    public static boolean isCriticalActionPreventingMuling() {
         // Add checks here for states in MixPotionNode, ProcessPotionNode, etc.
         // For now, just check processing phase.
         return isProcessingPhase(); // Simplistic check, expand as needed
    }

    /**
     * Set the refining session in progress flag.
     *
     * @param inProgress true if refining is active, false otherwise.
     */
    public static void setRefiningInProgress(boolean inProgress) {
        if (refineInProgress.get() != inProgress) {
            refineInProgress.set(inProgress);
            Logger.log("Refining In Progress set to: " + inProgress);
        }
    }

    /**
     * Check if the refining process is currently active.
     *
     * @return true if refining is in progress, false otherwise.
     */
    public static boolean isRefiningInProgress() {
        return refineInProgress.get();
    }

    /**
     * Check if buying rewards is currently in progress
     * @return true if the script is currently buying rewards
     */
    public static boolean isBuyingRewardsInProgress() {
        return buyingRewardsInProgress;
    }

    /**
     * Set the buying rewards state
     * @param state true if buying rewards is starting, false when finished
     */
    public static void setBuyingRewardsInProgress(boolean state) {
        buyingRewardsInProgress = state;
    }

    /**
     * Track an interrupted processing operation
     * 
     * @param orderIndex The index of the order being processed
     * @param processingMethod The processing method (C/H/Y)
     * @param stationName The name of the station
     */
    public static void trackInterruptedProcessing(int orderIndex, char processingMethod, String stationName) {
        if (orderIndex >= 0 && orderIndex < totalOrdersToProcess) {
            // Only track if not already tracking this order
            if (!hasInterruptedProcessing(orderIndex)) {
                interruptedProcessing.put(orderIndex, processingMethod);
                processingStation.put(orderIndex, stationName);
                processingStartTime.put(orderIndex, System.currentTimeMillis());
                Logger.log("Tracking interrupted processing for order #" + (orderIndex + 1) + " at " + stationName);
            }
        }
    }

    /**
     * Clear tracking for an interrupted processing operation
     * 
     * @param orderIndex The index of the order
     */
    public static void clearInterruptedProcessing(int orderIndex) {
        if (interruptedProcessing.remove(orderIndex) != null) {
            processingStation.remove(orderIndex);
            processingStartTime.remove(orderIndex);
            Logger.log("Cleared interrupted processing tracking for order #" + (orderIndex + 1));
        }
    }

    /**
     * Check if there is an interrupted processing operation
     * 
     * @param orderIndex The index of the order
     * @return true if there is an interrupted processing operation
     */
    public static boolean hasInterruptedProcessing(int orderIndex) {
        // Also check if the station is actually busy - if it is, we're not really interrupted
        if (isAnyStationBusy()) {
            clearInterruptedProcessing(orderIndex);
            return false;
        }
        return interruptedProcessing.containsKey(orderIndex);
    }

    /**
     * Get the processing method for an interrupted operation
     * 
     * @param orderIndex The index of the order
     * @return The processing method or null if not found
     */
    public static Character getInterruptedProcessingMethod(int orderIndex) {
        return interruptedProcessing.get(orderIndex);
    }

    /**
     * Get the station name for an interrupted operation
     * 
     * @param orderIndex The index of the order
     * @return The station name or null if not found
     */
    public static String getInterruptedProcessingStation(int orderIndex) {
        return processingStation.get(orderIndex);
    }

    /**
     * Get the start time for an interrupted operation
     * 
     * @param orderIndex The index of the order
     * @return The start time or 0 if not found
     */
    public static long getProcessingStartTime(int orderIndex) {
        return processingStartTime.getOrDefault(orderIndex, 0L);
    }
}
