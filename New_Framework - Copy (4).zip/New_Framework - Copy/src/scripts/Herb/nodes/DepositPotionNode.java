package scripts.Herb.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;
import scripts.Herb.HerbGlobalState;
import scripts.Herb.MixologyScript;
import scripts.Herb.config.HerbConfig;
import scripts.Herb.config.MixologyConfig;
import scripts.Herb.listeners.PotionItemListener;
import scripts.Herb.utils.MixologyConstants;
import scripts.Herb.utils.MixologyUtils;

import java.util.Arrays;

public class DepositPotionNode extends SimpleNode<HerbConfig> {
    private static final int CONVEYOR_BELT_ID = MixologyConstants.CONVEYOR_BELT_ID;
    private static final int DIGWEED_ID = MixologyConstants.DIGWEED_ID;
    private static final String DIGWEED_ITEM = "Digweed";
    private static final String MIXALOT_POTION = "Mixalot";

    // Using areas from MixologyConstants
    private static final Area MIXOLOGY_AREA = MixologyConstants.MIXOLOGY_AREA;
    private static final Area CONVEYOR_AREA = MixologyConstants.CONVEYOR_AREA;

    // IDs of processed potions - using the array from MixologyConstants
    private static final int[] PROCESSED_POTION_IDS = MixologyConstants.PROCESSED_POTION_IDS;

    private final MixologyConfig mixologyConfig;
    private final MixologyScript script;
    private PotionItemListener potionListener;

    private enum DepositState {
        COLLECT_DIGWEED, DEPOSIT_POTIONS
    }

    private DepositState currentState = DepositState.DEPOSIT_POTIONS;

    public DepositPotionNode(HerbConfig config, MixologyConfig mixologyConfig, MixologyScript script) {
        super("Deposit Potions", 9, config);
        this.mixologyConfig = mixologyConfig;
        this.script = script;
        // Initialize but don't register the PotionItemListener yet
        this.potionListener = new PotionItemListener(script);
    }


    @Override
    public boolean validate() {
        // Prevent running if muling is active
        if (HerbGlobalState.isMulingInProgress()) {
            return false;
        }

        // Check if we're in the Mixology area
        if (!MIXOLOGY_AREA.contains(Players.getLocal())) {
            return false;
        }

        // CRITICAL: Check if digweed is in slots 0-2, which would interfere with potion processing
        // If so, let DigweedNode handle it first
        Item digweedInCriticalSlot = Inventory.get(item ->
                item != null && item.getName().equals(DIGWEED_ITEM) && item.getSlot() <= 2);

        if (digweedInCriticalSlot != null) {
            Logger.log("[CRITICAL] Cannot deposit potions - Digweed found in slot " + digweedInCriticalSlot.getSlot());
            return false; // Let DigweedNode handle moving the digweed first
        }

        // Count how many processed potions we have in inventory
        int processedPotionCount = countProcessedPotions();

        // IMPORTANT: If we don't have any processed potions in inventory, don't validate
        if (processedPotionCount == 0) {
            return false;
        }

        int orderCount = HerbGlobalState.getTotalOrdersToProcess();

        // HIGHEST PRIORITY: Slot-based validation - if each order has a processed potion in its designated slot
        if (allProcessedPotionsInInventory()) {
            return true;
        }

        // Second check: If we have exactly the processed potions for all orders but not in the expected slots
        if (processedPotionCount > 0 &&
            processedPotionCount == orderCount &&
            orderCount > 0) {
            return true;
        }

        // Third check: If all potions are processed in the global state
        if (HerbGlobalState.areAllPotionsProcessed() && orderCount > 0) {

            // Ensure we have at least the same number of processed potions as total orders
            return processedPotionCount >= orderCount;
        }

        // Fourth check: If we have processed potions with no unprocessed ones, deposit them
        boolean hasUnprocessedPotions = Inventory.contains(item -> {
            if (item == null) return false;
            return isUnprocessedPotion(item.getName());
        });

        // If we have processed potions and no unprocessed potions, validate
        if (processedPotionCount > 0 && !hasUnprocessedPotions &&
            processedPotionCount >= orderCount &&
            orderCount > 0) {
            return true;
        }

        return false;
    }

    @Override
    protected int onExecute() {
        try {
            // Register the potion listener when this node is executed
            if (potionListener != null) {
                potionListener.register();
                Logger.debug("DepositPotionNode registered PotionItemListener");
            }

            depositPotions();
        } catch (Exception e) {
            setStatus("Error: " + e.getMessage());
        }
        return 600;
    }


    private int depositPotions() {
        setStatus("Depositing potions on conveyor belt");

        // Find the conveyor belt
        GameObject conveyorBelt = GameObjects.closest(obj ->
                obj != null && obj.getName().contains("Conveyor belt"));

        if (conveyorBelt == null) {
            setStatus("Conveyor belt not found");
            return 1000;
        }

        // Check if we need to walk to the conveyor belt
        if (conveyorBelt.distance() > 5) {
            setStatus("Walking to conveyor belt");
            Walking.walk(conveyorBelt);
            GameObject finalConveyorBelt = conveyorBelt;
            Sleep.sleepUntil(() -> finalConveyorBelt.distance() <= 5, 5000);
            return 600;
        }

        // Count processed potions first
        int processedPotionCount = countProcessedPotions();
        if (processedPotionCount == 0) {
            setStatus("No processed potions to deposit");
            return 100;
        }

        // CRITICAL: Check if digweed is in slots 0-2, which would interfere with potion processing
        Item digweedInCriticalSlot = Inventory.get(item ->
                item != null && item.getName().equals(DIGWEED_ITEM) && item.getSlot() <= 2);

        if (digweedInCriticalSlot != null) {
            setStatus("Digweed found in critical slot " + digweedInCriticalSlot.getSlot() + ", repositioning before deposit");
            Logger.log("[CRITICAL] Digweed found in slot " + digweedInCriticalSlot.getSlot() + " before deposit");

            // Try to move digweed to a safe slot
            for (int slot = 3; slot < 28; slot++) {
                if (Inventory.getItemInSlot(slot) == null) {
                    if (Inventory.drag(DIGWEED_ITEM, slot)) {
                        Logger.log("Successfully moved digweed to slot " + slot);
                        Sleep.sleep(600, 800);
                        break;
                    }
                }
            }
        }

        // Check if we need to use digweed on mixalot potion before depositing
        if (mixologyConfig.isUseDigweedOnMixalot()) {
            Item digweed = Inventory.get(DIGWEED_ITEM);
            Item mixalot = Inventory.get(item -> item != null && item.getName().contains(MIXALOT_POTION));

            if (digweed != null && mixalot != null) {
                setStatus("Using digweed on mixalot potion before depositing");
                Logger.info("Using digweed on mixalot potion before depositing");

                if (digweed.useOn(mixalot)) {
                    // Increment digweed->mixalot tracker in overlay
                    if (config.getMixologyOverlay() != null) {
                        config.getMixologyOverlay().incrementDigweedMixalotUses();
                    } else if (script != null && script.getOverlay() != null) {
                        script.getOverlay().incrementDigweedMixalotUses();
                    }
                    Sleep.sleepUntil(() -> !Inventory.contains(DIGWEED_ITEM), 3000);
                    // Short delay after using digweed
                    Sleep.sleep(300, 500);
                }
            }
        }

        // Log the priority deposit status if we have exactly the right number of potions
        if (processedPotionCount == HerbGlobalState.getTotalOrdersToProcess()) {
        }

        // Deposit each processed potion
        Item[] inventoryItems = Inventory.all(item -> isProcessedPotion(item.getID())).toArray(new Item[0]);
        if (inventoryItems.length > 0) {
            setStatus("Depositing " + inventoryItems.length + " processed potions");

            for (Item potion : inventoryItems) {
                if (potion != null) {
                    setStatus("Depositing " + potion.getName());
                    if (conveyorBelt.interact("Fulfil-order")) {
                        // Wait for the deposit animation to complete
                        if (Sleep.sleepUntil(() -> !Inventory.contains(potion.getID()), 3000)) {
                            // Record the completed potion in the overlay
                            if (config.getMixologyOverlay() != null) {
                                MixologyUtils.recordCompletedOrder(
                                        config.getMixologyOverlay(),
                                        potion.getName()
                                );
                            }

                            // If we no longer have any processed potions, reset tracking and return
                            if (countProcessedPotions() == 0) {
                                HerbGlobalState.resetTracking(HerbGlobalState.getCurrentOrders());
                                HerbGlobalState.resetDepositState();
                                return 600;
                            }

                            // Small delay between deposits
                            Sleep.sleep(300, 500);
                        }
                    }
                }
            }

            // If we somehow still have processed potions, reset tracking anyway
            if (countProcessedPotions() == 0) {
                HerbGlobalState.resetTracking(HerbGlobalState.getCurrentOrders());
                HerbGlobalState.resetDepositState();
            }

            return 600;
        }

        return 300;
    }

    /**
     * Count the number of processed potions in the inventory
     *
     * @return Count of processed potions
     */
    private int countProcessedPotions() {
        return Inventory.count(item -> isProcessedPotion(item.getID()));
    }

    private boolean isProcessedPotion(int itemId) {
        return Arrays.stream(PROCESSED_POTION_IDS).anyMatch(id -> id == itemId);
    }

    /**
     * Check if a potion is unprocessed by looking at its name
     *
     * @param itemName The name of the item
     * @return true if the item is an unprocessed potion, false otherwise
     */
    private boolean isUnprocessedPotion(String itemName) {
        if (itemName == null) return false;

        String lowerItemName = itemName.toLowerCase();
        return lowerItemName.contains("alco") ||
                lowerItemName.contains("mammoth") ||
                lowerItemName.contains("mystic") ||
                lowerItemName.contains("liplack") ||
                lowerItemName.contains("marley") ||
                lowerItemName.contains("azure") ||
                lowerItemName.contains("aqualux") ||
                lowerItemName.contains("megalite") ||
                lowerItemName.contains("anti-leech") ||
                lowerItemName.contains("mixalot");
    }





    /**
     * Checks if all processed potions for the current orders are in the inventory
     * This is a more comprehensive check than just counting
     *
     * @return true if all processed potions are in inventory and ready to deposit
     */
    private boolean allProcessedPotionsInInventory() {
        // First get how many orders we have
        int orderCount = HerbGlobalState.getTotalOrdersToProcess();
        if (orderCount == 0) {
            return false;
        }

        // Count processed potions
        int processedPotionCount = countProcessedPotions();

        // Quick count check first
        if (processedPotionCount < orderCount) {
            return false;
        }

        // Do we have any unprocessed potions that might be confused with processed ones?
        boolean hasUnprocessedPotions = Inventory.contains(item -> {
            if (item == null) return false;
            return isUnprocessedPotion(item.getName());
        });

        if (hasUnprocessedPotions) {
            return false;
        }

        // CRITICAL VALIDATION: Verify the strict inventory slot mapping is correct
        if (!HerbGlobalState.verifyStrictInventorySlotMapping()) {

            // Try to fix it
            if (HerbGlobalState.fixInventorySlotMapping()) {
            } else {
                return false;
            }
        }

        // Slot-based validation: Check if each order's designated slot contains a processed potion
        for (int i = 0; i < orderCount && i < 3; i++) {
            // Get the expected slot from the global state
            int expectedSlot = HerbGlobalState.getExpectedInventorySlot(i);
            Item itemInSlot = Inventory.getItemInSlot(expectedSlot);

            // If the slot is empty or doesn't contain a processed potion, validation fails
            if (itemInSlot == null) {
                return false;
            }

            int itemId = itemInSlot.getID();
            if (!isProcessedPotion(itemId)) {
                return false;
            }

            // Compare with what's stored in global state
            int trackedItemId = HerbGlobalState.getPotionItemId(i);
            if (trackedItemId != -1 && trackedItemId != itemId) {
                // Update the tracking
                HerbGlobalState.trackPotionItemId(i, itemId);
            }
        }

        // For extra safety, check if global state shows all potions as processed
        boolean allProcessed = true;
        for (int i = 0; i < orderCount; i++) {
            // Check if there's any order that's created but not yet processed
            if (HerbGlobalState.isPotionCreated(i) && !HerbGlobalState.isPotionProcessed(i)) {
                allProcessed = false;

                // Try to mark it as processed if we can confirm it's really processed
                int expectedSlot = HerbGlobalState.getExpectedInventorySlot(i);
                Item itemInSlot = Inventory.getItemInSlot(expectedSlot);

                if (itemInSlot != null && isProcessedPotion(itemInSlot.getID())) {
                    HerbGlobalState.markPotionProcessed(i, itemInSlot.getName());
                } else {
                    return false; // Can't auto-correct this issue
                }
            }
        }

        // If we got here, we have the right number of processed potions, no unprocessed ones,
        // all orders in global state are properly marked as processed, and each slot contains the right item
        return true;
    }

    @Override
    public void cleanup() {
        setStatus("Cleaning up deposit potion node");

        // Unregister the PotionItemListener if it exists
        if (potionListener != null) {
            try {
                potionListener.unregister();
                Logger.debug("DepositPotionNode unregistered PotionItemListener");
            } catch (Exception e) {
                Logger.error("Error in DepositPotionNode.cleanup(): " + e.getMessage());
            }
        }
    }

}