package scripts.Herb.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.widget.Widget;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;
import org.dreambot.api.wrappers.widgets.WidgetChild;
import org.dreambot.api.methods.widget.Widgets;
import scripts.Herb.MixologyScript;
import scripts.Herb.config.HerbConfig;
import scripts.Herb.config.MixologyConfig;
import scripts.Herb.utils.MixologyConstants;
import scripts.Herb.utils.MixologyUtils;
import scripts.Herb.HerbGlobalState;
import scripts.Herb.listeners.PotionItemListener;
import org.dreambot.api.methods.settings.PlayerSettings;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static scripts.Herb.utils.MixologyConstants.MIXING_AREA;

public class MixPotionNode extends SimpleNode<HerbConfig> {


    // Using areas from MixologyConstants
    private static final Area MIXOLOGY_AREA = MixologyConstants.MIXOLOGY_AREA;

    // Widget IDs for order interface
    private static final int ORDER_WIDGET_ID = 882;
    private static final int ORDER_WIDGET_CHILD_ID = 2;

    // Texture IDs for processing methods
    private static final int CRYSTALLIZE_TEXTURE_ID = 5673;
    private static final int CONCENTRATE_TEXTURE_ID = 5672;
    private static final int HOMOGENIZE_TEXTURE_ID = 5674;

    // Animation constants
    private static final int[] EQUIPMENT_BUSY_ANIMATION_IDS = {
            MixologyConstants.RETORT_BUSY_ANIMATION_ID,
            MixologyConstants.ALEMBIC_BUSY_ANIMATION_ID,
            MixologyConstants.AGITATOR_BUSY_ANIMATION_ID
    };

    // Potion recipes - key is potion name, value is sequence of pastes (M=Mox, L=Lye, A=Aga)
    private static final Map<String, String> POTION_RECIPES = new HashMap<>();
    static {
        POTION_RECIPES.put("Alco-augmentator", MixologyConstants.ALCO_AUGMENTATOR_RECIPE);
        POTION_RECIPES.put("Mammoth-might mix", MixologyConstants.MAMMOTH_MIGHT_RECIPE);
        POTION_RECIPES.put("Liplack liquor", MixologyConstants.LIPLACK_LIQUOR_RECIPE);
        POTION_RECIPES.put("Mystic mana amalgam", MixologyConstants.MYSTIC_MANA_RECIPE);
        POTION_RECIPES.put("Marley's moonlight", MixologyConstants.MARLEYS_MOONLIGHT_RECIPE);
        POTION_RECIPES.put("Azure aura mix", MixologyConstants.AZURE_AURA_RECIPE);
        POTION_RECIPES.put("AquaLux amalgam", MixologyConstants.AQUALUX_RECIPE);
        POTION_RECIPES.put("Megalite liquid", MixologyConstants.MEGALITE_RECIPE);
        POTION_RECIPES.put("Anti-leech lotion", MixologyConstants.ANTI_LEECH_RECIPE);
        POTION_RECIPES.put("MixaLot", MixologyConstants.MIXALOT_RECIPE);
    }

    // Map to store level requirements for each potion, using constants from MixologyConstants
    private static final Map<String, Integer> POTION_LEVEL_REQUIREMENTS = new HashMap<>();
    static {
        POTION_LEVEL_REQUIREMENTS.put("alco", MixologyConstants.ALCO_AUGMENTATOR_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("mammoth", MixologyConstants.MAMMOTH_MIGHT_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("liplack", MixologyConstants.LIPLACK_LIQUOR_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("mystic", MixologyConstants.MYSTIC_MANA_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("marley", MixologyConstants.MARLEYS_MOONLIGHT_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("azure", MixologyConstants.AZURE_AURA_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("aqualux", MixologyConstants.AQUALUX_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("megalite", MixologyConstants.MEGALITE_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("anti-leech", MixologyConstants.ANTI_LEECH_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("mixalot", MixologyConstants.MIXALOT_LEVEL);
    }

    private final MixologyConfig mixologyConfig;
    private PotionItemListener potionListener;
    private final MixologyScript script;

    private enum MixState {
        CHECK_ORDERS, PULL_LEVERS, TAKE_POTION
    }

    private MixState currentState = MixState.CHECK_ORDERS;
    private String currentRecipe = "";
    private int currentStep = 0;
    private String selectedPotionName = "";

    public MixPotionNode(HerbConfig config, MixologyConfig mixologyConfig, MixologyScript script) {
        super("Mix Potion", 2, config);
        this.mixologyConfig = mixologyConfig;
        this.potionListener = new PotionItemListener(context.getScript());
        this.script = script;
    }



    @Override
    public boolean validate() {
        // First check if refining is needed (similar to SimpleRefineHerbNode)
        Map<String, Integer> pasteTotals = getVarbitPaste();
        int threshold = (int)(0.20 * 3000); // LOW_THRESHOLD_RATIO * MAX_STORAGE
        boolean needsRefining = pasteTotals.get("Mox") < threshold || 
                              pasteTotals.get("Lye") < threshold || 
                              pasteTotals.get("Aga") < threshold;

        if (needsRefining && !Inventory.contains(MixologyConstants.UNPROCESSED_POTION_IDS)) {
            Logger.log("Refining needed - skipping MixPotionNode validation");
            return false;
        }

        // Debug logging to help diagnose issues

        if (!MIXOLOGY_AREA.contains(Players.getLocal()) || Inventory.isFull()) {
            return false;
        }

        // CRITICAL FIX: Add check to ensure we transition to processing phase when all potions are created but not processed
        if (HerbGlobalState.areAllPotionsCreatedButNotProcessed() && !HerbGlobalState.isProcessingPhase()) {
            Logger.log("MixPotionNode: All potions are created but not processed, setting processing phase");
            HerbGlobalState.setProcessingPhase(true);
            return false; // Let ProcessPotionNode take over
        }

        GameObject retort = GameObjects.closest("Retort");
        GameObject alembic = GameObjects.closest("Alembic");
        GameObject agitator = GameObjects.closest("Agitator");
        if (isEquipmentBusy(retort) || isEquipmentBusy(alembic) || isEquipmentBusy(agitator)) {
            setStatus("Processing equipment is in use, waiting...");
            return false;
        }

        List<PotionOrder> orders = getOrdersFromWidget();


        List<String> currentOrders = HerbGlobalState.getCurrentOrders();
        if (currentOrders.isEmpty()) {
            List<String> orderTexts = orders.stream().map(PotionOrder::getOrderText).collect(Collectors.toList());
            HerbGlobalState.resetTracking(orderTexts);
            Logger.log("Initialized global state with orders: " + orderTexts);
            return true;
        }

        // If we're in processing phase, don't run this node
        if (HerbGlobalState.isProcessingPhase()) {
            setStatus("In processing phase, skipping potion creation");
            return false;
        }

        // Find the next uncreated order
        int nextOrderIndex = -1;
        for (int i = 0; i < currentOrders.size(); i++) {
            if (!HerbGlobalState.isPotionCreated(i)) {
                nextOrderIndex = i;
                Logger.log("Found next uncreated order at index " + i + ": " + currentOrders.get(i));
                break;
            }
        }

        // If all potions are created, set processing phase
        if (nextOrderIndex == -1) {
            setStatus("All potions created, switching to processing phase");
            HerbGlobalState.setProcessingPhase(true);
            return false; // Let ProcessPotionNode take over
        }

        return true;
    }

    @Override
    protected int onExecute() {
        try {
            switch (currentState) {
                case CHECK_ORDERS:
                    return checkOrders();
                case PULL_LEVERS:
                    return pullLevers();
                case TAKE_POTION:
                    return takePotion();
                default:
                    return 100;
            }
        } catch (Exception e) {
            setStatus("Error: " + e.getMessage());
            return 600;
        }
    }

    /**
     * Gets the list of active orders from the widget interface
     *
     * @return List of potion orders that are currently ordered
     */
    private List<PotionOrder> getOrdersFromWidget() {
        List<PotionOrder> orders = new ArrayList<>();

        // Get the main widget for orders
        Widget orderWidget = Widgets.getWidget(ORDER_WIDGET_ID);
        if (orderWidget == null) {
            Logger.log("Order widget not found");
            return orders;
        }

        // Get the container child that holds the order entries
        WidgetChild orderContainer = orderWidget.getChild(ORDER_WIDGET_CHILD_ID);
        if (orderContainer == null) {
            Logger.log("Order container not found");
            return orders;
        }

        // Loop through children to find order entries
        WidgetChild[] children = orderContainer.getChildren();
        if (children == null) {
            Logger.log("Order children not found");
            return orders;
        }

        Logger.log("Found " + children.length + " widget children to check");

        // Look for potion entries at specific indices (2, 4, 6)
        if (children.length >= 3) {
            // First potion entry
            if (children.length >= 3 && children[2] != null &&
                    children[2].getText() != null && !children[2].getText().isEmpty()) {
                String orderText = children[2].getText();
                Character processingMethod = getProcessingMethod(orderText);
                String processMethodStr = processingMethod != null ? String.valueOf(processingMethod) : "unknown";

                // Add a position marker to uniquely identify this order
                String orderWithPosition = orderText + " (order:1)";

                orders.add(new PotionOrder(orderWithPosition, processingMethod, 1));
                Logger.log("Found order 1: " + orderText + " (Processing method: " + processMethodStr + ")");
            }

            // Second potion entry
            if (children.length >= 5 && children[4] != null &&
                    children[4].getText() != null && !children[4].getText().isEmpty()) {
                String orderText = children[4].getText();
                Character processingMethod = getProcessingMethod(orderText);
                String processMethodStr = processingMethod != null ? String.valueOf(processingMethod) : "unknown";

                // Add a position marker to uniquely identify this order
                String orderWithPosition = orderText + " (order:2)";

                orders.add(new PotionOrder(orderWithPosition, processingMethod, 2));
                Logger.log("Found order 2: " + orderText + " (Processing method: " + processMethodStr + ")");
            }

            // Third potion entry
            if (children.length >= 7 && children[6] != null &&
                    children[6].getText() != null && !children[6].getText().isEmpty()) {
                String orderText = children[6].getText();
                Character processingMethod = getProcessingMethod(orderText);
                String processMethodStr = processingMethod != null ? String.valueOf(processingMethod) : "unknown";

                // Add a position marker to uniquely identify this order
                String orderWithPosition = orderText + " (order:3)";

                orders.add(new PotionOrder(orderWithPosition, processingMethod, 3));
                Logger.log("Found order 3: " + orderText + " (Processing method: " + processMethodStr + ")");
            }
        }

        return orders;
    }

    /**
     * Gets the processing method required for a given order
     *
     * @param orderText The order text
     * @return 'C' for Concentrate, 'H' for Homogenize, 'Y' for Crystallize, or null if not found
     */
    private Character getProcessingMethod(String orderText) {
        // Extract order position if it exists in the text
        int orderPosition = -1;
        if (orderText.contains(" (order:")) {
            try {
                int startPos = orderText.indexOf(" (order:") + 8;
                int endPos = orderText.indexOf(")", startPos);
                if (endPos > startPos) {
                    String posStr = orderText.substring(startPos, endPos);
                    orderPosition = Integer.parseInt(posStr);
                    Logger.log("Extracted order position " + orderPosition + " from order text");
                }
            } catch (Exception e) {
                Logger.log("Error extracting order position: " + e.getMessage());
            }
        }

        // If we have a valid order position, use the direct widget mapping approach
        if (orderPosition > 0 && orderPosition <= 3) {
            // Use the utility method from PotionIdentifier for consistency
            Character processingMethod = scripts.Herb.utils.PotionIdentifier.getProcessingMethodForOrderPosition(orderPosition);
            if (processingMethod != null) {
                Logger.log("Using direct widget mapping for order position " + orderPosition +
                        ": " + processingMethod);
                return processingMethod;
            }
        }

        // If we don't have a position or couldn't get the method that way, try direct widget search
        // Convert orderText to lowercase for case-insensitive comparison
        String lowerOrderText = orderText.toLowerCase();

        // Strip position markers if present for text matching
        if (lowerOrderText.contains(" (order:")) {
            int posMarker = lowerOrderText.indexOf(" (order:");
            lowerOrderText = lowerOrderText.substring(0, posMarker);
        }

        // Get the widget container
        Widget orderWidget = Widgets.getWidget(ORDER_WIDGET_ID);
        if (orderWidget == null) {
            Logger.log("Order widget not found");
            return null;
        }

        WidgetChild orderContainer = orderWidget.getChild(ORDER_WIDGET_CHILD_ID);
        if (orderContainer == null) {
            Logger.log("Order container not found");
            return null;
        }

        // Find the widget child for this order
        WidgetChild[] children = orderContainer.getChildren();
        if (children == null || children.length < 7) {
            Logger.log("Order children not found or insufficient");
            return null;
        }

        // Check each of the potion widgets (indices 2, 4, 6) and their corresponding processing method widgets (indices 1, 3, 5)

        // Check the first potion-processing pair (Order 1)
        if (children[2] != null && children[2].getText() != null &&
                !children[2].getText().isEmpty() &&
                children[2].getText().toLowerCase().contains(lowerOrderText)) {

            int textureId = children[1].getTextureId();
            Logger.log("Found matching potion at index 2, processing method texture: " + textureId +
                    " - this is Order 1");

            return getProcessingMethodFromTextureId(textureId);
        }

        // Check the second potion-processing pair (Order 2)
        if (children[4] != null && children[4].getText() != null &&
                !children[4].getText().isEmpty() &&
                children[4].getText().toLowerCase().contains(lowerOrderText)) {

            int textureId = children[3].getTextureId();
            Logger.log("Found matching potion at index 4, processing method texture: " + textureId +
                    " - this is Order 2");

            return getProcessingMethodFromTextureId(textureId);
        }

        // Check the third potion-processing pair (Order 3)
        if (children[6] != null && children[6].getText() != null &&
                !children[6].getText().isEmpty() &&
                children[6].getText().toLowerCase().contains(lowerOrderText)) {

            int textureId = children[5].getTextureId();
            Logger.log("Found matching potion at index 6, processing method texture: " + textureId +
                    " - this is Order 3");

            return getProcessingMethodFromTextureId(textureId);
        }

        // If still not found, try the fallback to static mapping
        Logger.log("Falling back to static mapping for: " + orderText);
        for (Map.Entry<String, Character> entry : MixologyConstants.PROCESSING_METHODS.entrySet()) {
            if (lowerOrderText.contains(entry.getKey().toLowerCase())) {
                return entry.getValue();
            }
        }

        return null;
    }

    /**
     * Determines the processing method based on the texture ID
     *
     * @param textureId The texture ID from the widget
     * @return Processing method character
     */
    private Character getProcessingMethodFromTextureId(int textureId) {
        if (textureId == CRYSTALLIZE_TEXTURE_ID) {
            return 'Y'; // Crystallize
        } else if (textureId == CONCENTRATE_TEXTURE_ID) {
            return 'C'; // Concentrate
        } else if (textureId == HOMOGENIZE_TEXTURE_ID) {
            return 'H'; // Homogenize
        }
        return null;
    }

    private int checkOrders() {
        // Debug logging to help diagnose issues

        setStatus("Checking potion orders from widget");

        // Get the current herblore level
        int herbloreLevel = Skills.getRealLevel(Skill.HERBLORE);
        Logger.log("Current Herblore level: " + herbloreLevel);

        // Log all available recipes for debugging
        Logger.log("==== Available Recipes ====");
        for (Map.Entry<String, String> entry : POTION_RECIPES.entrySet()) {
            Logger.log("Recipe: " + entry.getKey() + " -> " + entry.getValue());
        }
        Logger.log("==========================");

        // Get orders from widget
        List<PotionOrder> orders = getOrdersFromWidget();
        if (orders.isEmpty()) {
            setStatus("No orders found in the widget. Moving closer");
            if (!Inventory.isEmpty() && !Bank.isOpen()){
                Bank.open();
                Sleep.sleepUntil(Bank::isOpen, 5000);
            }
            if (!Inventory.isEmpty() && Bank.isOpen()){
                Bank.depositAllItems();
                Sleep.sleepUntil(Inventory::isEmpty, 5000);
            }
            Walking.walk(MIXING_AREA);
            Sleep.sleepUntil(() -> MIXING_AREA.contains(Players.getLocal()), 3000);
            return 1000;
        }

        // Define clear mappings between potion identifiers, level requirements, and recipe keys
        Map<String, Integer> levelMap = new HashMap<>();
        levelMap.put("alco", MixologyConstants.ALCO_AUGMENTATOR_LEVEL);
        levelMap.put("mammoth", MixologyConstants.MAMMOTH_MIGHT_LEVEL);
        levelMap.put("liplack", MixologyConstants.LIPLACK_LIQUOR_LEVEL);
        levelMap.put("mystic", MixologyConstants.MYSTIC_MANA_LEVEL);
        levelMap.put("marley", MixologyConstants.MARLEYS_MOONLIGHT_LEVEL);
        levelMap.put("azure", MixologyConstants.AZURE_AURA_LEVEL);
        levelMap.put("aqualux", MixologyConstants.AQUALUX_LEVEL);
        levelMap.put("megalite", MixologyConstants.MEGALITE_LEVEL);
        levelMap.put("anti-leech", MixologyConstants.ANTI_LEECH_LEVEL);
        levelMap.put("mixalot", MixologyConstants.MIXALOT_LEVEL);

        Map<String, String> recipeKeyMap = new HashMap<>();
        recipeKeyMap.put("alco", "Alco-augmentator");
        recipeKeyMap.put("mammoth", "Mammoth-might mix");
        recipeKeyMap.put("liplack", "Liplack liquor");
        recipeKeyMap.put("mystic", "Mystic mana amalgam");
        recipeKeyMap.put("marley", "Marley's moonlight");
        recipeKeyMap.put("azure", "Azure aura mix");
        recipeKeyMap.put("aqualux", "AquaLux amalgam");
        recipeKeyMap.put("megalite", "Megalite liquid");
        recipeKeyMap.put("anti-leech", "Anti-leech lotion");
        recipeKeyMap.put("mixalot", "MixaLot");

        // Find the next uncreated order index
        List<String> currentOrders = HerbGlobalState.getCurrentOrders();
        int nextOrderIndex = -1;
        for (int i = 0; i < currentOrders.size(); i++) {
            if (!HerbGlobalState.isPotionCreated(i)) {
                nextOrderIndex = i;
                Logger.log("Next uncreated order is at index " + i + ": " + currentOrders.get(i));
                break;
            }
        }

        if (nextOrderIndex == -1) {
            setStatus("All orders already created");
            return 1000;
        }

        // Find the matching potion order in the widget orders
        String nextOrderText = currentOrders.get(nextOrderIndex);
        PotionOrder targetOrder = null;

        // Try to match the order by position first
        int orderPosition = nextOrderIndex + 1; // Convert to 1-based
        for (PotionOrder order : orders) {
            if (order.getOrderPosition() == orderPosition) {
                targetOrder = order;
                Logger.log("Found matching order by position: " + order.getOrderText());
                break;
            }
        }

        // If not found by position, try by name
        if (targetOrder == null) {
            for (PotionOrder order : orders) {
                if (potionMatchesOrder(nextOrderText, order.getOrderText())) {
                    targetOrder = order;
                    Logger.log("Found matching order by name: " + order.getOrderText());
                    break;
                }
            }
        }

        if (targetOrder == null) {
            setStatus("Could not find matching order for: " + nextOrderText);
            return 1000;
        }

        String orderText = targetOrder.getOrderText();
        String orderLower = orderText.toLowerCase();
        Character processingMethod = targetOrder.getProcessingMethod();

        Logger.log("Processing next order: " + orderText +
                " (Processing method: " + (processingMethod != null ? processingMethod : "unknown") + ")");

        // Find the matching potion by looking for key identifier words
        boolean foundMatchingPotion = false;
        boolean insufficientLevel = false;
        String matchedKey = null;
        int requiredLevel = -1;

        for (String key : levelMap.keySet()) {
            if (orderLower.contains(key)) {
                requiredLevel = levelMap.get(key);
                matchedKey = key;
                String recipeKey = recipeKeyMap.get(key);

                Logger.log("Found match: " + key + ", recipe key: " + recipeKey +
                        ", required level: " + requiredLevel + ", current level: " + herbloreLevel);

                // Check if the recipe key exists in POTION_RECIPES
                if (!POTION_RECIPES.containsKey(recipeKey)) {
                    Logger.log("ERROR: Recipe key '" + recipeKey + "' not found in POTION_RECIPES map!");
                    // Try case-insensitive search for debugging
                    for (String existingKey : POTION_RECIPES.keySet()) {
                        if (existingKey.equalsIgnoreCase(recipeKey)) {
                            Logger.log("Found case-insensitive match: '" + existingKey + "' instead of '" + recipeKey + "'");
                            recipeKey = existingKey; // Use the existing key with correct case
                            break;
                        }
                    }
                }

                // Check if we have the required level
                if (herbloreLevel >= requiredLevel) {
                    Logger.log("Sufficient level to make: " + orderText);
                    selectedPotionName = orderText;

                    // Get the recipe with additional logging
                    String recipe = POTION_RECIPES.get(recipeKey);
                    if (recipe == null) {
                        Logger.log("ERROR: No recipe found for key: " + recipeKey);
                        continue;
                    }

                    currentRecipe = recipe;
                    currentStep = 0;

                    setStatus("Selected potion: " + recipeKey + " with recipe: " + currentRecipe +
                            " (Processing method: " + (processingMethod != null ? processingMethod : "unknown") + ")");
                    currentState = MixState.PULL_LEVERS;
                    foundMatchingPotion = true;
                    return 100;
                } else {
                    Logger.log("Insufficient level for " + orderText + " (need " + requiredLevel + ", have " + herbloreLevel + ")");
                    insufficientLevel = true;
                }

                // We found a match for this order, so break whether we have the level or not
                break;
            }
        }

        // If we found a matching potion but don't have the level, mark it as impossible
        if (!foundMatchingPotion && insufficientLevel && matchedKey != null && requiredLevel > 0) {
            Logger.log("CRITICAL: Cannot make potion for order " + (nextOrderIndex + 1) +
                    " (" + orderText + ") due to insufficient Herblore level " +
                    "(need " + requiredLevel + ", have " + herbloreLevel + "). Marking as impossible.");

            // Skip this potion and mark it as impossible to make
            HerbGlobalState.markPotionImpossible(nextOrderIndex);

            // Reset state to check the next order
            currentState = MixState.CHECK_ORDERS;
            // Return immediately after marking impossible instead of continuing
            return 100;
        }
        // If we've checked all potions and didn't find one we can make, mark this order as impossible
        else if (!foundMatchingPotion) {
            setStatus("No suitable orders found for current Herblore level (" + herbloreLevel + ")");

            // We already have nextOrderIndex from above, so don't redefine it here
            if (nextOrderIndex != -1) {
                Logger.log("CRITICAL: Cannot identify potion recipe for order " + (nextOrderIndex + 1) +
                        ". Marking as impossible.");

                // Skip this potion and mark it as impossible to make
                HerbGlobalState.markPotionImpossible(nextOrderIndex);

                // Reset state to check the next order
                currentState = MixState.CHECK_ORDERS;
                // Return immediately to re-evaluate
                return 100;
            }
        }

        return 600;
    }

    private int pullLevers() {
        // Debug logging to help diagnose issues

        // Check if there's already a potion in the vessel that we might've accidentally created
        GameObject mixingVessel = GameObjects.closest(obj ->
                obj != null && obj.getName().contains("Mixing vessel") && !obj.getName().contains("Empty"));

        if (mixingVessel != null && !mixingVessel.getName().equals("Mixing vessel (Empty)")) {
            // There's a potion in the vessel, check if we can actually take it
            String vesselName = mixingVessel.getName();
            Logger.log("Found existing potion in mixing vessel: " + vesselName);

            // Extract the potion name
            String existingPotionName = null;
            if (vesselName.contains("Mixing vessel (") && vesselName.endsWith(")")) {
                existingPotionName = vesselName.substring("Mixing vessel (".length(), vesselName.length() - 1);
                Logger.log("Extracted existing potion name: " + existingPotionName);

                // Check if we have the level for this potion
                int herbloreLevel = Skills.getRealLevel(Skill.HERBLORE);
                boolean canTakePotion = true;

                // Check against our level requirements maps
                for (Map.Entry<String, Integer> entry : POTION_LEVEL_REQUIREMENTS.entrySet()) {
                    if (existingPotionName.toLowerCase().contains(entry.getKey().toLowerCase())) {
                        int requiredLevel = entry.getValue();
                        if (herbloreLevel < requiredLevel) {
                            canTakePotion = false;
                            Logger.log("Cannot take existing potion: " + existingPotionName +
                                    " (requires level " + requiredLevel + ", we have " + herbloreLevel + ")");

                            // We have a potion we can't take, let's just continue pulling levers
                            Logger.log("RECOVERY: Continuing with lever sequence to replace the impossible potion");
                            break;
                        }
                    }
                }

                // If we can take the potion and it's not uncompleted, take it regardless of lever steps
                if (canTakePotion && !vesselName.equals("Mixing vessel (Uncompleted)")) {
                    Logger.log("Found a valid potion we can take, switching to take potion state");
                    currentState = MixState.TAKE_POTION;
                    return 100;
                }
                // Otherwise we continue with lever pulling
            }
        }

        // Only check recipe steps if we don't have a valid potion to take
        if (currentStep >= currentRecipe.length()) {
            currentState = MixState.TAKE_POTION;
            return 100;
        }

        char nextIngredient = currentRecipe.charAt(currentStep);
        GameObject leverToUse = null;

        switch (nextIngredient) {
            case 'M':
                leverToUse = GameObjects.closest(obj ->
                        obj != null && obj.getName().contains("Mox lever"));
                Logger.log("Pulling Mox Lever");
                setStatus("Pulling Mox lever");
                break;
            case 'L':
                leverToUse = GameObjects.closest(obj ->
                        obj != null && obj.getName().contains("Lye lever"));
                Logger.log("Pulling Lye Lever");
                setStatus("Pulling Lye lever");
                break;
            case 'A':
                leverToUse = GameObjects.closest(obj ->
                        obj != null && obj.getName().contains("Aga lever"));
                Logger.log("Pulling Aga Lever");
                setStatus("Pulling Aga lever");
                break;
        }

        if (leverToUse == null) {
            setStatus("Lever not found");
            return 600;
        }

        // Check if we need to walk to the lever
        if (leverToUse.distance() >= 2) {
            setStatus("Walking to lever");
            if (Walking.walk(leverToUse)) {
                GameObject finalLeverToUse = leverToUse;
                Sleep.sleepUntil(() -> finalLeverToUse.distance() <= 1, 5000);
            }
            return 600;
        }

        // Pull the lever - note the added Sleep.sleepUntil to make sure the interaction completes
        if (leverToUse.interact("Operate")) {
            Logger.log("Pulling " + leverToUse.getName());
            setStatus("Pulling " + leverToUse.getName());
            Sleep.sleepUntil(() -> Players.getLocal().getAnimation() != 11619,3000);
            Logger.log("Successfully pulled lever for ingredient: " + nextIngredient);
            currentStep++;
            } else {
            Logger.log("Failed to pull lever for ingredient: " + nextIngredient + ". Retrying...");
            return 600;
        }
        return 600;
    }

    private int takePotion() {
        // Debug logging to help diagnose issues

        // Find the mixing vessel first to check its state
        GameObject mixingVessel = GameObjects.closest(obj ->
                obj != null && obj.getName().contains("Mixing vessel") && !obj.getName().contains("Empty"));

        // If vessel is empty and we're in TAKE_POTION state, reset and try again
        if (mixingVessel == null || mixingVessel.getName().equals("Mixing vessel (Empty)")) {
            Logger.log("Vessel is empty in TAKE_POTION state, resetting lever sequence");
            currentStep = 0;
            currentState = MixState.PULL_LEVERS;
            return 100;
        }

        // Get the current herblore level
        int herbloreLevel = Skills.getRealLevel(Skill.HERBLORE);

        // Check if the vessel contains a potion we don't have the level for
        String vesselName = mixingVessel.getName();
        Logger.log("Found mixing vessel with name: " + vesselName);

        // Check if the vessel contains an uncompleted potion - special case
        if (vesselName.equals("Mixing vessel (Uncompleted)")) {
            Logger.log("Found uncompleted potion in vessel. Need to continue pulling levers");
            setStatus("Uncompleted potion in vessel. Continuing lever sequence");
            // Continue the lever sequence from the current step
            currentState = MixState.PULL_LEVERS;
            return 100;
        }

        // Extract the potion name from the vessel name
        String potionName = null;
        if (vesselName.contains("Mixing vessel (") && vesselName.endsWith(")")) {
            potionName = vesselName.substring("Mixing vessel (".length(), vesselName.length() - 1);
            Logger.log("Extracted potion name from vessel: " + potionName);
        }

        // Check if the potion requires a level we don't have
        boolean hasRequiredLevel = true;
        if (potionName != null) {
            // Convert potion name to lowercase for case-insensitive matching
            String lowerPotionName = potionName.toLowerCase();

            // FIRST CHECK: Check against level requirements using our potion identifiers
            for (Map.Entry<String, Integer> entry : POTION_LEVEL_REQUIREMENTS.entrySet()) {
                if (lowerPotionName.contains(entry.getKey().toLowerCase())) {
                    int requiredLevel = entry.getValue();
                    Logger.log("Potion '" + potionName + "' requires level " + requiredLevel + ", we have " + herbloreLevel);

                    if (herbloreLevel < requiredLevel) {
                        hasRequiredLevel = false;
                        Logger.log("WARNING: We accidentally created a potion we don't have the level for: " +
                                potionName + " (need " + requiredLevel + ", have " + herbloreLevel + "). Continuing lever sequence.");
                        break;
                    }
                }
            }

            // SECOND CHECK: Direct check against recipe keys for better detection
            if (hasRequiredLevel) {
                for (Map.Entry<String, String> entry : POTION_RECIPES.entrySet()) {
                    String potionKey = entry.getKey();
                    if (potionName.equalsIgnoreCase(potionKey) || lowerPotionName.contains(potionKey.toLowerCase())) {
                        // The potion matches a recipe key, check if we have the required level
                        int requiredLevel = -1;

                        // Find the matching level requirement
                        if (potionKey.toLowerCase().contains("alco")) requiredLevel = MixologyConstants.ALCO_AUGMENTATOR_LEVEL;
                        else if (potionKey.toLowerCase().contains("mammoth")) requiredLevel = MixologyConstants.MAMMOTH_MIGHT_LEVEL;
                        else if (potionKey.toLowerCase().contains("liplack")) requiredLevel = MixologyConstants.LIPLACK_LIQUOR_LEVEL;
                        else if (potionKey.toLowerCase().contains("mystic")) requiredLevel = MixologyConstants.MYSTIC_MANA_LEVEL;
                        else if (potionKey.toLowerCase().contains("marley")) requiredLevel = MixologyConstants.MARLEYS_MOONLIGHT_LEVEL;
                        else if (potionKey.toLowerCase().contains("azure")) requiredLevel = MixologyConstants.AZURE_AURA_LEVEL;
                        else if (potionKey.toLowerCase().contains("aqualux")) requiredLevel = MixologyConstants.AQUALUX_LEVEL;
                        else if (potionKey.toLowerCase().contains("megalite")) requiredLevel = MixologyConstants.MEGALITE_LEVEL;
                        else if (potionKey.toLowerCase().contains("anti-leech")) requiredLevel = MixologyConstants.ANTI_LEECH_LEVEL;
                        else if (potionKey.toLowerCase().contains("mixalot")) requiredLevel = MixologyConstants.MIXALOT_LEVEL;

                        if (requiredLevel > 0) {
                            Logger.log("Direct recipe check: '" + potionName + "' matches recipe '" + potionKey +
                                    "' which requires level " + requiredLevel);

                            if (herbloreLevel < requiredLevel) {
                                hasRequiredLevel = false;
                                Logger.log("DIRECT RECIPE CHECK: We don't have the required level for " +
                                        potionKey + " (need " + requiredLevel + ", have " + herbloreLevel + ")");
                                break;
                            }
                        }
                    }
                }
            }
        }

        // If we don't have the required level, just continue pulling levers
        if (!hasRequiredLevel) {
            setStatus("Created potion we can't take (" + potionName + "). Continuing lever sequence.");
            Logger.log("RECOVERY: Continuing lever sequence to create the correct potion");

            // We don't reset currentStep to 0 here - we just continue the sequence where we are
            // This should replace the potion in the vessel with a new one

            // Check if we've already used all steps in the recipe
            if (currentStep >= currentRecipe.length()) {
                // If we've used all steps but still can't take the potion,
                // we need to reset and start over
                currentStep = 0;
                Logger.log("Used all steps in recipe but created a potion we can't take. Resetting lever sequence.");
            }

            // Switch to lever pulling state and continue
            currentState = MixState.PULL_LEVERS;
            return 100;
        }

        // Rest of the method for taking a valid potion remains the same
        setStatus("Taking potion from mixing vessel");

        // Check if we need to walk to the mixing vessel
        if (mixingVessel.distance() >= 5) {
            setStatus("Walking to mixing vessel");
            if (Walking.walk(mixingVessel)) {
                Sleep.sleepUntil(() -> mixingVessel.distance() <= 5, 1800);
            }
            return 600;
        }

        // Find the next uncreated order index (0-based)
        List<String> currentOrders = HerbGlobalState.getCurrentOrders();
        int nextUncreatedIndex = -1;
        for (int i = 0; i < currentOrders.size(); i++) {
            if (!HerbGlobalState.isPotionCreated(i)) {
                nextUncreatedIndex = i;
                Logger.log("Next uncreated order is at index " + i + ": " + currentOrders.get(i));
                break;
            }
        }

        if (nextUncreatedIndex == -1) {
            Logger.log("WARNING: No uncreated orders found, but still attempting to create a potion");
            setStatus("No orders need creation, checking again");
            currentState = MixState.CHECK_ORDERS;
            return 600;
        }

        // CRITICAL CHECK: Verify the target inventory slot is empty and available
        int targetInventorySlot = nextUncreatedIndex; // Direct mapping
        Item existingItem = Inventory.getItemInSlot(targetInventorySlot);

        if (existingItem != null) {
            Logger.log("WARNING: Target inventory slot " + targetInventorySlot +
                    " already contains item: " + existingItem.getName() +
                    " (ID: " + existingItem.getID() + ")");

            // Check if this is for a created but unprocessed order
            if (HerbGlobalState.isPotionCreated(targetInventorySlot) &&
                    !HerbGlobalState.isPotionProcessed(targetInventorySlot)) {
                Logger.log("CRITICAL WARNING: Slot " + targetInventorySlot +
                        " already contains a potion for order " + (targetInventorySlot + 1) +
                        " but we're trying to create a potion for order " + (nextUncreatedIndex + 1));

                // We should not proceed - this would mess up the strict slot mapping
                setStatus("Inventory slot conflict - cannot proceed");
                Logger.log("ABORTING potion creation to prevent slot mapping corruption");
                currentState = MixState.CHECK_ORDERS;
                return 1000;
            }
        }

        // Take the potion
        if (mixingVessel.interact("Take-from")) {
            setStatus("Taking potion from mixing vessel");

            // Wait until we get the potion in our inventory
            if (Sleep.sleepUntil(() -> GameObjects.closest("Mixing vessel (Empty)") != null, 3000)) {
                // Map order index directly to inventory slot (crucial part!)
                // STRICT MAPPING: Order 1 (index 0) -> slot 0
                //                 Order 2 (index 1) -> slot 1
                //                 Order 3 (index 2) -> slot 2

                // Get processing method directly from widget based on order position
                int orderPosition = nextUncreatedIndex + 1;
                Character processingMethod = scripts.Herb.utils.PotionIdentifier.getProcessingMethodForOrderPosition(orderPosition);

                if (processingMethod == null) {
                    // Fallback to existing widget order lookup
                    List<PotionOrder> widgetOrders = getOrdersFromWidget();
                    for (PotionOrder order : widgetOrders) {
                        if (order.getOrderPosition() == orderPosition) {
                            processingMethod = order.getProcessingMethod();
                            Logger.log("Found processing method " + processingMethod + " for order at position " + orderPosition);
                            break;
                        }
                    }
                }

                Logger.log("Using processing method: " + processingMethod + " for order position: " + orderPosition);

                // Verify the potion is actually in the expected slot
                Item newPotion = Inventory.getItemInSlot(targetInventorySlot);
                if (newPotion == null) {
                    Logger.log("ERROR: Expected newly created potion to be in slot " + targetInventorySlot +
                            " but slot is empty!");

                    // Try to find the new potion elsewhere in inventory
                    for (int id : MixologyConstants.UNPROCESSED_POTION_IDS) {
                        Item potentialPotion = Inventory.get(id);
                        if (potentialPotion != null) {
                            int actualSlot = potentialPotion.getSlot();
                            int potionItemId = potentialPotion.getID();

                            Logger.log("FOUND newly created potion in slot " + actualSlot +
                                    " instead of expected slot " + targetInventorySlot);

                            // Mark the potion as created but note the slot discrepancy
                            if (processingMethod != null) {
                                HerbGlobalState.markPotionCreated(nextUncreatedIndex, selectedPotionName, actualSlot, processingMethod);
                            } else {
                                HerbGlobalState.markPotionCreated(nextUncreatedIndex, selectedPotionName, actualSlot);
                            }

                            // Track the item ID
                            HerbGlobalState.trackPotionItemId(nextUncreatedIndex, potionItemId);

                            Logger.log("WARNING: Potion for order " + (nextUncreatedIndex + 1) +
                                    " created in incorrect slot " + actualSlot +
                                    " (should be in slot " + targetInventorySlot + ")");

                            // Debug log the state
                            HerbGlobalState.logAllOrdersState();

                            // Update overlay
                            if (config.getMixologyOverlay() != null) {
                                MixologyUtils.recordCompletedOrder(config.getMixologyOverlay(), selectedPotionName);
                                recordPointsForRecipe();
                            }

                            // Continue to check orders
                            currentState = MixState.CHECK_ORDERS;
                            return 600;
                        }
                    }

                    Logger.log("CRITICAL ERROR: Could not find newly created potion anywhere in inventory!");
                    currentState = MixState.CHECK_ORDERS;
                    return 600;
                } else {
                    // The potion is in the expected slot - perfect!
                    int potionItemId = newPotion.getID();

                    Logger.log("SUCCESS: Created potion is in correct slot " + targetInventorySlot +
                            " for order " + (nextUncreatedIndex + 1) +
                            " with ID " + potionItemId);

                    // Mark the potion as created with the correct inventory slot matching its order position
                    if (processingMethod != null) {
                        HerbGlobalState.markPotionCreated(nextUncreatedIndex, selectedPotionName, targetInventorySlot, processingMethod);
                    } else {
                        HerbGlobalState.markPotionCreated(nextUncreatedIndex, selectedPotionName, targetInventorySlot);
                    }

                    // Track item ID
                    HerbGlobalState.trackPotionItemId(nextUncreatedIndex, potionItemId);

                    Logger.log("Successfully marked order " + (nextUncreatedIndex + 1) + " (" + selectedPotionName +
                            ") as created in inventory slot " + targetInventorySlot +
                            " with item ID " + potionItemId);

                    // Debug log the state
                    HerbGlobalState.logAllOrdersState();

                    // Update overlay
                    if (config.getMixologyOverlay() != null) {
                        MixologyUtils.recordCompletedOrder(config.getMixologyOverlay(), selectedPotionName);
                        recordPointsForRecipe();
                    }

                    // Check if all potions are created
                    boolean allCreated = true;
                    for (int i = 0; i < currentOrders.size(); i++) {
                        if (!HerbGlobalState.isPotionCreated(i)) {
                            allCreated = false;
                            break;
                        }
                    }

                    // If all potions are created, switch to processing phase
                    if (allCreated) {
                        setStatus("All potions created, switching to processing phase");
                        HerbGlobalState.setProcessingPhase(true);
                    }

                    // Reset to check next order
                    currentState = MixState.CHECK_ORDERS;
                    return 600;
                }
            } else {
                Logger.log("Failed to take potion from mixing vessel. Retrying...");
            }

            return 600;
        }

        return 600;
    }

    /**
     * Record points gained for the current recipe to the overlay
     */
    private void recordPointsForRecipe() {
        int redPoints = 0, greenPoints = 0, bluePoints = 0;
        for (char c : currentRecipe.toCharArray()) {
            switch (c) {
                case 'M': redPoints += 5; break;
                case 'L': greenPoints += 5; break;
                case 'A': bluePoints += 5; break;
            }
        }
        MixologyUtils.recordPointsGained(config.getMixologyOverlay(), redPoints, greenPoints, bluePoints);
    }

    @Override
    public void cleanup() {
        setStatus("Cleaning up mix potion node");

        // Make sure we clean up properly
        if (potionListener != null) {
            try {
                context.getScript().getScriptManager().removeListener(potionListener);

                // Also call the listener's cleanup method if it has one
                if (potionListener instanceof scripts.Herb.listeners.PotionItemListener) {
                    ((scripts.Herb.listeners.PotionItemListener) potionListener).cleanup();
                }

                Logger.log("Successfully unregistered PotionItemListener during cleanup");
            } catch (Exception e) {
                Logger.log("Error unregistering PotionItemListener: " + e.getMessage());
            }
        }
    }

    /**
     * Checks if the given equipment object is currently busy with an animation
     *
     * @param equipment The GameObject to check
     * @return true if the equipment is busy, false otherwise
     */
    private boolean isEquipmentBusy(GameObject equipment) {
        if (equipment == null) {
            return false;
        }

        int animationId = equipment.getAnimationID();
        for (int busyAnimationId : EQUIPMENT_BUSY_ANIMATION_IDS) {
            if (animationId == busyAnimationId) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if a potion name matches an order string
     */
    private boolean potionMatchesOrder(String potionName, String orderText) {
        return HerbGlobalState.potionMatchesOrder(potionName, orderText);
    }

    // Store potion order information
    private static class PotionOrder {
        private final String orderText;
        private final Character processingMethod;
        private final int orderPosition;

        public PotionOrder(String orderText, Character processingMethod, int orderPosition) {
            this.orderText = orderText;
            this.processingMethod = processingMethod;
            this.orderPosition = orderPosition;
        }

        public String getOrderText() {
            return orderText;
        }

        public Character getProcessingMethod() {
            return processingMethod;
        }

        public int getOrderPosition() {
            return orderPosition;
        }

        public String getOriginalOrderText() {
            // Remove position marker if present
            int posMarker = orderText.indexOf(" (order:");
            if (posMarker > 0) {
                return orderText.substring(0, posMarker);
            }
            return orderText;
        }

        @Override
        public String toString() {
            return orderText;
        }
    }

    /**
     * Helper method to log debug information about the current potion creation state
     * This can help diagnose issues when things go wrong
     */
    private void logMixingDebugInfo() {
        Logger.log("========== MIXING DEBUG INFO ==========");
        Logger.log("Current state: " + currentState);
        Logger.log("Current recipe: " + currentRecipe);
        Logger.log("Current step: " + currentStep + "/" + (currentRecipe.length()));
        Logger.log("Selected potion: " + selectedPotionName);

        // Log herblore level
        int herbloreLevel = Skills.getRealLevel(Skill.HERBLORE);
        Logger.log("Current Herblore level: " + herbloreLevel);

        // Check mixing vessel
        GameObject mixingVessel = GameObjects.closest(obj ->
                obj != null && obj.getName().contains("Mixing vessel"));

        if (mixingVessel != null) {
            Logger.log("Mixing vessel state: " + mixingVessel.getName());

            // Check if vessel has a potion we can analyze
            if (!mixingVessel.getName().equals("Mixing vessel (Empty)") &&
                    !mixingVessel.getName().equals("Mixing vessel")) {

                String vesselName = mixingVessel.getName();
                if (vesselName.contains("Mixing vessel (") && vesselName.endsWith(")")) {
                    String potionName = vesselName.substring("Mixing vessel (".length(), vesselName.length() - 1);
                    Logger.log("Vessel contains potion: " + potionName);

                    // Check potion level requirements
                    for (Map.Entry<String, Integer> entry : POTION_LEVEL_REQUIREMENTS.entrySet()) {
                        if (potionName.toLowerCase().contains(entry.getKey().toLowerCase())) {
                            int requiredLevel = entry.getValue();
                            Logger.log("Potion requires level " + requiredLevel +
                                    " (we have " + herbloreLevel + "): " +
                                    (herbloreLevel >= requiredLevel ? "CAN MAKE" : "CANNOT MAKE"));
                            break;
                        }
                    }
                }
            }
        } else {
            Logger.log("Mixing vessel not found in area");
        }

        // Log current orders
        List<String> currentOrders = HerbGlobalState.getCurrentOrders();
        Logger.log("Current orders: " + currentOrders.size());
        for (int i = 0; i < currentOrders.size(); i++) {
            String orderStatus = "";
            if (HerbGlobalState.isPotionCreated(i)) {
                orderStatus += "CREATED";
                if (HerbGlobalState.isPotionProcessed(i)) {
                    orderStatus += ", PROCESSED";
                } else {
                    orderStatus += ", NOT PROCESSED";
                }
                if (HerbGlobalState.isPotionImpossible(i)) {
                    orderStatus += ", IMPOSSIBLE";
                }
            } else {
                orderStatus = "NOT CREATED";
                if (HerbGlobalState.isPotionImpossible(i)) {
                    orderStatus += ", IMPOSSIBLE";
                }
            }
            Logger.log("Order " + (i+1) + ": " + currentOrders.get(i) + " - " + orderStatus);
        }

        // Check if we're in processing phase
        Logger.log("Processing phase: " + (HerbGlobalState.isProcessingPhase() ? "YES" : "NO"));
        Logger.log("All potions created: " + (HerbGlobalState.areAllPotionsCreated() ? "YES" : "NO"));
        Logger.log("All potions processed: " + (HerbGlobalState.areAllPotionsProcessed() ? "YES" : "NO"));

        Logger.log("======================================");
    }

    /**
     * Gets the current paste levels from varbits and inventory.
     * @return Map of paste types ("Mox", "Lye", "Aga") to their total amounts.
     */
    private Map<String, Integer> getVarbitPaste() {
        Map<String, Integer> pasteLevels = new HashMap<>();
        pasteLevels.put("Mox", PlayerSettings.getBitValue(MixologyConstants.MOX_PASTE_VARBIT) + 
                        Inventory.count(i -> i != null && i.getName().contains("Mox paste")));
        pasteLevels.put("Lye", PlayerSettings.getBitValue(MixologyConstants.LYE_PASTE_VARBIT) + 
                        Inventory.count(i -> i != null && i.getName().contains("Lye paste")));
        pasteLevels.put("Aga", PlayerSettings.getBitValue(MixologyConstants.AGA_PASTE_VARBIT) + 
                        Inventory.count(i -> i != null && i.getName().contains("Aga paste")));
        return pasteLevels;
    }
}
