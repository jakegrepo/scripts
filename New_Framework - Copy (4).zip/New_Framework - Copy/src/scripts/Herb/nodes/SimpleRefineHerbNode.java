package scripts.Herb.nodes;

import core.base.SimpleNode;
import core.grandexchange.RestockGrandExchangeNode;
import scripts.Herb.config.HerbConfig;
import scripts.Herb.config.MixologyConfig;
import scripts.Herb.HerbGlobalState;
import scripts.Herb.MixologyScript;
import scripts.Herb.utils.MixologyConstants;
import scripts.Herb.utils.MixologyUtils;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.worldhopper.WorldHopper;
import org.dreambot.api.methods.world.Worlds;
import org.dreambot.api.methods.world.World;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.wrappers.items.Item;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.utilities.Logger;
import core.grandexchange.RestockCheckUtility;

import java.util.*;
import java.util.stream.Collectors;


public class SimpleRefineHerbNode extends SimpleNode<HerbConfig> {

    private static final double LOW_THRESHOLD_RATIO = 0.20;
    private static final int TOP_UP_THRESHOLD = 2800;
    private static final int MAX_STORAGE       = 3000;
    private static final List<String> PASTE_TYPES = Arrays.asList("Mox", "Lye", "Aga");
    private static final Map<String, Integer> HERB_YIELD = createYieldMap();

    private boolean hoppedWorld = false;
    private final Deque<String> refineQueue = new ArrayDeque<>();

    private final MixologyConfig mixologyCfg;
    private final MixologyScript script;

    public SimpleRefineHerbNode(HerbConfig cfg, MixologyConfig mCfg, MixologyScript script) {
        super("Simple Refining", 0, cfg);
        this.mixologyCfg = mCfg;
        this.script = script;
    }

    @Override
    public boolean validate() {
        // First check if we're in the right area and not in other states that would prevent refining
        if (HerbGlobalState.isMulingInProgress()) {
            return false;
        }

        if (!MixologyUtils.isInMixologyArea()) {
            return false;
        }

        if (HerbGlobalState.isProcessingPhase()) {
            return false;
        }

        if (Inventory.contains(MixologyConstants.UNPROCESSED_POTION_IDS)) {
            return false;
        }

        if (Inventory.contains(MixologyConstants.PROCESSED_POTION_IDS)) {
            return false;
        }

        int playerAnimation = Players.getLocal().getAnimation();
        if (playerAnimation == MixologyConstants.RETORT_BUSY_ANIMATION_ID ||
                playerAnimation == MixologyConstants.AGITATOR_BUSY_ANIMATION_ID ||
                playerAnimation == MixologyConstants.ALEMBIC_BUSY_ANIMATION_ID) {
            return false;
        }

        // Get total amounts (varbit + inventory)
        Map<String, Integer> totals = getVarbitPaste();
        int threshold = (int)(LOW_THRESHOLD_RATIO * MAX_STORAGE);

        // Get inventory amounts for logging
        int invMox = Inventory.count(i -> i != null && i.getName().contains("Mox paste"));
        int invLye = Inventory.count(i -> i != null && i.getName().contains("Lye paste"));
        int invAga = Inventory.count(i -> i != null && i.getName().contains("Aga paste"));


        // Check various states
        boolean needsRefining = totals.get("Mox") < threshold ||
                totals.get("Lye") < threshold ||
                totals.get("Aga") < threshold;
        boolean hasInventoryPaste = invMox > 0 || invLye > 0 || invAga > 0;
        boolean notAtMax = totals.get("Mox") < TOP_UP_THRESHOLD ||
                totals.get("Lye") < TOP_UP_THRESHOLD ||
                totals.get("Aga") < TOP_UP_THRESHOLD;
        boolean allAtOrAboveMax = totals.get("Mox") >= TOP_UP_THRESHOLD &&
                totals.get("Lye") >= TOP_UP_THRESHOLD &&
                totals.get("Aga") >= TOP_UP_THRESHOLD;

        // Validate if:
        // 1. We need to refine more paste OR
        // 2. We have paste in inventory and either:
        //    a. We're not at max levels OR
        //    b. We're at/above max levels (need to deposit) OR
        // 3. We're already in the middle of refining
        boolean shouldValidate = needsRefining ||
                (hasInventoryPaste && (notAtMax || allAtOrAboveMax)) ||
                HerbGlobalState.isRefiningInProgress();

        // Only set refining state if we're validating and not already in progress
        if (shouldValidate && !HerbGlobalState.isRefiningInProgress()) {
            HerbGlobalState.setRefiningInProgress(true);
            Logger.info("Setting refining in progress state");
        }

        // Also validate if we are in refining progress state even if other conditions are false,
        // to allow the node to finish its current task (like depositing).
        return shouldValidate || HerbGlobalState.isRefiningInProgress();
    }

    @Override
    protected int onExecute() {
        Logger.info("[REFINE NODE] onExecute called. State: " + HerbGlobalState.isRefiningInProgress());

        if (!HerbGlobalState.isRefiningInProgress()) {
            // This block should ideally not be hit due to validate(), but good as a safeguard
            HerbGlobalState.setRefiningInProgress(true);
            refineQueue.clear();
            refineQueue.addAll(PASTE_TYPES);
            hoppedWorld = false;
            Logger.info("► Starting refine session: topping up all paste types");
        }

        if (!hoppedWorld) {
            hopWorld();
            return 8000;
        }

        // Check if we're actually done refining
        Map<String, Integer> vb = getVarbitPaste();

        // Log current state (including inventory paste)
        int totalMox = vb.getOrDefault("Mox", 0) + Inventory.count(i -> i != null && i.getName().contains("Mox paste"));
        int totalLye = vb.getOrDefault("Lye", 0) + Inventory.count(i -> i != null && i.getName().contains("Lye paste"));
        int totalAga = vb.getOrDefault("Aga", 0) + Inventory.count(i -> i != null && i.getName().contains("Aga paste"));

        Logger.info(String.format("[REFINE NODE] Current Paste: Mox=%d, Lye=%d, Aga=%d (Target: %d)",
                totalMox, totalLye, totalAga, TOP_UP_THRESHOLD));

        // Check if we've reached our targets (including inventory paste)
        boolean allAboveThreshold = totalMox >= TOP_UP_THRESHOLD &&
                totalLye >= TOP_UP_THRESHOLD &&
                totalAga >= TOP_UP_THRESHOLD;

        if (allAboveThreshold && Inventory.count(i -> i != null && i.getName().contains("paste")) > 0) {
            // If we are above threshold but still have paste in inventory, deposit it.
            Logger.info("[REFINE NODE] All pastes at target levels, but inventory has paste. Depositing.");
            return depositAllPaste();
        }

        if (allAboveThreshold && Inventory.count(i -> i != null && i.getName().contains("paste")) == 0) {
            // If all pastes are above threshold AND inventory is clear of paste, finish.
            Logger.info("[REFINE NODE] All pastes at target levels and inventory is clear. Finishing refine session.");
            finish();
            return 500; // Small sleep after finishing
        }

        if (refineQueue.isEmpty()) {
            // If queue is empty but we're not done, refill it and process the first type
            Logger.info("[REFINE NODE] Refine queue empty but not finished. Refilling queue.");
            refineQueue.addAll(PASTE_TYPES);
            if (!refineQueue.isEmpty()) {
                String nextType = refineQueue.peek();
                Logger.info("[REFINE NODE] Next paste type to refine: " + nextType);
                return 500; // Small sleep before processing next type
            } else {
                // Should not happen if PASTE_TYPES is not empty, but as a safeguard
                Logger.warn("[REFINE NODE] Refill queue is empty, finishing unexpectedly.");
                finish();
                return 500;
            }
        }

        String type = refineQueue.peek();
        int varbit = PlayerSettings.getBitValue(getVarbitId(type));
        int invPaste = Inventory.count(i -> i != null
                && i.getName().startsWith(type)
                && i.getName().contains("paste"));
        int total = varbit + invPaste;

        if (total >= TOP_UP_THRESHOLD) {
            Logger.info("[REFINE NODE] " + type + " paste at target level. Moving to next type.");
            refineQueue.poll();
            return 500;
        }

        int needed = TOP_UP_THRESHOLD - total;

        // Log per‑herb breakdown based on GUI selection
        List<String> chosen = mixologyCfg.getSelectedHerbs().stream()
                .filter(h -> type.equals(getPasteType(h)))
                .collect(Collectors.toList());

        // Check if no herbs for the current type are in inventory OR bank
        boolean hasHerbsForType = false;

        // First check inventory
        hasHerbsForType = chosen.stream().anyMatch(herbName -> Inventory.count(herbName) > 0);
        Logger.info("[REFINE NODE] Has herbs in inventory (initial check): " + hasHerbsForType);
        
        // Log which herbs we're looking for
        Logger.info("[REFINE NODE] Looking for herbs: " + String.join(", ", chosen));

        // If not in inventory, check bank
        if (!hasHerbsForType) {
            if (!Bank.isOpen()) {
                if (Bank.open()) {
                    Sleep.sleepUntil(Bank::isOpen, 5000);
                } else {
                    Logger.warn("[REFINE NODE] Failed to open bank to check for herbs.");
                    return 1000; // Retry opening bank
                }
            }

            // Now check bank contents
            hasHerbsForType = chosen.stream().anyMatch(herbName -> Bank.count(herbName) > 0);
            Logger.info("[REFINE NODE] Has herbs in bank: " + hasHerbsForType);
        }

        if (!hasHerbsForType) {
            Logger.log("[REFINE NODE] No **herbs** for " + type + " found in inventory or bank.");

            // CENTRALIZED restock trigger
            if (script.getRestockNode().getRestockCheck().needsRestock()) {
                Logger.info("[REFINE NODE] Restock needed (no herbs for " + type
                        + "), forcing GE node to take over.");
                // kick off GE flow
                script.getRestockNode().forceExecute();
                HerbGlobalState.setRefiningInProgress(false);
                return 0;  // yield immediately
            }

            // no restock ➔ skip this herb type
            Logger.info("[REFINE NODE] Restock not needed or disabled. Cannot refine "
                    + type + ". Moving to next paste type.");
            refineQueue.poll();
            return 500;
        }

        // If we reach here, we have herbs for the current type in inventory or bank.
        // If no herbs in inventory, go bank for them.
        Logger.info("[REFINE NODE] Found herbs for " + type + " in inventory or bank. Checking if in inventory...");
        boolean hasInventoryHerbsForType = Inventory.all().stream()
                .filter(i -> i != null &&
                        chosen.contains(i.getName().replaceAll("\\(\\d+\\)$","")))
                .findFirst().isPresent();

        Logger.info("[REFINE NODE] Has herbs in inventory: " + hasInventoryHerbsForType);
        if (!hasInventoryHerbsForType) {
            Logger.log("[REFINE NODE] No **herbs** for " + type + " in inventory — banking more");
            return bankForHerbs(type, needed);
        }

        // Actually perform the refining action
        return refineHerbs(type, needed);
    }

    private void hopWorld() {
        int current = Worlds.getCurrentWorld();
        List<World> worlds = Worlds.getNormalizedWorlds().stream()
                .filter(w -> w.isMembers() && w.isNormal() && w.getWorld() != current && w.getMinimumLevel() == 0)
                .collect(Collectors.toList());
        if (!worlds.isEmpty()
                && WorldHopper.quickHop(worlds.get(new Random().nextInt(worlds.size())).getWorld())) {
            Sleep.sleepUntil(() -> Worlds.getCurrentWorld() != current, 10000);
        }
        hoppedWorld = true;
        Logger.log("Hopped world to " + Worlds.getCurrentWorld());
    }

    private int bankForHerbs(String type, int needed) {
        setStatus("Banking for " + type);
        if (!Bank.isOpen()) {
            Bank.open();
            {
                Sleep.sleepUntil(Bank::isOpen, 5000);
                Logger.warn("[REFINE NODE] Failed to open bank for herbs.");
                return 1000; // Retry opening bank
            }
        }

            // Deposit non‑relevant items (excluding paste, which depositAllPaste handles)
            Inventory.all().forEach(item -> {
                if (item != null
                        && !item.getName().contains("paste")
                        && !HERB_YIELD.containsKey(item.getName().replaceAll("\\(\\d+\\)$",""))) {
                    if (Bank.depositAll(item.getName())) {
                        Sleep.sleep(100,200);
                    }
                }
            });

            // Bulk withdraw
            List<String> chosen = mixologyCfg.getSelectedHerbs().stream()
                    .filter(h -> type.equals(getPasteType(h)))
                    .collect(Collectors.toList());

            boolean withdrawnAny = false;
            for (String herbName : chosen) {
                int yield = HERB_YIELD.getOrDefault(herbName,0);
                if (yield <= 0) continue;
                // Calculate how many herbs of this specific type are needed
                // Check available in bank first
                int bankCount = Bank.count(herbName);
                if (bankCount <= 0) continue;

                int currentTotalPaste = PlayerSettings.getBitValue(getVarbitId(type)) + Inventory.count(i -> i != null && i.getName().startsWith(type) && i.getName().contains("paste"));
                int remainingNeeded = TOP_UP_THRESHOLD - currentTotalPaste;
                if (remainingNeeded <= 0) {
                    Logger.info("[REFINE NODE] " + type + " paste level now sufficient during banking.");
                    break; // Stop withdrawing if target reached
                }

                int estimatedHerbsNeeded = (int)Math.ceil((double)remainingNeeded / yield);
                int freeSlots   = Inventory.getEmptySlots();
                int toWithdraw  = Math.min(freeSlots, estimatedHerbsNeeded);

                if (toWithdraw > 0 && bankCount > 0) {
                    // Adjust withdraw quantity if more is available than needed or fits
                    int actualWithdraw = Math.min(toWithdraw, bankCount);
                    Logger.info(String.format("[REFINE NODE] Withdrawing %d x %s (needed %d, bank has %d, free slots %d)",
                            actualWithdraw, herbName, estimatedHerbsNeeded, bankCount, freeSlots));

                    if (Bank.withdraw(herbName, actualWithdraw)) {
                        Sleep.sleepUntil(() -> Inventory.count(herbName) >= actualWithdraw, 5000);
                        withdrawnAny = true;
                        // After withdrawing, re-check if we need more herbs or can close bank
                        // This is important if we withdraw less than estimated needed
                        break; // Process only one type of herb per bank visit for simplicity
                    } else {
                        Logger.warn("[REFINE NODE] Failed to withdraw " + herbName);
                    }
                }
            }

            // Close bank when done withdrawing (or if nothing was withdrawn)
            if (withdrawnAny || chosen.stream().allMatch(herbName -> Bank.count(herbName) == 0)) {
                Logger.info("[REFINE NODE] Finished withdrawing or no more herbs available. Closing bank.");
                Bank.close();
                Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
            } else {
                // If we didn't withdraw any but still have herbs for the type in bank,
                // it means inventory was full or estimated needed was 0. Re-evaluate next tick.
                Logger.info("[REFINE NODE] Did not withdraw any herbs. Re-evaluating.");
            }
        return 1000;
    }

    private int refineHerbs(String type, int needed) {
        setStatus("Refining " + type);
        if (Bank.isOpen()){
            Bank.close();
            Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
            return 600;
        }
        // Get list of herbs that would work for this paste type
        List<String> chosen = mixologyCfg.getSelectedHerbs().stream()
                .filter(h -> type.equals(getPasteType(h)))
                .collect(Collectors.toList());

        // First, check if we have any suitable herbs to refine
        Optional<Item> optHerb = Inventory.all().stream()
                .filter(i -> i != null &&
                        chosen.contains(i.getName().replaceAll("\\(\\d+\\)$","")))
                .findFirst();

        // If no suitable herbs, go bank (handled by validate/execute loop now)
        if (!optHerb.isPresent()) {
            Logger.log("[REFINE NODE] No suitable herbs for " + type + " paste in inventory. This should have been caught earlier.");
            HerbGlobalState.setRefiningInProgress(false); // Something went wrong, reset
            return 500; // Re-validate to potentially go bank
        }

        // We have a suitable herb, proceed with refining
        GameObject refiner = GameObjects.closest(o -> o != null && o.getName().contains("Refiner"));
        if (refiner == null) {
            Logger.log("[REFINE NODE] Refiner not found!");
            return 1000;
        }

        Item herb = optHerb.get();
            long startTime = System.currentTimeMillis();
            long maxRefineTime = 30000; // Don't get stuck refining for too long

            while (Inventory.contains(herb.getName()) && System.currentTimeMillis() - startTime < maxRefineTime) {
                GameObject currentRefiner = GameObjects.closest("Refiner");
                if (currentRefiner != null && currentRefiner.interact("Operate")) {
                    Logger.info("[REFINE NODE] Using " + herb.getName() + " on Refiner for " + type + " paste.");
                    Sleep.sleep(100,150);
                } else {
                    Logger.warn("[REFINE NODE] Failed to interact with Refiner while animating.");
                    break; // Exit loop if interaction fails
                }
            // After animation stops or timeout, check if paste was created
            Sleep.sleep(600); // Small sleep to allow paste count to update
        }
        return 1000;
    }

    private int depositAllPaste() {
        setStatus("Depositing paste");
        GameObject hopper = GameObjects.closest(o -> o != null && o.getName().contains("Hopper"));
        if (hopper == null) {
            Logger.log("Hopper not found!");
            return 1000;
        }
        for (Item paste : Inventory.all(i -> i != null && i.getName().contains("paste"))) {
            if (paste.useOn(hopper)) {
                Sleep.sleepUntil(() -> !Inventory.contains(paste.getID()), 4000);
            }
            Sleep.sleep(100,200);
        }
        return 1000;
    }

    private void finish() {
        // Re-check paste levels (including inventory) before truly finishing
        Map<String, Integer> vb = getVarbitPaste();
        int totalMox = vb.getOrDefault("Mox", 0) + Inventory.count(i -> i != null && i.getName().contains("Mox paste"));
        int totalLye = vb.getOrDefault("Lye", 0) + Inventory.count(i -> i != null && i.getName().contains("Lye paste"));
        int totalAga = vb.getOrDefault("Aga", 0) + Inventory.count(i -> i != null && i.getName().contains("Aga paste"));
        boolean allAboveThreshold = totalMox >= TOP_UP_THRESHOLD &&
                totalLye >= TOP_UP_THRESHOLD &&
                totalAga >= TOP_UP_THRESHOLD;

        boolean inventoryHasPaste = Inventory.count(i -> i != null && i.getName().contains("paste")) > 0;


        Logger.info("[REFINE NODE] Checking finish conditions: All Above Threshold? " + allAboveThreshold + ", Inventory Has Paste? " + inventoryHasPaste);

        if (allAboveThreshold && !inventoryHasPaste) {
            HerbGlobalState.setRefiningInProgress(false);
            hoppedWorld = false;
            refineQueue.clear();
            setStatus("Idle");
            Logger.info("[REFINE NODE] Refine session complete, returning to idle");
        } else {
            // If not truly finished, keep state as in progress to continue next tick
            Logger.info("[REFINE NODE] Finish conditions not met, continuing refine session.");
            HerbGlobalState.setRefiningInProgress(true); // Ensure state stays true
        }
    }

    private Map<String,Integer> getVarbitPaste() {
        Map<String,Integer> m = new HashMap<>();
        for (String t : PASTE_TYPES) {
            int varbitId = getVarbitId(t);
            int value = PlayerSettings.getBitValue(varbitId);
            int invValue = Inventory.count(i -> i != null
                    && i.getName().startsWith(t)
                    && i.getName().contains("paste"));
            int total = value + invValue;
            m.put(t, total);
        }
        return m;
    }

    private int getVarbitId(String type) {
        switch(type) {
            case "Mox": return MixologyConstants.MOX_PASTE_VARBIT;
            case "Lye": return MixologyConstants.LYE_PASTE_VARBIT;
            default:    return MixologyConstants.AGA_PASTE_VARBIT;
        }
    }

    private static Map<String,Integer> createYieldMap() {
        Map<String,Integer> m = new LinkedHashMap<>();
        m.put("Guam leaf",10);
        m.put("Marrentill",13);
        m.put("Tarromin",15);
        m.put("Harralander",20);
        m.put("Ranarr weed",26);
        m.put("Toadflax",32);
        m.put("Avantoe",30);
        m.put("Kwuarm",33);
        m.put("Snapdragon",40);
        m.put("Irit leaf",30);
        m.put("Huasca",20);
        m.put("Cadantine",34);
        m.put("Lantadyme",40);
        m.put("Dwarf weed",42);
        m.put("Torstol",44);
        return Collections.unmodifiableMap(m);
    }

    private String getPasteType(String name) {
        if (name.contains("paste")) {
            if (name.startsWith("Mox")) return "Mox";
            if (name.startsWith("Lye")) return "Lye";
            return "Aga";
        }
        switch(name) {
            case "Guam leaf": case "Marrentill": case "Tarromin": case "Harralander":
                return "Mox";
            case "Ranarr weed": case "Toadflax": case "Avantoe": case "Kwuarm": case "Snapdragon":
                return "Lye";
            default:
                return "Aga";
        }
    }
}