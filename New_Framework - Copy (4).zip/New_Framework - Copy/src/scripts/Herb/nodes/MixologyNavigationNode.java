package scripts.Herb.nodes;

import core.base.SimpleNode;
import core.context.ScriptContext;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.interactive.Player;
import scripts.Herb.MixologyScript;
import scripts.Herb.config.MixologyConfig;
import scripts.Herb.enums.NavigationDestination;
import scripts.Herb.utils.MixologyConstants;
import scripts.Herb.utils.MixologyUtils;

import static scripts.Herb.utils.MixologyUtils.ALDARIN;
import static scripts.Herb.utils.MixologyUtils.MIXOLOGY_AREA;

/**
 * Node responsible for navigating to different areas within the Mixology minigame.
 */
public class MixologyNavigationNode extends SimpleNode<MixologyConfig> {

    private final MixologyConfig mixologyConfig;
    private final MixologyScript script;

    public MixologyNavigationNode(MixologyConfig config, MixologyScript script) {
        super("Navigation", 4, config);
        this.mixologyConfig = config;
        this.script = script;
    }

    @Override
    public boolean validate() {
        // Don't execute if RestockNode is active
        if (isRestockNodeActive()) {
            return false;
        }

        // Check if we have a destination set
        NavigationDestination destination = mixologyConfig.getCurrentDestination();
        if (destination == null) {
            return false;
        }

        // If we're already in the Mixology area and that's our destination, we're done
        if (MIXOLOGY_AREA.contains(Players.getLocal()) && destination == NavigationDestination.MIXOLOGY_AREA) {
            mixologyConfig.setCurrentDestination(null);
            return false;
        }

        // Otherwise, we need to navigate
        return true;
    }

    /**
     * Checks if the RestockNode is currently active
     * @return true if RestockNode is active and not in IDLE or FINISHED state
     */
    private boolean isRestockNodeActive() {
        try {
            // Find the RestockGrandExchangeNode in the script's nodes
            core.grandexchange.RestockGrandExchangeNode restockNode = script.getContext().tasks().getNodes().stream()
                .filter(node -> node instanceof core.grandexchange.RestockGrandExchangeNode)
                .map(node -> (core.grandexchange.RestockGrandExchangeNode) node)
                .findFirst()
                .orElse(null);

            if (restockNode != null) {
                boolean active = !restockNode.isFinished();
                if (active) {
                    Logger.info("RestockNode is active, MixologyNavigationNode will not execute");
                }
                return active;
            }

            return false;
        } catch (Exception e) {
            Logger.error("Error checking if RestockNode is active: " + e.getMessage());
            return false;
        }
    }

    @Override
    public int onExecute() {
        NavigationDestination destination = mixologyConfig.getCurrentDestination();

        if (destination == null) {
            Logger.log("No destination set");
            return 1000;
        }

        setStatus("Navigating to " + destination.getFormattedName());
        MixologyUtils.updateStatus("Navigating to " + destination.getFormattedName());

        switch (destination) {
            case ENTRANCE:
                return navigateToEntrance();
            case MIXOLOGY_AREA:
                return navigateToMixologyArea();
            case MIXING_AREA:
                return navigateToMixingArea();
            case REFINING_AREA:
                return navigateToRefiningArea();
            case STORAGE_AREA:
                return navigateToStorageArea();
            case EXIT:
                return navigateToExit();
            default:
                Logger.log("Unknown destination: " + destination);
                mixologyConfig.setCurrentDestination(null);
                return 1000;
        }
    }

    private int navigateToEntrance() {
        // Check if we're in a player-owned house (using isDynamicRegion as a proxy)
        if (org.dreambot.api.Client.isDynamicRegion()) {
            Logger.log("In player-owned house, using portal to exit");

            // Find and use the portal to exit the house
            GameObject portal = GameObjects.closest(obj -> obj != null && obj.getName().contains("Portal"));
            if (portal != null) {
                if (portal.distance() > 5) {
                    Walking.walk(portal.getTile());
                    Sleep.sleepUntil(() -> portal.distance() <= 5, 5000);
                    return 1000;
                }

                if (portal.interact("Enter")) {
                    Logger.log("Using portal to exit house");
                    Sleep.sleepUntil(() -> !org.dreambot.api.Client.isDynamicRegion(), 5000);
                    return 1000;
                }
            }
            return 1000;
        }

        // Handle Aldarin area navigation first
        if (ALDARIN.contains(Players.getLocal())) {
            GameObject staircase = GameObjects.closest(54946);

            if (staircase != null) {
                // If we're not close to the staircase, walk to it
                if (staircase.distance() > 3) {
                    Logger.log("Walking to staircase in Aldarin area");
                    Walking.walk(staircase.getTile());
                    Sleep.sleepUntil(() -> staircase.distance() <= 3, 5000);
                    return 1000;
                }
                // If we're close to the staircase, climb down
                else {
                    Logger.log("Climbing down staircase");
                    if (staircase.interact("Climb-down")) {
                        Sleep.sleepUntil(() -> !ALDARIN.contains(Players.getLocal()), 5000);
                        return 1000;
                    }
                }
            } else {
                Logger.log("Staircase not found in Aldarin area");
                // Walk to the known staircase location if we can't find it
                Walking.walk(new Tile(1389, 2918, 0));
                return 1000;
            }
        }

        // Check if we're already at the entrance
        GameObject entrancePortal = GameObjects.closest(MixologyUtils.ENTRANCE_PORTAL_ID);
        if (entrancePortal != null && entrancePortal.distance() < 5) {
            Logger.log("Already at the entrance portal");

            // Interact with the entrance portal
            if (entrancePortal.interact("Enter")) {
                Logger.log("Entering Mixology minigame");
                Sleep.sleepUntil(MixologyUtils::isInMixologyArea, 5000);

                // Clear the destination if we've reached it
                if (MixologyUtils.isInMixologyArea()) {
                    mixologyConfig.setCurrentDestination(null);
                }
            }

            return 1000;
        }

        // Try to use Teleport to House spell
        if (org.dreambot.api.methods.magic.Magic.canCast(org.dreambot.api.methods.magic.Normal.TELEPORT_TO_HOUSE)) {
            Logger.log("Casting Teleport to House spell");
            if (org.dreambot.api.methods.magic.Magic.castSpell(org.dreambot.api.methods.magic.Normal.TELEPORT_TO_HOUSE)) {
                Sleep.sleepUntil(() -> org.dreambot.api.Client.isDynamicRegion(), 5000);
                return 1000;
            }
        } else {
            // Check if we need to get a teleport to house tablet from the bank
            if (!org.dreambot.api.methods.container.impl.Inventory.contains(item -> item != null && item.getName().equals("Teleport to house"))) {
                Logger.log("Need to get Teleport to House tablet from bank");

                // Open the bank if it's not already open
                if (!org.dreambot.api.methods.container.impl.bank.Bank.isOpen()) {
                    if (org.dreambot.api.methods.container.impl.bank.Bank.open()) {
                        Sleep.sleepUntil(org.dreambot.api.methods.container.impl.bank.Bank::isOpen, 5000);
                    }
                    return 1000;
                }

                // Withdraw a teleport to house tablet
                if (org.dreambot.api.methods.container.impl.bank.Bank.contains(item -> item != null && item.getName().equals("Teleport to house"))) {
                    if (org.dreambot.api.methods.container.impl.bank.Bank.withdraw("Teleport to house", 1)) {
                        Sleep.sleepUntil(() -> org.dreambot.api.methods.container.impl.Inventory.contains(item -> item != null && item.getName().equals("Teleport to house")), 3000);
                        org.dreambot.api.methods.container.impl.bank.Bank.close();
                        return 1000;
                    }
                } else {
                    Logger.log("No Teleport to House tablets in bank");
                    org.dreambot.api.methods.container.impl.bank.Bank.close();
                }
            } else {
                // Use the teleport to house tablet
                Logger.log("Using Teleport to House tablet");
                org.dreambot.api.wrappers.items.Item houseTab = org.dreambot.api.methods.container.impl.Inventory.get(item -> item != null && item.getName().equals("Teleport to house"));
                if (houseTab != null) {
                    if (houseTab.interact()) {
                        Logger.log("Interacted with Teleport to house tablet");
                        Sleep.sleepUntil(() -> org.dreambot.api.Client.isDynamicRegion(), 5000);
                        return 1000;
                    } else {
                        Logger.log("Failed to interact with Teleport to house tablet");
                    }
                }
                return 1000;
            }

            // Fallback to finding the Mixology Master NPC
            NPC mixologyMaster = NPCs.closest(MixologyUtils.MIXOLOGY_MASTER_ID);
            if (mixologyMaster != null) {
                // If we're not close to the NPC, walk there
                if (mixologyMaster.distance() > 5) {
                    Logger.log("Walking to Mixology Master");
                    Walking.walk(mixologyMaster);
                    Sleep.sleepUntil(() -> mixologyMaster.distance() <= 5, 5000);
                    return 1000;
                }

                // Talk to the NPC to start the minigame
                if (mixologyMaster.interact("Talk-to")) {
                    Logger.log("Talking to Mixology Master");
                    Sleep.sleepUntil(() -> entrancePortal != null && entrancePortal.distance() < 10, 5000);
                    return 1000;
                }
            } else {
                Logger.log("Mixology Master not found");
            }
        }

        return 1000;
    }

    private int navigateToMixologyArea() {
        // Check if we're already in the Mixology area
        if (MixologyUtils.isInMixologyArea()) {
            Logger.log("Already in Mixology area");
            mixologyConfig.setCurrentDestination(null);
            return 0;
        }

        // Check if we're in a player-owned house
        if (org.dreambot.api.Client.isDynamicRegion()) {
            return navigateFromHouse();
        }

        // Try to use Teleport to House first
        if (org.dreambot.api.methods.magic.Magic.canCast(org.dreambot.api.methods.magic.Normal.TELEPORT_TO_HOUSE)) {
            Logger.log("Casting Teleport to House spell to get to Mixology area");
            if (org.dreambot.api.methods.magic.Magic.castSpell(org.dreambot.api.methods.magic.Normal.TELEPORT_TO_HOUSE)) {
                Sleep.sleepUntil(() -> org.dreambot.api.Client.isDynamicRegion(), 5000);
                return 1000;
            }
        } else if (org.dreambot.api.methods.container.impl.Inventory.contains(item -> item != null && item.getName().equals("Teleport to house"))) {
            // Use the teleport to house tablet
            Logger.log("Using Teleport to House tablet to get to Mixology area");
            org.dreambot.api.wrappers.items.Item houseTab = org.dreambot.api.methods.container.impl.Inventory.get(item -> item != null && item.getName().equals("Teleport to house"));
            if (houseTab != null) {
                if (houseTab.interact()) {
                    Logger.log("Interacted with Teleport to house tablet");
                    Sleep.sleepUntil(() -> org.dreambot.api.Client.isDynamicRegion(), 5000);
                    return 1000;
                }
            }
        } else {
            // Try to get a teleport to house tablet from the bank
            if (!org.dreambot.api.methods.container.impl.bank.Bank.isOpen()) {
                Logger.log("Opening bank to get Teleport to House tablet");
                if (org.dreambot.api.methods.container.impl.bank.Bank.open()) {
                    Sleep.sleepUntil(org.dreambot.api.methods.container.impl.bank.Bank::isOpen, 5000);
                }
                return 1000;
            }

            if (org.dreambot.api.methods.container.impl.bank.Bank.contains(item -> item != null && item.getName().equals("Teleport to house"))) {
                Logger.log("Withdrawing Teleport to House tablet from bank");
                if (org.dreambot.api.methods.container.impl.bank.Bank.withdraw("Teleport to house", 1)) {
                    Sleep.sleepUntil(() -> org.dreambot.api.methods.container.impl.Inventory.contains(item -> item != null && item.getName().equals("Teleport to house")), 3000);
                    org.dreambot.api.methods.container.impl.bank.Bank.close();
                    return 1000;
                }
            } else {
                Logger.log("No Teleport to House tablets in bank, falling back to normal navigation");
                org.dreambot.api.methods.container.impl.bank.Bank.close();

                // If we can't teleport, navigate to the entrance
                mixologyConfig.setCurrentDestination(NavigationDestination.ENTRANCE);
                return 1000;
            }
        }

        return 1000;
    }

    private int navigateToMixingArea() {
        // Check if we're already in the mixing area
        if (MixologyUtils.isInMixingArea()) {
            Logger.log("Already in mixing area");
            mixologyConfig.setCurrentDestination(null);
            return 0;
        }

        // Make sure we're in the Mixology area first
        if (!MixologyUtils.isInMixologyArea()) {
            mixologyConfig.setCurrentDestination(NavigationDestination.MIXOLOGY_AREA);
            return 0;
        }

        // Find and walk to the mixing area
        GameObject retort = GameObjects.closest(MixologyConstants.RETORT_ID);
        if (retort != null) {
            // If we're not close to the retort, walk there
            if (retort.distance() > 5) {
                Logger.log("Walking to mixing area");
                Walking.walk(retort);
                Sleep.sleepUntil(() -> retort.distance() <= 5 || MixologyUtils.isInMixingArea(), 5000);
                return 1000;
            }

            // If we've reached the mixing area, clear the destination
            if (MixologyUtils.isInMixingArea()) {
                mixologyConfig.setCurrentDestination(null);
                return 0;
            }
        } else {
            Logger.log("Retort not found");
        }

        return 1000;
    }

    private int navigateToRefiningArea() {
        // Check if we're already in the refining area
        if (MixologyUtils.isInRefinerArea()) {
            Logger.log("Already in refining area");
            mixologyConfig.setCurrentDestination(null);
            return 0;
        }

        // Make sure we're in the Mixology area first
        if (!MixologyUtils.isInMixologyArea()) {
            mixologyConfig.setCurrentDestination(NavigationDestination.MIXOLOGY_AREA);
            return 0;
        }

        // Find and walk to the refining area
        GameObject refiner = GameObjects.closest(MixologyConstants.REFINER_ID);
        if (refiner != null) {
            // If we're not close to the refiner, walk there
            if (refiner.distance() > 5) {
                Logger.log("Walking to refining area");
                Walking.walk(refiner);
                Sleep.sleepUntil(() -> refiner.distance() <= 5 || MixologyUtils.isInRefinerArea(), 5000);
                return 1000;
            }

            // If we've reached the refining area, clear the destination
            if (MixologyUtils.isInRefinerArea()) {
                mixologyConfig.setCurrentDestination(null);
                return 0;
            }
        } else {
            Logger.log("Refiner not found");
        }

        return 1000;
    }

    private int navigateToStorageArea() {
        // Check if we're already in the storage area
        if (MixologyUtils.isInStorageArea()) {
            Logger.log("Already in storage area");
            mixologyConfig.setCurrentDestination(null);
            return 0;
        }

        // Make sure we're in the Mixology area first
        if (!MixologyUtils.isInMixologyArea()) {
            mixologyConfig.setCurrentDestination(NavigationDestination.MIXOLOGY_AREA);
            return 0;
        }

        // Find and walk to the storage cabinet
        GameObject storageCabinet = GameObjects.closest(MixologyUtils.STORAGE_CABINET_ID);
        if (storageCabinet != null) {
            // If we're not close to the storage cabinet, walk there
            if (storageCabinet.distance() > 5) {
                Logger.log("Walking to storage area");
                Walking.walk(storageCabinet);
                Sleep.sleepUntil(() -> storageCabinet.distance() <= 5 || MixologyUtils.isInStorageArea(), 5000);
                return 1000;
            }

            // If we've reached the storage area, clear the destination
            if (MixologyUtils.isInStorageArea()) {
                mixologyConfig.setCurrentDestination(null);
                return 0;
            }
        } else {
            Logger.log("Storage cabinet not found");
        }

        return 1000;
    }

    /**
     * Navigate from the player-owned house to the Mixology area
     * @return Sleep time after navigation
     */
    private int navigateFromHouse() {
        Logger.log("Navigating from player-owned house to Mixology area");

        // Find and use the portal to exit the house
        GameObject portal = GameObjects.closest(obj -> obj != null && obj.getName().contains("Portal"));
        if (portal != null) {
            if (portal.distance() > 5) {
                Walking.walk(portal.getTile());
                Sleep.sleepUntil(() -> portal.distance() <= 5, 5000);
                return 1000;
            }

            if (portal.interact("Enter")) {
                Logger.log("Using portal to exit house");
                Sleep.sleepUntil(() -> !org.dreambot.api.Client.isDynamicRegion(), 5000);
                return 1000;
            }
        } else {
            Logger.log("Portal not found in house");
        }

        return 1000;
    }

    private int navigateToExit() {
        // Check if we're already outside
        if (!MixologyUtils.isInMixologyArea()) {
            Logger.log("Already outside Mixology area");
            mixologyConfig.setCurrentDestination(null);
            return 0;
        }

        // Find and interact with the exit portal
        GameObject exitPortal = GameObjects.closest(MixologyUtils.EXIT_PORTAL_ID);
        if (exitPortal != null) {
            // If we're not close to the exit portal, walk there
            if (exitPortal.distance() > 5) {
                Logger.log("Walking to exit portal");
                Walking.walk(exitPortal);
                Sleep.sleepUntil(() -> exitPortal.distance() <= 5, 5000);
                return 1000;
            }

            // Interact with the exit portal
            if (exitPortal.interact("Use")) {
                Logger.log("Exiting Mixology minigame");
                Sleep.sleepUntil(() -> !MixologyUtils.isInMixologyArea(), 5000);

                // Clear the destination if we've successfully exited
                if (!MixologyUtils.isInMixologyArea()) {
                    mixologyConfig.setCurrentDestination(null);
                }
            }
        } else {
            Logger.log("Exit portal not found");
        }

        return 1000;
    }

    @Override
    public void cleanup() {
        // Reset the navigation destination
        mixologyConfig.setCurrentDestination(null);
        Logger.log("Navigation node cleanup - destination reset");
    }
}
