package scripts.Herb.nodes;

import core.base.SimpleNode;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.bank.BankLocation;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.settings.PlayerSettings;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.widget.Widget;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.widgets.WidgetChild;
import scripts.Herb.HerbGlobalState;
import scripts.Herb.MixologyScript;
import scripts.Herb.config.HerbConfig;
import scripts.Herb.config.MixologyConfig;
import scripts.Herb.utils.MixologyConstants;

public class PurchaseRewardsNode extends SimpleNode<HerbConfig> {

    private static final int REWARDS_WIDGET_ROOT = 819;

    // widget paths: real IDs discovered in the client
    private static final int[] BARREL_SELECT   = {33, 108};
    private static final int[] ALDARIUM_SELECT = {33, 132};
private static final Area shop = new Area(1390, 9315, 1398, 9310);
    // point configs
    private static final int ALD_COST_MOX = 80;
    private static final int ALD_COST_LYE = 90;
    private static final int ALD_COST_AGA = 60;

    private final MixologyConfig mixologyConfig;
    private final MixologyScript script;
    private int aldariumPurchased = 0;
    private boolean aldariumPurchaseStarted = false;

    public PurchaseRewardsNode(HerbConfig config, MixologyConfig mixologyConfig, MixologyScript script) {
        super("Buy rewards", 0, config);
        this.mixologyConfig = mixologyConfig;
        this.script = script;
    }

    @Override
    public boolean validate() {

        // 0) deposit only when threshold reached or can't afford another
        int invCount = Inventory.count("Aldarium");
        boolean hasAld = invCount > 0;
        boolean thresholdReached = aldariumPurchased + invCount >= mixologyConfig.getAldariumPointsThreshold();
        boolean canAffordOne = ptsMox() >= ALD_COST_MOX
                            && ptsLye() >= ALD_COST_LYE
                            && ptsAga() >= ALD_COST_AGA;
        boolean needDeposit = hasAld && (thresholdReached || !canAffordOne);
        if (needDeposit && !BankLocation.GRAND_EXCHANGE.getArea(8).contains(Players.getLocal())) {
            return true;
        }

        // Don't run if we're muling
        if (HerbGlobalState.isMulingInProgress()) return false;
        if (!HerbGlobalState.isBuyingRewardsInProgress()) return false;
        // Don't run if we're not in the mixology area
        if (!MixologyConstants.MIXOLOGY_AREA.contains(Players.getLocal())) return false;
        
        // Don't run if we're refining
        if (HerbGlobalState.isRefiningInProgress()) return false;
        
        // Don't run if we have any potions in inventory (processed or unprocessed)
        if (Inventory.contains(item -> {
            if (item == null) return false;
            String name = item.getName().toLowerCase();
            return name.contains("potion") || name.contains("mix") || name.contains("amalgam");
        })) {
            return false;
        }
        
        // Don't run if we're in processing phase
        if (HerbGlobalState.isProcessingPhase()) return false;

        boolean canBuyBarrel = mixologyConfig.isBuyBarrel()
            && !Inventory.contains("Chugging barrel (disassembled)")
            && ptsMox() >= MixologyConstants.BARREL_COST_MOX
            && ptsLye() >= MixologyConstants.BARREL_COST_LYE
            && ptsAga() >= MixologyConstants.BARREL_COST_AGA;

        // Start Aldarium cycle only when GUI threshold cost is met
        if (!aldariumPurchaseStarted && mixologyConfig.isBuyAldarium()) {
            int costMox = mixologyConfig.getAldariumPointsThreshold() * ALD_COST_MOX;
            int costLye = mixologyConfig.getAldariumPointsThreshold() * ALD_COST_LYE;
            int costAga = mixologyConfig.getAldariumPointsThreshold() * ALD_COST_AGA;
            if (ptsMox() >= costMox && ptsLye() >= costLye && ptsAga() >= costAga) {
                aldariumPurchaseStarted = true;
                return true;
            }
        }

        // Keep node alive once cycle has started, until deposit
        if (aldariumPurchaseStarted) {
            return true;
        }

        return canBuyBarrel;
    }

    @Override
    protected int onExecute() {
        HerbGlobalState.setBuyingRewardsInProgress(true);

        // 1) Deposit only after full cycle or if we can't afford a single more
        int invCount = Inventory.count("Aldarium");
        if (invCount > 0) {
            boolean thresholdReached = aldariumPurchased + invCount >= mixologyConfig.getAldariumPointsThreshold();
            boolean canAffordOne   = ptsMox() >= ALD_COST_MOX
                                  && ptsLye() >= ALD_COST_LYE
                                  && ptsAga() >= ALD_COST_AGA;
            if (thresholdReached || !canAffordOne) {
                Bank.open();
                Sleep.sleepUntil(Bank::isOpen, 5000);
                Bank.depositAll("Aldarium");
                aldariumPurchased += invCount;
                closeRewardsInterface();
                HerbGlobalState.setBuyingRewardsInProgress(false);
                return 600;
            }
        }

        NPC lalo = NPCs.closest("Supervisor Lalo");
        Logger.log("Execute ▶ Supervisor Lalo found? " + (lalo != null));
        // 2) Open the rewards interface
        if (!isRewardsInterfaceOpen()) {
            Logger.log("Execute ▶ Opening rewards interface");
            if (lalo == null || Players.getLocal().distance(lalo) > 2) {
                Walking.walk(shop);
                Sleep.sleepUntil(() -> Players.getLocal().distance(lalo) <= 2, 5000);
            }
            if (lalo != null && lalo.hasAction("Rewards")) {
                lalo.interact("Rewards");
                Sleep.sleepUntil(this::isRewardsInterfaceOpen, 5000);
            }
            return 600;
        }
        Logger.log("Execute ▶ Rewards interface is OPEN");

        // 3) Barrel purchase
        if (mixologyConfig.isBuyBarrel()
         && !Inventory.contains("Chugging barrel (disassembled)")
         && ptsMox() >= MixologyConstants.BARREL_COST_MOX
         && ptsLye() >= MixologyConstants.BARREL_COST_LYE
         && ptsAga() >= MixologyConstants.BARREL_COST_AGA) {
            Logger.log("Execute ▶ Attempting Buy-1 Chugging barrel");
            WidgetChild barrel = getChildPath(REWARDS_WIDGET_ROOT, BARREL_SELECT);
            if (barrel != null && barrel.interact("Buy-1")) {
                Sleep.sleepUntil(() ->
                    Inventory.contains("Chugging barrel (disassembled)"), 5_000);
                Logger.log("Execute ▶ Bought Chugging barrel");
            }
            closeRewardsInterface();
            HerbGlobalState.setBuyingRewardsInProgress(false);
            return 1_800;
        }

        // 4) Aldarium purchase: always "Buy-50"
        if (mixologyConfig.isBuyAldarium()
                && aldariumPurchased < mixologyConfig.getAldariumPointsThreshold()
                && ptsMox() >= ALD_COST_MOX
                && ptsLye() >= ALD_COST_LYE
                && ptsAga() >= ALD_COST_AGA) {
            Logger.log("Execute ▶ Attempting Buy-50 Aldarium");
            WidgetChild ald = getChildPath(REWARDS_WIDGET_ROOT, ALDARIUM_SELECT);
            if (ald != null && ald.interact("Buy-50")) {
                Sleep.sleepUntil(() -> Inventory.count("Aldarium") > 0, 5000);
                Logger.log("Execute ▶ Bought Aldarium, inventoryCount=" + Inventory.count("Aldarium"));
            }
            closeRewardsInterface();
            HerbGlobalState.setBuyingRewardsInProgress(false);
            return 600;
        }

        // 5) nothing left to buy
        Logger.log("Execute ▶ No purchases left; closing interface");
        closeRewardsInterface();
        HerbGlobalState.setBuyingRewardsInProgress(false);
        return 300;
    }

    private boolean isRewardsInterfaceOpen() {
        WidgetChild check = getChildPath(REWARDS_WIDGET_ROOT, ALDARIUM_SELECT);
        return check != null && check.isVisible();
    }

    private void closeRewardsInterface() {
        @Nullable WidgetChild w = Widgets.get(819,3,11);
        if (w != null) w.interact("Close");
        Sleep.sleep(200, 350);
    }

    private int ptsMox() { return PlayerSettings.getConfig(4416); }
    private int ptsLye() { return PlayerSettings.getConfig(4414); }
    private int ptsAga() { return PlayerSettings.getConfig(4415); }

    private WidgetChild getChildPath(int root, int[] path) {
        WidgetChild c = Widgets.get(root,path[0]);
        for (int i = 1; i < path.length && c != null; i++) {
            c = c.getChild(path[i]);
        }
        return c;
    }

    @Override
    public void cleanup() {
        Logger.log("Cleanup ▶ Clearing buying-rewards state");
        HerbGlobalState.setBuyingRewardsInProgress(false);
    }
}
