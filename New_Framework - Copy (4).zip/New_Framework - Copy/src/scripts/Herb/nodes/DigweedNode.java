package scripts.Herb.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;
import scripts.Herb.MixologyScript;
import scripts.Herb.config.HerbConfig;
import scripts.Herb.config.MixologyConfig;
import scripts.Herb.utils.MixologyConstants;
import scripts.Herb.utils.MixologyUtils;
import scripts.Herb.HerbGlobalState;

/**
 * Node for collecting digweed spawns in the Mastering Mixology minigame
 */
public class DigweedNode extends SimpleNode<HerbConfig> {
    private final MixologyConfig mixologyConfig;
    private final MixologyScript script;
    private static final String DIGWEED = "Mature digweed";
    private static final String DIGWEED_ITEM = "Digweed";
    private static final int SAFE_INVENTORY_SLOT = 3; // Slot to move digweed to (0-based index)
    private static final int MAX_RETRIES = 3; // Maximum number of retries for moving digweed

    public DigweedNode(HerbConfig config, MixologyConfig mixologyConfig, MixologyScript script) {
        super("Collect Digweed", 0, config); // Priority 0 (highest) to ensure it runs before other nodes when digweed needs repositioning
        this.mixologyConfig = mixologyConfig;
        this.script = script;
    }

    @Override
    public boolean validate() {
        // Only validate if mixology is enabled and digweed collection is enabled
        if (!mixologyConfig.isCollectDigweed()) {
            return false;
        }
        if (HerbGlobalState.isAnyStationBusy()){
            return false;
        }
        if (HerbGlobalState.isMulingInProgress()){
            return false;
        }

        // CRITICAL: First check if digweed is in slots 0-2 and needs immediate repositioning
        Item digweed = Inventory.get(DIGWEED_ITEM);
        if (digweed != null && digweed.getSlot() <= 2) {
            Logger.log("[CRITICAL] Digweed found in slot " + digweed.getSlot() + " - needs immediate repositioning");
            return true;
        }

        // Check if there are digweed spawns to collect
        GameObject digweedSpawn = GameObjects.closest(obj ->
                obj != null && obj.getName().equalsIgnoreCase(DIGWEED) && obj.hasAction("Collect"));

        return digweedSpawn != null;
    }

    @Override
    protected int onExecute() {
        // CRITICAL: First handle any digweed in slots 0-2
        Item digweedItem = Inventory.get(DIGWEED_ITEM);
        if (digweedItem != null && digweedItem.getSlot() <= 2) {
            setStatus("CRITICAL: Moving digweed from slot " + digweedItem.getSlot() + " to safe slot");
            return repositionDigweed();
        }

        // Find the digweed spawn
        GameObject digweedSpawn = GameObjects.closest(obj ->
                obj != null && obj.getName().contains(DIGWEED));

        if (digweedSpawn == null) {
            setStatus("Digweed not found");
            return 1000;
        }

        // Check if we need to walk to the digweed
        if (digweedSpawn.distance() >= 5) {
            setStatus("Walking to digweed");
            Walking.walk(digweedSpawn);
            Sleep.sleepUntil(() -> digweedSpawn.distance() <= 5, 5000);
            return 600;
        }

        // Collect the digweed
        if (digweedSpawn.interact("Collect")) {
            setStatus("Picking digweed");
            Sleep.sleepUntil(() -> Inventory.contains(DIGWEED_ITEM) ||
                    !GameObjects.all().contains(digweedSpawn), 3000);

            // After picking, check if we need to reposition the digweed
            if (needsToRepositionDigweed()) {
                return repositionDigweed();
            }
            return 600;
        }

        return 600;
    }

    @Override
    public void cleanup() {
        setStatus("Cleaning up digweed node");
    }

    /**
     * Checks if digweed needs to be repositioned in the inventory
     *
     * @return true if digweed is in slots 0, 1, or 2 and needs to be moved
     */
    private boolean needsToRepositionDigweed() {
        Item digweed = Inventory.get(DIGWEED_ITEM);

        // If digweed is in slots 0-2, it needs to be moved
        if (digweed != null && digweed.getSlot() <= 2) {
            // If we're in processing phase, this is critical and should be handled immediately
            if (HerbGlobalState.isProcessingPhase()) {
                Logger.log("[CRITICAL] Digweed found in slot " + digweed.getSlot() + " during processing phase!");
            }
            return true;
        }
        return false;
    }

    /**
     * Repositions digweed to a safe slot in the inventory
     *
     * @return sleep time in ms
     */
    private int repositionDigweed() {
        Item digweed = Inventory.get(DIGWEED_ITEM);
        if (digweed == null) {
            return 100;
        }

        int currentSlot = digweed.getSlot();
        setStatus("Moving digweed from slot " + currentSlot + " to safe slot");

        // Try to find an empty slot above slot 2
        for (int slot = 3; slot < 28; slot++) {
            Item itemAtSlot = Inventory.getItemInSlot(slot);
            if (itemAtSlot == null) {
                // Found an empty slot, move digweed there
                if (Inventory.drag("Digweed", slot)) {
                    Sleep.sleepUntil(() -> {
                        Item movedDigweed = Inventory.get(DIGWEED_ITEM);
                        return movedDigweed != null && movedDigweed.getSlot() > 2;
                    }, 2000);
                    return 600;
                }
            }
        }

        // If we couldn't find an empty slot, try to use slot 3 anyway
        // This is better than leaving digweed in slots 0-2
        if (Inventory.drag("Digweed", SAFE_INVENTORY_SLOT)) {
            Sleep.sleepUntil(() -> {
                Item movedDigweed = Inventory.get(DIGWEED_ITEM);
                return movedDigweed != null && movedDigweed.getSlot() > 2;
            }, 2000);
            return 600;
        }

        // If we get here, we failed to move the digweed
        Logger.log("[WARNING] Failed to reposition digweed from slot " + currentSlot);
        return 600;
    }
}