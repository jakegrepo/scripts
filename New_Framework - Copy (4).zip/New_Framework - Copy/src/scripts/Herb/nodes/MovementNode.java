package scripts.Herb.nodes;

import core.base.SimpleNode;
import core.grandexchange.RestockCheckUtility;
import core.grandexchange.RestockGrandExchangeNode;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.bank.BankLocation;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.world.World;
import org.dreambot.api.methods.world.WorldType;
import org.dreambot.api.methods.world.Worlds;
import org.dreambot.api.methods.worldhopper.WorldHopper;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import scripts.Herb.MixologyScript;
import scripts.Herb.config.MixologyConfig;
import scripts.Herb.utils.MixologyConstants;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * Movement node to teleport to house, exit, then walk directly to mixology area
 */
public class MovementNode extends SimpleNode<MixologyConfig> {
    private static final Area MIXOLOGY_AREA = MixologyConstants.MIXOLOGY_AREA;
    private static final String HOUSE_TABLET = "Teleport to house";
    private static final String HOUSE_TABLET_ALT = "House teleport";
    private static final int HOUSE_TABLET_ID = 8013;
    private final MixologyScript script;
    private boolean hoppedWorld = false;
    private boolean teleported = false;
    private boolean hasCheckedRestock = false;
    
    // Track when RestockNode is finishing up
    private boolean restockFinishing = false;
    private long restockFinishTime = 0;
    private static final long RESTOCK_FINISH_GRACE_PERIOD = 5000; // 5 seconds grace period

    public MovementNode(MixologyConfig config, MixologyScript script) {
        super("Movement", 3, config);
        this.script=script;
    }

    @Override
    public boolean validate() {


        // If we're not at mixology area and restock is disabled or complete
        if (!MIXOLOGY_AREA.contains(Players.getLocal()) && !script.getRestockNode().isForceExecuting()) {
            Logger.info("[MOVEMENT_NODE] Not at mixology area, need to move there");
            return true;
        }

        return false;
    }

    @Override
    public int onExecute() {
        try {

            if (Worlds.getCurrent().isF2P()){
                hopWorld();
            }
            // 1) If inside a player-owned house, exit and mark teleported
            if (Client.isDynamicRegion()) {
                int res = exitHouse();
                // after exiting house, teleport flow done
                teleported = true;
                return res;
            }

            // 2) If we have tablet and haven't used it yet, use it
            if (hasHouseTeleport() && !teleported) {
                teleported = true;
                return useHouseTeleport();
            }

            // 3) Only withdraw if we haven't teleported yet and lack tablet
            if (!teleported && !hasHouseTeleport()) {
                // Open bank if not open
                if (!Bank.isOpen()) {
                    setStatus("Opening bank");
                    if (Bank.open()) {
                        Sleep.sleepUntil(Bank::isOpen, 5000);
                    }
                    return 600;
                }

                // Withdraw tablet
                setStatus("Withdrawing house teleport");
                if (Bank.contains(HOUSE_TABLET) || Bank.contains(HOUSE_TABLET_ALT) || Bank.contains(HOUSE_TABLET_ID)) {
                    // First try by name
                    if (Bank.contains(HOUSE_TABLET) && Bank.withdraw(HOUSE_TABLET, 1)) {
                        Logger.info("Withdrawing house tablet by name: " + HOUSE_TABLET);
                        Sleep.sleepUntil(this::hasHouseTeleport, 3000);
                    } 
                    // Try alternate name
                    else if (Bank.contains(HOUSE_TABLET_ALT) && Bank.withdraw(HOUSE_TABLET_ALT, 1)) {
                        Logger.info("Withdrawing house tablet by alternate name: " + HOUSE_TABLET_ALT);
                        Sleep.sleepUntil(this::hasHouseTeleport, 3000);
                    }
                    // Try by ID
                    else if (Bank.contains(HOUSE_TABLET_ID) && Bank.withdraw(HOUSE_TABLET_ID, 1)) {
                        Logger.info("Withdrawing house tablet by ID: " + HOUSE_TABLET_ID);
                        Sleep.sleepUntil(this::hasHouseTeleport, 3000);
                    }
                    
                    // If we successfully have the tablet now, close the bank and continue
                    if (hasHouseTeleport()) {
                        Logger.info("Successfully obtained house tablet");
                        Bank.close();
                        return 1000;
                    }
                    
                    // If we still don't have it, wait a bit and retry
                    Logger.warn("Failed to withdraw house tablet, retrying...");
                    return 600;
                } else {
                    Logger.error("No house tablets found in bank!");
                    return 1000;
                }
            }

            // 4) Once teleported/exited (or after withdraw), walk to mixology
            return walkToMixology();

        } catch (Exception e) {
            Logger.error("Error in MovementNode: " + e.getMessage());
            return 600;
        }
    }

    private void hopWorld() {
        int current = Worlds.getCurrentWorld();
        List<World> worlds = Worlds.getNormalizedWorlds().stream()
                .filter(w -> w.isMembers() && w.isNormal() && w.getWorld() != current && w.getMinimumLevel() == 0)
                .collect(Collectors.toList());
        if (!worlds.isEmpty()
                && WorldHopper.quickHop(worlds.get(new Random().nextInt(worlds.size())).getWorld())) {
            Sleep.sleepUntil(() -> Worlds.getCurrentWorld() != current, 10000);
        }
        hoppedWorld = true;
        hasCheckedRestock = false;
        Logger.log("Hopped world to " + Worlds.getCurrentWorld());
    }

    private boolean hasHouseTeleport() {
        return Inventory.contains(item -> item != null && (
                item.getName().equals(HOUSE_TABLET) || 
                item.getName().equals(HOUSE_TABLET_ALT) || 
                item.getID() == HOUSE_TABLET_ID));
    }

    private int useHouseTeleport() {
        setStatus("Using house teleport");
        var tab = Inventory.get(item -> item != null && (
                item.getName().equals(HOUSE_TABLET)));
        if (tab != null && tab.interact()) {
            Sleep.sleepUntil(Client::isDynamicRegion, 10000);
            return 1000;
        }
        return 600;
    }

    private int exitHouse() {
        setStatus("Exiting house");
        var portal = GameObjects.closest(obj -> obj != null && obj.getName().contains("Portal"));
        if (portal != null && portal.interact("Enter")) {
            Sleep.sleepUntil(() -> !Client.isDynamicRegion(), 10000);
            return 1000;
        }
        return 600;
    }

    private int walkToMixology() {
        setStatus("Walking to Mixology");
        if (Walking.walk(MIXOLOGY_AREA)) {
            Sleep.sleepUntil(() -> MIXOLOGY_AREA.contains(Players.getLocal()) || !Players.getLocal().isMoving(), 2000);
            return 1000;
        }
        return 600;
    }
}
