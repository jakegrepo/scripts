package scripts.Herb.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.GraphicsObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.graphics.GraphicsObject;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;
import scripts.Herb.HerbGlobalState;
import scripts.Herb.MixologyScript;
import scripts.Herb.config.HerbConfig;
import scripts.Herb.config.MixologyConfig;
import scripts.Herb.listeners.PotionItemListener;
import scripts.Herb.utils.MixologyConstants;
import scripts.Herb.utils.MixologyUtils;
import scripts.Herb.utils.PotionIdentifier;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProcessPotionNode extends SimpleNode<HerbConfig> implements GameTickListener {
    private static final int ORDER_WIDGET_ID = 304;
    private static final int ORDER_WIDGET_CHILD_ID = 0;

    // Constant values for station animations - updated to match MixologyConstants
    private static final int RETORT_BUSY_ANIM = MixologyConstants.RETORT_BUSY_ANIMATION_ID;
    private static final int AGITATOR_BUSY_ANIM = MixologyConstants.AGITATOR_BUSY_ANIMATION_ID;
    private static final int ALEMBIC_BUSY_ANIM = MixologyConstants.ALEMBIC_BUSY_ANIMATION_ID;

    // Station object IDs
    private static final int RETORT_ID = MixologyConstants.RETORT_ID;
    private static final int AGITATOR_ID = MixologyConstants.AGITATOR_ID;
    private static final int ALEMBIC_ID = MixologyConstants.ALEMBIC_ID;

    // Using areas from MixologyConstants
    private static final Area MIXOLOGY_AREA = MixologyConstants.MIXOLOGY_AREA;
    private static final Area PROCESSING_AREA = MixologyConstants.PROCESSING_AREA;

    // Map to store level requirements for each potion, using constants from MixologyConstants
    private static final Map<String, Integer> POTION_LEVEL_REQUIREMENTS = new HashMap<>();

    static {
        POTION_LEVEL_REQUIREMENTS.put("alco-augmentator", MixologyConstants.ALCO_AUGMENTATOR_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("mammoth-might mix", MixologyConstants.MAMMOTH_MIGHT_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("liplack liquor", MixologyConstants.LIPLACK_LIQUOR_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("mystic mana amalgam", MixologyConstants.MYSTIC_MANA_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("marley's moonlight", MixologyConstants.MARLEYS_MOONLIGHT_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("azure aura mix", MixologyConstants.AZURE_AURA_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("aqualux amalgam", MixologyConstants.AQUALUX_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("megalite liquid", MixologyConstants.MEGALITE_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("anti-leech lotion", MixologyConstants.ANTI_LEECH_LEVEL);
        POTION_LEVEL_REQUIREMENTS.put("mixalot", MixologyConstants.MIXALOT_LEVEL);
    }

    // Potion processing methods - key is potion name, value is processing method (C=Concentrate, H=Homogenise, Y=Crystallise)
    private static final Map<String, Character> PROCESSING_METHODS = new HashMap<>();

    static {
        PROCESSING_METHODS.put("alco-augmentator", MixologyConstants.ALCO_AUGMENTATOR_PROCESS);
        PROCESSING_METHODS.put("mammoth-might mix", MixologyConstants.MAMMOTH_MIGHT_PROCESS);
        PROCESSING_METHODS.put("liplack liquor", MixologyConstants.LIPLACK_LIQUOR_PROCESS);
        PROCESSING_METHODS.put("mystic mana amalgam", MixologyConstants.MYSTIC_MANA_PROCESS);
        PROCESSING_METHODS.put("marley's moonlight", MixologyConstants.MARLEYS_MOONLIGHT_PROCESS);
        PROCESSING_METHODS.put("azure aura mix", MixologyConstants.AZURE_AURA_PROCESS);
        PROCESSING_METHODS.put("aqualux amalgam", MixologyConstants.AQUALUX_PROCESS);
        PROCESSING_METHODS.put("megalite liquid", MixologyConstants.MEGALITE_PROCESS);
        PROCESSING_METHODS.put("anti-leech lotion", MixologyConstants.ANTI_LEECH_PROCESS);
        PROCESSING_METHODS.put("mixalot", MixologyConstants.MIXALOT_PROCESS);
    }

    private final MixologyConfig mixologyConfig;
    private final MixologyScript script;
    private PotionItemListener potionListener;

    private enum ProcessState {
        IDENTIFY_POTION, PROCESS_AT_STATION
    }

    private ProcessState currentState = ProcessState.IDENTIFY_POTION;
    private String currentPotion = "";
    private Character processingMethod = null;

    // Add these fields to the class
    private boolean retortNeedsOptimization = false;
    private boolean agitatorNeedsOptimization = false;
    private boolean alembicNeedsOptimization = false;
    private long lastRetortInteractionTime = 0;
    private long lastAgitatorInteractionTime = 0;
    private long lastAlembicInteractionTime = 0;
    private int retortClickCount = 0;
    private long retortProcessStartTime = 0;

    // Additional state tracking for Agitator
    private enum AgitatorState {NOT_STARTED, OPTIMIZATION_NEEDED, COMPLETE}

    private AgitatorState agitatorState = AgitatorState.NOT_STARTED;
    private long agitatorVisualEffectTime = 0;
    private boolean agitatorEffectDetected = false;
    private long agitatorProcessStartTime = 0;

    // Additional state tracking for Alembic
    public enum AlembicState {NOT_STARTED, OPTIMIZATION_NEEDED, OPTIMIZATION_COMPLETE}

    public AlembicState alembicState = AlembicState.NOT_STARTED;
    private long alembicSignalTime = 0;
    private boolean alembicSignalDetected = false;
    private long alembicProcessStartTime = 0;
    private boolean alembicOptimizationPerformed = false;
    // --- Alembic pump tracking fields ---
    private int alembicPumpCount = 0;
    private boolean alembicBonusClicked = false;
    private int alembicLastPlayerAnim = -1;
    private boolean alembicBonusEligible = false;

    // Graphics object IDs for optimization signals
    private static final int AGITATOR_FIREWORKS_GFX_ID = 2954;
    private static final int ALEMBIC_PUMP_SIGNAL_GFX_ID = 2955;

    public ProcessPotionNode(HerbConfig config, MixologyConfig mixologyConfig, MixologyScript script) {
        super("Process Potion", 10, config);
        this.mixologyConfig = mixologyConfig;
        this.script = script;
        // Register as GameTickListener
        script.getScriptManager().addListener(this);
        // Initialize but don't register the PotionItemListener yet
        this.potionListener = new PotionItemListener(script);
    }

    public ProcessPotionNode(HerbConfig config, MixologyConfig mixologyConfig, int priority, MixologyScript script) {
        super("Process Potion", priority, config);
        this.mixologyConfig = mixologyConfig;
        this.script = script;
        // Register as GameTickListener
        script.getScriptManager().addListener(this);
        // Initialize but don't register the PotionItemListener yet
        this.potionListener = new PotionItemListener(script);
    }

    @Override
    public boolean validate() {
        // Prevent running if muling is active
        if (HerbGlobalState.isMulingInProgress()) {
            return false;
        }

        // Special case: If any station needs optimization, prioritize that immediately
        if (retortNeedsOptimization || agitatorNeedsOptimization || alembicNeedsOptimization) {
            return true;
        }

        // Check if we're in the Mixology area
        if (!MixologyConstants.MIXOLOGY_AREA.contains(Players.getLocal())) {
            return false;
        }

        // IMPORTANT: Check if there are any unprocessed potions left in inventory
        boolean hasUnprocessedPotions = Inventory.contains(item -> MixologyUtils.isUnprocessedPotion(item.getID()));
        if (!hasUnprocessedPotions) {
            return false;
        }

        // CRITICAL: Check if digweed is in slots 0-2, which would interfere with potion processing
        Item digweed = Inventory.get("Digweed");
        if (digweed != null && digweed.getSlot() <= 2) {
            Logger.log("[CRITICAL] Cannot process potions - Digweed found in slot " + digweed.getSlot());
            return false; // Let DigweedNode handle moving the digweed first
        }

        // Only activate in processing phase or if global state indicates all potions are created but not processed
        boolean isInProcessingPhase = HerbGlobalState.isProcessingPhase();
        boolean allPotionsCreatedNotProcessed = HerbGlobalState.areAllPotionsCreatedButNotProcessed();

        if (!isInProcessingPhase && !allPotionsCreatedNotProcessed) {
            // Log detailed state for debugging
            return false;
        }

        // If we got here, the transition check passed
        if (!isInProcessingPhase && allPotionsCreatedNotProcessed) {
            HerbGlobalState.setProcessingPhase(true);
        }

        // IMPORTANT: Don't process a new potion if any station is busy
        if (isAnyStationBusy() || isRetortBusy()) {
            return false;
        }

        // Get current orders from HerbGlobalState
        List<String> currentOrders = HerbGlobalState.getCurrentOrders();

        // If there are no orders tracked, don't proceed
        if (currentOrders.isEmpty()) {
            return false;
        }

        // Check if any created potions still need processing
        boolean hasUnprocessedOrders = false;
        for (int i = 0; i < currentOrders.size(); i++) {
            if (HerbGlobalState.isPotionCreated(i) && !HerbGlobalState.isPotionProcessed(i)) {
                hasUnprocessedOrders = true;
                break;
            }
        }

        if (!hasUnprocessedOrders) {
            return false;
        }

        // Use PotionIdentifier to find any unprocessed potions
        // This is more reliable than our previous method
        Map<String, Object> potionInfo = PotionIdentifier.identifyPotion();

        // If we found a valid potion and its processing method, we can validate
        return potionInfo.get("potionName") != null && potionInfo.get("processingMethod") != null;
    }

    /**
     * Checks if any processing station is currently busy with an animation
     *
     * @return true if any station is busy, false otherwise
     */
    private boolean isRetortBusy() {
        GameObject retort = GameObjects.closest(obj -> obj != null && obj.getName().contains("Retort"));

        if (retort != null) {
            int anim = retort.getAnimationID();
            if (anim == RETORT_BUSY_ANIM) {
                // If this is the first time we're detecting it as busy, record the start time
                if (retortProcessStartTime == 0) {
                    retortProcessStartTime = System.currentTimeMillis();
                    retortClickCount = 0;
                }
                return true;
            } else if (anim == -1 && retortProcessStartTime > 0) {
                // Reset tracking when animation ends
                retortProcessStartTime = 0;
                retortClickCount = 0;
                retortNeedsOptimization = false;
            }
        }

        return false;
    }

    /**
     * Checks if the Agitator is currently busy with animation
     */
    private boolean isAgitatorBusy() {
        GameObject agitator = GameObjects.closest(obj -> obj != null && obj.getName().contains("Agitator"));

        if (agitator != null) {
            int anim = agitator.getAnimationID();
            if (anim == AGITATOR_BUSY_ANIM) {
                return true;
            }
        }

        return false;
    }

    /**
     * Checks if the Alembic is currently busy with animation
     */
    private boolean isAlembicBusy() {
        GameObject alembic = GameObjects.closest(obj -> obj != null && obj.getName().contains("Alembic"));

        if (alembic != null) {
            int anim = alembic.getAnimationID();
            if (anim == ALEMBIC_BUSY_ANIM) {
                // If this is the first detection, record initial state
                if (alembicState == AlembicState.NOT_STARTED) {
                    alembicState = AlembicState.OPTIMIZATION_NEEDED;
                    alembicProcessStartTime = System.currentTimeMillis();
                }
                return true;
            } else if (anim != ALEMBIC_BUSY_ANIM && alembicState != AlembicState.NOT_STARTED) {
                // Reset state when animation ends
                resetAlembicState();
            }
        }

        return false;
    }

    /**
     * Checks if any station is busy with an animation
     */
    private boolean isAnyStationBusy() {
        return isAgitatorBusy() || isAlembicBusy() || isRetortBusy();
    }

    /**
     * Check if a potion name matches an order string
     */
    private boolean potionMatchesOrder(String potionName, String orderText) {
        return HerbGlobalState.potionMatchesOrder(potionName, orderText);
    }

    @Override
    protected int onExecute() {
        try {
            // Register the potion listener when this node is executed
            if (potionListener != null) {
                potionListener.register();
                Logger.debug("ProcessPotionNode registered PotionItemListener");
            }

            // Check if we need to optimize any station
            if (retortNeedsOptimization) {
                setStatus("Optimizing Retort process");
                return optimiseRetortProcessing();
            }

            if (agitatorNeedsOptimization) {
                setStatus("Optimizing Agitator process");
                return optimizeAgitatorProcessing();
            }

            if (alembicNeedsOptimization) {
                setStatus("Optimizing Alembic process");
                return optimizeAlembicProcessing();
            }

            // Only proceed with normal processing if no optimizations are needed
            // Regular execution logic
            switch (currentState) {
                case IDENTIFY_POTION:
                    return identifyPotion();
                case PROCESS_AT_STATION:
                    return processAtStation();
                default:
                    return 100;
            }
        } catch (Exception e) {
            setStatus("Error: " + e.getMessage());
            return 600;
        }
    }

    /**
     * Find the unprocessed potion order index based on inventory item and current orders
     *
     * @param potionName The potion name to match
     * @return The order index or -1 if not found
     */
    private int findUnprocessedPotionOrderIndex(String potionName) {
        List<String> currentOrders = HerbGlobalState.getCurrentOrders();

        // Get the actual item from inventory
        Item potionItem = Inventory.get(item -> isUnprocessedPotion(item.getName()));

        if (potionItem == null) {
            return -1;
        }

        // CRITICAL - Check if this inventory slot is actually valid
        int inventorySlot = potionItem.getSlot();
        int itemId = potionItem.getID();
        Item slotItem = Inventory.getItemInSlot(inventorySlot);

        if (slotItem == null || slotItem.getID() != itemId) {
            return -1;
        }

        // First check: Extract order position from the potion name (most reliable)
        int orderPosition = -1;
        if (potionName.contains(" (order:")) {
            try {
                int startPos = potionName.indexOf(" (order:") + 8;
                int endPos = potionName.indexOf(")", startPos);
                if (endPos > startPos) {
                    String posStr = potionName.substring(startPos, endPos);
                    orderPosition = Integer.parseInt(posStr);

                    // If we have a valid order position, use it directly - This is the most reliable method
                    int indexToCheck = orderPosition - 1; // Convert 1-based position to 0-based index
                    if (indexToCheck < currentOrders.size() &&
                            HerbGlobalState.isPotionCreated(indexToCheck) &&
                            !HerbGlobalState.isPotionProcessed(indexToCheck)) {

                        // Double check that the slot information matches what we expect
                        int storedSlot = HerbGlobalState.getPotionInventorySlot(indexToCheck);
                        int storedItemId = HerbGlobalState.getPotionItemId(indexToCheck);

                        // If there's a mismatch in either slot or ID, something is wrong
                        if (storedSlot != inventorySlot || (storedItemId != -1 && storedItemId != itemId)) {

                            // The order needs to be reset since the tracking is incorrect
                            HerbGlobalState.resetOrderCreationStatus(indexToCheck);

                            // Now update with correct information
                            HerbGlobalState.trackPotionItemId(indexToCheck, itemId);
                            HerbGlobalState.setPotionInventorySlot(indexToCheck, inventorySlot);
                            // For now don't mark as created - we'll let ProcessPotionNode handle that
                        }

                        return indexToCheck;
                    }
                }
            } catch (Exception e) {
            }
        }

        // Second check: Look for matching item ID in global state
        int orderIndexByItemId = HerbGlobalState.findOrderIndexByItemId(itemId);

        if (orderIndexByItemId >= 0 && !HerbGlobalState.isPotionProcessed(orderIndexByItemId)) {
            // Verify slot information is consistent
            int storedSlot = HerbGlobalState.getPotionInventorySlot(orderIndexByItemId);
            if (storedSlot != inventorySlot) {
                HerbGlobalState.setPotionInventorySlot(orderIndexByItemId, inventorySlot);
            }

            return orderIndexByItemId;
        }

        // Third check: Look for matching inventory slot in global state
        for (int i = 0; i < currentOrders.size(); i++) {
            int storedSlot = HerbGlobalState.getPotionInventorySlot(i);

            if (storedSlot == inventorySlot &&
                    HerbGlobalState.isPotionCreated(i) &&
                    !HerbGlobalState.isPotionProcessed(i)) {

                // If there's an item ID stored, verify it matches
                int storedItemId = HerbGlobalState.getPotionItemId(i);
                if (storedItemId != -1 && storedItemId != itemId) {
                    HerbGlobalState.trackPotionItemId(i, itemId);
                }

                return i;
            }
        }

        // Fourth scan: Look for exact order matches that are created but not processed
        for (int i = 0; i < currentOrders.size(); i++) {
            if (potionMatchesOrder(potionName, currentOrders.get(i)) &&
                    HerbGlobalState.isPotionCreated(i) &&
                    !HerbGlobalState.isPotionProcessed(i)) {


                // Update slot and item ID information
                HerbGlobalState.trackPotionItemId(i, itemId);
                HerbGlobalState.setPotionInventorySlot(i, inventorySlot);

                return i;
            }
        }

        return -1;
    }

    private int identifyPotion() {
        setStatus("Identifying potion to process");

        // Find any unprocessed potion in the inventory
        Item potionItem = Inventory.get(item -> MixologyUtils.isUnprocessedPotion(item.getID()));

        if (potionItem == null) {
            setStatus("No unprocessed potion found");
            return 100;
        }

        // Get inventory slot and directly map to order position
        int inventorySlot = potionItem.getSlot();
        if (inventorySlot > 2) {
            Logger.log("Potion found in slot " + inventorySlot + " which is outside the expected range (0-2)");
            return 600;
        }

        // Double-check that this slot doesn't contain digweed
        Item itemInSlot = Inventory.getItemInSlot(inventorySlot);
        if (itemInSlot != null && itemInSlot.getName().equals("Digweed")) {
            Logger.log("[CRITICAL] Attempted to process a slot containing Digweed");
            return 600; // Skip this cycle and let DigweedNode handle it
        }

        // Direct 1:1 mapping between slot and order position
        int orderPosition = inventorySlot + 1; // Convert 0-based slot to 1-based position
        int orderIndex = inventorySlot;  // Order index is 0-based, same as slot

        // Get processing method directly from widget
        processingMethod = PotionIdentifier.getProcessingMethodForOrderPosition(orderPosition);

        if (processingMethod == null) {
            return 600;
        }

        // Set current potion name
        currentPotion = potionItem.getName();

        // Store for state tracking if needed
        HerbGlobalState.setPotionProcessingMethod(orderIndex, processingMethod);

        // Move to processing at station
        currentState = ProcessState.PROCESS_AT_STATION;
        return 200;
    }

    /**
     * Process the identified potion at the appropriate station
     */
    private int processAtStation() {
        if (processingMethod == null) {
            currentState = ProcessState.IDENTIFY_POTION;
            return 400;
        }

        // First check if any station is busy - don't proceed if so
        if (isAnyStationBusy()) {
            return 1000;
        }

        // Find the unprocessed potion in the inventory
        Item potionItem = Inventory.get(item -> MixologyUtils.isUnprocessedPotion(item.getID()));

        if (potionItem == null) {
            currentState = ProcessState.IDENTIFY_POTION;
            return 100;
        }

        // Select appropriate processing station based on the identified method
        GameObject targetStation = null;
        String stationName = "";

        switch (processingMethod) {
            case 'C': // Concentrate
                targetStation = GameObjects.closest(RETORT_ID);
                stationName = "Retort";
                setStatus("Processing potion at Retort (Concentrate)");
                break;

            case 'H': // Homogenize
                targetStation = GameObjects.closest(AGITATOR_ID);
                stationName = "Agitator";
                setStatus("Processing potion at Agitator (Homogenize)");
                break;

            case 'Y': // Crystallize
                targetStation = GameObjects.closest(ALEMBIC_ID);
                stationName = "Alembic";
                setStatus("Processing potion at Alembic (Crystallize)");
                break;

            default:
                Logger.log("Unknown processing method: " + processingMethod);
                currentState = ProcessState.IDENTIFY_POTION;
                return 400;
        }

        if (targetStation == null) {

            // Try to walk to the processing area if we can't find the station
            if (!PROCESSING_AREA.contains(Players.getLocal())) {
                setStatus("Walking to processing area");
                Walking.walk(PROCESSING_AREA.getRandomTile());
                return 1000;
            }

            return 600;
        }

        // Ensure we're in the processing area
        if (!PROCESSING_AREA.contains(Players.getLocal())) {
            setStatus("Walking to processing area");
            Walking.walk(PROCESSING_AREA.getRandomTile());
            return 1000;
        }

        // Get important tracking information before using the potion
        int itemId = potionItem.getID();
        int inventorySlot = potionItem.getSlot();
        String potionName = potionItem.getName();

        // Get current orders for reference
        List<String> currentOrders = HerbGlobalState.getCurrentOrders();

        // Use the potion on the station
        if (targetStation.interact()) {
            Sleep.sleepUntil(() -> isAnyStationBusy() || isRetortBusy(), 8000);
            // Wait for the processing to start
            String finalStationName = stationName;
            if (Sleep.sleepUntil(() -> {
                GameObject station = GameObjects.closest(obj -> obj != null && obj.getName().contains(finalStationName));
                return station != null && station.getAnimationID() != -1;
            }, 5000)) {
                Logger.log("Successfully started processing at " + stationName);

                // Reset state for next potion
                currentState = ProcessState.IDENTIFY_POTION;

                // Find order index based on inventory slot first - most reliable at this point
                int orderIndex = HerbGlobalState.findOrderIndexByInventorySlot(inventorySlot);

                if (orderIndex >= 0) {

                    // Important: We don't mark it as processed yet!
                    // The GameTickListener will detect when it's processed and update the state
                    // Just make sure our tracking information is up to date
                    if (!HerbGlobalState.isPotionCreated(orderIndex)) {
                        HerbGlobalState.markPotionCreated(orderIndex, potionName, inventorySlot);
                    }
                    HerbGlobalState.trackPotionItemId(orderIndex, itemId);
                } else {
                    // Cannot find order by slot - less reliable fallbacks

                    // Try by item ID
                    orderIndex = HerbGlobalState.findOrderIndexByItemId(itemId);
                    if (orderIndex >= 0) {

                        // Update inventory slot for this order
                        HerbGlobalState.setPotionInventorySlot(orderIndex, inventorySlot);
                    } else {
                        // Try by order position in potion name
                        if (potionName.contains(" (order:")) {
                            try {
                                int startPos = potionName.indexOf(" (order:") + 8;
                                int endPos = potionName.indexOf(")", startPos);
                                if (endPos > startPos) {
                                    String posStr = potionName.substring(startPos, endPos);
                                    int orderPosition = Integer.parseInt(posStr);
                                    orderIndex = orderPosition - 1; // Convert 1-based to 0-based


                                    // Update tracking for this order
                                    if (orderIndex >= 0 && orderIndex < currentOrders.size()) {
                                        HerbGlobalState.setPotionInventorySlot(orderIndex, inventorySlot);
                                        HerbGlobalState.trackPotionItemId(orderIndex, itemId);

                                        if (!HerbGlobalState.isPotionCreated(orderIndex)) {
                                            HerbGlobalState.markPotionCreated(orderIndex, potionName, inventorySlot);
                                        }
                                    }
                                }
                            } catch (Exception e) {
                            }
                        }

                        if (orderIndex < 0) {
                        }
                    }
                }

                return 2000; // Wait a bit longer to ensure processing completes
            } else {
                return 800;
            }
        } else {
            return 600;
        }
    }
    /* ─── retort click optimiser ──────────────────────────────────── */
    /* ───── Retort‑optimiser bookkeeping ───── */
    private volatile boolean optimiseRetort   = false; // true while a potion is in the retort
    private volatile boolean clickThisTick    = false; // set by onGameTick, consumed by node
    private int retortClickCounter            = 0;     // 0‑…‑9

    public boolean isOptimiseRetortActive() { return optimiseRetort; }
    public void    startRetortOptimiser()  { optimiseRetort = true;  retortClickCounter = 0; }
    private void   stopRetortOptimiser()   { optimiseRetort = false; clickThisTick = false; }
    /**
     * Improved method to check if a potion is unprocessed
     * Uses direct item ID checking via MixologyUtils
     */
    private boolean isUnprocessedPotion(String itemName) {
        return PotionIdentifier.isUnprocessedPotion(itemName);
    }

    @Override
    public void cleanup() {
        setStatus("Cleaning up process potion node");
        // Unregister the GameTickListener
        script.getScriptManager().removeListener(this);

        // Unregister the PotionItemListener if it exists
        if (potionListener != null) {
            try {
                potionListener.unregister();
                Logger.debug("ProcessPotionNode unregistered PotionItemListener");
            } catch (Exception e) {
                Logger.error("Error in ProcessPotionNode.cleanup(): " + e.getMessage());
            }
        }
    }

    /**
     * Checks if an item ID is that of a processed potion
     *
     * @param itemId The item ID to check
     * @return true if it's a processed potion, false otherwise
     */
    private boolean isProcessedPotion(int itemId) {
        return PotionIdentifier.isProcessedPotion(itemId);
    }

    @Override
    public void onServerTick() {
        // Only check for potions if we're in the Mixology area and have ongoing orders
        if (!MIXOLOGY_AREA.contains(Players.getLocal()) || HerbGlobalState.getCurrentOrders().isEmpty()) {
            return;
        }
        // --- Alembic pump tracking logic ---
        GameObject alembic = GameObjects.closest(obj -> obj != null && obj.getName().contains("Alembic"));
        boolean alembicBusy = (alembic != null && alembic.getAnimationID() == ALEMBIC_BUSY_ANIM);
        int playerAnim = Players.getLocal().getAnimation();
        if (alembicBusy) {
            // Start tracking if just started
            if (alembicState == AlembicState.NOT_STARTED) {
                alembicState = AlembicState.OPTIMIZATION_NEEDED;
                alembicPumpCount = 0;
                alembicBonusClicked = false;
                alembicBonusEligible = false;
                alembicLastPlayerAnim = -1;
            }
            // Detect pump: animation transitions from not pumping to pumping
            if (playerAnim == ALEMBIC_BUSY_ANIM && alembicLastPlayerAnim != ALEMBIC_BUSY_ANIM) {
                alembicPumpCount++;
                //Logger.log("Alembic pump count: " + alembicPumpCount);
                // Set eligible for bonus click on 5th or 7th pump
                if ((alembicPumpCount == 5 || alembicPumpCount == 7) && !alembicBonusClicked) {
                    alembicNeedsOptimization = true;
                    alembicBonusEligible = true;
                }
            }
            alembicLastPlayerAnim = playerAnim;
        } else {
            // Reset all alembic pump tracking if process ends
            alembicState = AlembicState.NOT_STARTED;
            alembicPumpCount = 0;
            alembicBonusClicked = false;
            alembicBonusEligible = false;
            alembicLastPlayerAnim = -1;
            alembicNeedsOptimization = false;
        }
        if (optimiseRetort) {
            clickThisTick = true;        // worker may consume it
        }
        // Enhanced logging for graphics objects detection
        if (PROCESSING_AREA.contains(Players.getLocal())) {
            List<GraphicsObject> nearbyGraphics = GraphicsObjects.all(gfx -> gfx != null);
            if (!nearbyGraphics.isEmpty()) {
                StringBuilder gfxLog = new StringBuilder("Found graphics objects in processing area: ");
                for (GraphicsObject gfx : nearbyGraphics) {
                    gfxLog.append("ID:").append(gfx.getID());
                }
            }
        }

        // Check for station optimizations - this is critical for precise timing
        checkAllStationStatuses();

        // Check for GraphicsObjects that indicate optimization opportunities
        checkForGraphicsObjects();

        // Check each slot that corresponds to an order
        List<String> currentOrders = HerbGlobalState.getCurrentOrders();
        int orderCount = currentOrders.size();

        if (orderCount > 0) {
            // Log the current inventory contents
            HerbGlobalState.logInventorySlotContents();

            // CRITICAL: Perform complete inventory verification
            verifyAllInventorySlots();

            // Verify the strict inventory slot mapping
            if (!HerbGlobalState.verifyStrictInventorySlotMapping()) {

                // Try to fix any discrepancies
                if (HerbGlobalState.fixInventorySlotMapping()) {
                } else {
                }
            }

            // IMPORTANT - prioritize tracking by inventory slot, not by order index
            // Using the strict mapping between order index and inventory slot:
            // Order 1 (index 0) -> slot 0
            // Order 2 (index 1) -> slot 1
            // Order 3 (index 2) -> slot 2
            for (int i = 0; i < orderCount && i < 3; i++) {
                // Skip orders that are already marked as processed
                if (HerbGlobalState.isPotionProcessed(i)) {
                    continue;
                }

                // Get the expected inventory slot for this order
                int expectedSlot = HerbGlobalState.getExpectedInventorySlot(i);
                Item itemInSlot = Inventory.getItemInSlot(expectedSlot);

                if (itemInSlot != null) {
                    int itemId = itemInSlot.getID();

                    // If it's a processed potion, mark it as processed
                    if (isProcessedPotion(itemId)) {

                        // Mark the potion as processed in the global state
                        if (HerbGlobalState.isPotionCreated(i) && !HerbGlobalState.isPotionProcessed(i)) {
                            HerbGlobalState.markPotionProcessed(i, itemInSlot.getName());

                            // Track the item ID for future reference
                            HerbGlobalState.trackPotionItemId(i, itemId);

                        }
                    } else if (MixologyUtils.isUnprocessedPotion(itemId)) {
                        // If we have an unprocessed potion in a slot, track it correctly
                        if (!HerbGlobalState.isPotionProcessed(i)) {

                            if (!HerbGlobalState.isPotionCreated(i)) {
                                // Mark as created if not already
                                HerbGlobalState.markPotionCreated(i, itemInSlot.getName(), expectedSlot);
                                HerbGlobalState.trackPotionItemId(i, itemId);
                            } else {
                                // Verify the item ID matches what we expect
                                int expectedItemId = HerbGlobalState.getPotionItemId(i);
                                if (expectedItemId != -1 && expectedItemId != itemId) {

                                    // Update with the correct item ID
                                    HerbGlobalState.trackPotionItemId(i, itemId);
                                }
                            }
                        }
                    }
                }
            }

            // Check if all potions are processed now
            boolean allProcessed = true;
            for (int i = 0; i < orderCount; i++) {
                if (HerbGlobalState.isPotionCreated(i) && !HerbGlobalState.isPotionProcessed(i)) {
                    allProcessed = false;
                    break;
                }
            }

            if (allProcessed && orderCount > 0) {
                HerbGlobalState.setProcessingPhase(false);
            }
        }
    }

    /**
     * Verifies the inventory slots for all orders, making sure each order's potion is
     * in the expected slot and updating tracking if necessary.
     */
    private void verifyAllInventorySlots() {
        List<String> currentOrders = HerbGlobalState.getCurrentOrders();
        int orderCount = currentOrders.size();

        if (orderCount == 0) {
            return;
        }

        // Log the inventory contents for debugging
        StringBuilder inventoryLog = new StringBuilder("Current inventory slots (0-2): ");
        for (int slot = 0; slot < 3 && slot < 28; slot++) {
            Item item = Inventory.getItemInSlot(slot);
            if (item != null) {
            } else {
            }
        }

        // Check each order against its expected inventory slot
        boolean needsStateLog = false;

        for (int i = 0; i < orderCount && i < 3; i++) {
            // The expected inventory slot for this order
            int expectedSlot = i; // Direct 1:1 mapping

            // Get the current tracking for this order
            int currentSlot = HerbGlobalState.getPotionInventorySlot(i);
            int trackedItemId = HerbGlobalState.getPotionItemId(i);
            boolean isCreated = HerbGlobalState.isPotionCreated(i);
            boolean isProcessed = HerbGlobalState.isPotionProcessed(i);

            // Check what's actually in the expected slot
            Item itemInExpectedSlot = Inventory.getItemInSlot(expectedSlot);

            if (isCreated && !isProcessed) {
                // This order should have an unprocessed potion in its slot

                if (itemInExpectedSlot == null) {


                    // Try to find the item by ID elsewhere in inventory
                    if (trackedItemId != -1) {
                        Item misplacedItem = Inventory.get(trackedItemId);
                        if (misplacedItem != null) {
                            int actualSlot = misplacedItem.getSlot();

                            // Update tracking to the actual slot
                            if (currentSlot != actualSlot) {
                                HerbGlobalState.setPotionInventorySlot(i, actualSlot);
                                needsStateLog = true;
                            }
                        }
                    }
                } else {
                    // There is an item in the expected slot, check if it's the one we're tracking
                    int itemId = itemInExpectedSlot.getID();

                    if (trackedItemId != -1 && trackedItemId != itemId) {

                        // Check if it's a processed version
                        if (isProcessedPotion(itemId)) {

                            HerbGlobalState.markPotionProcessed(i, itemInExpectedSlot.getName());
                            HerbGlobalState.trackPotionItemId(i, itemId);
                            needsStateLog = true;
                        } else {
                            // Try to find our expected item elsewhere
                            Item trackedItem = Inventory.get(trackedItemId);
                            if (trackedItem != null) {
                                int actualSlot = trackedItem.getSlot();

                                HerbGlobalState.setPotionInventorySlot(i, actualSlot);
                                needsStateLog = true;
                            } else {
                                // Item not found, update to use what's in the expected slot

                                HerbGlobalState.trackPotionItemId(i, itemId);
                                needsStateLog = true;
                            }
                        }
                    } else if (isProcessedPotion(itemId)) {
                        // This is a processed potion but not marked as such

                        HerbGlobalState.markPotionProcessed(i, itemInExpectedSlot.getName());
                        HerbGlobalState.trackPotionItemId(i, itemId);
                        needsStateLog = true;
                    }
                }
            }
            // It could be that we have an order that should be in the slot but isn't tracked
            else if (!isCreated && !isProcessed) {
                if (itemInExpectedSlot != null) {
                    int itemId = itemInExpectedSlot.getID();

                    // Check if this is an unprocessed potion that should be tracked
                    if (MixologyUtils.isUnprocessedPotion(itemId)) {

                        HerbGlobalState.markPotionCreated(i, itemInExpectedSlot.getName(), expectedSlot);
                        HerbGlobalState.trackPotionItemId(i, itemId);
                        needsStateLog = true;
                    }
                    // It could be a processed potion that was missed
                    else if (isProcessedPotion(itemId)) {

                        HerbGlobalState.markPotionCreated(i, itemInExpectedSlot.getName(), expectedSlot);
                        HerbGlobalState.markPotionProcessed(i, itemInExpectedSlot.getName());
                        HerbGlobalState.trackPotionItemId(i, itemId);
                        needsStateLog = true;
                    }
                }
            }
        }
    }

    /**
     * Checks the status of all processing stations and sets optimization flags as needed
     */
    private void checkAllStationStatuses() {
        // Only proceed if we're in the processing area
        if (!PROCESSING_AREA.contains(Players.getLocal())) {
            retortNeedsOptimization = false;
            agitatorNeedsOptimization = false;
            alembicNeedsOptimization = false;
            resetStationStates();
            return;
        }

        // Check Retort
        GameObject retort = GameObjects.closest(obj -> obj != null && obj.getName().contains("Retort"));
        if (retort != null) {
            int animation = retort.getAnimationID();
            boolean currentlyBusy = (animation == RETORT_BUSY_ANIM);

            if (currentlyBusy) {
                retortNeedsOptimization = true;
            } else if (!currentlyBusy && retortNeedsOptimization) {
                retortNeedsOptimization = false;
            }
        } else {
            retortNeedsOptimization = false;
        }

        // Check Agitator - just check if it's busy, GraphicsObjectSpawnedListener will handle the fireworks
        GameObject agitator = GameObjects.closest(obj -> obj != null && obj.getName().contains("Agitator"));
        if (agitator != null) {
            int animation = agitator.getAnimationID();
            boolean currentlyBusy = (animation == AGITATOR_BUSY_ANIM);

            if (currentlyBusy) {
                // Only set the optimization flag if we don't already have it set
                // The fireworks detection will handle setting it when needed

                // Initial state when process first detected
                if (agitatorState == AgitatorState.NOT_STARTED) {
                    agitatorState = AgitatorState.OPTIMIZATION_NEEDED;
                    agitatorProcessStartTime = System.currentTimeMillis();
                }
            } else {
                agitatorNeedsOptimization = false;
                // Reset state when complete
                if (agitatorState != AgitatorState.NOT_STARTED) {
                    resetAgitatorState();
                }
            }
        } else {
            agitatorNeedsOptimization = false;
            resetAgitatorState();
        }

        // Check Alembic - just check if it's busy, GraphicsObjectSpawnedListener will handle the pump signals
        GameObject alembic = GameObjects.closest(obj -> obj != null && obj.getName().contains("Alembic"));
        if (alembic != null) {
            int animation = alembic.getAnimationID();
            boolean currentlyBusy = (animation == ALEMBIC_BUSY_ANIM);

            if (!currentlyBusy) {
                alembicNeedsOptimization = false;
                // Reset state when complete
                resetAlembicState();
            }
        } else {
            alembicNeedsOptimization = false;
            resetAlembicState();
        }
    }

    /**
     * Reset all station states - used when player leaves the processing area
     */
    private void resetStationStates() {
        resetAgitatorState();
        resetAlembicState();
        // Also reset Retort state
        retortProcessStartTime = 0;
        retortClickCount = 0;
        retortNeedsOptimization = false;
    }

    /**
     * Reset the Agitator state tracking
     */
    private void resetAgitatorState() {
        agitatorState = AgitatorState.NOT_STARTED;
        agitatorEffectDetected = false;
        agitatorVisualEffectTime = 0;
        agitatorProcessStartTime = 0;
    }

    /**
     * Reset the Alembic state tracking
     */
    private void resetAlembicState() {
        alembicState = AlembicState.NOT_STARTED;
        alembicSignalDetected = false;
        alembicSignalTime = 0;
        alembicProcessStartTime = 0;
        alembicNeedsOptimization = false;
        alembicOptimizationPerformed = false;
    }

    /**
     * Optimization for Agitator processing
     * Click once when fireworks graphics object appears
     */
    private int optimizeAgitatorProcessing() {
        GameObject agitator = GameObjects.closest(obj -> obj != null && obj.getName().contains("Agitator"));

        if (agitator == null || agitator.getAnimationID() != AGITATOR_BUSY_ANIM) {
            agitatorNeedsOptimization = false;
            resetAgitatorState();
            return 0;
        }

        long currentTime = System.currentTimeMillis();

        // Single click optimization when effect is detected
        if (agitatorEffectDetected && agitatorState == AgitatorState.OPTIMIZATION_NEEDED) {
            // Click as quickly as possible after the effect
            if (currentTime - agitatorVisualEffectTime <= 600) { // within 1 tick
                if (agitator.interact("Homogenise-potion")) {
                    lastAgitatorInteractionTime = currentTime;
                    setStatus("Agitator optimization complete");
                    agitatorState = AgitatorState.COMPLETE;
                    return 100;
                }
            } else {
                // Missed the window for optimization
                Logger.log("❌ Missed Agitator optimization window - " +
                        (currentTime - agitatorVisualEffectTime) + "ms elapsed");
                agitatorState = AgitatorState.COMPLETE;
                return 100;
            }
        }

        return 50; // Short sleep to check again soon
    }

    /**
     * Optimization for Alembic processing
     * Click once on the 5th (or 7th if missed) pump for bonus XP
     */
    private int optimizeAlembicProcessing() {
        GameObject alembic = GameObjects.closest(obj -> obj != null && obj.getName().contains("Alembic"));
        if (alembic == null || alembic.getAnimationID() != ALEMBIC_BUSY_ANIM) {
            alembicNeedsOptimization = false;
            resetAlembicState();
            return 0;
        }
        // Only perform one interaction after eligible pump
        if (alembicBonusEligible && !alembicBonusClicked) {
            if (alembic.interact("Crystalise-potion")) {
                lastAlembicInteractionTime = System.currentTimeMillis();
                setStatus("Alembic bonus XP click (" + alembicPumpCount + "th pump)");
                alembicBonusClicked = true;
                alembicNeedsOptimization = false;
                return 3000; // Wait one tick
            }
        }
        return 50; // Short sleep to check again soon
    }

    /**
     * Optimization for Retort processing
     * Click once per tick, limited to 11 clicks total
     */

    private int optimiseRetortProcessing() {

        GameObject retort = GameObjects.closest("Retort");
        if (retort == null) {
            stopRetortOptimiser();
            return 0;
        }

        /* potion just started processing – kick off optimiser */
        if (retort.getAnimationID() == RETORT_BUSY_ANIM && !isOptimiseRetortActive()) {
            startRetortOptimiser();
            return 100;
        }

        /* Retort became idle → stop clicking */
        if (retort.getAnimationID() != RETORT_BUSY_ANIM) {
            stopRetortOptimiser();
            return 0;
        }

        /* Retort is busy AND optimiser active */
        if (clickThisTick && retortClickCounter < 9) {
            clickThisTick = false;                  // consume the tick
            if (retort.interact("Concentrate-potion")) {
                retortClickCounter++;
            }
        }

        /* stop after 9 clicks even if animation still running */
        if (retortClickCounter >= 9) {
            stopRetortOptimiser();
        }

        return 50;    // small sleep keeps node responsive
    }


    /**
     * Check for GraphicsObjects during game ticks to detect optimization cues
     */
    private void checkForGraphicsObjects() {
        // Only process if we're in the right area
        if (!PROCESSING_AREA.contains(Players.getLocal())) {
            return;
        }

        // Check Retort status (no graphics objects, but still needs optimization)
        if (isRetortBusy()) {
            // If retort is busy and we haven't started optimization yet, always trigger it
            if (!retortNeedsOptimization && retortClickCount < 11) {
                long currentTime = System.currentTimeMillis();
                if (retortProcessStartTime == 0) {
                    // This is the first detection of this process, record start time
                    retortProcessStartTime = currentTime;
                }
                retortNeedsOptimization = true;
                lastRetortInteractionTime = 0; // Reset to ensure first click happens immediately
            }
        } else if (!isRetortBusy() && retortProcessStartTime > 0) {
            // Reset when retort is no longer busy
            retortProcessStartTime = 0;
            retortClickCount = 0;
            retortNeedsOptimization = false;
        }

        // Check for Agitator fireworks (ID: 2954)
        if (isAgitatorBusy()) {
            GraphicsObject fireworks = GraphicsObjects.closest(gfx ->
                    gfx != null &&
                            gfx.getID() == AGITATOR_FIREWORKS_GFX_ID);

            if (fireworks != null) {
                // Find the nearest Agitator to verify this is relevant
                GameObject agitator = GameObjects.closest(obj ->
                        obj != null &&
                                obj.getName().contains("Agitator"));

                if (agitator != null && agitator.distance() < 3) {

                    // Update state
                    agitatorEffectDetected = true;
                    agitatorVisualEffectTime = System.currentTimeMillis();
                    agitatorNeedsOptimization = true;

                    // Set state to indicate optimization is needed
                    agitatorState = AgitatorState.OPTIMIZATION_NEEDED;

                    // Force immediate execution in the next tick
                    lastAgitatorInteractionTime = 0;
                }
            }
        }

        // Check for Alembic signal (ID: 2955)
        if (isAlembicBusy() && !alembicOptimizationPerformed) {
            // Log ALL graphics objects in detail when Alembic is busy
            List<GraphicsObject> nearbyGraphics = GraphicsObjects.all(gfx -> gfx != null);
            if (!nearbyGraphics.isEmpty()) {
                StringBuilder gfxLog = new StringBuilder("Alembic is busy - Graphics objects nearby: ");
                for (GraphicsObject gfx : nearbyGraphics) {
                    gfxLog.append("ID:").append(gfx.getID());
                }
            }

            GraphicsObject pumpSignal = GraphicsObjects.closest(gfx ->
                    gfx != null &&
                            gfx.getID() == ALEMBIC_PUMP_SIGNAL_GFX_ID);

            if (pumpSignal != null) {
                // Find the nearest Alembic to verify this is relevant
                GameObject alembic = GameObjects.closest(obj ->
                        obj != null &&
                                obj.getName().contains("Alembic"));

                if (alembic != null && alembic.distance() < 3) {
                    long currentTime = System.currentTimeMillis();
                    String timeInfo = "";

                    // Calculate timing from process start if available
                    if (alembicProcessStartTime > 0) {
                        timeInfo = " (" + (currentTime - alembicProcessStartTime) + "ms after process start)";
                    }

                    // Update state - ENSURE WE ONLY TRIGGER ONCE
                    if (!alembicSignalDetected) {

                        alembicSignalDetected = true;
                        alembicSignalTime = currentTime;
                        alembicNeedsOptimization = true;
                        alembicState = AlembicState.OPTIMIZATION_NEEDED;
                        lastAlembicInteractionTime = 0;
                    }
                }
            }
        }
    }
}
