package scripts.Herb.listeners;

import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.script.AbstractScript;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.script.listener.ItemContainerListener;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.items.Item;
import scripts.Herb.HerbGlobalState;
import scripts.Herb.utils.MixologyConstants;

/**
 * Listens for inventory changes specifically for potion items
 * Handles tracking of potion items as they're added/removed from inventory
 */
public class PotionItemListener implements ItemContainerListener, GameTickListener {

    private final AbstractScript script;

    public PotionItemListener(AbstractScript script) {
        this.script = script;
        // No longer automatically registering in constructor
        Logger.log("PotionItemListener initialized (not yet registered)");
    }

    /**
     * Register this listener with the script manager
     */
    public void register() {
        script.getScriptManager().addListener(this);
    }

    /**
     * Unregister this listener from the script manager
     */
    public void unregister() {
        script.getScriptManager().removeListener(this);
    }

    @Override
    public void onInventoryItemAdded(Item item) {
        if (item == null) return;

        String itemName = item.getName();
        int itemId = item.getID();
        int inventorySlot = item.getSlot();

        // Check if this is an unprocessed potion
        if (isUnprocessedPotion(itemName)) {


            // Find the corresponding order based on inventory slot
            // STRICT MAPPING: order 1 -> slot 0, order 2 -> slot 1, order 3 -> slot 2
            int orderIndex = inventorySlot; // Direct 1:1 mapping

            if (orderIndex >= 0 && orderIndex < HerbGlobalState.getTotalOrdersToProcess()) {
                // Verify this is using the strict mapping approach
                if (HerbGlobalState.useStrictInventorySlotMapping()) {
                    int expectedSlot = HerbGlobalState.getExpectedInventorySlot(orderIndex);
                    if (inventorySlot != expectedSlot) {

                    }
                }

                // Only track if not already tracked - don't override the MixPotionNode's work
                if (!HerbGlobalState.isPotionCreated(orderIndex)) {

                    // Mark as created with the strict inventory slot mapping
                    HerbGlobalState.markPotionCreated(orderIndex, itemName, inventorySlot);

                    // Track the item ID for this order
                    HerbGlobalState.trackPotionItemId(orderIndex, itemId);
                } else {
                    // Check if we need to update the inventory slot
                    int currentSlot = HerbGlobalState.getPotionInventorySlot(orderIndex);
                    if (currentSlot != inventorySlot) {
                        HerbGlobalState.setPotionInventorySlot(orderIndex, inventorySlot);
                    }

                    // Also check if we need to update the item ID
                    int currentItemId = HerbGlobalState.getPotionItemId(orderIndex);
                    if (currentItemId != itemId) {
                        HerbGlobalState.trackPotionItemId(orderIndex, itemId);
                    }
                }
            } else {
            }
        }
        // Check if this is a processed potion
        else if (isProcessedPotion(item.getID())) {

            // Find the matching unprocessed potion order index based on slot
            int orderIndex = inventorySlot; // Direct 1:1 mapping
            if (orderIndex >= 0 && orderIndex < HerbGlobalState.getTotalOrdersToProcess()) {
                if (HerbGlobalState.isPotionCreated(orderIndex) && !HerbGlobalState.isPotionProcessed(orderIndex)) {
                    HerbGlobalState.markPotionProcessed(orderIndex, itemName);
                    // Update the item ID to the processed potion ID
                    HerbGlobalState.trackPotionItemId(orderIndex, itemId);

                    // Log the current state of all orders for debugging
                    HerbGlobalState.logAllOrdersState();
                }
            }
        }
    }

    @Override
    public void onInventoryItemRemoved(Item item) {
        if (item == null) return;

        String itemName = item.getName();
        int itemId = item.getID();
        int slot = item.getSlot();


        // Check if this is an unprocessed potion being removed
        if (isUnprocessedPotion(itemName)) {
            // Find the order index by item ID and verify it matches the slot
            int orderIndex = HerbGlobalState.findOrderIndexByItemId(itemId);

            if (orderIndex >= 0) {
                // Double check slot mapping - use the strict method
                int expectedSlot = HerbGlobalState.getExpectedInventorySlot(orderIndex);

                // If the slot doesn't match, this could be a tracking issue
                if (slot != expectedSlot && slot >= 0 && slot < 3) {

                    // If there's a valid order at the actual slot position, check its status
                    int actualOrderIndex = slot;
                    if (actualOrderIndex >= 0 && actualOrderIndex < HerbGlobalState.getTotalOrdersToProcess()) {
                        boolean isCreated = HerbGlobalState.isPotionCreated(actualOrderIndex);
                        boolean isProcessed = HerbGlobalState.isPotionProcessed(actualOrderIndex);
                    }
                }
            }
        }
    }

    /**
     * Performs a full verification of inventory slots against order tracking.
     * Call this method periodically to ensure consistency between inventory and tracking.
     */
    public void verifyInventorySlots() {

        int orderCount = HerbGlobalState.getTotalOrdersToProcess();
        if (orderCount == 0) {
            return;
        }

        // Check each slot that should contain a potion
        for (int i = 0; i < orderCount && i < 3; i++) {
            // Skip processed orders
            if (HerbGlobalState.isPotionProcessed(i)) {
                continue;
            }

            // Verify the correct item is in the expected slot
            int expectedSlot = HerbGlobalState.getExpectedInventorySlot(i);
            Item itemInSlot = Inventory.getItemInSlot(expectedSlot);

            if (HerbGlobalState.isPotionCreated(i)) {
                // If the order is marked as created, there should be a potion in this slot
                if (itemInSlot == null) {

                    // Look for this potion elsewhere in inventory
                    int itemId = HerbGlobalState.getPotionItemId(i);
                    if (itemId != -1) {
                        Item foundItem = Inventory.get(itemId);
                        if (foundItem != null) {
                            int actualSlot = foundItem.getSlot();

                            // Update the slot information
                            HerbGlobalState.setPotionInventorySlot(i, actualSlot);
                        } else {
                        }
                    }
                } else {
                    // There is an item in this slot, check if it's the expected potion
                    int itemId = itemInSlot.getID();
                    int expectedItemId = HerbGlobalState.getPotionItemId(i);

                    if (expectedItemId != -1 && itemId != expectedItemId) {

                        // Try to find the expected item elsewhere
                        Item expectedItem = Inventory.get(expectedItemId);
                        if (expectedItem != null) {
                            int actualSlot = expectedItem.getSlot();

                            // Update the slot information
                            HerbGlobalState.setPotionInventorySlot(i, actualSlot);
                        }
                    } else if (isProcessedPotion(itemId)) {
                        // This potion is processed but not marked as such

                        HerbGlobalState.markPotionProcessed(i, itemInSlot.getName());
                        HerbGlobalState.trackPotionItemId(i, itemId);
                    }
                }
            } else {
                // Order is not created, slot should be empty or contain something else
                if (itemInSlot != null && isUnprocessedPotion(itemInSlot.getName())) {

                    HerbGlobalState.markPotionCreated(i, itemInSlot.getName(), expectedSlot);
                    HerbGlobalState.trackPotionItemId(i, itemInSlot.getID());
                }
            }
        }

        // Log the current state after verification
        HerbGlobalState.logAllOrdersState();
    }

    /**
     * GameTickListener implementation to verify inventory slots on every game tick
     */
    @Override
    public void onServerTick() {
        // Fast check to avoid spamming logs when not in Mixology area
        if (!MixologyConstants.MIXOLOGY_AREA.contains(org.dreambot.api.methods.interactive.Players.getLocal())) {
            return;
        }

        int orderCount = HerbGlobalState.getTotalOrdersToProcess();
        if (orderCount > 0) {
            // Perform verification on every tick when we have active orders
            verifyInventorySlots();

            // Also run the strict slot mapping verification
            HerbGlobalState.verifyStrictInventorySlotMapping();
        }
    }

    /**
     * Check if an item name is an unprocessed potion
     */
    private boolean isUnprocessedPotion(String itemName) {
        if (itemName == null) return false;

        // Use a simple keyword check with lowercase for case-insensitivity
        String lowerItemName = itemName.toLowerCase();
        boolean isPotentialUnprocessedPotion =
               lowerItemName.contains("alco") ||
               lowerItemName.contains("mammoth") ||
               lowerItemName.contains("mystic") ||
               lowerItemName.contains("liplack") ||
               lowerItemName.contains("marley") ||
               lowerItemName.contains("azure") ||
               lowerItemName.contains("aqualux") ||
               lowerItemName.contains("megalite") ||
               lowerItemName.contains("anti-leech") ||
               lowerItemName.contains("mixalot");

        // If it's potentially an unprocessed potion, make sure it's not one of the completed versions
        if (isPotentialUnprocessedPotion) {
            Item item = Inventory.get(itemName);
            if (item != null) {
                for (int potionId : MixologyConstants.PROCESSED_POTION_IDS) {
                    if (item.getID() == potionId) {
                        return false;
                    }
                }
            }
            return true;
        }

        return false;
    }

    /**
     * Check if an item ID is a processed potion
     */
    private boolean isProcessedPotion(int itemId) {
        for (int potionId : MixologyConstants.PROCESSED_POTION_IDS) {
            if (itemId == potionId) {
                return true;
            }
        }
        return false;
    }

    /**
     * Cleanup method to unregister the GameTickListener
     * @deprecated Use unregister() instead
     */
    public void cleanup() {
        unregister();
    }
}