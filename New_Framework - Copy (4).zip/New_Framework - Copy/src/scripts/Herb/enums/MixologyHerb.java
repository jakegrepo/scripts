package scripts.Herb.enums;

/**
 * Enum representing the different herbs available in the Mixology minigame.
 */
public enum MixologyHerb {
    HARRALANDER("Harralander"),
    AVANTOE("Avantoe"),
    DWARF_WEED("Dwarf weed"),
    CACTUS_SPINE("Cactus spine"),
    KWUARM("Kwuarm"),
    SNAPDRAGON("Snapdragon"),
    DIGWEED("Digweed");

    private final String name;

    MixologyHerb(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    /**
     * Find a herb by name.
     * @param name The name of the herb.
     * @return The herb enum, or null if not found.
     */
    public static MixologyHerb getByName(String name) {
        for (MixologyHerb herb : values()) {
            if (herb.getName().equalsIgnoreCase(name)) {
                return herb;
            }
        }
        return null;
    }
    
    /**
     * Check if a herb name is valid.
     * @param name The name to check.
     * @return True if the name is a valid herb, false otherwise.
     */
    public static boolean isValidHerb(String name) {
        return getByName(name) != null;
    }
} 