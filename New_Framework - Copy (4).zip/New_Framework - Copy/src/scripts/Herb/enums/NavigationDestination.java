package scripts.Herb.enums;

/**
 * Enum representing the different navigation destinations in the Mixology minigame.
 */
public enum NavigationDestination {
    ENTRANCE,
    MIXOLOGY_AREA,
    MIXING_AREA,
    REFINING_AREA,
    STORAGE_AREA,
    EXECUTE_CHILDREN,
    EXIT;
    
    /**
     * Get a user-friendly name for the destination.
     * @return A formatted string representing the destination.
     */
    public String getFormattedName() {
        return name().replace("_", " ").toLowerCase();
    }
} 