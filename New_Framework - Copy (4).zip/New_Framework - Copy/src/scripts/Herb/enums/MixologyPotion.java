package scripts.Herb.enums;

/**
 * Enum representing the different potions available in the Mixology minigame.
 * Each potion has a name and a default priority value.
 */
public enum MixologyPotion {
    ALCO_AUGMENTATOR("Alco-AugmentAtor", 5),
    MAMMOTH_MIGHT("Mammoth-Might Mix", 4),
    LIPLACK_LIQUOR("LipLack Liquor", 3),
    MYSTIC_MANA("Mystic Mana Amalgam", 2),
    MARLEYS_MOONLIGHT("Marley's MoonLight", 2),
    AZURE_AURA("Azure Aura Mix", 1),
    AQUALUX("AquaLux Amalgam", 1),
    MEGALITE("MegaLite Liquid", 1),
    ANTI_LEECH("Anti-Leech Lotion", 1),
    MIXALOT("MixALot", 1);

    private final String name;
    private final int defaultPriority;

    MixologyPotion(String name, int defaultPriority) {
        this.name = name;
        this.defaultPriority = defaultPriority;
    }

    public String getName() {
        return name;
    }

    public int getDefaultPriority() {
        return defaultPriority;
    }

    /**
     * Find a potion by name.
     * @param name The name of the potion.
     * @return The potion enum, or null if not found.
     */
    public static MixologyPotion getByName(String name) {
        for (MixologyPotion potion : values()) {
            if (potion.getName().equalsIgnoreCase(name)) {
                return potion;
            }
        }
        return null;
    }
    
    /**
     * Check if a potion name is valid.
     * @param name The name to check.
     * @return True if the name is a valid potion, false otherwise.
     */
    public static boolean isValidPotion(String name) {
        return getByName(name) != null;
    }
} 