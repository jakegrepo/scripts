package scripts.ScarWraths.muling;

/**
 * Represents the different states the MulingNode can be in.
 */
public enum MuleStatus {
    IDLE,                   // Not currently muling
    CHECK_CONDITIONS,       // Checking if muling is necessary
    WALKING_TO_MEET,        // Moving to the meeting location
    HOPPING_WORLD,          // Hopping to the mule's world
    CONNECTING_TO_MULE,     // Attempting socket connection
    WAITING_FOR_MULE,       // Connected, waiting for mule player/confirmation
    TRADING,                // Actively in the trade interface
    TRADE_ACCEPTED_NEED_CONFIRM, // Player accepted, waiting for mule's second accept
    WAITING_FOR_COMPLETION, // Both accepted, waiting for trade to finalize
    COMPLETE,               // Muling process finished successfully
    DISCONNECTING,          // Cleaning up connection
    ERROR                   // Error state
}
