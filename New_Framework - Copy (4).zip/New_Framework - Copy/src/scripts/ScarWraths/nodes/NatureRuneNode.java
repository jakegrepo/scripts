package scripts.ScarWraths.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.Calculations;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;
import scripts.ScarWraths.ScarWrathsScript;
import scripts.ScarWraths.config.ScarWrathsConfig;

/**
 * NatureRune node for crafting Nature runes at the altar
 */
public class NatureRuneNode extends SimpleNode<ScarWrathsConfig> {
    private final ScarWrathsScript script;

    // Constants
    private static final String PURE_ESSENCE = "Pure essence";
    private static final String NATURE_RUNE = "Nature rune";
    private static final String ALTAR = "Altar";
    private static final String CRAFT_RUNE = "Craft-rune";

    /**
     * Constructor
     *
     * @param config The script configuration
     * @param script The script instance
     */
    public NatureRuneNode(ScarWrathsConfig config, ScarWrathsScript script) {
        super("Crafting Nature Runes", 1, config);
        this.script = script;
    }

    @Override
    public boolean validate() {
        // Only validate if Nature rune type is selected
        if (config.getRuneTypeEnum() != ScarWrathsConfig.RuneType.NATURE) {
            return false;
        }

        GameObject altar = GameObjects.closest(ALTAR);
        int essCount = Inventory.count(PURE_ESSENCE);

        // We can craft runes if:
        // 1. We have pure essence in our inventory
        // 2. We have access to the altar
        return altar != null && altar.exists() && altar.hasAction(CRAFT_RUNE) && essCount > 0;
    }

    @Override
    protected int onExecute() {
        try {
            // Set the status for debugging
            setStatus("Crafting Nature runes");

            // Get the altar
            GameObject altar = GameObjects.closest(ALTAR);
            if (altar == null || !altar.exists() || !altar.hasAction(CRAFT_RUNE)) {
                Logger.error("Altar not found or not accessible");
                return 1000;
            }

            // Check if we have essence
            int essCount = Inventory.count(PURE_ESSENCE);
            if (essCount <= 0) {
                Logger.error("No pure essence in inventory");
                return 1000;
            }

            // Craft the runes
            Logger.info("Crafting Nature runes at altar");
            if (altar.interact(CRAFT_RUNE)) {
                // Wait until we have Nature runes in our inventory or we've used all our essence
                int startEssCount = essCount;
                Sleep.sleepUntil(() ->
                    Inventory.contains(NATURE_RUNE) ||
                    Inventory.count(PURE_ESSENCE) < startEssCount,
                    10000
                );

                // Count how many runes we crafted
                int runesCrafted = Inventory.count(NATURE_RUNE);
                if (runesCrafted > 0) {
                    Logger.info("Successfully crafted " + runesCrafted + " Nature runes");
                    // Increment the counter
                    script.incrementNatureRunesCrafted(runesCrafted);

                    // Also log the total count for debugging
                    Logger.info("Total Nature runes crafted: " + script.getNatureRunesCrafted());
                }
            } else {
                Logger.error("Failed to interact with altar");
            }

            return 600;
        } catch (Exception e) {
            Logger.error("Error in NatureRuneNode: " + e.getMessage());
            e.printStackTrace();
            return 1000;
        }
    }
}
