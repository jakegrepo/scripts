package scripts.ScarWraths.nodes;

import core.base.SimpleNode;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.magic.Magic;
import org.dreambot.api.methods.magic.Normal;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;
import scripts.ScarWraths.ScarWrathsScript;
import scripts.ScarWraths.config.ScarWrathsConfig;

/**
 * Movement node for Nature rune crafting
 */
public class NatureMovementNode extends SimpleNode<ScarWrathsConfig> {
    private final ScarWrathsScript script;

    // Constants
    private static final String PURE_ESSENCE = "Pure essence";
    private static final String NATURE_RUNE = "Nature rune";
    private static final String ALTAR = "Altar";
    private static final String CRAFT_RUNE = "Craft-rune";
    private static final String MYSTERIOUS_RUINS = "Mysterious ruins";
    private static final String NATURE_TALISMAN = "Nature talisman";
    private static final String FAIRY_RING = "Fairy ring";
    private static final String LAST_DESTINATION = "Last-destination (CKR)";
    private static final String TELEPORT_TO_HOUSE = "Teleport to House";
    private static final Area TAI_BWO = new Area(2770, 3048, 2880, 2994);
    // Nature altar location
    private static final Tile NATURE_RUINS_TILE = new Tile(2868, 3018, 0);
    private static final Area NATURE_RUINS_AREA = new Area(2862, 3025, 2876, 3012);

    /**
     * Constructor
     *
     * @param config The script configuration
     * @param script The script instance
     */
    public NatureMovementNode(ScarWrathsConfig config, ScarWrathsScript script) {
        super("Moving to Nature Altar", 2, config);
        this.script = script;
    }

    @Override
    public boolean validate() {
        // Only validate if Nature rune type is selected
        if (config.getRuneTypeEnum() != ScarWrathsConfig.RuneType.NATURE) {
            return false;
        }

        GameObject altar = GameObjects.closest(ALTAR);
        int essCount = Inventory.count(PURE_ESSENCE);

        // We need to move if:
        // 1. We have pure essence in our inventory
        // 2. We don't have access to the altar OR we're not close to it
        // 3. We have a nature talisman to access the ruins

        if (essCount <= 0) {
            return false; // No essence, no need to move to altar
        }

        if (altar != null && altar.exists() && altar.hasAction(CRAFT_RUNE)) {
            return false; // Already at the altar
        }

        if (!Inventory.contains(NATURE_TALISMAN)) {
            return false; // No talisman to access the ruins
        }

        return true; // We need to move to the altar
    }

    @Override
    protected int onExecute() {
        try {
            setStatus("Moving to Nature altar");

            // Check if we're at the ruins
            GameObject ruins = GameObjects.closest(MYSTERIOUS_RUINS);
            Item natureTalisman = Inventory.get(NATURE_TALISMAN);

            // If we're at the ruins, use the talisman on it
            if (ruins != null && ruins.exists() && NATURE_RUINS_AREA.contains(Players.getLocal())) {
                Logger.info("Using talisman on ruins");

                if (natureTalisman != null && natureTalisman.useOn(ruins)) {
                    Sleep.sleepUntil(() -> {
                        GameObject newAltar = GameObjects.closest(ALTAR);
                        return newAltar != null && newAltar.exists() && newAltar.hasAction(CRAFT_RUNE);
                    }, 10000);
                    return 600;
                }
                return 1000;
            }

            // Check if we're in the Nature ruins area
            if (TAI_BWO.contains(Players.getLocal())) {
                // Walk to the ruins
                Logger.info("Walking to Nature ruins at " + NATURE_RUINS_TILE);
                if (Walking.walk(NATURE_RUINS_TILE)) {
                    Sleep.sleepUntil(() -> {
                        GameObject newRuins = GameObjects.closest(MYSTERIOUS_RUINS);
                        return newRuins != null && newRuins.exists();
                    }, 2000);
                } else {
                    Logger.error("Failed to start walking to Nature ruins");
                }
                return 1000;
            }

            // If we're not at the ruins area, use teleport to house and fairy ring
            // Step 1: Teleport to house if we're not already in a house
            if (!Client.isDynamicRegion() && !TAI_BWO.contains(Players.getLocal())) { // Most POH are on z=1
                Logger.info("Casting Teleport to House spell");
                if (Magic.castSpell(Normal.TELEPORT_TO_HOUSE)) {
                    Sleep.sleepUntil(Client::isDynamicRegion, 1600);
                    return 1000;
                }
                return 600;
            }

            // Step 2: Find and use the fairy ring in the house
            GameObject fairyRing = GameObjects.closest(obj ->
                obj != null &&
                obj.getName().equals(FAIRY_RING) &&
                obj.hasAction(LAST_DESTINATION));

            if (fairyRing != null && !TAI_BWO.contains(Players.getLocal())) {
                // Check if run energy is low and restore it if needed
                if (Walking.getRunEnergy() <= 50) {
                    Logger.info("Run energy is low, restoring at Pool of Revitalisation");
                    GameObject pool = GameObjects.closest(obj -> 
                        obj != null && 
                        obj.getName().equals("Pool of Revitalisation") && 
                        obj.hasAction("Drink"));
                    
                    if (pool != null && pool.interact("Drink")) {
                        // Wait until run energy is restored
                        Sleep.sleepUntil(() -> Walking.getRunEnergy() > 90, 5000);
                        return 1000;
                    }
                    return 600;
                }
                
                Logger.info("Using fairy ring with Last destination");
                if (fairyRing.interact(LAST_DESTINATION)) {
                    // Wait until we're at the nature altar area
                    Sleep.sleepUntil(() -> NATURE_RUINS_AREA.contains(Players.getLocal()), 1600);
                    return 1000;
                }
                return 600;
            }

            // If we can't find the fairy ring or teleport, try walking as a fallback
            Logger.info("Couldn't use teleport method, walking to Nature ruins area");
            if (Walking.walk(NATURE_RUINS_AREA.getCenter())) {
                Sleep.sleepUntil(() -> NATURE_RUINS_AREA.contains(Players.getLocal()), 2000);
                return 1000;
            }

            Logger.error("Could not find a way to get to the Nature altar");
            return 2000;
        } catch (Exception e) {
            Logger.error("Error in NatureMovementNode: " + e.getMessage());
            e.printStackTrace();
            return 1000;
        }
    }
}
