package scripts.ScarWraths.nodes;

import core.base.SimpleNode;
import core.grandexchange.RestockGrandExchangeNode;
import core.state.ScriptState;
import org.dreambot.api.methods.Calculations;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.bank.BankLocation;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.Item;
import scripts.ScarWraths.ScarWrathsScript;
import scripts.ScarWraths.config.ScarWrathsConfig;

public class BankingNode extends SimpleNode<ScarWrathsConfig> {
    private final ScarWrathsScript script;

    // Constants
    private static final String PURE_ESSENCE = "Pure essence";
    private static final String WRATH_RUNE = "Wrath rune";
    private static final String WRATH_TALISMAN = "Wrath talisman";
    private static final String MYTHICAL_CAPE = "Mythical cape";
    private static final String STAMINA_POTION_1 = "Stamina potion(1)";
    private static final String VIAL = "Vial";
    private static final int LOW_RUN_ENERGY = 60;

    public BankingNode(ScarWrathsConfig config, ScarWrathsScript script) {
        super("Banking", 3, config);
        this.script = script;
    }

    @Override
    public boolean validate() {
        // Skip if muling is in progress
        if (config.getMulingConfig().isEnabled()) {
            // Check if we've reached the muling threshold
            int wrathRuneCount = Inventory.count(WRATH_RUNE);
            int triggerValue = config.getMulingConfig().getTriggerValue();

            // If we have enough Wrath runes to trigger muling, let the MulingNode handle it
            if (wrathRuneCount >= triggerValue &&
                config.getMulingConfig().getItemsToMule().contains(WRATH_RUNE)) {
                return false;
            }
        }

        // We need to bank if:
        // 1. We have wrath runes to deposit, or
        // 2. We're out of pure essence, or
        // 3. We need a stamina potion (low run energy and no stamina effect)
        // 4. We need a wrath talisman
        // 5. We need a mythical cape for teleporting

        boolean hasWrathRunes = Inventory.contains(WRATH_RUNE);
        boolean outOfEssence = !Inventory.contains(PURE_ESSENCE);
        boolean needsStamina = Walking.getRunEnergy() < LOW_RUN_ENERGY && !Walking.isStaminaActive();
        boolean needsTalisman = !Inventory.contains(WRATH_TALISMAN);
        boolean needsMythicalCape = !Inventory.contains(MYTHICAL_CAPE);

        return hasWrathRunes || outOfEssence || needsStamina || needsTalisman || needsMythicalCape;
    }

    @Override
    protected int onExecute() {
        status("Banking at Varrock West");

        // Walk to bank if not already there
        if (!Bank.isOpen() && !BankLocation.VARROCK_EAST.getArea(10).contains(Players.getLocal())) {
            Logger.info("Walking to Varrock West bank");
            if (Walking.walk(BankLocation.VARROCK_EAST.getCenter())) {
                Sleep.sleepUntil(() -> BankLocation.VARROCK_EAST.getArea(10).contains(Players.getLocal()), 1200);
            }
            return 600;
        }

        // Open bank if not already open
        if (!Bank.isOpen()) {
            Logger.info("Opening bank");
            if (Bank.open(BankLocation.VARROCK_EAST)) {
                Sleep.sleepUntil(Bank::isOpen, 1200);
            }
            return 600;
        }

        // Check if restock is needed
        if (script.getScriptConfig().getRestockConfig().isEnabled()) {
            // Get the RestockGrandExchangeNode from the script
            RestockGrandExchangeNode restockNode = script.getContext().tasks().getNodes().stream()
                .filter(node -> node instanceof RestockGrandExchangeNode)
                .map(node -> (RestockGrandExchangeNode) node)
                .findFirst().orElse(null);

            if (restockNode != null) {
                // Force a restock check
                Logger.info("Checking if restock is needed during banking");
                restockNode.forceRestockCheck();
                Logger.info("Triggered restock check during ScarWraths banking");

                // If restock is needed, let the RestockGrandExchangeNode handle it
                if (!restockNode.isFinished()) {
                    // Close the bank to let the restock node take over
                    Logger.info("Restock needed, closing bank to let RestockNode take over");
                    Bank.close();
                    Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
                    return 0;
                }
            }
        }

        // Check if we need to deposit wrath runes
        if (Inventory.contains(WRATH_RUNE)) {
            Logger.info("Depositing Wrath runes");
            Bank.depositAll(WRATH_RUNE);
            Sleep.sleepTick();
        }

        // Check if we need a stamina potion
        if (Walking.getRunEnergy() < LOW_RUN_ENERGY && !Walking.isStaminaActive()|| Walking.getRunEnergy()<= 30) {
            Logger.info("Withdrawing stamina potion");
            if (Bank.contains(STAMINA_POTION_1)) {
                Bank.withdraw(STAMINA_POTION_1, 1);
                Sleep.sleepUntil(() -> Inventory.contains(STAMINA_POTION_1), 3000);

                // Drink the stamina potion
                if (Inventory.contains(STAMINA_POTION_1)) {
                    Logger.info("Drinking stamina potion");
                    Item staminaPotion = Inventory.get(STAMINA_POTION_1);
                    if (staminaPotion != null && staminaPotion.interact("Drink")) {
                        Sleep.sleepUntil(Walking::isStaminaActive, 3000);
                    }
                }
            } else {
                Logger.warn("No stamina potions available");
            }
        }

        // Make sure we have a wrath talisman
        if (!Inventory.contains(WRATH_TALISMAN) && Bank.contains(WRATH_TALISMAN)) {
            Logger.info("Withdrawing Wrath talisman");
            Bank.withdraw(WRATH_TALISMAN, 1);
            Sleep.sleepUntil(() -> Inventory.contains(WRATH_TALISMAN), 3000);
        }

        // Make sure we have a mythical cape for teleporting
        if (!Inventory.contains(MYTHICAL_CAPE) && Bank.contains(MYTHICAL_CAPE)) {
            Logger.info("Withdrawing Mythical cape");
            Bank.withdraw(MYTHICAL_CAPE, 1);
            Sleep.sleepUntil(() -> Inventory.contains(MYTHICAL_CAPE), 3000);
        }
        if (Inventory.contains(VIAL) && Bank.isOpen()) {
            Logger.info("Depositing empty vial");
            Bank.depositAll(VIAL);
            Sleep.sleepTicks(2);
        }
        // Withdraw pure essence
        if (Bank.contains(PURE_ESSENCE)) {
            Logger.info("Withdrawing Pure essence");
            Bank.withdrawAll(PURE_ESSENCE);
            Sleep.sleepUntil(() -> Inventory.isFull() || !Bank.contains(PURE_ESSENCE), 3000);
        } else {
            Logger.error("Out of Pure essence!");
            script.setState(ScriptState.STOPPED);
            return 1000;
        }

        // Close the bank
        Logger.info("Closing bank");
        Bank.close();
        Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);

        return Calculations.random(600, 1200);
    }
}
