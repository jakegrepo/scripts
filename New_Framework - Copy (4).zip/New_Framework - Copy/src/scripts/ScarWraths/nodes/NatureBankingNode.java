package scripts.ScarWraths.nodes;

import core.base.SimpleNode;
import core.grandexchange.RestockGrandExchangeNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.bank.BankLocation;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import scripts.ScarWraths.ScarWrathsScript;
import scripts.ScarWraths.config.ScarWrathsConfig;

/**
 * Banking node for Nature rune crafting
 */
public class NatureBankingNode extends SimpleNode<ScarWrathsConfig> {
    private final ScarWrathsScript script;

    // Constants
    private static final String PURE_ESSENCE = "Pure essence";
    private static final String NATURE_RUNE = "Nature rune";
    private static final String NATURE_TALISMAN = "Nature talisman";
    private static final BankLocation BANK_LOCATION = BankLocation.VARROCK_EAST;

    /**
     * Constructor
     *
     * @param config The script configuration
     * @param script The script instance
     */
    public NatureBankingNode(ScarWrathsConfig config, ScarWrathsScript script) {
        super("Banking for Pure Ess", 3, config);
        this.script = script;
    }

    @Override
    public boolean validate() {
        // Only validate if Nature rune type is selected
        if (config.getRuneTypeEnum() != ScarWrathsConfig.RuneType.NATURE) {
            return false;
        }

        // We need to bank if:
        // 1. We don't have pure essence in our inventory
        // 2. We don't have a nature talisman in our inventory
        return Inventory.count(PURE_ESSENCE) == 0 || !Inventory.contains(NATURE_TALISMAN);
    }

    @Override
    protected int onExecute() {
        setStatus("Banking for Pure Ess");

        // Walk to bank if not already there
        if (!Bank.isOpen() && !BANK_LOCATION.getArea(10).contains(Players.getLocal())) {
            Logger.info("Walking to Varrock East bank");
            if (Walking.walk(BANK_LOCATION.getCenter())) {
                Sleep.sleepUntil(() -> BANK_LOCATION.getArea(10).contains(Players.getLocal()), 1600);
            }
            return 600;
        }

        // Open bank if not already open
        if (!Bank.isOpen()) {
            Logger.info("Opening bank");
            if (Bank.open(BANK_LOCATION)) {
                Sleep.sleepUntil(Bank::isOpen, 1600);
            }
            return 600;
        }

        // Check if restock is needed
        if (script.getScriptConfig().getRestockConfig().isEnabled()) {
            // Get the RestockGrandExchangeNode from the script
            RestockGrandExchangeNode restockNode = script.getContext().tasks().getNodes().stream()
                .filter(node -> node instanceof RestockGrandExchangeNode)
                .map(node -> (RestockGrandExchangeNode) node)
                .findFirst().orElse(null);

            if (restockNode != null) {
                // Force a restock check
                Logger.info("Checking if restock is needed during nature banking");
                restockNode.forceRestockCheck();
                Logger.info("Triggered restock check during NatureBankingNode banking");

                // If restock is needed, let the RestockGrandExchangeNode handle it
                if (!restockNode.isFinished()) {
                    // Close the bank to let the restock node take over
                    Logger.info("Restock needed, closing bank to let RestockNode take over");
                    Bank.close();
                    Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
                    return 0;
                }
            }
        }

        // Deposit all items except for nature talisman
        if (Inventory.contains(NATURE_RUNE)) {
            Logger.info("Depositing items");
            Bank.depositAll(NATURE_RUNE);
            Sleep.sleepUntil(() -> !Inventory.contains(NATURE_RUNE), 1600);
            return 600;
        }

        // Withdraw nature talisman if needed
        if (!Inventory.contains(NATURE_TALISMAN)) {
            Logger.info("Withdrawing Nature talisman");
            if (Bank.contains(NATURE_TALISMAN)) {
                Bank.withdraw(NATURE_TALISMAN, 1);
                Sleep.sleepUntil(() -> Inventory.contains(NATURE_TALISMAN), 1600);
            } else {
                Logger.error("No Nature talisman in bank");
                return 1000;
            }
            return 600;
        }

        // Withdraw pure essence
        if (Inventory.count(PURE_ESSENCE) == 0) {
            Logger.info("Withdrawing Pure essence");
            if (Bank.contains(PURE_ESSENCE)) {
                Bank.withdrawAll(PURE_ESSENCE);
                Sleep.sleepUntil(() -> Inventory.contains(PURE_ESSENCE), 1600);
            } else {
                Logger.error("No Pure essence in bank");
                return 1000;
            }
            return 600;
        }

        // Close bank
        if (Bank.isOpen()) {
            Logger.info("Closing bank");
            Bank.close();
            Sleep.sleepUntil(() -> !Bank.isOpen(), 1600);
            return 600;
        }

        return 600;
    }
}
