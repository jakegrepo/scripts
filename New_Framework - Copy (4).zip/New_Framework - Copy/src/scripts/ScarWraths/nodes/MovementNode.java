package scripts.ScarWraths.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;
import scripts.ScarWraths.ScarWrathsScript;
import scripts.ScarWraths.config.ScarWrathsConfig;

public class MovementNode extends SimpleNode<ScarWrathsConfig> {
    private final ScarWrathsScript script;
    private final Tile ruinsTile = new Tile(2447, 2822, 0);

    // Constants for items and objects
    private static final String PURE_ESSENCE = "Pure essence";
    private static final String WRATH_TALISMAN = "Wrath talisman";
    private static final String MYTHICAL_CAPE = "Mythical cape";
    private static final String MYSTERIOUS_RUINS = "Mysterious ruins";
    private static final String ALTAR = "Altar";
    private static final String CRAFT_RUNE = "Craft-rune";
    private static final String MYTHIC_STATUE = "Mythic Statue";
    private static final String CAVE = "Cave";
    private static final String ENTER = "Enter";
    private static final String TELEPORT = "Teleport";

    // Area in the Myths Guild where the cave entrance is located
    private static final Area CAVE_ENTRANCE_AREA = new Area(1929, 8973, 1947, 8963, 1);

    public MovementNode(ScarWrathsConfig config, ScarWrathsScript script) {
        super("Movement", 2, config);
        this.script = script;
    }

    @Override
    public boolean validate() {
        GameObject altar = GameObjects.closest(ALTAR);
        int essCount = Inventory.count(PURE_ESSENCE);

        // We need to move if:
        // 1. We have pure essence in our inventory
        // 2. We don't have access to the altar OR we're not close to it
        // 3. We have a wrath talisman to access the ruins

        if (essCount <= 0) {
            return false; // No essence, no need to move to altar
        }

        if (altar != null && altar.exists() && altar.hasAction(CRAFT_RUNE)) {
            return false; // Already at the altar
        }

        if (!Inventory.contains(WRATH_TALISMAN)) {
            return false; // No talisman to access the ruins
        }

        return true; // We need to move to the altar
    }

    @Override
    protected int onExecute() {
        status("Moving to Wrath altar");

        // Check if we're at the altar
        GameObject altar = GameObjects.closest(ALTAR);
        if (altar != null && altar.exists() && altar.hasAction(CRAFT_RUNE)) {
            Logger.info("Already at altar");
            return 600;
        }

        // Check if we're at the ruins
        GameObject ruins = GameObjects.closest(MYSTERIOUS_RUINS);
        Item wrathTalisman = Inventory.get(WRATH_TALISMAN);
        GameObject statue1 = GameObjects.closest(MYTHIC_STATUE);

        // If we're at the ruins, use the talisman on it
        if (ruins != null && ruins.exists() && Players.getLocal().getTile().distance(ruinsTile) <= 8) {
            Logger.info("Using talisman on ruins");

            if (wrathTalisman != null && wrathTalisman.useOn(ruins)) {
                Sleep.sleepUntil(() -> {
                    GameObject newAltar = GameObjects.closest(ALTAR);
                    return newAltar != null && newAltar.exists() && newAltar.hasAction(CRAFT_RUNE);
                }, 5000);
                return 600;
            }
            return 1000;
        }
GameObject ruinsAltar = GameObjects.closest(MYSTERIOUS_RUINS);
        // Check if we're in the Wrath ruins area
        if (Players.getLocal().getTile().distance(ruinsAltar) <= 18) {
            // Walk to the ruins
            Logger.info("Walking to Wrath ruins at " + ruinsTile);
            if (Walking.walk(ruinsTile)) {
                Sleep.sleepUntil(() -> {
                    GameObject newRuins = GameObjects.closest(MYSTERIOUS_RUINS);
                    return newRuins != null && newRuins.exists();
                }, 2000);
            } else {
                Logger.error("Failed to start walking to Wrath ruins");
            }
            return 1000;
        }

        // Check if we're in the cave entrance area
        if (Players.getLocal().getZ() == 1 && CAVE_ENTRANCE_AREA.contains(Players.getLocal())) {
            // Look for the cave entrance
            GameObject cave = GameObjects.closest(obj ->
                obj.getName().equals(CAVE) && obj.hasAction(ENTER));

            if (cave != null && cave.exists()) {
                Logger.info("Entering cave");
                if (cave.interact(ENTER)) {
                    Sleep.sleepUntil(() -> Players.getLocal().getTile().distance(ruinsTile) <= 20, 2000);
                }
            } else {
                // Walk to the cave entrance area center
                Logger.info("Walking to cave entrance");
                Walking.walk(CAVE_ENTRANCE_AREA.getCenter());
                Sleep.sleepTicks(2);
            }
            return 1000;
        }

        // Check if we're in the Myths Guild (Z=1)
        if (Players.getLocal().getZ() == 1) {
            Logger.info("Walking to cave entrance area");
            Walking.walk(CAVE_ENTRANCE_AREA.getCenter());
            Sleep.sleepUntil(() -> CAVE_ENTRANCE_AREA.contains(Players.getLocal()), 2000);
            return 1000;
        }

        // Check if we're at the Myths Guild entrance
        GameObject statue = GameObjects.closest(obj ->
            obj.getName().equals(MYTHIC_STATUE) && obj.hasAction(ENTER));

        if (statue != null && statue.exists()) {
            Logger.info("Entering Myths Guild");
            if (statue.interact(ENTER)) {
                Sleep.sleepUntil(() -> Players.getLocal().getZ() == 1, 2000);
            }
            return 1000;
        }

        // Use Mythical cape to teleport
        Item mythicalCape = Inventory.get(MYTHICAL_CAPE);
        if (mythicalCape != null) {
            Logger.info("Using Mythical cape to teleport");
            if (mythicalCape.interact(TELEPORT)) {
                Sleep.sleepUntil(() -> {
                    GameObject mythicStatue = GameObjects.closest(MYTHIC_STATUE);
                    return mythicStatue != null && mythicStatue.exists() && mythicStatue.hasAction(ENTER);
                }, 4000);
            }
            return 1000;
        }

        Logger.error("Could not find a way to get to the Wrath altar");
        return 2000;
    }
}
