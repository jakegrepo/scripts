package scripts.ScarWraths.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.dreambot.api.utilities.Logger;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Utility class for safely saving and loading configuration files
 */
public class ConfigUtil {
    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .serializeNulls()
            .create();

    /**
     * Safely save an object to a JSON file
     * @param object The object to save
     * @param scriptName The script name (used for directory)
     * @param fileName The file name
     */
    public static void safeSave(Object object, String scriptName, String fileName) {
        safeSave(object, scriptName, "", fileName);
    }

    /**
     * Safely save an object to a JSON file in a subdirectory
     * @param object The object to save
     * @param scriptName The script name (used for directory)
     * @param subDir The subdirectory
     * @param fileName The file name
     */
    public static void safeSave(Object object, String scriptName, String subDir, String fileName) {
        try {
            // Create base directory
            String baseDir = System.getProperty("user.home") + File.separator +
                    "DreamBot" + File.separator +
                    "Scripts" + File.separator +
                    scriptName;

            // Create full directory path
            String dirPath = baseDir;
            if (subDir != null && !subDir.isEmpty()) {
                dirPath += File.separator + subDir;
            }

            // Create directories if they don't exist
            Path path = Paths.get(dirPath);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }

            // Create full file path
            String filePath = dirPath + File.separator + fileName;

            // Create temp file path
            String tempFilePath = filePath + ".tmp";

            // Write to temp file first
            try (FileWriter writer = new FileWriter(tempFilePath)) {
                GSON.toJson(object, writer);
            }

            // Rename temp file to actual file
            File tempFile = new File(tempFilePath);
            File actualFile = new File(filePath);
            
            // Delete existing file if it exists
            if (actualFile.exists()) {
                actualFile.delete();
            }
            
            // Rename temp file to actual file
            if (!tempFile.renameTo(actualFile)) {
                Logger.warn("Failed to rename temp file to actual file: " + filePath);
            }
        } catch (IOException e) {
            Logger.error("Error saving config: " + e.getMessage());
        }
    }

    /**
     * Safely load an object from a JSON file
     * @param clazz The class of the object to load
     * @param scriptName The script name (used for directory)
     * @param fileName The file name
     * @param <T> The type of the object to load
     * @return The loaded object, or null if loading failed
     */
    public static <T> T safeLoad(Class<T> clazz, String scriptName, String fileName) {
        return safeLoad(clazz, scriptName, "", fileName);
    }

    /**
     * Safely load an object from a JSON file in a subdirectory
     * @param clazz The class of the object to load
     * @param scriptName The script name (used for directory)
     * @param subDir The subdirectory
     * @param fileName The file name
     * @param <T> The type of the object to load
     * @return The loaded object, or null if loading failed
     */
    public static <T> T safeLoad(Class<T> clazz, String scriptName, String subDir, String fileName) {
        try {
            // Create base directory
            String baseDir = System.getProperty("user.home") + File.separator +
                    "DreamBot" + File.separator +
                    "Scripts" + File.separator +
                    scriptName;

            // Create full directory path
            String dirPath = baseDir;
            if (subDir != null && !subDir.isEmpty()) {
                dirPath += File.separator + subDir;
            }

            // Create full file path
            String filePath = dirPath + File.separator + fileName;

            // Check if file exists
            File file = new File(filePath);
            if (!file.exists()) {
                return null;
            }

            // Read from file
            try (FileReader reader = new FileReader(file)) {
                return GSON.fromJson(reader, clazz);
            }
        } catch (IOException e) {
            Logger.error("Error loading config: " + e.getMessage());
            return null;
        }
    }
}
