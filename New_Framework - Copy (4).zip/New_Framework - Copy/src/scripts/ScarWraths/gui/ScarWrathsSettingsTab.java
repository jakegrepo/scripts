package scripts.ScarWraths.gui;

import core.context.ScriptContext;
import core.gui.AbstractSettingsTab;
import core.gui.style.StyleManager;
import org.dreambot.api.utilities.Logger;
import scripts.ScarWraths.config.ScarWrathsConfig;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Settings tab for the template script
 */
public class ScarWrathsSettingsTab extends AbstractSettingsTab {
    private final ScarWrathsConfig config;
    private ScarWrathsGeneralPanel generalPanel;
    private ScarWrathsListPanel listPanel;

    /**
     * Constructor
     * @param context The script context
     */
    public ScarWrathsSettingsTab(ScriptContext context) {
        super(context);
        this.config = (ScarWrathsConfig) ((core.base.ScarScript<?>) context.getScript()).getConfig();

        // Initialize panels
        generalPanel = new ScarWrathsGeneralPanel(config);
        listPanel = new ScarWrathsListPanel(config);

        // Add panels to tab
        addSection("General Settings", generalPanel);
        addSection("List Settings", listPanel);
    }

    @Override
    public void createComponents() {
        // No additional components needed
    }

    @Override
    public String getTitle() {
        return "ScarWraths";
    }

    @Override
    public void resetToDefaults() {
        // Reset config to defaults
        config.setDefaults();

        // Update panels
        generalPanel.loadSettings();
        listPanel.loadSettings();
    }

    @Override
    public void updateFromConfig() {
        // Update all panels with the latest config
        generalPanel.loadSettings();
        listPanel.loadSettings();
    }

    /**
     * General settings panel
     */
    class ScarWrathsGeneralPanel extends core.gui.SettingsPanel {
        private final ScarWrathsConfig config;
        private JCheckBox exampleBooleanCheckbox;
        private JSpinner exampleIntSpinner;
        private JComboBox<String> exampleStringComboBox;
        private JComboBox<String> runeTypeComboBox;
        private boolean isLoading = false;

        /**
         * Constructor
         * @param config The script configuration
         */
        public ScarWrathsGeneralPanel(ScarWrathsConfig config) {
            super();
            this.config = config;
            initializeComponents();
            loadSettings();
        }

        /**
         * Initialize the panel components
         */
        private void initializeComponents() {
            // Create main panel with GridBagLayout for precise control
            JPanel mainPanel = new JPanel(new GridBagLayout());
            StyleManager.applyStyle(mainPanel);

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.weightx = 1.0;

            // Add section header
            JLabel headerLabel = new JLabel("General Settings");
            headerLabel.setFont(StyleManager.HEADER_FONT);
            headerLabel.setForeground(StyleManager.ACCENT);
            mainPanel.add(headerLabel, gbc);

            // Example boolean setting
            gbc.gridy++;
            gbc.gridwidth = 1;
            exampleBooleanCheckbox = new JCheckBox("ScarWraths Boolean Setting");
            StyleManager.styleCheckBox(exampleBooleanCheckbox);
            mainPanel.add(exampleBooleanCheckbox, gbc);

            // Example int setting
            gbc.gridy++;
            gbc.gridx = 0;
            JLabel intLabel = new JLabel("ScarWraths Int Setting:");
            StyleManager.styleLabel(intLabel);
            mainPanel.add(intLabel, gbc);

            gbc.gridx = 1;
            exampleIntSpinner = new JSpinner(new SpinnerNumberModel(10, 1, 100, 1));
            StyleManager.styleSpinner(exampleIntSpinner);
            mainPanel.add(exampleIntSpinner, gbc);

            // Example string setting
            gbc.gridy++;
            gbc.gridx = 0;
            JLabel stringLabel = new JLabel("ScarWraths String Setting:");
            StyleManager.styleLabel(stringLabel);
            mainPanel.add(stringLabel, gbc);

            gbc.gridx = 1;
            String[] options = {"Option 1", "Option 2", "Option 3", "Default"};
            exampleStringComboBox = new JComboBox<>(options);
            StyleManager.styleComboBox(exampleStringComboBox);
            mainPanel.add(exampleStringComboBox, gbc);

            // Rune type setting
            gbc.gridy++;
            gbc.gridx = 0;
            JLabel runeTypeLabel = new JLabel("Rune Type to Craft:");
            StyleManager.styleLabel(runeTypeLabel);
            mainPanel.add(runeTypeLabel, gbc);

            gbc.gridx = 1;
            String[] runeTypes = {ScarWrathsConfig.RuneType.WRATH.toString(), ScarWrathsConfig.RuneType.NATURE.toString()};
            runeTypeComboBox = new JComboBox<>(runeTypes);
            StyleManager.styleComboBox(runeTypeComboBox);
            mainPanel.add(runeTypeComboBox, gbc);

            // Add the main panel to this panel
            setLayout(new BorderLayout());
            add(mainPanel, BorderLayout.CENTER);

            // Add listeners
            exampleBooleanCheckbox.addActionListener(e -> {
                if (!isLoading) saveSettings();
            });

            exampleIntSpinner.addChangeListener(e -> {
                if (!isLoading) saveSettings();
            });

            exampleStringComboBox.addActionListener(e -> {
                if (!isLoading) saveSettings();
            });

            runeTypeComboBox.addActionListener(e -> {
                if (!isLoading) saveSettings();
            });
        }

        /**
         * Load settings from config
         */
        public void loadSettings() {
            isLoading = true;
            try {
                exampleBooleanCheckbox.setSelected(config.isScarWrathsBooleanSetting());
                exampleIntSpinner.setValue(config.getScarWrathsIntSetting());
                exampleStringComboBox.setSelectedItem(config.getExampleStringSetting());
                runeTypeComboBox.setSelectedItem(config.getRuneType());
            } finally {
                isLoading = false;
            }
        }

        /**
         * Save settings to config
         */
        public void saveSettings() {
            if (isLoading) return;

            config.setExampleBooleanSetting(exampleBooleanCheckbox.isSelected());
            config.setExampleIntSetting((int) exampleIntSpinner.getValue());
            config.setExampleStringSetting((String) exampleStringComboBox.getSelectedItem());
            config.setRuneType((String) runeTypeComboBox.getSelectedItem());

            // Mark config as dirty
            config.markDirty();
        }

        /**
         * Updates from config - called when loading a profile
         */
        public void updateFromConfig() {
            // Call loadSettings to update all components
            loadSettings();
        }
    }

    /**
     * List settings panel
     */
    class ScarWrathsListPanel extends core.gui.SettingsPanel {
        private final ScarWrathsConfig config;
        private JList<String> itemsList;
        private DefaultListModel<String> itemsListModel;
        private JTextField newItemField;
        private JButton addItemButton;
        private JButton removeItemButton;
        private boolean isLoading = false;

        /**
         * Constructor
         * @param config The script configuration
         */
        public ScarWrathsListPanel(ScarWrathsConfig config) {
            super();
            this.config = config;
            initializeComponents();
            loadSettings();
        }

        /**
         * Initialize the panel components
         */
        private void initializeComponents() {
            // Create main panel with GridBagLayout for precise control
            JPanel mainPanel = new JPanel(new GridBagLayout());
            StyleManager.applyStyle(mainPanel);

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.weightx = 1.0;

            // Add section header
            JLabel headerLabel = new JLabel("List Settings");
            headerLabel.setFont(StyleManager.HEADER_FONT);
            headerLabel.setForeground(StyleManager.ACCENT);
            mainPanel.add(headerLabel, gbc);

            // Items list
            gbc.gridy++;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.weighty = 1.0;
            itemsListModel = new DefaultListModel<>();
            itemsList = new JList<>(itemsListModel);
            StyleManager.styleList(itemsList);
            JScrollPane scrollPane = new JScrollPane(itemsList);
            StyleManager.styleScrollPane(scrollPane);
            mainPanel.add(scrollPane, gbc);

            // New item field
            gbc.gridy++;
            gbc.gridwidth = 1;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.weighty = 0.0;
            newItemField = new JTextField();
            StyleManager.styleTextField(newItemField);
            mainPanel.add(newItemField, gbc);

            // Add button
            gbc.gridx = 1;
            addItemButton = new JButton("Add");
            StyleManager.styleButton(addItemButton);
            mainPanel.add(addItemButton, gbc);

            // Remove button
            gbc.gridy++;
            gbc.gridx = 0;
            gbc.gridwidth = 2;
            removeItemButton = new JButton("Remove Selected");
            StyleManager.styleButton(removeItemButton);
            mainPanel.add(removeItemButton, gbc);

            // Add the main panel to this panel
            setLayout(new BorderLayout());
            add(mainPanel, BorderLayout.CENTER);

            // Add listeners
            addItemButton.addActionListener(e -> {
                String newItem = newItemField.getText().trim();
                if (!newItem.isEmpty() && !itemsListModel.contains(newItem)) {
                    itemsListModel.addElement(newItem);
                    newItemField.setText("");
                    saveSettings();
                }
            });

            removeItemButton.addActionListener(e -> {
                int selectedIndex = itemsList.getSelectedIndex();
                if (selectedIndex != -1) {
                    itemsListModel.remove(selectedIndex);
                    saveSettings();
                }
            });
        }

        /**
         * Load settings from config
         */
        public void loadSettings() {
            isLoading = true;
            try {
                // Load items
                itemsListModel.clear();
                for (String item : config.getScarWrathsListSetting()) {
                    itemsListModel.addElement(item);
                }
            } finally {
                isLoading = false;
            }
        }

        /**
         * Save settings to config
         */
        public void saveSettings() {
            if (isLoading) return;

            // Save items
            List<String> items = new ArrayList<>();
            for (int i = 0; i < itemsListModel.size(); i++) {
                items.add(itemsListModel.getElementAt(i));
            }
            config.setExampleListSetting(items);

            // Mark config as dirty
            config.markDirty();
        }

        /**
         * Updates from config - called when loading a profile
         */
        public void updateFromConfig() {
            // Call loadSettings to update all components
            loadSettings();
        }
    }
}
