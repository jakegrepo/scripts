package scripts.ScarWraths.config;

import com.google.gson.annotations.Expose;
import core.config.ScriptConfig;
import core.context.ScriptContext;
import org.dreambot.api.settings.ScriptSettings;
import org.dreambot.api.utilities.Logger;
import scripts.ScarWraths.utils.ConfigUtil;

import java.io.File;
import java.util.*;

/**
 * Configuration class for ScarWraths script
 */
public class ScarWrathsConfig extends ScriptConfig {
    // Default values
    private static final String DEFAULT_OPTION = "Default";
    private static final int DEFAULT_VALUE = 10;

    // Rune crafting types
    public enum RuneType {
        WRATH("Wrath"),
        NATURE("Nature");

        private final String name;

        RuneType(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }

        public static RuneType fromString(String text) {
            for (RuneType type : RuneType.values()) {
                if (type.name.equalsIgnoreCase(text)) {
                    return type;
                }
            }
            return WRATH; // Default to Wrath
        }
    }

    // Settings
    @Expose private boolean scarwrathsBooleanSetting = true;
    @Expose private int scarwrathsIntSetting = DEFAULT_VALUE;
    @Expose private String scarwrathsStringSetting = DEFAULT_OPTION;
    @Expose private List<String> scarwrathsListSetting = new ArrayList<>();
    @Expose private Map<String, Integer> scarwrathsMapSetting = new HashMap<>();
    @Expose private String runeType = RuneType.WRATH.toString(); // Default to Wrath runes

    // Flag to track if settings have been modified
    private boolean dirty = false;

    // Add transient fields if ScriptContext is needed but not saved
    private transient ScriptContext context;

    /**
     * Constructor with context
     */
    public ScarWrathsConfig(ScriptContext context) {
        super(context, "template_config");
        this.context = context;
        setDefaults();
    }

    /**
     * Default constructor with default values (for Gson deserialization)
     */
    public ScarWrathsConfig() {
        // Use the no-args constructor in the parent class
        super();
        setDefaults();
    }

    @Override
    public void setDefaults() {
        // Reset to default values
        scarwrathsBooleanSetting = true;
        scarwrathsIntSetting = DEFAULT_VALUE;
        scarwrathsStringSetting = DEFAULT_OPTION;
        runeType = RuneType.WRATH.toString(); // Default to Wrath runes

        // Initialize example list
        scarwrathsListSetting = Arrays.asList("Item 1", "Item 2", "Item 3");

        // Initialize example map
        scarwrathsMapSetting = new HashMap<>();
        scarwrathsMapSetting.put("Key 1", 1);
        scarwrathsMapSetting.put("Key 2", 2);
        scarwrathsMapSetting.put("Key 3", 3);

        // Mark as dirty to ensure it's saved
        markDirty();
    }

    @Override
    public void saveConfig() {
        if (!dirty) {
            return;  // Only save if changes were made
        }

        try {
            // Create config data for saving
            ConfigData data = new ConfigData();
            data.scarwrathsBooleanSetting = this.scarwrathsBooleanSetting;
            data.scarwrathsIntSetting = this.scarwrathsIntSetting;
            data.scarwrathsStringSetting = this.scarwrathsStringSetting;
            data.scarwrathsListSetting = new ArrayList<>(this.scarwrathsListSetting);
            data.scarwrathsMapSetting = new HashMap<>(this.scarwrathsMapSetting);
            data.runeType = this.runeType;

            // Include framework-level configurations
            data.mulingConfig = this.getMulingConfig();
            data.breakConfig = this.getBreakConfig();
            data.antiBanConfig = this.getAntiBanConfig();

            // Save using our safe utility method
            ConfigUtil.safeSave(data, "ScarScarWraths", "template_config.json");
            Logger.log("ScarWraths config saved successfully");

            markClean();
        } catch (Exception e) {
            Logger.log("Error saving ScarWraths config: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void loadConfig() {
        try {
            // Load from script settings
            ConfigData data = ScriptSettings.load(ConfigData.class, "ScarScarWraths", "template_config.json");

            if (data != null) {
                this.scarwrathsBooleanSetting = data.scarwrathsBooleanSetting;
                this.scarwrathsIntSetting = data.scarwrathsIntSetting;
                this.scarwrathsStringSetting = data.scarwrathsStringSetting;
                this.scarwrathsListSetting = new ArrayList<>(data.scarwrathsListSetting);
                this.scarwrathsMapSetting = new HashMap<>(data.scarwrathsMapSetting);
                this.runeType = data.runeType;

                // Load framework-level configurations
                if (data.mulingConfig != null) {
                    this.setMulingConfig(data.mulingConfig);
                }
                if (data.breakConfig != null) {
                    this.setBreakConfig(data.breakConfig);
                }
                if (data.antiBanConfig != null) {
                    this.setAntiBanConfig(data.antiBanConfig);
                }

                Logger.log("ScarWraths config loaded successfully");
            } else {
                Logger.log("No existing ScarWraths config found, using defaults");
                setDefaults();
            }

            markClean();
        } catch (Exception e) {
            Logger.log("Error loading ScarWraths config: " + e.getMessage());
            e.printStackTrace();
            setDefaults();  // Fall back to defaults if loading fails
        }
    }

    /**
     * Inner class to hold serializable data
     */
    private static class ConfigData {
        public boolean scarwrathsBooleanSetting = true;
        public int scarwrathsIntSetting = DEFAULT_VALUE;
        public String scarwrathsStringSetting = DEFAULT_OPTION;
        public List<String> scarwrathsListSetting = new ArrayList<>();
        public Map<String, Integer> scarwrathsMapSetting = new HashMap<>();
        public String runeType = RuneType.WRATH.toString(); // Default to Wrath runes

        // Framework-level configurations
        public core.config.MulingConfig mulingConfig = new core.config.MulingConfig();
        public core.config.BreakConfig breakConfig = new core.config.BreakConfig();
        public core.config.AntiBanConfig antiBanConfig = new core.config.AntiBanConfig();
    }

    /**
     * Save configuration to a profile file
     * @param name The profile name
     */
    public void saveProfile(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }

        try {
            // Create config data for saving
            ConfigData data = new ConfigData();
            data.scarwrathsBooleanSetting = this.scarwrathsBooleanSetting;
            data.scarwrathsIntSetting = this.scarwrathsIntSetting;
            data.scarwrathsStringSetting = this.scarwrathsStringSetting;
            data.scarwrathsListSetting = new ArrayList<>(this.scarwrathsListSetting);
            data.scarwrathsMapSetting = new HashMap<>(this.scarwrathsMapSetting);
            data.runeType = this.runeType;

            // Include framework-level configurations
            data.mulingConfig = this.getMulingConfig();
            data.breakConfig = this.getBreakConfig();
            data.antiBanConfig = this.getAntiBanConfig();

            // Save using our safe utility method
            ConfigUtil.safeSave(data, "ScarScarWraths", "profiles", name + ".json");
            Logger.log("ScarWraths profile saved: " + name);
        } catch (Exception e) {
            Logger.log("Error saving ScarWraths profile: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /**
     * Load configuration from a profile file
     * @param name The profile name
     */
    public void loadProfile(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }

        try {
            // Load from profiles directory
            ConfigData data = ConfigUtil.safeLoad(ConfigData.class, "ScarScarWraths", "profiles", name + ".json");

            if (data != null) {
                this.scarwrathsBooleanSetting = data.scarwrathsBooleanSetting;
                this.scarwrathsIntSetting = data.scarwrathsIntSetting;
                this.scarwrathsStringSetting = data.scarwrathsStringSetting;
                this.scarwrathsListSetting = new ArrayList<>(data.scarwrathsListSetting);
                this.scarwrathsMapSetting = new HashMap<>(data.scarwrathsMapSetting);
                this.runeType = data.runeType;

                // Load framework-level configurations
                if (data.mulingConfig != null) {
                    this.setMulingConfig(data.mulingConfig);
                }
                if (data.breakConfig != null) {
                    this.setBreakConfig(data.breakConfig);
                }
                if (data.antiBanConfig != null) {
                    this.setAntiBanConfig(data.antiBanConfig);
                }

                Logger.log("ScarWraths profile loaded: " + name);
                markDirty();
                saveConfig();
            } else {
                Logger.warn("Profile not found: " + name);
                throw new RuntimeException("Profile not found: " + name);
            }
        } catch (Exception e) {
            Logger.error("Error loading ScarWraths profile: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /**
     * Delete a profile
     * @param name The profile name
     * @return true if successful
     */
    public boolean deleteProfile(String name) {
        if (name == null || name.isEmpty()) {
            return false;
        }

        try {
            File profileFile = new File(getProfilesDirectory(), name + ".json");
            boolean deleted = profileFile.delete();
            if (deleted) {
                Logger.log("Deleted ScarWraths profile: " + name);
            } else {
                Logger.log("Failed to delete ScarWraths profile: " + name);
            }
            return deleted;
        } catch (Exception e) {
            Logger.log("Error deleting ScarWraths profile: " + e.getMessage());
            return false;
        }
    }

    /**
     * Get available profiles
     * @return List of profile names
     */
    public List<String> getAvailableProfiles() {
        List<String> profiles = new ArrayList<>();
        File profilesDir = getProfilesDirectory();

        if (profilesDir.exists() && profilesDir.isDirectory()) {
            File[] files = profilesDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".json"));
            if (files != null) {
                for (File file : files) {
                    String name = file.getName();
                    profiles.add(name.substring(0, name.lastIndexOf('.')));
                }
            }
        }

        return profiles;
    }

    /**
     * Get the profiles directory
     * @return The profiles directory
     */
    private File getProfilesDirectory() {
        String baseDir = System.getProperty("user.home") + File.separator +
                        "DreamBot" + File.separator +
                        "Scripts" + File.separator +
                        "ScarScarWraths";

        File profilesDir = new File(baseDir + File.separator + "profiles");
        if (!profilesDir.exists()) {
            profilesDir.mkdirs();
        }

        return profilesDir;
    }

    // Mark config as dirty (changed)
    @Override
    public void markDirty() {
        this.dirty = true;
    }

    // Mark config as clean (saved)
    @Override
    public void markClean() {
        this.dirty = false;
    }

    // Check if config is dirty
    @Override
    public boolean isDirty() {
        return this.dirty;
    }

    @Override
    protected void copyConfigValues(ScriptConfig other) {
        // Call the parent implementation to copy framework-level configs
        super.copyConfigValues(other);
        if (other instanceof ScarWrathsConfig) {
            ScarWrathsConfig otherConfig = (ScarWrathsConfig) other;
            this.scarwrathsBooleanSetting = otherConfig.scarwrathsBooleanSetting;
            this.scarwrathsIntSetting = otherConfig.scarwrathsIntSetting;
            this.scarwrathsStringSetting = otherConfig.scarwrathsStringSetting;
            this.scarwrathsListSetting = new ArrayList<>(otherConfig.scarwrathsListSetting);
            this.scarwrathsMapSetting = new HashMap<>(otherConfig.scarwrathsMapSetting);

            markDirty();
        }
    }

    @Override
    public void reset() {
        setDefaults();
    }

    // Framework-level configuration getters and setters are inherited from ScriptConfig

    // Add explicit methods to ensure proper serialization
    @Override
    public core.config.MulingConfig getMulingConfig() {
        return super.getMulingConfig();
    }

    @Override
    public void setMulingConfig(core.config.MulingConfig mulingConfig) {
        super.setMulingConfig(mulingConfig);
    }

    @Override
    public core.config.BreakConfig getBreakConfig() {
        return super.getBreakConfig();
    }

    @Override
    public void setBreakConfig(core.config.BreakConfig breakConfig) {
        super.setBreakConfig(breakConfig);
    }

    @Override
    public core.config.AntiBanConfig getAntiBanConfig() {
        return super.getAntiBanConfig();
    }

    @Override
    public void setAntiBanConfig(core.config.AntiBanConfig antiBanConfig) {
        super.setAntiBanConfig(antiBanConfig);
    }

    // Getters and setters for the script-specific settings

    public boolean isScarWrathsBooleanSetting() {
        return scarwrathsBooleanSetting;
    }

    public void setExampleBooleanSetting(boolean scarwrathsBooleanSetting) {
        this.scarwrathsBooleanSetting = scarwrathsBooleanSetting;
        markDirty();
    }

    public int getScarWrathsIntSetting() {
        return scarwrathsIntSetting;
    }

    public void setExampleIntSetting(int scarwrathsIntSetting) {
        this.scarwrathsIntSetting = scarwrathsIntSetting;
        markDirty();
    }

    public String getExampleStringSetting() {
        return scarwrathsStringSetting;
    }

    public void setExampleStringSetting(String scarwrathsStringSetting) {
        this.scarwrathsStringSetting = scarwrathsStringSetting;
        markDirty();
    }

    public List<String> getScarWrathsListSetting() {
        return scarwrathsListSetting;
    }

    public void setExampleListSetting(List<String> scarwrathsListSetting) {
        this.scarwrathsListSetting = scarwrathsListSetting;
        markDirty();
    }

    public Map<String, Integer> getScarWrathsMapSetting() {
        return scarwrathsMapSetting;
    }

    public void setExampleMapSetting(Map<String, Integer> scarwrathsMapSetting) {
        this.scarwrathsMapSetting = scarwrathsMapSetting;
        markDirty();
    }

    /**
     * Gets the rune type as a string
     * @return The rune type string
     */
    public String getRuneType() {
        return runeType;
    }

    /**
     * Gets the rune type as an enum
     * @return The RuneType enum value
     */
    public RuneType getRuneTypeEnum() {
        return RuneType.fromString(runeType);
    }

    /**
     * Sets the rune type
     * @param runeType The rune type string
     */
    public void setRuneType(String runeType) {
        this.runeType = runeType;
        markDirty();
    }

    /**
     * Sets the rune type using the enum
     * @param runeType The RuneType enum value
     */
    public void setRuneType(RuneType runeType) {
        this.runeType = runeType.toString();
        markDirty();
    }
}
