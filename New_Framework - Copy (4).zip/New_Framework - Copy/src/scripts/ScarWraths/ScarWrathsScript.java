package scripts.ScarWraths;

import core.base.ScarScript;
import core.grandexchange.RestockGrandExchangeNode;
import core.gui.AbstractSettingsTab;
import core.node.TaskNode;
import core.paint.PaintBuilder;
import core.paint.ScriptPaint;
import core.state.ScriptState;
import events.EventType;
import events.ScriptEvent;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Timer;
import scripts.ScarWraths.config.ScarWrathsConfig;
import scripts.ScarWraths.gui.ScarWrathsOverlay;
import scripts.ScarWraths.gui.ScarWrathsSettingsTab;
import scripts.ScarWraths.muling.MulingNode;
import scripts.ScarWraths.nodes.*;

import java.awt.*;

public class ScarWrathsScript extends ScarScript<ScarWrathsConfig> {

    private Timer scriptTimer;
    private int actionsCompleted = 0;
    private int wrathRunesCrafted = 0;
    private int natureRunesCrafted = 0;
    private ScriptPaint paint;

    // Track starting stats
    private int startRcXP;
    private int startRcLevel;
    private long startTime;

    // Constants
    private static final String WRATH_RUNE = "Wrath rune";
    private static final String NATURE_RUNE = "Nature rune";

    /**
     * Called when the script starts
     */
    @Override
    protected void onScriptStart() {
        try {
            // Add logging for initialization
            Logger.log("=== ScarWraths SCRIPT INITIALIZATION ===");

            // Initialize script timer
            scriptTimer = new Timer();

            // Initialize starting stats
            startRcXP = Skills.getExperience(Skill.RUNECRAFTING);
            startRcLevel = Skills.getRealLevel(Skill.RUNECRAFTING);
            startTime = System.currentTimeMillis();

            // We'll use the framework paint only, no need for a separate overlay

            // Initialize paint based on rune type
            if (config.getRuneTypeEnum() == ScarWrathsConfig.RuneType.WRATH) {
                paint = new PaintBuilder(context)
                        .setTitle("Wrath Rune Crafter")
                        .addRow("Status", this::getScriptStatus)
                        .addRow("Current Node", () -> {
                            TaskNode node = context.tasks().getActiveNode();
                            return node != null ? node.getName() : "None";
                        })
                        .addRow("Wrath Runes", () -> String.valueOf(wrathRunesCrafted))
                        .addPerHour("Runes", () -> (long) wrathRunesCrafted)
                        .addFormattedRow("Total XP", this::getRunecraftXP)
                        .addPerHour("XP", this::getRunecraftXP)
                        .build();
            } else {
                paint = new PaintBuilder(context)
                        .setTitle("Nature Rune Crafter")
                        .addRow("Status", this::getScriptStatus)
                        .addRow("Current Node", () -> {
                            TaskNode node = context.tasks().getActiveNode();
                            return node != null ? node.getName() : "None";
                        })
                        .addRow("Nature Runes", () -> String.valueOf(natureRunesCrafted))
                        .addPerHour("Runes", () -> (long) natureRunesCrafted)
                        .addFormattedRow("Total XP", this::getRunecraftXP)
                        .addPerHour("XP", this::getRunecraftXP)
                        .build();
            }

            // Initialize nodes
            initializeNodes();

            // Register for inventory events to track Wrath runes
            // Note: We're also directly tracking in the ScarWrathsNode for reliability
            try {
                context.getEventManager().addEventListener(EventType.ITEM_GAINED, event -> {
                    if (event.getType() == EventType.ITEM_GAINED) {
                        itemGained(event);
                    }
                });
                Logger.info("Successfully registered inventory event listener");
            } catch (Exception e) {
                Logger.error("Failed to register inventory event listener: " + e.getMessage());
            }

            // Perform initial restock check if restock is enabled
            if (config.getRestockConfig().isEnabled()) {
                Logger.info("=== CHECKING RESTOCK NEEDS ON SCRIPT START ===");

                // Find the RestockGrandExchangeNode
                RestockGrandExchangeNode restockNode = context.tasks().getNodes().stream()
                    .filter(node -> node instanceof RestockGrandExchangeNode)
                    .map(node -> (RestockGrandExchangeNode) node)
                    .findFirst()
                    .orElse(null);

                if (restockNode != null) {
                    Logger.info("Forcing initial restock check on script start");
                    restockNode.forceRestockCheck();
                } else {
                    Logger.warn("RestockGrandExchangeNode not found, cannot check restock needs");
                }
            } else {
                Logger.info("Restock is disabled in settings, skipping initial check");
            }

            // Set script state to running
            setState(ScriptState.RUNNING);
            context.getLogger().info("ScarWraths script started successfully!");
        } catch (Exception e) {
            context.getLogger().error("Error during script initialization", e);
            setState(ScriptState.ERROR);
        }
    }

    /**
     * Initialize the script nodes
     */
    private void initializeNodes() {
        logger.info("=== INITIALIZING NODES ===");

        try {
            // Clear existing nodes
            context.tasks().clearNodes();

            // Add nodes in priority order
            // 0. Muling node (highest priority - takes over when muling is needed)
            context.tasks().addNode(new MulingNode(config, this));

            // Add RestockGrandExchangeNode (high priority, but will only execute when needed)
            context.tasks().addNode(new RestockGrandExchangeNode("RestockGE", 1, config));

            // Add nodes based on the selected rune type
            if (config.getRuneTypeEnum() == ScarWrathsConfig.RuneType.WRATH) {
                // Wrath rune crafting nodes
                // 1. Banking node (high priority - handles banking when needed)
                context.tasks().addNode(new BankingNode(config, this));

                // 2. Movement node (medium priority - handles movement to altar)
                context.tasks().addNode(new MovementNode(config, this));

                // 3. Crafting node (lowest priority - handles crafting at altar)
                context.tasks().addNode(new ScarWrathsNode(config, this));

                Logger.info("Initialized Wrath rune crafting nodes");
            } else if (config.getRuneTypeEnum() == ScarWrathsConfig.RuneType.NATURE) {
                // Nature rune crafting nodes
                // 1. Banking node (high priority - handles banking when needed)
                context.tasks().addNode(new NatureBankingNode(config, this));

                // 2. Movement node (medium priority - handles movement to altar)
                context.tasks().addNode(new NatureMovementNode(config, this));

                // 3. Crafting node (lowest priority - handles crafting at altar)
                context.tasks().addNode(new NatureRuneNode(config, this));

                Logger.info("Initialized Nature rune crafting nodes");
            }

            logger.info("All nodes initialized with script reference");
            logger.info("Total nodes initialized: " + context.tasks().getNodes().size());
        } catch (Exception e) {
            logger.error("Error initializing nodes: " + e.getMessage());
            setState(ScriptState.ERROR);
        }
    }

    /**
     * Called on each script loop
     */
    @Override
    protected int onScriptLoop() {
        try {
            if (getState().isRunnable()) {
                if (context.tasks().getNodes().isEmpty()) {
                    Logger.error("No nodes available - attempting reinitialization...");
                    initializeNodes();
                    return 600;
                }

                int sleepTime = context.tasks().execute(); // Execute the node
                return sleepTime; // Return the sleep time from the executed node
            }

            return 600;
        } catch (Exception e) {
            Logger.error("Error in script loop: " + e.getMessage());
            setState(ScriptState.ERROR);
            return 1000;
        }
    }

    /**
     * Called when the script stops
     */
    @Override
    protected void onScriptStop() {
        try {
            Logger.info("ScarWraths script stopping...");

            // Log final stats
            int gainedXp = (int) (Skills.getExperience(Skill.RUNECRAFTING) - startRcXP);
            int gainedLevels = Skills.getRealLevel(Skill.RUNECRAFTING) - startRcLevel;

            Logger.info("ScarWraths script completed");
            Logger.info("Runtime: " + (scriptTimer != null ? scriptTimer.formatTime() : "N/A"));
            Logger.info("Gained RC XP: " + gainedXp);
            Logger.info("Gained RC Levels: " + gainedLevels);

            // Log runes crafted based on the selected rune type
            if (config.getRuneTypeEnum() == ScarWrathsConfig.RuneType.WRATH) {
                Logger.info("Total Wrath runes crafted: " + wrathRunesCrafted);
            } else if (config.getRuneTypeEnum() == ScarWrathsConfig.RuneType.NATURE) {
                Logger.info("Total Nature runes crafted: " + natureRunesCrafted);
            }
        } catch (Exception e) {
            Logger.error("Error during script stopping: " + e.getMessage());
        }
    }

    /**
     * Get the script's settings tab
     */
    @Override
    protected AbstractSettingsTab getScriptTab() {
        return new ScarWrathsSettingsTab(context);
    }

    /**
     * Get the script configuration
     */
    @Override
    public ScarWrathsConfig getScriptConfig() {
        if (config == null) {
            config = new ScarWrathsConfig(context);
        }
        return config;
    }

    /**
     * Whether the script requires a GUI
     */
    @Override
    public boolean requiresGUI() {
        return true;
    }

    /**
     * Paint method
     */
    @Override
    public void onPaint(Graphics2D g) {
        if (paint != null) {
            paint.render(g);
        }

        // We're only using the framework paint
    }

    /**
     * Get the script status
     */
    private String getScriptStatus() {
        if (context.tasks().getActiveNode() != null) {
            return context.tasks().getActiveNode().getName();
        }
        return "Idle";
    }

    /**
     * Get the runecraft XP gained
     */
    private long getRunecraftXP() {
        return Skills.getExperience(Skill.RUNECRAFTING) - startRcXP;
    }

    /**
     * Get the starting runecraft XP
     */
    public int getStartRcXP() {
        return startRcXP;
    }

    /**
     * Increment the items processed counter
     */
    public void incrementActionsCompleted() {
        actionsCompleted++;
    }

    /**
     * Get the number of items processed
     * @return Number of items processed
     */
    public int getActionsCompleted() {
        return actionsCompleted;
    }

    /**
     * Increment the Wrath runes crafted counter
     * @param count Number of runes to add
     */
    public void incrementWrathRunesCrafted(int count) {
        wrathRunesCrafted += count;
        incrementActionsCompleted();
    }

    /**
     * Get the number of Wrath runes crafted
     * @return Number of Wrath runes crafted
     */
    public int getWrathRunesCrafted() {
        return wrathRunesCrafted;
    }

    /**
     * Increment the Nature runes crafted counter
     * @param count Number of runes to add
     */
    public void incrementNatureRunesCrafted(int count) {
        natureRunesCrafted += count;
        incrementActionsCompleted();
    }

    /**
     * Get the number of Nature runes crafted
     * @return Number of Nature runes crafted
     */
    public int getNatureRunesCrafted() {
        return natureRunesCrafted;
    }

    /**
     * Get the script configuration
     * @return The script configuration
     */
    public ScarWrathsConfig getConfig() {
        return config;
    }

    /**
     * Get the script timer
     * @return Script timer
     */
    public Timer getScriptTimer() {
        return scriptTimer;
    }

    /**
     * Handle item gained event
     * @param event The script event
     */
    private void itemGained(ScriptEvent event) {
        try {
            // Log all attributes for debugging
            Logger.info("Item gained event received with attributes: " + event.getAttributes());

            String itemName = (String) event.getAttribute("name");
            int quantity = (int) event.getAttribute("quantity");

            Logger.info("Item gained: " + itemName + " x" + quantity);

            if (WRATH_RUNE.equals(itemName)) {
                Logger.info("Gained " + quantity + " Wrath runes - incrementing counter");
                incrementWrathRunesCrafted(quantity);
                Logger.info("New total: " + wrathRunesCrafted + " Wrath runes");
            } else if (NATURE_RUNE.equals(itemName)) {
                Logger.info("Gained " + quantity + " Nature runes - incrementing counter");
                incrementNatureRunesCrafted(quantity);
                Logger.info("New total: " + natureRunesCrafted + " Nature runes");
            }
        } catch (Exception e) {
            Logger.error("Error in itemGained event handler: " + e.getMessage());
        }
    }
}
