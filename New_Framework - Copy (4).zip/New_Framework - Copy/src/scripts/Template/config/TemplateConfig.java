package scripts.Template.config;

import com.google.gson.annotations.Expose;
import core.config.ScriptConfig;
import core.context.ScriptContext;
import org.dreambot.api.settings.ScriptSettings;
import org.dreambot.api.utilities.Logger;
import scripts.Template.utils.ConfigUtil;

import java.io.File;
import java.util.*;

/**
 * Configuration class for Template script
 */
public class TemplateConfig extends ScriptConfig {
    // Default values
    private static final String DEFAULT_OPTION = "Default";
    private static final int DEFAULT_VALUE = 10;

    // Settings
    @Expose private boolean exampleBooleanSetting = true;
    @Expose private int exampleIntSetting = DEFAULT_VALUE;
    @Expose private String exampleStringSetting = DEFAULT_OPTION;
    @Expose private List<String> exampleListSetting = new ArrayList<>();
    @Expose private Map<String, Integer> exampleMapSetting = new HashMap<>();

    // Flag to track if settings have been modified
    private boolean dirty = false;

    // Add transient fields if ScriptContext is needed but not saved
    private transient ScriptContext context;

    /**
     * Constructor with context
     */
    public TemplateConfig(ScriptContext context) {
        super(context, "template_config");
        this.context = context;
        setDefaults();
    }

    /**
     * Default constructor with default values (for Gson deserialization)
     */
    public TemplateConfig() {
        // Use the no-args constructor in the parent class
        super();
        setDefaults();
    }

    @Override
    public void setDefaults() {
        // Reset to default values
        exampleBooleanSetting = true;
        exampleIntSetting = DEFAULT_VALUE;
        exampleStringSetting = DEFAULT_OPTION;
        
        // Initialize example list
        exampleListSetting = Arrays.asList("Item 1", "Item 2", "Item 3");
        
        // Initialize example map
        exampleMapSetting = new HashMap<>();
        exampleMapSetting.put("Key 1", 1);
        exampleMapSetting.put("Key 2", 2);
        exampleMapSetting.put("Key 3", 3);

        // Mark as dirty to ensure it's saved
        markDirty();
    }

    @Override
    public void saveConfig() {
        if (!dirty) {
            return;  // Only save if changes were made
        }

        try {
            // Create config data for saving
            ConfigData data = new ConfigData();
            data.exampleBooleanSetting = this.exampleBooleanSetting;
            data.exampleIntSetting = this.exampleIntSetting;
            data.exampleStringSetting = this.exampleStringSetting;
            data.exampleListSetting = new ArrayList<>(this.exampleListSetting);
            data.exampleMapSetting = new HashMap<>(this.exampleMapSetting);

            // Include framework-level configurations
            data.mulingConfig = this.getMulingConfig();
            data.breakConfig = this.getBreakConfig();
            data.antiBanConfig = this.getAntiBanConfig();

            // Save using our safe utility method
            ConfigUtil.safeSave(data, "ScarTemplate", "template_config.json");
            Logger.log("Template config saved successfully");

            markClean();
        } catch (Exception e) {
            Logger.log("Error saving Template config: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void loadConfig() {
        try {
            // Load from script settings
            ConfigData data = ScriptSettings.load(ConfigData.class, "ScarTemplate", "template_config.json");

            if (data != null) {
                this.exampleBooleanSetting = data.exampleBooleanSetting;
                this.exampleIntSetting = data.exampleIntSetting;
                this.exampleStringSetting = data.exampleStringSetting;
                this.exampleListSetting = new ArrayList<>(data.exampleListSetting);
                this.exampleMapSetting = new HashMap<>(data.exampleMapSetting);

                // Load framework-level configurations
                if (data.mulingConfig != null) {
                    this.setMulingConfig(data.mulingConfig);
                }
                if (data.breakConfig != null) {
                    this.setBreakConfig(data.breakConfig);
                }
                if (data.antiBanConfig != null) {
                    this.setAntiBanConfig(data.antiBanConfig);
                }

                Logger.log("Template config loaded successfully");
            } else {
                Logger.log("No existing Template config found, using defaults");
                setDefaults();
            }

            markClean();
        } catch (Exception e) {
            Logger.log("Error loading Template config: " + e.getMessage());
            e.printStackTrace();
            setDefaults();  // Fall back to defaults if loading fails
        }
    }

    /**
     * Inner class to hold serializable data
     */
    private static class ConfigData {
        public boolean exampleBooleanSetting = true;
        public int exampleIntSetting = DEFAULT_VALUE;
        public String exampleStringSetting = DEFAULT_OPTION;
        public List<String> exampleListSetting = new ArrayList<>();
        public Map<String, Integer> exampleMapSetting = new HashMap<>();

        // Framework-level configurations
        public core.config.MulingConfig mulingConfig = new core.config.MulingConfig();
        public core.config.BreakConfig breakConfig = new core.config.BreakConfig();
        public core.config.AntiBanConfig antiBanConfig = new core.config.AntiBanConfig();
    }

    /**
     * Save configuration to a profile file
     * @param name The profile name
     */
    public void saveProfile(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }

        try {
            // Create config data for saving
            ConfigData data = new ConfigData();
            data.exampleBooleanSetting = this.exampleBooleanSetting;
            data.exampleIntSetting = this.exampleIntSetting;
            data.exampleStringSetting = this.exampleStringSetting;
            data.exampleListSetting = new ArrayList<>(this.exampleListSetting);
            data.exampleMapSetting = new HashMap<>(this.exampleMapSetting);

            // Include framework-level configurations
            data.mulingConfig = this.getMulingConfig();
            data.breakConfig = this.getBreakConfig();
            data.antiBanConfig = this.getAntiBanConfig();

            // Save using our safe utility method
            ConfigUtil.safeSave(data, "ScarTemplate", "profiles", name + ".json");
            Logger.log("Template profile saved: " + name);
        } catch (Exception e) {
            Logger.log("Error saving Template profile: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /**
     * Load configuration from a profile file
     * @param name The profile name
     */
    public void loadProfile(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }

        try {
            // Load from profiles directory
            ConfigData data = ConfigUtil.safeLoad(ConfigData.class, "ScarTemplate", "profiles", name + ".json");

            if (data != null) {
                this.exampleBooleanSetting = data.exampleBooleanSetting;
                this.exampleIntSetting = data.exampleIntSetting;
                this.exampleStringSetting = data.exampleStringSetting;
                this.exampleListSetting = new ArrayList<>(data.exampleListSetting);
                this.exampleMapSetting = new HashMap<>(data.exampleMapSetting);

                // Load framework-level configurations
                if (data.mulingConfig != null) {
                    this.setMulingConfig(data.mulingConfig);
                }
                if (data.breakConfig != null) {
                    this.setBreakConfig(data.breakConfig);
                }
                if (data.antiBanConfig != null) {
                    this.setAntiBanConfig(data.antiBanConfig);
                }

                Logger.log("Template profile loaded: " + name);
                markDirty();
                saveConfig();
            } else {
                Logger.warn("Profile not found: " + name);
                throw new RuntimeException("Profile not found: " + name);
            }
        } catch (Exception e) {
            Logger.error("Error loading Template profile: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /**
     * Delete a profile
     * @param name The profile name
     * @return true if successful
     */
    public boolean deleteProfile(String name) {
        if (name == null || name.isEmpty()) {
            return false;
        }

        try {
            File profileFile = new File(getProfilesDirectory(), name + ".json");
            boolean deleted = profileFile.delete();
            if (deleted) {
                Logger.log("Deleted Template profile: " + name);
            } else {
                Logger.log("Failed to delete Template profile: " + name);
            }
            return deleted;
        } catch (Exception e) {
            Logger.log("Error deleting Template profile: " + e.getMessage());
            return false;
        }
    }

    /**
     * Get available profiles
     * @return List of profile names
     */
    public List<String> getAvailableProfiles() {
        List<String> profiles = new ArrayList<>();
        File profilesDir = getProfilesDirectory();

        if (profilesDir.exists() && profilesDir.isDirectory()) {
            File[] files = profilesDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".json"));
            if (files != null) {
                for (File file : files) {
                    String name = file.getName();
                    profiles.add(name.substring(0, name.lastIndexOf('.')));
                }
            }
        }

        return profiles;
    }

    /**
     * Get the profiles directory
     * @return The profiles directory
     */
    private File getProfilesDirectory() {
        String baseDir = System.getProperty("user.home") + File.separator +
                        "DreamBot" + File.separator +
                        "Scripts" + File.separator +
                        "ScarTemplate";

        File profilesDir = new File(baseDir + File.separator + "profiles");
        if (!profilesDir.exists()) {
            profilesDir.mkdirs();
        }

        return profilesDir;
    }

    // Mark config as dirty (changed)
    @Override
    public void markDirty() {
        this.dirty = true;
    }

    // Mark config as clean (saved)
    @Override
    public void markClean() {
        this.dirty = false;
    }

    // Check if config is dirty
    @Override
    public boolean isDirty() {
        return this.dirty;
    }

    @Override
    protected void copyConfigValues(ScriptConfig other) {
        // Call the parent implementation to copy framework-level configs
        super.copyConfigValues(other);
        if (other instanceof TemplateConfig) {
            TemplateConfig otherConfig = (TemplateConfig) other;
            this.exampleBooleanSetting = otherConfig.exampleBooleanSetting;
            this.exampleIntSetting = otherConfig.exampleIntSetting;
            this.exampleStringSetting = otherConfig.exampleStringSetting;
            this.exampleListSetting = new ArrayList<>(otherConfig.exampleListSetting);
            this.exampleMapSetting = new HashMap<>(otherConfig.exampleMapSetting);

            markDirty();
        }
    }

    @Override
    public void reset() {
        setDefaults();
    }

    // Framework-level configuration getters and setters are inherited from ScriptConfig
    
    // Add explicit methods to ensure proper serialization
    @Override
    public core.config.MulingConfig getMulingConfig() {
        return super.getMulingConfig();
    }
    
    @Override
    public void setMulingConfig(core.config.MulingConfig mulingConfig) {
        super.setMulingConfig(mulingConfig);
    }
    
    @Override
    public core.config.BreakConfig getBreakConfig() {
        return super.getBreakConfig();
    }
    
    @Override
    public void setBreakConfig(core.config.BreakConfig breakConfig) {
        super.setBreakConfig(breakConfig);
    }
    
    @Override
    public core.config.AntiBanConfig getAntiBanConfig() {
        return super.getAntiBanConfig();
    }
    
    @Override
    public void setAntiBanConfig(core.config.AntiBanConfig antiBanConfig) {
        super.setAntiBanConfig(antiBanConfig);
    }

    // Getters and setters for the script-specific settings
    
    public boolean isExampleBooleanSetting() {
        return exampleBooleanSetting;
    }

    public void setExampleBooleanSetting(boolean exampleBooleanSetting) {
        this.exampleBooleanSetting = exampleBooleanSetting;
        markDirty();
    }

    public int getExampleIntSetting() {
        return exampleIntSetting;
    }

    public void setExampleIntSetting(int exampleIntSetting) {
        this.exampleIntSetting = exampleIntSetting;
        markDirty();
    }

    public String getExampleStringSetting() {
        return exampleStringSetting;
    }

    public void setExampleStringSetting(String exampleStringSetting) {
        this.exampleStringSetting = exampleStringSetting;
        markDirty();
    }

    public List<String> getExampleListSetting() {
        return exampleListSetting;
    }

    public void setExampleListSetting(List<String> exampleListSetting) {
        this.exampleListSetting = exampleListSetting;
        markDirty();
    }

    public Map<String, Integer> getExampleMapSetting() {
        return exampleMapSetting;
    }

    public void setExampleMapSetting(Map<String, Integer> exampleMapSetting) {
        this.exampleMapSetting = exampleMapSetting;
        markDirty();
    }
}
