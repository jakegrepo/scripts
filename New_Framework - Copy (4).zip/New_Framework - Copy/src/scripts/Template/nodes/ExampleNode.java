package scripts.Template.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.Calculations;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import scripts.Template.TemplateScript;
import scripts.Template.config.TemplateConfig;

/**
 * Example node for the template script
 */
public class ExampleNode extends SimpleNode<TemplateConfig> {
    private final TemplateScript script;

    /**
     * Constructor
     * @param config The script configuration
     * @param script The script instance
     */
    public ExampleNode(TemplateConfig config, TemplateScript script) {
        super("Example Node", 1, config);
        this.script = script;
    }

    @Override
    public boolean validate() {
        // Check if the node should execute
        // This is called before onExecute() to determine if the node should run

        // Example validation logic:
        // - Check if the player is idle
        // - Check if a specific setting is enabled
        return !isPlayerAnimating() && !isPlayerMoving() && config.isExampleBooleanSetting();
    }

    @Override
    public int onExecute() {
        // Execute the node's logic
        // Return the number of milliseconds to sleep before the next node check

        try {
            // Set the status for debugging
            status("Executing example node");

            // Example logic:
            // - Increment the items processed counter
            script.incrementItemsProcessed();

            // Log the action
            Logger.info("Processed an item. Total: " + script.getItemsProcessed());

            // Perform some action
            if (config.getExampleIntSetting() > 5) {
                status("Example int setting is greater than 5");
                // Do something specific when the setting is greater than 5
            } else {
                status("Example int setting is less than or equal to 5");
                // Do something else when the setting is less than or equal to 5
            }

            // Example of using the list setting
            if (!config.getExampleListSetting().isEmpty()) {
                String firstItem = config.getExampleListSetting().get(0);
                status("First item in list: " + firstItem);
            }

            // Example of using the map setting
            if (config.getExampleMapSetting().containsKey("Key 1")) {
                int value = config.getExampleMapSetting().get("Key 1");
                status("Value for Key 1: " + value);
            }

            // Sleep for a random amount of time to simulate work
            Sleep.sleepTick();

            // Return a sleep time in milliseconds
            return 1000 + Calculations.random(500, 1500);
        } catch (Exception e) {
            Logger.error("Error in ExampleNode: " + e.getMessage());
            return 1000; // Sleep for 1 second on error
        }
    }
}
