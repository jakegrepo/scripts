package scripts.Template;

import core.base.ScarScript;
import core.context.ScriptContext;
import core.grandexchange.RestockGrandExchangeNode;
import core.gui.AbstractSettingsTab;
import core.node.TaskNode;
import core.paint.PaintBuilder;
import core.paint.ScriptPaint;
import core.state.ScriptState;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Timer;
import scripts.Template.config.TemplateConfig;
import scripts.Template.gui.TemplateOverlay;
import scripts.Template.gui.TemplateSettingsTab;
import scripts.Template.nodes.*;

import java.awt.*;


public class TemplateScript extends ScarScript<TemplateConfig> {

    private Timer scriptTimer;
    private int itemsProcessed = 0;
    private TemplateOverlay statsOverlay;
    private ScriptPaint paint;

    // Restock components
    private RestockGrandExchangeNode restockNode;

    // Track starting stats
    private int startHerbXp;
    private int startHerbLevel;
    private long startTime;

    /**
     * Called when the script starts
     */
    @Override
    protected void onScriptStart() {
        try {
            // Add logging for initialization
            Logger.log("=== TEMPLATE SCRIPT INITIALIZATION ===");

            // Initialize script timer
            scriptTimer = new Timer();

            // Initialize starting stats
            startHerbXp = Skills.getExperience(Skill.HERBLORE);
            startHerbLevel = Skills.getRealLevel(Skill.HERBLORE);
            startTime = System.currentTimeMillis();

            // Initialize overlay
            statsOverlay = new TemplateOverlay(context, this);
            context.getDebugOverlayManager().registerOverlay(statsOverlay);

            // Initialize restock node
            restockNode = new RestockGrandExchangeNode("RestockGE", 0, config);

            // Initialize paint
            paint = new PaintBuilder(context)
                    .setTitle("Template Script")
                    .addRow("Status", this::getScriptStatus)
                    .addRow("Current Node", () -> {
                        TaskNode node = context.tasks().getActiveNode();
                        return node != null ? node.getName() : "None";
                    })
                    .addRow("Items Processed", () -> String.valueOf(itemsProcessed))
                    .addFormattedRow("Total XP", this::getHerbloreXp)
                    .addPerHour("XP", this::getHerbloreXp)
                    .build();

            // Initialize nodes
            initializeNodes();

            // Set script state to running
            setState(ScriptState.RUNNING);
            context.getLogger().info("Template script started successfully!");
        } catch (Exception e) {
            context.getLogger().error("Error during script initialization", e);
            setState(ScriptState.ERROR);
        }
    }

    /**
     * Initialize the script nodes
     */
    private void initializeNodes() {
        logger.info("=== INITIALIZING NODES ===");

        try {
            // Clear existing nodes
            context.tasks().clearNodes();

            // Add nodes
            context.tasks().addNode(new ExampleNode(config, this));

            // Add restock node (high priority)
            context.tasks().addNode(restockNode);

            // Add more nodes as needed
            // context.tasks().addNode(new AnotherNode(config, this));

            logger.info("All nodes initialized with script reference");
            logger.info("Total nodes initialized: " + context.tasks().getNodes().size());
        } catch (Exception e) {
            logger.error("Error initializing nodes: " + e.getMessage());
            setState(ScriptState.ERROR);
        }
    }

    /**
     * Called on each script loop
     */
    @Override
    protected int onScriptLoop() {
        try {
            if (getState().isRunnable()) {
                if (context.tasks().getNodes().isEmpty()) {
                    Logger.error("No nodes available - attempting reinitialization...");
                    initializeNodes();
                    return 600;
                }

                int sleepTime = context.tasks().execute(); // Execute the node
                return sleepTime; // Return the sleep time from the executed node
            }

            return 600;
        } catch (Exception e) {
            Logger.error("Error in script loop: " + e.getMessage());
            setState(ScriptState.ERROR);
            return 1000;
        }
    }

    /**
     * Called when the script stops
     */
    @Override
    protected void onScriptStop() {
        try {
            Logger.info("Template script stopping...");

            // Log final stats
            int gainedXp = (int) (Skills.getExperience(Skill.HERBLORE) - startHerbXp);
            int gainedLevels = Skills.getRealLevel(Skill.HERBLORE) - startHerbLevel;

            Logger.info("Template script completed");
            Logger.info("Runtime: " + (scriptTimer != null ? scriptTimer.formatTime() : "N/A"));
            Logger.info("Gained Herblore XP: " + gainedXp);
            Logger.info("Gained Herblore Levels: " + gainedLevels);
            Logger.info("Total items processed: " + itemsProcessed);
        } catch (Exception e) {
            Logger.error("Error during script stopping: " + e.getMessage());
        }
    }

    /**
     * Get the script's settings tab
     */
    @Override
    protected AbstractSettingsTab getScriptTab() {
        return new TemplateSettingsTab(context);
    }

    /**
     * Get the script configuration
     */
    @Override
    public TemplateConfig getScriptConfig() {
        if (config == null) {
            config = new TemplateConfig(context);
        }
        return config;
    }

    /**
     * Whether the script requires a GUI
     */
    @Override
    public boolean requiresGUI() {
        return true;
    }

    /**
     * Paint method
     */
    @Override
    public void onPaint(Graphics2D g) {
        if (paint != null) {
            paint.render(g);
        }

        // Render stats overlay
        if (statsOverlay != null && statsOverlay.isEnabled()) {
            statsOverlay.render(g);
        }
    }

    /**
     * Get the script status
     */
    private String getScriptStatus() {
        if (context.tasks().getActiveNode() != null) {
            return context.tasks().getActiveNode().getName();
        }
        return "Idle";
    }

    /**
     * Get the herblore XP gained
     */
    private long getHerbloreXp() {
        return Skills.getExperience(Skill.HERBLORE) - startHerbXp;
    }

    /**
     * Increment the items processed counter
     */
    public void incrementItemsProcessed() {
        itemsProcessed++;
    }

    /**
     * Get the number of items processed
     * @return Number of items processed
     */
    public int getItemsProcessed() {
        return itemsProcessed;
    }

    /**
     * Example of how to use the restock functionality
     */
    private void checkRestock() {
        // Check if restock is needed
        if (restockNode.getRestockCheck().needsRestock()) {
            Logger.info("Need to restock items, forcing restock check");
            restockNode.forceRestockCheck();
        }
    }

    /**
     * Get the script timer
     * @return Script timer
     */
    public Timer getScriptTimer() {
        return scriptTimer;
    }
}
