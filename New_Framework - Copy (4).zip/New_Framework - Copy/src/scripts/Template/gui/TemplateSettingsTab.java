package scripts.Template.gui;

import core.context.ScriptContext;
import core.gui.AbstractSettingsTab;
import core.gui.style.StyleManager;
import org.dreambot.api.utilities.Logger;
import scripts.Template.config.TemplateConfig;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Settings tab for the template script
 */
public class TemplateSettingsTab extends AbstractSettingsTab {
    private final TemplateConfig config;
    private TemplateGeneralPanel generalPanel;
    private TemplateListPanel listPanel;

    /**
     * Constructor
     * @param context The script context
     */
    public TemplateSettingsTab(ScriptContext context) {
        super(context);
        this.config = (TemplateConfig) ((core.base.ScarScript<?>) context.getScript()).getConfig();
        
        // Initialize panels
        generalPanel = new TemplateGeneralPanel(config);
        listPanel = new TemplateListPanel(config);
        
        // Add panels to tab
        addSection("General Settings", generalPanel);
        addSection("List Settings", listPanel);
    }

    @Override
    public void createComponents() {
        // No additional components needed
    }

    @Override
    public String getTitle() {
        return "Template";
    }

    @Override
    public void resetToDefaults() {
        // Reset config to defaults
        config.setDefaults();
        
        // Update panels
        generalPanel.loadSettings();
        listPanel.loadSettings();
    }
    
    @Override
    public void updateFromConfig() {
        // Update all panels with the latest config
        generalPanel.loadSettings();
        listPanel.loadSettings();
    }

    /**
     * General settings panel
     */
    class TemplateGeneralPanel extends core.gui.SettingsPanel {
        private final TemplateConfig config;
        private JCheckBox exampleBooleanCheckbox;
        private JSpinner exampleIntSpinner;
        private JComboBox<String> exampleStringComboBox;
        private boolean isLoading = false;

        /**
         * Constructor
         * @param config The script configuration
         */
        public TemplateGeneralPanel(TemplateConfig config) {
            super();
            this.config = config;
            initializeComponents();
            loadSettings();
        }

        /**
         * Initialize the panel components
         */
        private void initializeComponents() {
            // Create main panel with GridBagLayout for precise control
            JPanel mainPanel = new JPanel(new GridBagLayout());
            StyleManager.applyStyle(mainPanel);

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.weightx = 1.0;

            // Add section header
            JLabel headerLabel = new JLabel("General Settings");
            headerLabel.setFont(StyleManager.HEADER_FONT);
            headerLabel.setForeground(StyleManager.ACCENT);
            mainPanel.add(headerLabel, gbc);

            // Example boolean setting
            gbc.gridy++;
            gbc.gridwidth = 1;
            exampleBooleanCheckbox = new JCheckBox("Example Boolean Setting");
            StyleManager.styleCheckBox(exampleBooleanCheckbox);
            mainPanel.add(exampleBooleanCheckbox, gbc);

            // Example int setting
            gbc.gridy++;
            gbc.gridx = 0;
            JLabel intLabel = new JLabel("Example Int Setting:");
            StyleManager.styleLabel(intLabel);
            mainPanel.add(intLabel, gbc);

            gbc.gridx = 1;
            exampleIntSpinner = new JSpinner(new SpinnerNumberModel(10, 1, 100, 1));
            StyleManager.styleSpinner(exampleIntSpinner);
            mainPanel.add(exampleIntSpinner, gbc);

            // Example string setting
            gbc.gridy++;
            gbc.gridx = 0;
            JLabel stringLabel = new JLabel("Example String Setting:");
            StyleManager.styleLabel(stringLabel);
            mainPanel.add(stringLabel, gbc);

            gbc.gridx = 1;
            String[] options = {"Option 1", "Option 2", "Option 3", "Default"};
            exampleStringComboBox = new JComboBox<>(options);
            StyleManager.styleComboBox(exampleStringComboBox);
            mainPanel.add(exampleStringComboBox, gbc);

            // Add the main panel to this panel
            setLayout(new BorderLayout());
            add(mainPanel, BorderLayout.CENTER);

            // Add listeners
            exampleBooleanCheckbox.addActionListener(e -> {
                if (!isLoading) saveSettings();
            });

            exampleIntSpinner.addChangeListener(e -> {
                if (!isLoading) saveSettings();
            });

            exampleStringComboBox.addActionListener(e -> {
                if (!isLoading) saveSettings();
            });
        }

        /**
         * Load settings from config
         */
        public void loadSettings() {
            isLoading = true;
            try {
                exampleBooleanCheckbox.setSelected(config.isExampleBooleanSetting());
                exampleIntSpinner.setValue(config.getExampleIntSetting());
                exampleStringComboBox.setSelectedItem(config.getExampleStringSetting());
            } finally {
                isLoading = false;
            }
        }

        /**
         * Save settings to config
         */
        public void saveSettings() {
            if (isLoading) return;

            config.setExampleBooleanSetting(exampleBooleanCheckbox.isSelected());
            config.setExampleIntSetting((int) exampleIntSpinner.getValue());
            config.setExampleStringSetting((String) exampleStringComboBox.getSelectedItem());

            // Mark config as dirty
            config.markDirty();
        }
        
        /**
         * Updates from config - called when loading a profile
         */
        public void updateFromConfig() {
            // Call loadSettings to update all components
            loadSettings();
        }
    }

    /**
     * List settings panel
     */
    class TemplateListPanel extends core.gui.SettingsPanel {
        private final TemplateConfig config;
        private JList<String> itemsList;
        private DefaultListModel<String> itemsListModel;
        private JTextField newItemField;
        private JButton addItemButton;
        private JButton removeItemButton;
        private boolean isLoading = false;

        /**
         * Constructor
         * @param config The script configuration
         */
        public TemplateListPanel(TemplateConfig config) {
            super();
            this.config = config;
            initializeComponents();
            loadSettings();
        }

        /**
         * Initialize the panel components
         */
        private void initializeComponents() {
            // Create main panel with GridBagLayout for precise control
            JPanel mainPanel = new JPanel(new GridBagLayout());
            StyleManager.applyStyle(mainPanel);

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.weightx = 1.0;

            // Add section header
            JLabel headerLabel = new JLabel("List Settings");
            headerLabel.setFont(StyleManager.HEADER_FONT);
            headerLabel.setForeground(StyleManager.ACCENT);
            mainPanel.add(headerLabel, gbc);

            // Items list
            gbc.gridy++;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.weighty = 1.0;
            itemsListModel = new DefaultListModel<>();
            itemsList = new JList<>(itemsListModel);
            StyleManager.styleList(itemsList);
            JScrollPane scrollPane = new JScrollPane(itemsList);
            StyleManager.styleScrollPane(scrollPane);
            mainPanel.add(scrollPane, gbc);

            // New item field
            gbc.gridy++;
            gbc.gridwidth = 1;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.weighty = 0.0;
            newItemField = new JTextField();
            StyleManager.styleTextField(newItemField);
            mainPanel.add(newItemField, gbc);

            // Add button
            gbc.gridx = 1;
            addItemButton = new JButton("Add");
            StyleManager.styleButton(addItemButton);
            mainPanel.add(addItemButton, gbc);

            // Remove button
            gbc.gridy++;
            gbc.gridx = 0;
            gbc.gridwidth = 2;
            removeItemButton = new JButton("Remove Selected");
            StyleManager.styleButton(removeItemButton);
            mainPanel.add(removeItemButton, gbc);

            // Add the main panel to this panel
            setLayout(new BorderLayout());
            add(mainPanel, BorderLayout.CENTER);

            // Add listeners
            addItemButton.addActionListener(e -> {
                String newItem = newItemField.getText().trim();
                if (!newItem.isEmpty() && !itemsListModel.contains(newItem)) {
                    itemsListModel.addElement(newItem);
                    newItemField.setText("");
                    saveSettings();
                }
            });

            removeItemButton.addActionListener(e -> {
                int selectedIndex = itemsList.getSelectedIndex();
                if (selectedIndex != -1) {
                    itemsListModel.remove(selectedIndex);
                    saveSettings();
                }
            });
        }

        /**
         * Load settings from config
         */
        public void loadSettings() {
            isLoading = true;
            try {
                // Load items
                itemsListModel.clear();
                for (String item : config.getExampleListSetting()) {
                    itemsListModel.addElement(item);
                }
            } finally {
                isLoading = false;
            }
        }

        /**
         * Save settings to config
         */
        public void saveSettings() {
            if (isLoading) return;

            // Save items
            List<String> items = new ArrayList<>();
            for (int i = 0; i < itemsListModel.size(); i++) {
                items.add(itemsListModel.getElementAt(i));
            }
            config.setExampleListSetting(items);

            // Mark config as dirty
            config.markDirty();
        }
        
        /**
         * Updates from config - called when loading a profile
         */
        public void updateFromConfig() {
            // Call loadSettings to update all components
            loadSettings();
        }
    }
}
