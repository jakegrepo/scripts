package scripts.Template.gui;

import core.context.ScriptContext;
import core.paint.debug.DebugOverlayInterface;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import scripts.Template.TemplateScript;

import java.awt.*;

/**
 * Overlay for displaying script statistics
 */
public class TemplateOverlay implements DebugOverlayInterface {
    private final TemplateScript script;
    private final ScriptContext context;
    private final Font titleFont = new Font("Arial", Font.BOLD, 16);
    private final Font textFont = new Font("Arial", Font.PLAIN, 12);
    private final Color backgroundColor = new Color(0, 0, 0, 180);
    private final Color titleColor = new Color(255, 255, 255);
    private final Color textColor = new Color(200, 200, 200);
    private final Color highlightColor = new Color(255, 165, 0);
    private final Rectangle panelBounds = new Rectangle(7, 340, 200, 120);
    private boolean enabled = true;

    /**
     * Constructor
     * @param context The script context
     * @param script The script instance
     */
    public TemplateOverlay(ScriptContext context, TemplateScript script) {
        this.context = context;
        this.script = script;
    }

    @Override
    public void render(Graphics2D g) {
        // Save original settings
        Font originalFont = g.getFont();
        Color originalColor = g.getColor();

        // Calculate metrics
        int startXp = Skills.getExperience(Skill.HERBLORE);
        int currentXp = Skills.getExperience(Skill.HERBLORE);
        int xpGained = currentXp - startXp;

        long runTime = script.getScriptTimer().elapsed();
        long xpPerHour = (long) (xpGained / (runTime / 3600000.0));

        int itemsProcessed = script.getItemsProcessed();
        long itemsPerHour = (long) (itemsProcessed / (runTime / 3600000.0));

        // Draw background
        g.setColor(backgroundColor);
        g.fillRoundRect(panelBounds.x, panelBounds.y, panelBounds.width, panelBounds.height, 10, 10);

        // Draw title
        g.setFont(titleFont);
        g.setColor(titleColor);
        g.drawString("Template Stats", panelBounds.x + 10, panelBounds.y + 20);

        // Draw stats
        g.setFont(textFont);
        g.setColor(textColor);

        int y = panelBounds.y + 40;
        int lineHeight = 16;

        g.drawString("Runtime: ", panelBounds.x + 10, y);
        g.setColor(highlightColor);
        g.drawString(formatTime(runTime), panelBounds.x + 100, y);
        y += lineHeight;

        g.setColor(textColor);
        g.drawString("Items Processed: ", panelBounds.x + 10, y);
        g.setColor(highlightColor);
        g.drawString(String.valueOf(itemsProcessed), panelBounds.x + 100, y);
        y += lineHeight;

        g.setColor(textColor);
        g.drawString("Items/Hour: ", panelBounds.x + 10, y);
        g.setColor(highlightColor);
        g.drawString(String.valueOf(itemsPerHour), panelBounds.x + 100, y);
        y += lineHeight;

        g.setColor(textColor);
        g.drawString("XP Gained: ", panelBounds.x + 10, y);
        g.setColor(highlightColor);
        g.drawString(String.valueOf(xpGained), panelBounds.x + 100, y);
        y += lineHeight;

        g.setColor(textColor);
        g.drawString("XP/Hour: ", panelBounds.x + 10, y);
        g.setColor(highlightColor);
        g.drawString(String.valueOf(xpPerHour), panelBounds.x + 100, y);

        // Restore original settings
        g.setFont(originalFont);
        g.setColor(originalColor);
    }

    /**
     * Format time in milliseconds to HH:MM:SS
     * @param time Time in milliseconds
     * @return Formatted time string
     */
    private String formatTime(long time) {
        long seconds = time / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;

        return String.format("%02d:%02d:%02d", hours, minutes % 60, seconds % 60);
    }

    @Override
    public String getName() {
        return "Template Stats";
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
