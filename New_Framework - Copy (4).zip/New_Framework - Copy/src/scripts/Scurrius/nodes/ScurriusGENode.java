package scripts.Scurrius.nodes;

import core.grandexchange.GrandExchangeNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.utilities.Logger;
import scripts.Scurrius.ScurriusConfig;
import scripts.Scurrius.enums.TeleportType;

import java.util.List;
import java.util.Map;

public class ScurriusGENode extends GrandExchangeNode<ScurriusConfig> {
    private static final int DEFAULT_TELEPORT_COUNT = 2;
    private static final int DEFAULT_NATURE_RUNE_COUNT = 100;
    private static final int DEFAULT_FIRE_RUNE_COUNT = 500;
    private static final int DEFAULT_LAW_RUNE_COUNT = 10;
    private static final int DEFAULT_AIR_RUNE_COUNT = 30;
    private static final int DEFAULT_FIRE_TELEPORT_COUNT = 30;

    public ScurriusGENode(ScurriusConfig config) {
        super("Scurrius GE", 2, config);
    }

    @Override
    protected void checkAndPreparePurchaseList() {
        // Clear any existing items
        clearCustomItems();

        int multiplier = config.getSuppliesMultiplier();
        boolean needsItems = false;

        // Check and restock ALL supplies to their target quantities
        Map<String, Integer> supplies = config.getSupplies();
        if (supplies != null) {
            for (Map.Entry<String, Integer> entry : supplies.entrySet()) {
                String itemName = entry.getKey();
                int targetAmount = entry.getValue() * multiplier;
                int currentAmount = Bank.count(itemName) + Inventory.count(itemName);
                
                if (currentAmount < targetAmount) {
                    int amountNeeded = targetAmount - currentAmount;
                    Logger.log("Need to buy " + amountNeeded + " " + itemName);
                    addItemToBuy(itemName, amountNeeded);
                    needsItems = true;
                }
            }
        }

        // Check and restock food
        List<String> foodNames = config.getFoodNames();
        if (!foodNames.isEmpty()) {
            String preferredFood = foodNames.get(0);
            int targetFoodAmount = config.getTargetFoodCount() * multiplier;
            int currentFoodAmount = Bank.count(preferredFood) + Inventory.count(preferredFood);
            
            if (currentFoodAmount < targetFoodAmount) {
                int foodNeeded = targetFoodAmount - currentFoodAmount;
                Logger.log("Need to buy " + foodNeeded + " " + preferredFood);
                addItemToBuy(preferredFood, foodNeeded);
                needsItems = true;
            }
        }

        // Check and restock ammo
        Map<String, String> equipment = config.getEquipment();
        if (equipment.containsKey("ammo") && config.getAmmoQuantity() > 0) {
            String ammoType = equipment.get("ammo");
            if (ammoType != null && !ammoType.isEmpty()) {
                int targetAmmo = config.getAmmoQuantity() * multiplier;
                int currentAmmo = Bank.count(ammoType) + Inventory.count(ammoType);
                
                if (currentAmmo < targetAmmo) {
                    int ammoNeeded = targetAmmo - currentAmmo;
                    Logger.log("Need to buy " + ammoNeeded + " " + ammoType);
                    addItemToBuy(ammoType, ammoNeeded);
                    needsItems = true;
                }
            }
        }
        if (config.isAlchemyEnabled()) {
            checkAndAddAlchRunes(multiplier);
            needsItems = true;
        }
        // Check and restock teleport supplies
        TeleportType teleportType = config.getTeleportType();
        if (teleportType != TeleportType.NONE) {
            switch (teleportType) {
                case TABLET:
                    checkAndAddTeleportTablets(multiplier);
                    needsItems = true;
                    break;

                case SPELL:
                    checkAndAddTeleportRunes(multiplier);
                    needsItems = true;
                    break;
            }
        }

        if (!needsItems) {
            Logger.log("No items need to be purchased - all quantities at or above targets");
            completed = true;
        }

        Logger.log("Will restock all supplies to their target quantities");
    }

    private void checkAndAddTeleportTablets(int multiplier) {
        int currentTeleports = Bank.count("Varrock teleport") + Inventory.count("Varrock teleport");
        int targetTeleports = DEFAULT_TELEPORT_COUNT * multiplier;
        if (currentTeleports < targetTeleports) {
            int teleportsNeeded = targetTeleports - currentTeleports;
            addItemToBuy("Varrock teleport", teleportsNeeded);
        }
    }

    private void checkAndAddTeleportRunes(int multiplier) {
        // Law runes
        int currentLaws = Bank.count("Law rune") + Inventory.count("Law rune");
        int targetLaws = DEFAULT_LAW_RUNE_COUNT * multiplier;
        if (currentLaws < targetLaws) {
            addItemToBuy("Law rune", targetLaws - currentLaws);
        }

        // Air runes
        int currentAir = Bank.count("Air rune") + Inventory.count("Air rune");
        int targetAir = DEFAULT_AIR_RUNE_COUNT * multiplier;
        if (currentAir < targetAir) {
            addItemToBuy("Air rune", targetAir - currentAir);
        }

        // Fire runes
        int currentFire = Bank.count("Fire rune") + Inventory.count("Fire rune");
        int targetFire = DEFAULT_FIRE_RUNE_COUNT * multiplier;
        if (currentFire < targetFire) {
            addItemToBuy("Fire rune", targetFire - currentFire);
        }
    }
    private void checkAndAddAlchRunes(int multiplier) {
        // Law runes
        int currentFires = Bank.count("Fire rune") + Inventory.count("Fire rune");
        int targetFires = DEFAULT_FIRE_RUNE_COUNT * multiplier;
        if (currentFires < targetFires) {
            addItemToBuy("Fire rune", targetFires - currentFires);
        }

        // Air runes
        int currentNatures = Bank.count("Nature rune") + Inventory.count("Nature rune");
        int targetNatures = DEFAULT_NATURE_RUNE_COUNT * multiplier;
        if (currentNatures < targetNatures) {
            addItemToBuy("Nature rune", targetNatures - currentNatures);
        }
    }

    @Override
    protected void notifyComplete() {
        super.notifyComplete();
        
        // Reset force execute flag
        setForceExecute(false);
        
        // Reset banking node
        context.tasks().getNodes().stream()
            .filter(node -> node instanceof BankingNode)
            .map(node -> (BankingNode) node)
            .forEach(node -> {
                node.resetTransitioning();
                node.reset();
            });

        // Reset config GE flag if all items were successfully purchased
        if (itemsToBuy.isEmpty()) {
            config.setUseGrandExchange(false);
        }
    }
}