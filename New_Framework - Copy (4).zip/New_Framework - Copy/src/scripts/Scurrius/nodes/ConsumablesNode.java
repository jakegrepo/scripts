package scripts.Scurrius.nodes;

import core.base.SimpleNode;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.items.Item;
import scripts.Scurrius.ScurriusConfig;

import static org.dreambot.api.methods.skills.Skill.PRAYER;

public class ConsumablesNode extends SimpleNode<ScurriusConfig> implements Runnable {
    private volatile boolean stopRequested = false;
    private final MovementNode movementNode;

    public ConsumablesNode(ScurriusConfig config, MovementNode movementNode) {
        super("Consumables", 1, config);
        this.movementNode = movementNode;
    }

    @Override
    public boolean validate() {
        return Client.isDynamicRegion();
    }

    @Override
    protected int onExecute() {
        // Not used since we're running in a separate thread
        return 0;
    }

    @Override
    public void run() {
        while (!stopRequested) {
            try {
                handleConsumables();
                Thread.sleep(100); // Check every 100ms
            } catch (Exception e) {
                Logger.log("ConsumablesNode error: " + e.getMessage());
            }
        }
    }

    private void handleConsumables() {
        // First priority: Eat if health is low
        if (isHealthLow()) {
            eatFood();
            }

        // Second priority: Handle potions
        handlePotions();
    }

    private boolean isHealthLow() {
        int currentHealth = Skills.getBoostedLevel(Skill.HITPOINTS);
        return currentHealth <= config.getHealthThreshold();
    }

    private boolean isPrayerLow() {
        int currentPrayer = Skills.getBoostedLevel(PRAYER);
        int maxPrayer = Skills.getRealLevel(PRAYER);
        int prayerPercent = (currentPrayer * 100) / maxPrayer;
        return prayerPercent <= 25;
    }

    private boolean eatFood() {
        Logger.log("Attempting to eat food...");
        Logger.log("Configured food names: " + config.getFoodNames());



        Logger.log("Failed to eat configured food, trying backup food...");
        // If no configured food available, try looted common foods
        if (tryEatFood("Shark")) return true;
        if (tryEatFood("Lobster")) return true;
        if (tryEatFood("Tuna")) return true;
        if (eatConfiguredFood()) {
            Logger.log("Successfully ate configured food");
            return true;
        }
        Logger.log("Failed to eat any food!");
        return false;
    }

    private boolean eatConfiguredFood() {
        if (!config.getFoodNames().isEmpty()) {
            String foodName = config.getFoodNames().get(0);
            Logger.log("Attempting to eat configured food: " + foodName);
            return tryEatFood(foodName);
        }
        Logger.log("No food configured in settings!");
        return false;
    }

    private boolean tryEatFood(String foodName) {
        Logger.log("Checking for food: " + foodName);
        Item food = Inventory.get(foodName);
        if (food != null && food.hasAction("Eat")) {
            status("Eating " + foodName);
            int initialCount = Inventory.count(foodName);
            if (food.interact("Eat")) {
                boolean eaten = sleepUntil(() -> Inventory.count(foodName) < initialCount, 1200);
                Logger.log("Food was eaten: " + eaten);
                return eaten;
            }
            Logger.log("Failed to interact with " + foodName);
        } else {
            Logger.log("No " + foodName + " found or it can't be eaten.");
        }
        return false;
    }
    private boolean shouldBoost(Skill skill) {
        int currentLevel = Skills.getBoostedLevel(skill);
        int baseLevel = Skills.getRealLevel(skill);
        int boostThreshold = 5;
        return currentLevel <= baseLevel + boostThreshold && Client.isDynamicRegion();
    }

    private void handlePotions() {
        // Combat boosting potions
        if (shouldBoost(Skill.ATTACK) || shouldBoost(Skill.STRENGTH) || shouldBoost(Skill.DEFENCE)) {
            if (drinkPotion("Super combat potion")) return;
            if (shouldBoost(Skill.ATTACK) && drinkPotion("Super attack")) return;
            if (shouldBoost(Skill.STRENGTH) && drinkPotion("Super strength")) return;
            if (shouldBoost(Skill.DEFENCE) && drinkPotion("Super defence")) return;
        }

        // Ranging potion
        if (shouldBoost(Skill.RANGED) && drinkPotion("Ranging potion")) return;

        // Prayer restore
        if (isPrayerLow()) {
            if (drinkPotion("Super restore")) return;
            drinkPotion("Prayer potion");
        }
    }

    private boolean drinkPotion(String baseName) {
        for (int dose = 4; dose >= 1; dose--) {
            String potionName = baseName + "(" + dose + ")";
            Item potion = Inventory.get(potionName);
            if (potion != null && potion.hasAction("Drink")) {
                status("Drinking " + potionName);
                if (potion.interact("Drink")) {
                    sleepUntil(() -> !Inventory.contains(potionName), 1200);
                    return true;
                }
            }
        }
        return false;
    }

    public void stopNode() {
        stopRequested = true;
    }
} 