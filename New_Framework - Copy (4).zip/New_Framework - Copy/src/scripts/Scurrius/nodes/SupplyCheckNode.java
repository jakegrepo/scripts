package scripts.Scurrius.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import scripts.Scurrius.ScurriusConfig;
import scripts.Scurrius.enums.TeleportType;

import java.util.List;
import java.util.Map;

public class SupplyCheckNode extends SimpleNode<ScurriusConfig> {
    private boolean checkComplete = false;

    public SupplyCheckNode(ScurriusConfig config) {
        super("Supply Check", 1, config);  // Highest priority (1)
    }

    @Override
    public boolean validate() {
        if (checkComplete) {
            return false;
        }
        
        // Only run if we're not in instance and bank is open
        return !config.isInInstance() && Bank.isOpen();
    }

    @Override
    protected int onExecute() {
        // First ensure everything is deposited
        Bank.depositAllItems();
        Bank.depositAllEquipment();
        Sleep.sleep(600);

        // Log current supply status
        logSupplyStatus();

        // Check if we need to resupply
        if (needsResupply()) {
            Logger.log("Supply check failed - triggering GE resupply");
            triggerGeNode();
        } else {
            Logger.log("Supply check passed - proceeding with banking");
            triggerBankNode();
        }

        checkComplete = true;
        return 600;
    }

    private void logSupplyStatus() {
        int multiplier = config.getSuppliesMultiplier();
        Logger.log("=== Supply Status (Multiplier: " + multiplier + "x) ===");

        // Check food
        List<String> foodNames = config.getFoodNames();
        if (!foodNames.isEmpty()) {
            String preferredFood = foodNames.get(0);
            int requiredForTrip = config.getTargetFoodCount();
            int targetQuantity = requiredForTrip * multiplier;
            int currentAmount = Bank.count(preferredFood) + Inventory.count(preferredFood);
            
            Logger.log("--- Food ---");
            Logger.log(String.format("%s: Have %d / Need %d per trip / Target %d total",
                preferredFood, currentAmount, requiredForTrip, targetQuantity));
        }

        // Check supplies
        Map<String, Integer> supplies = config.getSupplies();
        if (supplies != null) {
            Logger.log("--- Supplies ---");
            for (Map.Entry<String, Integer> entry : supplies.entrySet()) {
                String itemName = entry.getKey();
                int requiredForTrip = entry.getValue();
                int targetQuantity = requiredForTrip * multiplier;
                int currentAmount = Bank.count(itemName) + Inventory.count(itemName);
                
                Logger.log(String.format("%s: Have %d / Need %d per trip / Target %d total",
                    itemName, currentAmount, requiredForTrip, targetQuantity));
            }
        }

        // Check ammo
        Map<String, String> equipment = config.getEquipment();
        if (equipment.containsKey("ammo") && config.getAmmoQuantity() > 0) {
            String ammoType = equipment.get("ammo");
            if (ammoType != null && !ammoType.isEmpty()) {
                int currentAmmo = Bank.count(ammoType) + Inventory.count(ammoType);
                int requiredForTrip = config.getAmmoQuantity();
                int targetQuantity = requiredForTrip * multiplier;
                
                Logger.log("--- Ammo ---");
                Logger.log(String.format("%s: Have %d / Need %d per trip / Target %d total",
                    ammoType, currentAmmo, requiredForTrip, targetQuantity));
            }
        }

        // Check prayer potions
        int currentPrayers = Bank.count("Prayer potion(4)") + Inventory.count("Prayer potion(4)");
        Logger.log("--- Prayer Potions ---");
        Logger.log(String.format("Prayer potion(4): Have %d / Need 4 per trip / Target %d total",
            currentPrayers, 4 * multiplier));

        // Check teleport supplies
        TeleportType teleportType = config.getTeleportType();
        if (teleportType != TeleportType.NONE) {
            Logger.log("--- Teleport Supplies ---");
            switch (teleportType) {
                case TABLET:
                    int currentTeleports = Bank.count("Varrock teleport") + Inventory.count("Varrock teleport");
                    Logger.log(String.format("Varrock teleport: Have %d / Need 2 per trip / Target %d total",
                        currentTeleports, 2 * multiplier));
                    break;

                case SPELL:
                    int currentLaws = Bank.count("Law rune") + Inventory.count("Law rune");
                    int currentAir = Bank.count("Air rune") + Inventory.count("Air rune");
                    int currentFire = Bank.count("Fire rune") + Inventory.count("Fire rune");
                    
                    Logger.log(String.format("Law rune: Have %d / Need 10 per trip / Target %d total",
                        currentLaws, 10 * multiplier));
                    Logger.log(String.format("Air rune: Have %d / Need 30 per trip / Target %d total",
                        currentAir, 30 * multiplier));
                    Logger.log(String.format("Fire rune: Have %d / Need 30 per trip / Target %d total",
                        currentFire, 30 * multiplier));
                    break;
            }
        }
        Logger.log("=====================================");
    }

    private boolean needsResupply() {
        // Check food first
        List<String> foodNames = config.getFoodNames();
        if (!foodNames.isEmpty()) {
            String preferredFood = foodNames.get(0);
            int requiredForTrip = config.getTargetFoodCount();
            int currentAmount = Bank.count(preferredFood) + Inventory.count(preferredFood);
            
            if (currentAmount < requiredForTrip) {
                Logger.log("Food check failed: " + preferredFood + " (have " + currentAmount + ", need " + requiredForTrip + " for trip)");
                return true;
            }
        }

        // Check supplies
        Map<String, Integer> supplies = config.getSupplies();
        if (supplies != null) {
            for (Map.Entry<String, Integer> entry : supplies.entrySet()) {
                String itemName = entry.getKey();
                int requiredForTrip = entry.getValue();
                int currentAmount = Bank.count(itemName) + Inventory.count(itemName);
                
                if (currentAmount < requiredForTrip) {
                    Logger.log("Supply check failed: " + itemName + " (have " + currentAmount + ", need " + requiredForTrip + " for trip)");
                    return true;
                }
            }
        }

        // Check ammo
        Map<String, String> equipment = config.getEquipment();
        if (equipment.containsKey("ammo") && config.getAmmoQuantity() > 0) {
            String ammoType = equipment.get("ammo");
            if (ammoType != null && !ammoType.isEmpty()) {
                int currentAmmo = Bank.count(ammoType) + Inventory.count(ammoType);
                if (currentAmmo < config.getAmmoQuantity()) {
                    Logger.log("Ammo check failed: " + ammoType);
                    return true;
                }
            }
        }

        // Check prayer potions
        int currentPrayers = Bank.count("Prayer potion(4)") + Inventory.count("Prayer potion(4)");
        if (currentPrayers < 4) {
            Logger.log("Prayer potion check failed");
            return true;
        }

        // Check teleport supplies
        TeleportType teleportType = config.getTeleportType();
        if (teleportType != TeleportType.NONE) {
            switch (teleportType) {
                case TABLET:
                    int currentTeleports = Bank.count("Varrock teleport") + Inventory.count("Varrock teleport");
                    if (currentTeleports < 2) {
                        Logger.log("Teleport tablet check failed");
                        return true;
                    }
                    break;

                case SPELL:
                    int currentLaws = Bank.count("Law rune") + Inventory.count("Law rune");
                    int currentAir = Bank.count("Air rune") + Inventory.count("Air rune");
                    int currentFire = Bank.count("Fire rune") + Inventory.count("Fire rune");
                    
                    if (currentLaws < 10 || currentAir < 30 || currentFire < 30) {
                        Logger.log("Teleport runes check failed");
                        return true;
                    }
                    break;
            }
        }

        return false;
    }

    private void triggerGeNode() {
        config.setUseGrandExchange(true);
        context.tasks().getNodes().stream()
            .filter(node -> node instanceof ScurriusGENode)
            .map(node -> (ScurriusGENode) node)
            .forEach(node -> {
                node.reset();
                node.setForceExecute(true);
            });
    }

    private void triggerBankNode() {
        context.tasks().getNodes().stream()
            .filter(node -> node instanceof BankingNode)
            .map(node -> (BankingNode) node)
            .forEach(BankingNode::reset);
    }

    public void reset() {
        checkComplete = false;
    }
} 