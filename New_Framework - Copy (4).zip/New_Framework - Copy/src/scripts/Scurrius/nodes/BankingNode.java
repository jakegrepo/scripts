package scripts.Scurrius.nodes;

import core.base.SimpleNode;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.container.impl.equipment.EquipmentSlot;
import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.Item;
import scripts.Scurrius.ScurriusConfig;
import scripts.Scurrius.enums.TeleportType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BankingNode extends SimpleNode<ScurriusConfig> {
    private static final int DEFAULT_NATURE_RUNE_COUNT = 100;
    private static final int DEFAULT_FIRE_RUNE_COUNT = 500;
    private static final double HEALTH_RESTORE_THRESHOLD = 0.70; // Restore if below 70% health
    private static final double PRAYER_RESTORE_THRESHOLD = 0.30; // Restore if below 30% prayer
    private static final String PRAYER_POTION_NAME = "Prayer potion(4)";

    private enum BankingState {
        OPEN_BANK,
        DEPOSIT_ITEMS,
        CHECK_SUPPLIES,
        EQUIP_AND_WITHDRAW,
        FINISHED
    }

    private BankingState currentState = BankingState.OPEN_BANK;
    private boolean transitioning = false;

    public BankingNode(ScurriusConfig config) {
        super("Banking", 5, config);
    }

    @Override
    public boolean validate() {
        if (transitioning) {
            return false;  // Don't run banking node if we're transitioning to GE
        }

        if (!isReadyToExecute()) return false;

        // Don't validate if GE is open or has active offers
        if (GrandExchange.isOpen() && GrandExchange.getUsedSlots() > 0) {
            return false;
        }

        // Don't bank if in instance
        if (getCurrentFoodCount() == 0 && Inventory.isFull()) {
            return true;
        }
        if (config.isInInstance()) {
            return false;
        }
        // Check if we're critically low on supplies (no food or no essential supplies)
        boolean criticallyLowFood = getCurrentFoodCount() == 0;
        boolean criticallyLowSupplies = checkCriticalSupplies();

        // Check if we need to withdraw supplies for next trip
        boolean needsToWithdraw = checkNeedsWithdraw();


        return criticallyLowFood || criticallyLowSupplies || needsToWithdraw;
    }

    @Override
    protected int onExecute() {
        Logger.log("Current State: " + currentState);
        switch (currentState) {
            case OPEN_BANK:
                return handleOpenBank();

            case DEPOSIT_ITEMS:
                return handleDepositItems();

            case CHECK_SUPPLIES:
                // First check if we need health/prayer restore
                int restoreResult = handleHealthAndPrayerRestore();
                if (restoreResult >= 0) {
                    return restoreResult;
                }
                return handleCheckSupplies();

            case EQUIP_AND_WITHDRAW:
                return handleEquipAndWithdraw();

            case FINISHED:
                return handleFinished();

            default:
                return 600;
        }
    }

    private int handleOpenBank() {
        if (GrandExchange.isOpen()) {
            GrandExchange.close();
            Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 2000);
        }
        if (!Bank.isOpen()) {
            Logger.log("Attempting to open bank...");
            if (Bank.open()) {
                Sleep.sleep(1000);
            } else {
                Sleep.sleep(600);
                return 600;
            }
        }

        if (Bank.isOpen()) {
            Logger.log("Bank opened successfully, moving to deposit state");
            config.setInInstance(false);
            currentState = BankingState.DEPOSIT_ITEMS;
            return handleDepositItems(); // Immediately handle deposits
        }

        Logger.log("Failed to open bank, retrying...");
        return 600;
    }

    private int handleDepositItems() {
        if (!Bank.isOpen()) {
            currentState = BankingState.OPEN_BANK;
            return 600;
        }

        Logger.log("Depositing all items and equipment...");
        Bank.depositAllItems();
        Sleep.sleep(800);
        Bank.depositAllEquipment();
        Sleep.sleep(800);

        // Verify deposit was successful
        if (Inventory.isEmpty() && Equipment.isEmpty()) {
            Logger.log("Successfully deposited all items and equipment");
            currentState = BankingState.CHECK_SUPPLIES;
            return handleCheckSupplies(); // Immediately proceed to check supplies
        } else {
            Logger.log("Failed to deposit all items, retrying...");
            return 600;
        }
    }

    private int handleCheckSupplies() {
        if (!Bank.isOpen()) return handleOpenBank();

        // Check if we have enough supplies for another trip
        boolean needsResupply = checkNeedsGeResupply();
        if (needsResupply) {
            Logger.log("Insufficient supplies for another trip - triggering GE resupply");
            // Find and reset the GE node
            context.tasks().getNodes().stream()
                .filter(node -> node instanceof ScurriusGENode)
                .map(node -> (ScurriusGENode) node)
                .forEach(node -> {
                    node.reset();
                    node.setForceExecute(true);
                    config.setUseGrandExchange(true);  // Enable GE usage
                });
            
            // Set transitioning flag and close bank
            transitioning = true;
            Bank.close();
            return 600;
        }

        currentState = BankingState.EQUIP_AND_WITHDRAW;
        return 600;
    }

    private boolean checkCriticalSupplies() {
        // Check if we're completely out of any crucial supplies in both inventory AND bank
        Map<String, Integer> supplies = config.getSupplies();
        for (Map.Entry<String, Integer> entry : supplies.entrySet()) {
            int totalCount = Inventory.count(entry.getKey()) + Bank.count(entry.getKey());
            if (totalCount == 0) {
                Logger.log("Critically low on " + entry.getKey() + " (none in inventory or bank)");
                return true;
            }
        }

        // Check teleport supplies as critical
        TeleportType teleportType = config.getTeleportType();
        if (teleportType != TeleportType.NONE) {
            switch (teleportType) {
                case TABLET:
                    int totalTablets = Inventory.count("Varrock teleport") + Bank.count("Varrock teleport");
                    if (totalTablets == 0) {
                        return true;
                    }
                    break;
                case SPELL:
                    int totalLaw = Inventory.count("Law rune") + Bank.count("Law rune");
                    int totalAir = Inventory.count("Air rune") + Bank.count("Air rune");
                    int totalFire = Inventory.count("Fire rune") + Bank.count("Fire rune");
                    if (totalLaw == 0 || totalAir == 0 || totalFire == 0) {
                        Logger.log("Missing teleport runes - Law: " + totalLaw + ", Air: " + totalAir + ", Fire: " + totalFire);
                        return true;
                    }
                    break;
            }
        }

        // Check ammo as critical supply
        Map<String, String> equipment = config.getEquipment();
        if (equipment.containsKey("ammo")) {
            String ammoType = equipment.get("ammo");
            int requiredAmmo = config.getAmmoQuantity();
            if (requiredAmmo > 0) {
                int totalAmmo = Bank.count(ammoType) + Inventory.count(ammoType) + Equipment.count(ammoType);
                if (totalAmmo == 0) {
                    Logger.log("Critically low on " + ammoType + " (none in inventory, bank, or equipment)");
                    return true;
                }
            }
        }

        return false;
    }

    private boolean hasEssentialTeleportSupplies() {
        TeleportType teleportType = config.getTeleportType();
        if (teleportType == TeleportType.NONE) {
            return true; // No teleport supplies needed
        }

        switch (teleportType) {
            case TABLET:
                if (!Inventory.contains("Varrock teleport")) {
                    Logger.log("Missing essential Varrock teleport tablet");
                    return false;
                }
                break;
            case SPELL:
                if (!Inventory.contains("Law rune") ||
                    !Inventory.contains("Air rune") ||
                    !Inventory.contains("Fire rune")) {
                    Logger.log("Missing essential teleport runes");
                    return false;
                }
                break;
        }
        return true;
    }

    private boolean checkNeedsGeResupply() {
        if (!config.isUsingGrandExchange()) {
            return false;
        }

        // Don't trigger resupply if GE is active
        if (GrandExchange.isOpen()) {
            Logger.log("GE is open, waiting for it to complete");
            return false;
        }

        // Check food first
        List<String> foodNames = config.getFoodNames();
        if (!foodNames.isEmpty()) {
            String preferredFood = foodNames.get(0);
            int requiredForTrip = config.getTargetFoodCount();
            int currentAmount = Bank.count(preferredFood) + Inventory.count(preferredFood);
            
            if (currentAmount < requiredForTrip) {
                Logger.log("Food check failed: " + preferredFood + " (have " + currentAmount + ", need " + requiredForTrip + " for trip)");
                return true;
            }
        }

        // Check all supplies against their target quantities
        Map<String, Integer> supplies = config.getSupplies();
        if (supplies != null) {
            for (Map.Entry<String, Integer> entry : supplies.entrySet()) {
                String itemName = entry.getKey();
                int requiredForOneTrip = entry.getValue();
                int currentAmount = Bank.count(itemName) + Inventory.count(itemName);
                
                if (currentAmount < requiredForOneTrip) {
                    Logger.log("Supply check failed: " + itemName + " (have " + currentAmount + ", need " + requiredForOneTrip + " for one trip)");
                    return true;
                }
            }
        }

        // Check teleport supplies
        TeleportType teleportType = config.getTeleportType();
        if (teleportType != TeleportType.NONE) {
            switch (teleportType) {
                case TABLET:
                    if (Bank.count("Varrock teleport") + Inventory.count("Varrock teleport") < 2) {
                        Logger.log("Teleport tablet check failed: need at least 2 Varrock teleports");
                        return true;
                    }
                    break;
                case SPELL:
                    if (Bank.count("Law rune") + Inventory.count("Law rune") < 10 ||
                        Bank.count("Air rune") + Inventory.count("Air rune") < 30 ||
                        Bank.count("Fire rune") + Inventory.count("Fire rune") < 30) {
                        Logger.log("Teleport runes check failed: insufficient runes for teleporting");
                        return true;
                    }
                    break;
            }
        }

        return false;
    }

    private int handleEquipAndWithdraw() {
        Logger.log("Equipping gear and withdrawing supplies...");
        if (!Bank.isOpen()) {
            if (Bank.open()) {
                Sleep.sleep(1000);
            } else {
                return 600;
            }
        }

        // Handle ammo specifically first
        Map<String, String> equipment = config.getEquipment();
        if (equipment.containsKey("ammo")) {
            String ammoType = equipment.get("ammo");
            int requiredAmmo = config.getAmmoQuantity();
            
            if (requiredAmmo > 0) {
                int currentAmmo = Bank.count(ammoType) + Inventory.count(ammoType) + Equipment.count(ammoType);
                
                if (currentAmmo < requiredAmmo) {
                    Logger.log("Insufficient ammo. Have: " + currentAmmo + ", Need: " + requiredAmmo);
                    handleMissingItems();
                    return 600;
                }
                
                // Calculate how much more ammo we need
                int equippedAmmo = Equipment.count(ammoType);
                int neededAmmo = requiredAmmo - equippedAmmo;
                
                if (neededAmmo > 0) {
                    Logger.log("Withdrawing " + neededAmmo + " " + ammoType);
                    if (Bank.contains(ammoType)) {
                        Bank.withdraw(ammoType, neededAmmo);
                        Sleep.sleepUntil(() -> Inventory.contains(ammoType), 2000);
                        
                        // Use the same equipping method as other gear
                        Item gearItem = Inventory.get(ammoType);
                        if (gearItem != null) {
                            if (gearItem.hasAction("Wear")) gearItem.interact("Wear");
                            else if (gearItem.hasAction("Wield")) gearItem.interact("Wield");
                            else if (gearItem.hasAction("Equip")) gearItem.interact("Equip");
                            Sleep.sleep(800);
                        }
                    } else {
                        Logger.log("Bank does not contain required ammo!");
                        handleMissingItems();
                        return 600;
                    }
                }
            }
        }

        // Equip gear first
        for (Map.Entry<String, String> entry : config.getEquipment().entrySet()) {
            String slot = entry.getKey();
            String itemName = entry.getValue();
            if (itemName.isEmpty() || "None".equals(itemName) ||
                (Equipment.contains(itemName) && !slot.equals("ammo"))) {
                continue;
            }

            // Special handling for ammo
            if (slot.equals("ammo")) {
                int targetQuantity = config.getAmmoQuantity();
                if (targetQuantity > 0) {
                    // Check if we need more ammo
                    Item equippedAmmo = Equipment.getItemInSlot(EquipmentSlot.ARROWS);
                    int currentAmmo = equippedAmmo != null && equippedAmmo.getName().equals(itemName) ?
                                    equippedAmmo.getAmount() : 0;

                    if (currentAmmo < targetQuantity) {
                        int neededAmmo = targetQuantity - currentAmmo;

                        // Withdraw needed amount if available
                        if (Bank.contains(itemName)) {
                            Logger.log("Withdrawing ammo: " + itemName + " x" + neededAmmo);
                            Bank.withdraw(itemName, neededAmmo);
                            Sleep.sleep(800);
                        }
                    }
                }
            } else {
                // Handle regular equipment
                if (!Inventory.contains(itemName) && Bank.contains(itemName)) {
                    Logger.log("Withdrawing gear: " + itemName);
                    Bank.withdraw(itemName, 1);
                    Sleep.sleep(800);
                }
            }

            Item gearItem = Inventory.get(itemName);
            if (gearItem != null) {
                if (gearItem.hasAction("Wear")) gearItem.interact("Wear");
                else if (gearItem.hasAction("Wield")) gearItem.interact("Wield");
                else if (gearItem.hasAction("Equip")) gearItem.interact("Equip");
                Sleep.sleep(800);
            }
        }

        // Modify the healing section to have a clear exit condition
        if (!config.getFoodNames().isEmpty()) {
            String foodName = config.getFoodNames().get(0);
            int currentHP = Skills.getBoostedLevel(Skill.HITPOINTS);
            int maxHP = Skills.getRealLevel(Skill.HITPOINTS);
            int currentPrayer = Skills.getBoostedLevel(Skill.PRAYER);
            int maxPrayer = Skills.getRealLevel(Skill.PRAYER);

            // Add maximum attempts to prevent infinite loop
            int attempts = 0;
            int maxAttempts = 5;

            // Handle healing
            while (currentHP < maxHP && Bank.contains(foodName) && attempts < maxAttempts) {
                if (!Inventory.contains(foodName)) {
                    Logger.log("Withdrawing food to heal: " + foodName);
                    Bank.withdraw(foodName, 1);
                    Sleep.sleep(600);
                }

                Item food = Inventory.get(foodName);
                if (food != null && food.interact("Eat")) {
                    Sleep.sleep(600);
                    currentHP = Skills.getBoostedLevel(Skill.HITPOINTS);
                    attempts++;
                }
            }

            // Reset attempts for prayer restoration
            attempts = 0;

            // Handle prayer restoration
            while (currentPrayer < maxPrayer && attempts < maxAttempts) {
                // Try each prayer potion dose
                boolean foundPotion = false;
                for (int dose = 4; dose >= 1; dose--) {
                    String potionName = "Prayer potion(" + dose + ")";
                    if (Bank.contains(potionName)) {
                        if (!Inventory.contains(potionName)) {
                            Logger.log("Withdrawing " + potionName + " to restore prayer");
                            Bank.withdraw(potionName, 1);
                            Sleep.sleep(600);
                        }

                        Item potion = Inventory.get(potionName);
                        if (potion != null && potion.interact("Drink")) {
                            Sleep.sleep(600);
                            currentPrayer = Skills.getBoostedLevel(Skill.PRAYER);
                            attempts++;
                            foundPotion = true;

                            // Deposit empty vial or remaining doses
                            Sleep.sleep(600);
                            if (Inventory.contains("Vial")) {
                                Logger.log("Depositing empty vial");
                                Bank.deposit("Vial", 1);
                                Sleep.sleep(600);
                            }
                            // Check for and deposit any remaining prayer potion doses
                            for (int remainingDose = 1; remainingDose <= 4; remainingDose++) {
                                String remainingPotionName = "Prayer potion(" + remainingDose + ")";
                                if (Inventory.contains(remainingPotionName)) {
                                    Logger.log("Depositing remaining " + remainingPotionName);
                                    Bank.deposit(remainingPotionName, 1);
                                    Sleep.sleep(600);
                                }
                            }
                            break;  // Break the dose loop if we successfully drank a potion
                        }
                    }
                }

                // If no potions found and GE is enabled, trigger resupply
                if (!foundPotion && config.isUsingGrandExchange()) {
                    Logger.log("No prayer potions in bank - triggering GE resupply");
                    context.tasks().getNodes().stream()
                        .filter(node -> node instanceof ScurriusGENode)
                        .map(node -> (ScurriusGENode) node)
                        .forEach(node -> {
                            node.addItem("Prayer potion(4)", 4);
                            node.reset();
                            node.setForceExecute(true);
                        });
                    break;  // Exit the while loop
                } else if (!foundPotion) {
                    break;  // Exit if no potions found and GE not enabled
                }
            }

            // Final check for any remaining potions or vials
            if (Inventory.contains("Vial")) {
                Logger.log("Final deposit of empty vial");
                Bank.deposit("Vial", 1);
                Sleep.sleep(600);
            }
            for (int dose = 1; dose <= 4; dose++) {
                String potionName = "Prayer potion(" + dose + ")";
                if (Inventory.contains(potionName)) {
                    Logger.log("Final deposit of " + potionName);
                    Bank.deposit(potionName, 1);
                    Sleep.sleep(600);
                }
            }
        }

        Map<String, Integer> supplies = new HashMap<>(config.getSupplies());

        // Add teleport supplies if needed - MOVED THIS SECTION EARLIER
        TeleportType teleportType = config.getTeleportType();
        Logger.log("Handling teleport supplies withdrawal - Type: " + teleportType);
        if (teleportType != TeleportType.NONE) {
            switch (teleportType) {
                case TABLET:
                    Logger.log("Checking Varrock teleport tablets...");
                    int currentTablets = Inventory.count("Varrock teleport");
                    int bankTablets = Bank.count("Varrock teleport");
                    Logger.log("Current tablets in inventory: " + currentTablets + ", in bank: " + bankTablets);
                    if (currentTablets < 5) {
                        Logger.log("Attempting to withdraw Varrock teleport tablets");
                        if (Bank.contains("Varrock teleport")) {
                            Bank.withdraw("Varrock teleport", 5 - currentTablets);
                            Sleep.sleepUntil(() -> Inventory.count("Varrock teleport") >= 5, 1200);
                            currentTablets = Inventory.count("Varrock teleport");
                            Logger.log("After withdrawal: " + currentTablets + " tablets in inventory");
                        }
                    }
                    break;
                case SPELL:
                    Logger.log("Checking teleport runes...");
                    int currentLaw = Inventory.count("Law rune");
                    int currentAir = Inventory.count("Air rune");
                    int currentFire = Inventory.count("Fire rune");
                    if (currentLaw < 10) {
                        Bank.withdraw("Law rune", 10 - currentLaw);
                        Sleep.sleep(600);
                    }
                    if (currentAir < 30) {
                        Bank.withdraw("Air rune", 30 - currentAir);
                        Sleep.sleep(600);
                    }
                    if (currentFire < 30) {
                        Bank.withdraw("Fire rune", 30 - currentFire);
                        Sleep.sleep(600);
                    }
                    break;
            }
        }

        // Add alchemy runes if enabled
        if (config.isAlchemyEnabled()) {
            Logger.log("Adding alchemy runes to supplies");
            int currentNature = Inventory.count("Nature rune");
            int currentFire = Inventory.count("Fire rune");
            if (currentNature < DEFAULT_NATURE_RUNE_COUNT) {
                supplies.put("Nature rune", DEFAULT_NATURE_RUNE_COUNT);
            }
            if (currentFire < DEFAULT_FIRE_RUNE_COUNT) {
                supplies.put("Fire rune", Math.max(supplies.getOrDefault("Fire rune", 0), DEFAULT_FIRE_RUNE_COUNT));
            }
        }

        // Continue with normal supply withdrawals
        if (!supplies.isEmpty()) {
            for (Map.Entry<String, Integer> entry : supplies.entrySet()) {
                String itemName = entry.getKey();
                int requiredAmount = entry.getValue();

                if (itemName == null || itemName.isEmpty()) {
                    continue;
                }

                int currentAmount = Inventory.count(itemName);
                if (currentAmount < requiredAmount) {
                    int amountToWithdraw = requiredAmount - currentAmount;
                    Logger.log(String.format("Withdrawing %d of %s", amountToWithdraw, itemName));

                    if (Bank.contains(itemName)) {
                        Bank.withdraw(itemName, amountToWithdraw);
                        Sleep.sleep(600);
                    } else {
                        Logger.log(String.format("Bank does not contain %s!", itemName));
                    }
                }
            }
        }

        // Withdraw food last to fill remaining inventory spaces
        if (!config.getFoodNames().isEmpty()) {
            String foodName = config.getFoodNames().get(0);
            int currentFoodCount = Inventory.count(foodName);
            int targetCount = config.getTargetFoodCount();

            if (currentFoodCount < targetCount && Bank.contains(foodName)) {
                Logger.log(String.format("Withdrawing %d more %s", targetCount - currentFoodCount, foodName));
                Bank.withdraw(foodName, targetCount - currentFoodCount);
                Sleep.sleep(600);
            }
        }

        // Modified verification section
        boolean hasEssentialItems = true;

        // Verify teleport supplies first
        if (teleportType != TeleportType.NONE) {
            switch (teleportType) {
                case TABLET:
                    int tabletCount = Inventory.count("Varrock teleport");
                    if (tabletCount < 5) {
                        Logger.log("Missing required Varrock teleport tablets. Have: " + tabletCount + ", Need: 5");
                        hasEssentialItems = false;
                    }
                    break;
                case SPELL:
                    if (Inventory.count("Law rune") < 10 ||
                        Inventory.count("Air rune") < 30 ||
                        Inventory.count("Fire rune") < 30) {
                        Logger.log("Missing required teleport runes");
                        hasEssentialItems = false;
                    }
                    break;
            }
        }

        // Check food
        if (!config.getFoodNames().isEmpty()) {
            String foodName = config.getFoodNames().get(0);
            hasEssentialItems &= Inventory.count(foodName) >= Math.max(1, config.getTargetFoodCount() / 2);
        }

        // Check if we have all essential items
        if (hasEssentialItems) {
            Logger.log("All essential items obtained, proc" +
                    "eeding to finish banking");
            currentState = BankingState.FINISHED;
            // Call handleFinished immediately to close the bank
            return handleFinished();
        }

        Logger.log("Missing essential items (including teleport supplies), retrying withdrawals...");
        return 600;
    }

    private int handleFinished() {
        Logger.log("Banking finished, closing bank...");
        if (Bank.isOpen()) {
            Bank.close();
            Sleep.sleep(1000);
        }
        // Reset state for next banking session
        currentState = BankingState.OPEN_BANK;
        return 0;
    }

    private int getCurrentFoodCount() {
        if (config.getFoodNames().isEmpty()) {
            return 0;
        }
        String food = config.getFoodNames().get(0);
        // Include both inventory and bank
        return Inventory.count(food) + Bank.count(food);
    }

    private boolean checkSupplies() {
        // Check if we're missing any crucial supplies
        Map<String, Integer> supplies = config.getSupplies();
        for (Map.Entry<String, Integer> entry : supplies.entrySet()) {
            if (Inventory.count(entry.getKey()) < entry.getValue() / 2) {
                return true;
            }
        }
        return false;
    }

    protected void onScriptStop() {
        transitioning = false;  // Reset the transitioning flag when script stops
    }

    // Add method to reset the transitioning flag
    public void resetTransitioning() {
        transitioning = false;
    }

    public void reset() {
        transitioning = false;
        currentState = BankingState.OPEN_BANK;
        Logger.log("Banking node reset");
    }

    private boolean checkNeedsWithdraw() {
        // Check if inventory is empty or missing required items
        if (Inventory.isEmpty()) {
            return true;
        }

        // Check if we have enough food in inventory
        if (!config.getFoodNames().isEmpty()) {
            String foodName = config.getFoodNames().get(0);
            if (Inventory.count(foodName) < config.getTargetFoodCount()) {
                return true;
            }
        }

        // Check if we have all required supplies in inventory
        Map<String, Integer> supplies = config.getSupplies();
        for (Map.Entry<String, Integer> entry : supplies.entrySet()) {
            String itemName = entry.getKey();
            int requiredAmount = entry.getValue();
            if (Inventory.count(itemName) < requiredAmount) {
                return true;
            }
        }

        // Check if we have all required equipment
        for (Map.Entry<String, String> entry : config.getEquipment().entrySet()) {
            String itemName = entry.getValue();
            if (itemName != null && !itemName.isEmpty() && !itemName.equals("None") &&
                !Equipment.contains(itemName) && !Inventory.contains(itemName)) {
                return true;
            }
        }

        // Check if we need to withdraw ammo
        Map<String, String> equipment = config.getEquipment();
        if (equipment.containsKey("ammo")) {
            String ammoType = equipment.get("ammo");
            int requiredAmmo = config.getAmmoQuantity();
            if (requiredAmmo > 0) {
                int totalAmmo = Inventory.count(ammoType) + Equipment.count(ammoType);
                if (totalAmmo < requiredAmmo) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean checkNeedsHealthOrPrayerRestore() {
        double healthPercent = (double) Skills.getBoostedLevel(Skill.HITPOINTS) / Skills.getRealLevel(Skill.HITPOINTS);
        double prayerPercent = (double) Skills.getBoostedLevel(Skill.PRAYER) / Skills.getRealLevel(Skill.PRAYER);

        return healthPercent < HEALTH_RESTORE_THRESHOLD || prayerPercent < PRAYER_RESTORE_THRESHOLD;
    }

    private int handleHealthAndPrayerRestore() {
        if (!Bank.isOpen()) {
            return handleOpenBank();
        }

        double healthPercent = (double) Skills.getBoostedLevel(Skill.HITPOINTS) / Skills.getRealLevel(Skill.HITPOINTS);
        double prayerPercent = (double) Skills.getBoostedLevel(Skill.PRAYER) / Skills.getRealLevel(Skill.PRAYER);

        // Handle health restoration
        if (healthPercent < HEALTH_RESTORE_THRESHOLD) {
            String foodName = config.getFoodNames().get(0);
            if (Bank.contains(foodName)) {
                if (!Inventory.contains(foodName)) {
                    Bank.withdraw(foodName, 1);
                    Sleep.sleepUntil(() -> Inventory.contains(foodName), 1200);
                    return 600;
                }
                Inventory.interact(foodName, "Eat");
                return 600;
            }
        }

        // Handle prayer restoration
        if (prayerPercent <= 0.25) { // Changed threshold to 25%
            // Try to find any prayer potion dose in bank
            for (int dose = 4; dose >= 1; dose--) {
                String potionName = "Prayer potion(" + dose + ")";
                if (Bank.contains(potionName)) {
                    if (!Inventory.contains(potionName)) {
                        Bank.withdraw(potionName, 1);
                        Sleep.sleepUntil(() -> Inventory.contains(potionName), 1200);
                        return 600;
                    }
                    Inventory.interact(potionName, "Drink");
                    Sleep.sleep(600);
                    return 600;
                }
            }

            // If no prayer potions found and GE is enabled, trigger resupply
            if (config.isUsingGrandExchange()) {
                Logger.log("No prayer potions in bank - triggering GE resupply");
                context.tasks().getNodes().stream()
                    .filter(node -> node instanceof ScurriusGENode)
                    .map(node -> (ScurriusGENode) node)
                    .forEach(node -> {
                        node.addItem("Prayer potion(4)", 4); // Buy 4 prayer potions
                        node.reset();
                        node.setForceExecute(true);
                    });

                transitioning = true;
                Bank.close();
                currentState = BankingState.FINISHED;
                return 0;
            }
        }

        return -1; // Return -1 if no restoration needed
    }

    private void handleMissingItems() {
        if (Bank.isOpen()) {
            Bank.close();
            Sleep.sleepUntil(() -> !Bank.isOpen(), 2000);
        }

        config.setUseGrandExchange(true);
        
        // Get the GE node and prepare the purchase list
        context.tasks().getNodes().stream()
            .filter(node -> node instanceof ScurriusGENode)
            .map(node -> (ScurriusGENode) node)
            .findFirst()
            .ifPresent(geNode -> {
                // Add teleport supplies if needed
                TeleportType teleportType = config.getTeleportType();
                int multiplier = config.getSuppliesMultiplier();
                
                if (teleportType != TeleportType.NONE) {
                    switch (teleportType) {
                        case TABLET:
                            int totalTablets = Bank.count("Varrock teleport") + Inventory.count("Varrock teleport");
                            if (totalTablets < 5) {
                                int amountNeeded = (5 * multiplier) - totalTablets;
                                Logger.log("Adding " + amountNeeded + " Varrock teleport tablets to GE buy list");
                                geNode.addItem("Varrock teleport", amountNeeded);
                            }
                            break;

                        case SPELL:
                            int totalLaw = Bank.count("Law rune") + Inventory.count("Law rune");
                            int totalAir = Bank.count("Air rune") + Inventory.count("Air rune");
                            int totalFire = Bank.count("Fire rune") + Inventory.count("Fire rune");

                            if (totalLaw < 10) {
                                int lawNeeded = (10 * multiplier) - totalLaw;
                                geNode.addItem("Law rune", lawNeeded);
                            }
                            if (totalAir < 30) {
                                int airNeeded = (30 * multiplier) - totalAir;
                                geNode.addItem("Air rune", airNeeded);
                            }
                            if (totalFire < 30) {
                                int fireNeeded = (30 * multiplier) - totalFire;
                                geNode.addItem("Fire rune", fireNeeded);
                            }
                            break;
                    }
                }

                geNode.setForceExecute(true);
                geNode.reset();
            });

        reset();
    }
}
