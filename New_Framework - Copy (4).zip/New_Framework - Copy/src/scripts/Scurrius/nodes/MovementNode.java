package scripts.Scurrius.nodes;

import core.base.SimpleNode;
import core.paint.debug.DebugOverlay;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import scripts.Scurrius.ScurriusConfig;

import java.util.Optional;
import java.util.Set;

public class MovementNode extends SimpleNode<ScurriusConfig> implements Runnable {
    private final DebugOverlay debugOverlay;
    private volatile boolean stopRequested = false;

    // How long from graphic spawn until impact (ms).
    // This should be determined empirically or known from game mechanics.
    private static final long FALLING_ROCKS_TIME_TO_IMPACT = 3000;

    // Flags or states set by CombatNode or main script to indicate movement needed
    private volatile boolean needToFlee;
    private volatile boolean needToLeaveInstance;

    public MovementNode(ScurriusConfig config, DebugOverlay debugOverlay) {
        super("Movement", 1, config);
        this.debugOverlay = debugOverlay;
    }

    @Override
    public boolean validate() {
        // Since this node runs on its own thread,
        // we may not rely on DreamBot's node system for `validate`.
        // If you keep it in the same model, you can return false here
        // and let run() handle everything. Or keep it single-threaded and rely on validate().
        return false;
    }

    @Override
    protected int onExecute() {
        // Not used if we run in a separate thread.
        return 0;
    }

    @Override
    public void run() {
        while (!stopRequested) {
            try {
                // Check if player is in a dangerous situation periodically
                handleMovementLogic();
                Thread.sleep(100); // Adjust frequency as needed
            } catch (Exception e) {
                Logger.log("MovementNode error: " + e.getMessage());
            }
        }
    }

    private void handleMovementLogic() {
        // Update debugOverlay data
        debugOverlay.updateAllTiles();
        debugOverlay.updateScurriusHighlight();
        debugOverlay.updateGraphicsHighlights();

        Tile playerTile = Players.getLocal().getTile();
        if (playerTile == null) return;

        // Check if current tile or upcoming tile is dangerous
        if (isCurrentOrFutureDanger(playerTile)) {
            moveToSafeTile();
        }

        // If combat node requests leaving the instance
        if (needToLeaveInstance) {
            // Move player out of instance
            // Use a known safe tile or exit tile from your config or script
            Tile exitTile = NavigationNode.ENTRANCE_TILE;
            Walking.walk(exitTile);
            // Once done, reset the flag
            needToLeaveInstance = false;
        }

        // If we need to flee to a safe tile due to low health, etc.
        if (needToFlee) {
            moveToSafeTile();
            // Once safe, reset the flag
            needToFlee = false;
        }
    }

    private boolean isCurrentOrFutureDanger(Tile tile) {
        // Check if tile is currently dangerous
        if (debugOverlay.isDangerTile(tile)) {
            return true;
        }

        // Check if a rock is going to land soon on this tile
        // For each graphics object with the falling rocks ID:
        //   If it matches the player's tile, estimate time to impact using debugOverlay.
        //   If within a certain threshold, consider it dangerous.
        // Example:
        long timeToImpact = debugOverlay.getTimeToImpactForTile(tile, FALLING_ROCKS_TIME_TO_IMPACT);
        return timeToImpact <= 1000; // If less than 1 second to impact, consider dangerous
    }

    private void moveToSafeTile() {
        Set<Tile> borderTiles = debugOverlay.getBorderTiles();
        Set<Tile> dangerTiles = debugOverlay.getDangerTiles();
        Tile playerTile = Players.getLocal().getTile();

        Optional<Tile> safeBorderTile = borderTiles.stream()
                .filter(tile -> !dangerTiles.contains(tile))
                .filter(tile -> !tile.equals(playerTile))
                .filter(tile -> Players.getLocal().canReach(tile))
                .min((t1, t2) -> Double.compare(t1.distance(playerTile), t2.distance(playerTile)));

        safeBorderTile.ifPresent(Walking::walk);
    }

    public void requestFlee() {
        needToFlee = true;
    }

    public void requestLeaveInstance() {
        needToLeaveInstance = true;
    }

    public void stopNode() {
        stopRequested = true;
    }
}

