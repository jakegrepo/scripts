package scripts.Scurrius.nodes;

import core.base.SimpleNode;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.item.GroundItems;
import org.dreambot.api.methods.magic.Magic;
import org.dreambot.api.methods.magic.Normal;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.GroundItem;
import org.dreambot.api.wrappers.items.Item;
import scripts.Scurrius.ScurriusConfig;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class LootingNode extends SimpleNode<ScurriusConfig> {
    private static final Set<String> LOOT_ITEMS = new HashSet<>(Arrays.asList(
            "Scroll box (medium)","Ranarr weed","Kwuarm","Snapdragon","Harralander","Irit leaf","Cadantine","Amulet of fury","Abyssal whip","Dark bow","Rune chainbody","Mage's book","Berserker ring","Master wand","Archers ring","Seers ring","Dragon battleaxe","Wrath rune","Nature rune","Soul rune","Blood rune","Death rune","Chaos rune","Rune platelegs","Rune full helm","Rune plateskirt","Rune med helm","Mystic robe bottom","Adamant platebody", "Scurrius' spine",
            "Accumulation charm", "Stockpile charm", "Vulnerability charm", "Nimbleness charm","Rune battleaxe","Rune sq shield","Rune arrows","Rune scimitar","Dragon battleaxe"
    ));

    private static final Set<String> ALCHABLE_ITEMS = new HashSet<>(Arrays.asList(
            "Adamant platebody", "Rune med helm", "Rune full helm", "Rune sq shield",
            "Rune chainbody", "Rune battleaxe","Dragon battleaxe","Rune platelegs","Rune plateskirt","Mystic robe bottom","Rune plateskirt","Rune scimitar"
    ));

    private static final Set<String> FOOD_ITEMS = new HashSet<>(Arrays.asList(
            "Tuna", "Lobster", "Shark","Cooked karambwan"
    ));

    private String currentLootingItem = null;
    private long lootingStartTime = 0;
    private static final long LOOTING_TIMEOUT = 5000; // 5 seconds timeout

    public LootingNode(ScurriusConfig config) {
        super("Looting", 2, config);
    }

    @Override
    public boolean validate() {
        if (!isReadyToExecute()) return false;

        // Check if we're in the instance
        if (!Client.isDynamicRegion()) {
            log("Not in dynamic region");
            return false;
        }


        // Don't loot if there are giant rats or if Scurrius is present
        if (NPCs.closest("Scurrius") != null) {
            return false;
        }

        try {
            // Reset stale looting state
            if (currentLootingItem != null) {
                long timeSpentLooting = System.currentTimeMillis() - lootingStartTime;
                if (timeSpentLooting > LOOTING_TIMEOUT) {
                    log("Resetting stale looting state for: " + currentLootingItem);
                    currentLootingItem = null;
                    lootingStartTime = 0;
                }
            }



            // If inventory is full but there's a spine, we should still validate
            // Update: Allow validation if *any* important loot is present when inventory is full
            GroundItem[] importantLoot = GroundItems.all(item -> {
                try {
                    return item != null &&
                           item.getName() != null &&
                           (LOOT_ITEMS.contains(item.getName()) || item.getName().equals("Scurrius' spine")) && // Check against LOOT_ITEMS or spine
                           item.exists() &&
                           item.canReach() &&
                           item.distance() <= 10;
                } catch (Exception e) {
                    log("Error checking important loot item in validate: " + e.getMessage());
                    return false;
                }
            }).toArray(new GroundItem[0]);

            boolean hasImportantGroundLoot = importantLoot != null && importantLoot.length > 0;

            if (Inventory.isFull() && !hasImportantGroundLoot) { // Check against any important loot now
                 log("Inventory full and no important ground loot found.");
                return false;
            }

            // Check for lootable items on ground with additional verification
            GroundItem[] lootItems = GroundItems.all(item -> {
                try {
                    return item != null &&
                            item.getName() != null &&
                            LOOT_ITEMS.contains(item.getName()) &&
                            item.exists() &&
                            item.canReach() &&
                            item.distance() <= 10;
                } catch (Exception e) {
                    log("Error checking loot item: " + e.getMessage());
                    return false;
                }
            }).toArray(new GroundItem[0]);

            boolean hasGroundLoot = lootItems != null && lootItems.length > 0;

            // Check for alchable items in inventory if alchemy is enabled
            boolean hasAlchables = config.isAlchemyEnabled() &&
                    Inventory.contains(item -> {
                        try {
                            return item != null &&
                                    item.getName() != null &&
                                    ALCHABLE_ITEMS.contains(item.getName());
                        } catch (Exception e) {
                            log("Error checking alchable item: " + e.getMessage());
                            return false;
                        }
                    });

            // If we're not currently looting anything and there's nothing to do, return false
            if (currentLootingItem == null && !hasGroundLoot && !hasAlchables) {
                return false;
            }

            return true;

        } catch (Exception e) {
            log("Error in validate(): " + e.getMessage());
            return false;
        }
    }
    private boolean tryEatFoodForSpace() {
        for (String foodName : FOOD_ITEMS) {
            Item food = Inventory.get(foodName);
            if (food != null && food.hasAction("Eat")) {
                status("Eating " + food.getName() + " to make space");
                int initialCount = Inventory.count(food.getName());
                if (food.interact("Eat")) {
                    return Sleep.sleepUntil(() -> Inventory.count(food.getName()) < initialCount, 1200);
                }
                // If interaction fails for some reason, try the next food type
            }
        }
        // No food from the specified list was found or eaten
        log("No edible food from FOOD_ITEMS found to make space.");
        return false;
    }
    @Override
    protected int onExecute() {
        try {
            // Reset status if we're not actively looting
            if (currentLootingItem == null) {
                status("Looking for loot");
            }

            // Handle ground items with error handling
            GroundItem[] lootItems = GroundItems.all(item -> {
                try {
                    return item != null &&
                            item.getName() != null &&
                            (item.getName().contains("charm") || LOOT_ITEMS.contains(item.getName())) &&
                            item.exists() &&
                            item.canReach();
                } catch (Exception e) {
                    log("Error filtering loot items: " + e.getMessage());
                    return false;
                }
            }).toArray(new GroundItem[0]);

            if (lootItems != null) {
                for (GroundItem loot : lootItems) {
                    try {
                        if (loot == null || !loot.exists() || !loot.canReach()) {
                            continue;
                        }

                        String itemName = loot.getName();
                        if (itemName == null) continue;

                        // If inventory is full, eat food to make space
                        if (Inventory.isFull()) {
                            status("Eating food to make space for " + itemName);
                            if (!tryEatFoodForSpace()) {
                                continue;
                            }
                        }

                        int initialCount = Inventory.count(itemName);
                        if (loot.interact("Take")) {
                            currentLootingItem = itemName;
                            lootingStartTime = System.currentTimeMillis();
                            status("Looting " + itemName);
                            boolean looted = sleepUntil(() -> {
                                try {
                                    return !loot.exists() ||
                                            !loot.canReach() ||
                                            loot.distance() > 10 ||
                                            Inventory.count(itemName) > initialCount;
                                } catch (Exception e) {
                                    log("Error in loot sleepUntil: " + e.getMessage());
                                    return true;
                                }
                            }, 3000);

                            if (!looted) {
                                log("Failed to loot " + itemName + ", skipping...");
                                currentLootingItem = null;
                                continue;
                            }

                            // Reset looting state after successful loot
                            currentLootingItem = null;
                            lootingStartTime = 0;
                        }
                    } catch (Exception e) {
                        log("Error processing loot item: " + e.getMessage());
                    }
                }
            }

            // Handle Alchemy if enabled and possible
            if (config.isAlchemyEnabled() && canCastAlchemy()) {
                for (String alchItemName : ALCHABLE_ITEMS) {
                    if (Inventory.contains(alchItemName)) {
                        handleAlchemy(alchItemName);
                        // Add a small delay between alchs if needed
                        sleep(200, 400);
                        // Exit after one alch attempt per cycle to avoid locking up
                        // Or continue if you want to alch everything in one go
                        // For now, let's alch one item per execution cycle
                    }
                }
            }

            return 600;

        } catch (Exception e) {
            log("Error in onExecute(): " + e.getMessage());
            currentLootingItem = null;
            lootingStartTime = 0;
            return 600;
        }
    }

    private boolean canCastAlchemy() {
        // Check if alchemy is enabled in config
        if (!config.isAlchemyEnabled()) {
            return false;
        }

        // Check if there are any enemies in the room
        if (NPCs.closest("Scurrius") != null || NPCs.closest("Giant rat") != null) {
            log("Cannot alch - enemies present in room");
            return false;
        }

        // Check magic level requirement (level 55)
        if (Skills.getRealLevel(Skill.MAGIC) < 55) {
            log("Magic level too low for High Alchemy");
            return false;
        }

        // Check for required runes
        boolean hasNatureRunes = Inventory.contains("Nature rune");
        boolean hasFireRunes = Inventory.contains("Fire rune");

        // Log status if debugging needed
        if (!hasNatureRunes) log("Missing nature runes for alchemy");
        if (!hasFireRunes) log("Missing fire runes for alchemy");

        return Magic.canCast(Normal.HIGH_LEVEL_ALCHEMY) &&
                hasNatureRunes &&
                hasFireRunes;
    }

    private void handleAlchemy(String itemName) {
        Item itemToAlch = Inventory.get(itemName);
        if (itemToAlch != null && canCastAlchemy()) {
            status("Alching " + itemName);
            if (Magic.castSpell(Normal.HIGH_LEVEL_ALCHEMY)) {
                sleep(300, 500);
                if (itemToAlch.interact()) {
                    sleepUntil(() -> !Inventory.contains(itemName), 1800);
                }
            }
        }
    }

    private boolean eatFood() {
        for (String foodName : FOOD_ITEMS) {
            Item food = Inventory.get(foodName);
            if (food != null && food.hasAction("Eat")) {
                return food.interact("Eat");
            }
        }
        return false;
    }
} 