package scripts.Scurrius.nodes;

import core.base.SimpleNode;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import scripts.Scurrius.ScurriusConfig;

public class NavigationNode extends SimpleNode<ScurriusConfig> {
    private static final Area ENTRANCE_AREA = new Area(3277, 9870, 3281, 9864);
    public static final Tile ENTRANCE_TILE = new Tile(3281, 9870, 0);
    private static final int ENTRANCE_OBJECT_ID = 14203;
    private static final Area VARROCK_ALTAR_AREA = new Area(3252, 3485, 3254, 3487, 0);
    private static final Tile ALTAR_TILE = new Tile(3253, 3486, 0);

    public NavigationNode(ScurriusConfig config) {
        super("Navigation", 2, config);
    }

    @Override
    public boolean validate() {
        if (!isReadyToExecute()) return false;
        
        // Additional check for login state
        if (!Client.isLoggedIn()) {
            return false;
        }
        
        // Reset instance state if we're in entrance area or not in a dynamic region
        if (config.isInInstance() && (ENTRANCE_AREA.contains(Players.getLocal()) || !Client.isDynamicRegion())) {
            log("Player in entrance area or not in dynamic region - resetting instance state");
            config.setInInstance(false);
        }
        
        // Check prayer level first
        int currentPrayer = Skills.getBoostedLevel(Skill.PRAYER);
        int maxPrayer = Skills.getRealLevel(Skill.PRAYER);
        if (currentPrayer <= maxPrayer * 0.25 && !config.isUsingGrandExchange()) {
            return true; // Need to restore prayer at altar
        }
        
        // Rest of the validation logic
        boolean allEquipped = config.getEquipment().values().stream()
            .filter(item -> !item.isEmpty() && !"None".equals(item))
            .allMatch(Equipment::contains);
        config.setEquipmentReady(allEquipped);
        
        int foodCount = getCurrentFoodCount();
        
        boolean readyForNextTrip = allEquipped && 
                                  foodCount > 1 &&
                                  !config.isInInstance() &&
                                  !Bank.isOpen();
        
        return readyForNextTrip;
    }

    private int getCurrentFoodCount() {
        if (config.getFoodNames().isEmpty()) {
            log("WARNING: No food configured!");
            return 0;
        }
        // Only count the specifically configured food
        String foodName = config.getFoodNames().get(0);
        int count = Inventory.count(foodName);
        log("Counting " + foodName + ": " + count);
        return count;
    }

    @Override
    protected int onExecute() {
        // Check if we need to restore prayer first
        int currentPrayer = Skills.getBoostedLevel(Skill.PRAYER);
        int maxPrayer = Skills.getRealLevel(Skill.PRAYER);
        if (currentPrayer <= maxPrayer * 0.25 && !config.isUsingGrandExchange()) {
            return handlePrayerRestore();
        }

        // Regular navigation logic
        if (!ENTRANCE_AREA.contains(Players.getLocal())) {
            status("Walking to entrance");
            Walking.walk(ENTRANCE_TILE);
            sleepUntil(() -> 
                ENTRANCE_AREA.contains(Players.getLocal()) || 
                !Players.getLocal().isMoving(), 5000);
            return 600;
        }

        // At entrance area, handle entering the instance
        GameObject entrance = GameObjects.closest(ENTRANCE_OBJECT_ID);
        if (entrance != null) {
            status("Entering Scurrius lair");
            if (entrance.interact("Climb-through (private)")) {
                // Handle dialogue options for entering the instance
                if (sleepUntil(Dialogues::inDialogue, 5000)) {
                    // Check for either "Private" or "Yes, and don't ask again." options
                    if (Dialogues.getOptions() != null) {
                        if (Dialogues.chooseFirstOptionContaining("Private")) {
                            log("Selecting 'Private' option");
                            Dialogues.chooseOption("Private");
                        } else if (Dialogues.chooseFirstOptionContaining("Yes, and don't ask again.")) {
                            log("Selecting 'Yes, and don't ask again' option");
                            Dialogues.chooseOption("Yes, and don't ask again.");
                            Sleep.sleepUntil(Client::isDynamicRegion,5000);
                        }
                    }
                }
                config.setInInstance(true);
                log("Successfully entered instance");
            }
        }

        return 600;
    }

    private int handlePrayerRestore() {
        // If not at altar area, walk there
        if (!VARROCK_ALTAR_AREA.contains(Players.getLocal())) {
            status("Walking to Varrock altar");
            Walking.walk(ALTAR_TILE);
            return 600;
        }

        // At altar area, pray at altar
        GameObject altar = GameObjects.closest(obj -> obj != null && 
            obj.getID() == 14860 && 
            obj.hasAction("Pray-at"));
            
        if (altar != null && altar.interact("Pray-at")) {
            status("Praying at altar");
            Sleep.sleepUntil(() ->
                Skills.getBoostedLevel(Skill.PRAYER) == Skills.getRealLevel(Skill.PRAYER), 
                3000);
        }
        
        return 600;
    }

    @Override
    protected boolean shouldWait() {
        return isPlayerAnimating() || isPlayerMoving();
    }

    @Override
    protected int handleError(Exception e) {
        logError("Error in navigation", e);
        return super.handleError(e);
    }
} 