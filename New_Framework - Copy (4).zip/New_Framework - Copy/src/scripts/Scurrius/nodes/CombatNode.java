package scripts.Scurrius.nodes;

import core.base.SimpleNode;
import core.utils.PrayerFlicker;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.prayer.Prayer;
import org.dreambot.api.methods.prayer.Prayers;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.items.Item;
import scripts.Scurrius.ScurriusConfig;
import scripts.Scurrius.ScurriusScript;

import static org.dreambot.api.methods.skills.Skill.PRAYER;

public class CombatNode extends SimpleNode<ScurriusConfig> {
    private final PrayerFlicker prayerFlicker;
    private boolean prayerFlickingActive = false;
    private NPC currentScurrius = null;
    public Area waitingArea = new Area(3226, 9875, 3286, 9856);

    // Reference to the MovementNode to request movement actions
    private final MovementNode movementNode;

    public CombatNode(ScurriusConfig config, MovementNode movementNode) {
        super("Combat", 3, config);
        this.prayerFlicker = new PrayerFlicker(getContext());
        this.movementNode = movementNode;
    }

    @Override
    public boolean validate() {
        // First check if we're in a dynamic (instanced) region
        boolean isInDynamicRegion = Client.isDynamicRegion();

        if (NPCs.closest("Death") != null) {
            return false;
        }

        // Don't validate if there are giant rats present OR if player is already fighting a rat
        NPC rat = NPCs.closest("Giant rat");
        if (rat != null) {
            return false;
        }

        // Don't validate if player is looting
        if (Players.getLocal().isAnimating() && 
            Players.getLocal().getAnimation() == 827) { // Looting animation
            return false;
        }

        // Additional check for login state
        if (!Client.isLoggedIn()) {
            if (config.isInInstance()) {
                log("Player not logged in but state shows in instance - resetting state");
                config.setInInstance(false);
                if (prayerFlicker.prayerFlickingRunning) {
                    prayerFlicker.stop();
                }
                turnOffAllProtectionPrayers();
            }
            return false;
        }

        // If we're not in a dynamic region but our state thinks we are, reset it
        if (!isInDynamicRegion && config.isInInstance()) {
            log("Player not in dynamic region but state shows in instance - resetting state");
            config.setInInstance(false);
            if (prayerFlicker.prayerFlickingRunning) {
                prayerFlicker.stop();
            }
            turnOffAllProtectionPrayers();
            return false;
        }

        // Update instance state based on dynamic region
        config.setInInstance(isInDynamicRegion);

        if (!isReadyToExecute()) return false;
        if (waitingArea.contains(Players.getLocal())) return false;

        // Double check we're actually in instance before proceeding
        if (!config.isInInstance() || !isInDynamicRegion) {
            return false;
        }

        // If low health, eat regardless of Scurrius presence
        if (isHealthLow()) {
            return true;
        }

        // Handle prayer flicking logic
        try {
            NPC scurrius = NPCs.closest("Scurrius");
            NPC giantRat = NPCs.closest("Giant Rat");
            boolean scurriusPresent = scurrius != null && scurrius.exists();
            boolean giantRatPresent = giantRat != null && giantRat.exists();
            boolean shouldPrayerFlick = config.isInInstance() &&
                    Players.getLocal().isInCombat() &&
                    scurriusPresent||giantRatPresent ;

            if (shouldPrayerFlick && !prayerFlicker.prayerFlickingRunning) {
                log("Starting prayer flicking - Scurrius detected");
                prayerFlicker.startPrayerFlick();
            } else if (!scurriusPresent) {
                if (prayerFlicker.prayerFlickingRunning) {
                    log("Stopping prayer flicking - Scurrius not present");
                    prayerFlicker.stop();
                }
                // Turn off all protection prayers if Scurrius is not present
                turnOffAllProtectionPrayers();
            }

            return isInDynamicRegion;
        } catch (Exception e) {
            log("Error in validate: " + e.getMessage());
            if (prayerFlicker.prayerFlickingRunning) {
                prayerFlicker.stop();
            }
            turnOffAllProtectionPrayers();
            return isInDynamicRegion;
        }
    }

    @Override
    protected int onExecute() {
        // CRITICAL CHECKS - handled at the start of onExecute

        // Check health and eat if needed, regardless of Scurrius presence
        if (isHealthLow()) {
            Logger.log("Health check triggered");
            Logger.log("Current health: " + Skills.getBoostedLevel(Skill.HITPOINTS));
            Logger.log("Health threshold: " + config.getHealthThreshold());

            status("Health low, eating food");
            if (eatFood()) {
                return 600;
            }

            // If we couldn't eat and health is still low, we must leave
            Logger.log("Failed to eat food, leaving instance");
            config.setInInstance(false);
            movementNode.requestLeaveInstance();
            return 600;
        }

        // Check if we need to leave due to supplies (no prayer pots, low food, etc.)
        if (shouldLeaveInstance()) {
            status("Out of supplies - leaving instance");
            Bank.open();
            config.setInInstance(false);
            movementNode.requestLeaveInstance();
            return 600;
        }

        // Normal combat handling
        handlePotions();

        // First priority: Handle Scurrius if present
        NPC scurrius = NPCs.closest("Scurrius");
        if (scurrius != null) {
            if (currentScurrius != null && !currentScurrius.exists()) {
                ((ScurriusScript)getContext().getScript()).incrementKillCount();
                currentScurrius = null;
                if (prayerFlicker.prayerFlickingRunning) {
                    prayerFlicker.stop();
                }
                log("Scurrius killed!");
            }

            // Update current Scurrius reference
            if (currentScurrius == null) {
                currentScurrius = scurrius;
            }

            // Only attack if healthy
            if (!isHealthLow()) {
                if (!Players.getLocal().isInteracting(scurrius)) {
                    status("Attacking Scurrius");
                    if (scurrius.interact("Attack")) {
                        sleepUntil(() -> Players.getLocal().isInCombat(), 2400);
                    }
                }
            }
            return 600;
        }

        return 600;
    }

    public void stopPrayerFlicking() {
        if (prayerFlickingActive) {
            prayerFlicker.stop();
            prayerFlickingActive = false;
        }
    }

    @Override
    public void cleanup() {
        stopPrayerFlicking();
        super.cleanup();
    }

    @Override
    protected int handleError(Exception e) {
        stopPrayerFlicking();
        return super.handleError(e);
    }

    @Override
    protected boolean shouldWait() {
        return isPlayerAnimating() || isPlayerMoving();
    }

    private int getCurrentFoodCount() {
        if (config.getFoodNames().isEmpty()) {
            log("WARNING: No food configured!");
            return 0;
        }
        String foodName = config.getFoodNames().get(0);
        int count = Inventory.count(foodName);
        log("Counting " + foodName + ": " + count);
        return count;
    }

    private boolean shouldLeaveInstance() {
        boolean lowFood = getCurrentFoodCount() <= 1;
        boolean noPrayer = Skills.getBoostedLevel(Skill.PRAYER) < 10 &&
                !Inventory.contains(item -> item.getName().contains("Prayer potion") ||
                        item.getName().contains("Super restore"));

        if (lowFood || noPrayer) {
            log("Should leave instance - Low food: " + lowFood + ", No prayer: " + noPrayer);
            log("Current HP: " + Skills.getBoostedLevel(Skill.HITPOINTS) +
                    "/" + Skills.getRealLevel(Skill.HITPOINTS));
            log("Health threshold: " + config.getHealthThreshold());
            return true;
        }

        return false;
    }

    private boolean isHealthLow() {
        int currentHealth = Skills.getBoostedLevel(Skill.HITPOINTS);
        int threshold = config.getHealthThreshold();
        return currentHealth < threshold;
    }

    private boolean isPrayerLow() {
        int currentPrayer = Skills.getBoostedLevel(PRAYER);
        int maxPrayer = Skills.getRealLevel(PRAYER);
        int prayerPercent = (currentPrayer * 100) / maxPrayer;
        return prayerPercent <= 25;
    }

    private boolean eatFood() {
        Logger.log("Attempting to eat food...");
        Logger.log("Configured food names: " + config.getFoodNames());

        // First try configured food
        if (eatConfiguredFood()) {
            Logger.log("Successfully ate configured food");
            return true;
        }

        Logger.log("Failed to eat configured food, trying backup food...");
        // If no configured food available, try looted common foods
        if (tryEatFood("Shark")) return true;
        if (tryEatFood("Lobster")) return true;
        if (tryEatFood("Tuna")) return true;

        Logger.log("Failed to eat any food!");
        return false;
    }

    private boolean eatConfiguredFood() {
        if (!config.getFoodNames().isEmpty()) {
            String foodName = config.getFoodNames().get(0);
            Logger.log("Attempting to eat configured food: " + foodName);
            return tryEatFood(foodName);
        }
        Logger.log("No food configured in settings!");
        return false;
    }

    private boolean tryEatFood(String foodName) {
        Logger.log("Checking for food: " + foodName);
        Item food = Inventory.get(foodName);
        if (food != null && food.hasAction("Eat")) {
            status("Eating " + foodName);
            int initialCount = Inventory.count(foodName);
            if (food.interact("Eat")) {
                boolean eaten = sleepUntil(() -> Inventory.count(foodName) < initialCount, 1200);
                Logger.log("Food was eaten: " + eaten);
                return eaten;
            }
            Logger.log("Failed to interact with " + foodName);
        } else {
            Logger.log("No " + foodName + " found or it can't be eaten.");
        }
        return false;
    }

    private boolean shouldBoost(Skill skill) {
        int currentLevel = Skills.getBoostedLevel(skill);
        int baseLevel = Skills.getRealLevel(skill);
        int boostThreshold = 5; // Only boost when within 5 levels of base

        // If we're not in combat, wait for combat to start before boosting
        if (!Players.getLocal().isInCombat() && currentLevel > baseLevel) {
            return false;
        }

        return currentLevel <= baseLevel + boostThreshold;
    }

    private void handlePotions() {
        // Only use potions if in combat with Scurrius
        NPC scurrius = NPCs.closest("Scurrius");
        if (scurrius == null || !Players.getLocal().isInCombat()) {
            return;
        }

        // Combat boosting potions
        if (shouldBoost(Skill.ATTACK) || shouldBoost(Skill.STRENGTH) || shouldBoost(Skill.DEFENCE)) {
            if (drinkPotion("Super combat potion")) return;
            if (shouldBoost(Skill.ATTACK) && drinkPotion("Super attack")) return;
            if (shouldBoost(Skill.STRENGTH) && drinkPotion("Super strength")) return;
            if (shouldBoost(Skill.DEFENCE) && drinkPotion("Super defence")) return;
        }

        // Ranging potion
        if (shouldBoost(Skill.RANGED) && drinkPotion("Ranging potion")) return;

        // Prayer restore
        if (isPrayerLow()) {
            if (drinkPotion("Super restore")) return;
            drinkPotion("Prayer potion");
        }
    }

    private boolean drinkPotion(String baseName) {
        for (int dose = 4; dose >= 1; dose--) {
            String potionName = baseName + "(" + dose + ")";
            Item potion = Inventory.get(potionName);
            if (potion != null && potion.hasAction("Drink")) {
                status("Drinking " + potionName);
                if (potion.interact("Drink")) {
                    sleepUntil(() -> !Inventory.contains(potionName), 1200);
                    return true;
                }
            }
        }
        return false;
    }

    private void turnOffAllProtectionPrayers() {
        if (Prayers.isActive(Prayer.PROTECT_FROM_MELEE)) {
            Prayers.toggle(false,Prayer.PROTECT_FROM_MELEE);
        }
        if (Prayers.isActive(Prayer.PROTECT_FROM_MISSILES)) {
            Prayers.toggle(false,Prayer.PROTECT_FROM_MISSILES);
        }
        if (Prayers.isActive(Prayer.PROTECT_FROM_MAGIC)) {
            Prayers.toggle(false,Prayer.PROTECT_FROM_MAGIC);
        }
        log("Turned off all protection prayers");
    }
}
