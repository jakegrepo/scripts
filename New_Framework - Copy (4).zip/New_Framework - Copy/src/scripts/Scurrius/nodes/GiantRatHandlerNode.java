package scripts.Scurrius.nodes;

import core.base.SimpleNode;
import core.paint.debug.DebugOverlay;
import org.dreambot.api.Client;
import org.dreambot.api.methods.interactive.GraphicsObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.NPC;
import scripts.Scurrius.ScurriusConfig;

public class GiantRatHandlerNode extends SimpleNode<ScurriusConfig> {
    public static final int FALLING_ROCKS_GRAPHICS_ID = 2644; // Same as in CombatNode
    private final DebugOverlay debugOverlay;
    private final MovementNode movementNode;
    public Area waitingArea = new Area(3226, 9875, 3286, 9856);

    public GiantRatHandlerNode(ScurriusConfig config, DebugOverlay debugOverlay, MovementNode movementNode) {
        super("GiantRatHandler", 1, config);
        this.debugOverlay = debugOverlay;
        this.movementNode = movementNode;
    }

    @Override
    public boolean validate() {
        if (NPCs.closest("Death") != null) {
            return false;
        }
        
        if (!Client.isLoggedIn() || !config.isInInstance()) {
            return false;
        }

        if (!isReadyToExecute()) {
            return false;
        }

        // If player is in waiting area, do nothing
        if (waitingArea.contains(Players.getLocal())) {
            return false;
        }

        // Simply check if there's a rat to handle - no other conditions needed
        NPC rat = NPCs.closest("Giant rat");
        return rat != null && rat.exists();
    }

    @Override
    protected int onExecute() {
        // Continuously handle giant rats until no valid target is found or we must leave
        while (true) {
            if (isInDanger() || isHealthLow()) {
                movementNode.requestFlee();
                return 50; // Return quickly so we can re-check conditions
            }

            NPC rat = NPCs.closest("Giant rat");

            if (rat == null || !rat.exists()) {
                // No rat found, break out of the loop and return quickly
                break;
            }

            // If the player is not currently interacting with a rat, start attacking immediately
                if (rat.interact("Attack")) {
                    // Instead of a long sleep, just do a short wait or no wait at all
                    Sleep.sleep(50);
                } else {
                    // If interaction failed, just break and retry on next loop
                    break;
                }
            // Check if the rat is dead or no longer valid after a short interval
            // Instead of a long wait, do quick checks
            Sleep.sleep(50);
            if (!rat.exists() || rat.getHealthPercent() <= 0) {
                // Rat is dead, immediately continue the loop to find the next one
                continue;
            }

            // If still alive and we're still attacking it, break out to avoid infinite loop
            // Will re-run on next onExecute() call quickly due to short return
            break;
        }

        // Return a small sleep to keep script responsive
        return 50;
    }


    private boolean isHealthLow() {
        int currentHealth = Skills.getBoostedLevel(Skill.HITPOINTS);
        return currentHealth <= config.getHealthThreshold();
    }

    private boolean isInDanger() {
        // Check if current tile is dangerous using the debugOverlay or falling rocks
        return debugOverlay.isDangerTile(Players.getLocal().getTile()) ||
                GraphicsObjects.all().stream()
                        .anyMatch(g -> g != null && g.getID() == FALLING_ROCKS_GRAPHICS_ID
                                && g.getTile().equals(Players.getLocal().getTile()));
    }

    @Override
    protected boolean shouldWait() {
        return isPlayerAnimating() || isPlayerMoving();
    }

    @Override
    protected int handleError(Exception e) {
        logError("Error handling Giant Rat", e);
        return super.handleError(e);
    }
}
