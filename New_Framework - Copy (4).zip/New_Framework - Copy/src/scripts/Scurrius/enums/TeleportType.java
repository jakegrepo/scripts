package scripts.Scurrius.enums;

public enum TeleportType {
    NONE("None"),
    TABLET("Tablet"),
    SPELL("Spell");

    private final String displayName;

    TeleportType(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
} 