package scripts.Scurrius;

import core.base.ScarScript;
import core.gui.AbstractSettingsTab;
import core.node.TaskNode;
import core.nodes.DeathNode;
import core.paint.PaintBuilder;
import core.paint.ScriptPaint;
import core.paint.debug.DebugOverlay;
import core.paint.debug.NPCHighlightManager;
import core.state.ScriptState;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import scripts.Scurrius.gui.ScurriusSettingsTab;
import scripts.Scurrius.nodes.*;

import java.awt.*;

@ScriptManifest(
        name = "ScarScurrius",
        author = "Scarfade",
        version = 1.5,
        description = "Scurrius",
        category = Category.COMBAT
)
public class ScurriusScript extends ScarScript<ScurriusConfig> {
    private ScurriusConfig config;
    private ScriptPaint paint;
    private int killCount = 0;
    private long startXp = 0;
    private long lastDebugUpdate = 0;
    private DebugOverlay debugOverlay;
    private NPCHighlightManager npcHighlightManager;
    private Rectangle debugToggleButton;

    // Add a reference to the MovementNode thread so we can manage it if needed
    private Thread movementThread;
    private MovementNode movementNode; // Keep a reference to the movementNode as well

    private boolean wasPressed = false;

    private Thread consumablesThread;
    private ConsumablesNode consumablesNode;

    @Override
    protected int onScriptLoop() {
        try {
            if (getState().isRunnable()) {
                if (System.currentTimeMillis() - lastDebugUpdate > 100) {
                    updateDebugInfo();
                    lastDebugUpdate = System.currentTimeMillis();
                }

                if (context.tasks().getNodes().isEmpty()) {
                    context.getLogger().error("No nodes available - attempting reinitialization...");
                    initializeNodes();
                    return 600;
                }

                return context.tasks().execute();
            }
            return 600;
        } catch (Exception e) {
            context.getLogger().error("Error in script loop: " + e.getMessage());
            setState(ScriptState.ERROR);
            stopAllActivities();
            return 1000;
        }
    }

    private void stopAllActivities() {
        context.tasks().getNodes().forEach(node -> {
            if (node instanceof CombatNode) {
                ((CombatNode) node).stopPrayerFlicking();
            }
        });
    }

    @Override
    protected void onScriptStart() {
        try {
            context.getLogger().info("=== STARTING SCURRIUS SCRIPT ===");
            context.initialize(); // Ensure logger is ready

            config = getScriptConfig();
            context.initializeLogger(getClass().getSimpleName());
            context.getLogger().info("Initializing Scurrius Script");

            // Initialize debug overlay (shared)
            debugOverlay = new DebugOverlay(context);
            context.getLogger().info("Debug overlay initialized");

            // Initialize NPC highlight manager
            npcHighlightManager = new NPCHighlightManager(context);
            npcHighlightManager.addNpcToHighlight("Scurrius");
            context.getLogger().info("NPC highlight manager initialized");

            // Initialize paint
            paint = new PaintBuilder(context)
                    .setTitle("ScarScurrius")
                    .addRow("Status", this::getScriptStatus)
                    .addRow("Current Node", () -> {
                        TaskNode node = context.tasks().getActiveNode();
                        return node != null ? node.getName() : "None";
                    })
                    .addRow("Scurrius Kills", this::getKillCount)
                    .addPerHour("Kills", this::getKillCount)
                    .addFormattedRow("Total XP", this::getTotalXpGained)
                    .addPerHour("XP", this::getTotalXpGained)
                    .build();

            // Set our debug overlay instance in the paint
            ((ScriptPaint)paint).setDebugOverlay(debugOverlay);

            // Initialize all nodes, including the MovementNode
            initializeNodes();

            // Start the MovementNode in its own thread
            // MovementNode runs continuously, monitoring player safety
            movementThread = new Thread(movementNode);
            movementThread.start();
            context.getLogger().info("Movement node started on a separate thread");

            // XP tracking
            startXp = getTotalCombatXp();

            setState(ScriptState.RUNNING);
            context.getLogger().info("Scurrius script started successfully!");
        } catch (Exception e) {
            context.getLogger().error("Error during script start: " + e.getMessage());
            setState(ScriptState.ERROR);
        }
    }

    private void initializeNodes() {
        context.getLogger().info("=== INITIALIZING NODES ===");
        clearNodes();

        try {
            // Initialize debug overlay if not already initialized
            if (debugOverlay == null) {
                debugOverlay = new DebugOverlay(context);
                context.getLogger().info("Debug overlay initialized");
            }

            // Initialize movement node first
            movementNode = new MovementNode(config, debugOverlay);
            context.getLogger().info("Movement node initialized");

            // Initialize all other nodes
            DeathNode<ScurriusConfig> deathNode = new DeathNode<>(config);
            CombatNode combatNode = new CombatNode(config, movementNode);
            NavigationNode navigationNode = new NavigationNode(config);
            BankingNode bankingNode = new BankingNode(config);
            ScurriusGENode geNode = new ScurriusGENode(config);
            SupplyCheckNode supplyCheckNode = new SupplyCheckNode(config);
            GiantRatHandlerNode ratNode = new GiantRatHandlerNode(config, debugOverlay, movementNode);
            LootingNode lootingNode = new LootingNode(config);

            // Add nodes to the task list in order of priority
            context.getLogger().info("Adding nodes to task manager...");
            addNode(deathNode);
            addNode(supplyCheckNode);  // Highest priority (1)
            addNode(geNode);           // Priority 2
            addNode(bankingNode);      // Priority 3
            addNode(combatNode);
            addNode(navigationNode);
            addNode(ratNode);
            addNode(lootingNode);

            // Initialize and start consumables node if not already running
            if (consumablesNode == null) {
                consumablesNode = new ConsumablesNode(config, movementNode);
                consumablesThread = new Thread(consumablesNode);
                consumablesThread.start();
                context.getLogger().info("Consumables node started on a separate thread");
            }

            context.getLogger().info("=== NODE INITIALIZATION COMPLETE ===");
            context.getLogger().info("Total nodes initialized: " + context.tasks().getNodes().size());
        } catch (Exception e) {
            context.getLogger().error("Error initializing nodes: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    protected void onScriptStop() {
        context.getLogger().info("Scurrius script stopping...");

        // Request MovementNode to stop if needed
        if (movementNode != null) {
            movementNode.stopNode();
        }

        // Clean up debug overlay
        if (debugOverlay != null) {
            debugOverlay.clearTileHighlights();
            debugOverlay.clearProjectileHighlights();
        }

        // Stop prayer flicking
        context.tasks().getNodes().forEach(node -> {
            if (node instanceof CombatNode) {
                ((CombatNode) node).stopPrayerFlicking();
            }
        });

        if (consumablesNode != null) {
            consumablesNode.stopNode();
        }

        context.getLogger().info("Scurrius script stopped.");
    }

    @Override
    public void onPaint(Graphics2D g) {
        if (paint != null) {
            paint.render(g);
        }

        // Render NPC highlights
        if (npcHighlightManager != null) {
            npcHighlightManager.render(g);
        }
    }


    @Override
    public ScurriusConfig getScriptConfig() {
        if (config == null) {
            config = new ScurriusConfig(getContext());
        }
        return config;
    }

    @Override
    public boolean requiresGUI() {
        return true;
    }

    @Override
    protected AbstractSettingsTab getScriptTab() {
        return new ScurriusSettingsTab(getContext());
    }

    private String formatTime(long millis) {
        long seconds = millis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;

        return String.format("%02d:%02d:%02d",
                hours,
                minutes % 60,
                seconds % 60);
    }

    private String getScriptStatus() {
        TaskNode activeNode = context.tasks().getActiveNode();
        if (activeNode != null) {
            return activeNode.getStatus();
        }
        return getState().toString();
    }

    private long getRuntime() {
        return context.getRuntime();
    }

    private int getKillCount() {
        return killCount;
    }

    private long getTotalXpGained() {
        long currentTotalXp = getTotalCombatXp();
        return currentTotalXp - startXp;
    }

    private long getTotalCombatXp() {
        return Skills.getExperience(Skill.ATTACK) +
                Skills.getExperience(Skill.STRENGTH) +
                Skills.getExperience(Skill.DEFENCE) +
                Skills.getExperience(Skill.RANGED) +
                Skills.getExperience(Skill.MAGIC) +
                Skills.getExperience(Skill.HITPOINTS);
    }

    public void incrementKillCount() {
        killCount++;
    }

    private void updateDebugInfo() {
        if (debugOverlay == null) return;

        // Update debug overlays if needed
        debugOverlay.updateAllTiles();
        debugOverlay.updateScurriusHighlight();
        debugOverlay.updateGraphicsHighlights();
    }

    @Override
    public void openTestingGUI() {
        // Initialize nodes if they haven't been initialized yet
        if (context.tasks().getNodes().isEmpty()) {
            context.getLogger().info("Initializing nodes for testing...");
            initializeNodes();
        }
        
        // Call parent implementation to open the GUI
        super.openTestingGUI();
    }
}
