package scripts.Scurrius.gui;

import core.gui.SettingsPanel;
import core.gui.style.StyleManager;
import scripts.Scurrius.ScurriusConfig;

import javax.swing.*;
import java.awt.*;

public class TeleportsPanel extends SettingsPanel {
    private final ScurriusConfig config;
    private JComboBox<String> teleportMethodComboBox;

    public TeleportsPanel(ScurriusConfig config) {
        this.config = config;
        initializeComponents();
        StyleManager.applyStyle(this);
    }

    private void initializeComponents() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Teleport method selection
        JLabel teleportLabel = new JLabel("Teleport Method:");
        StyleManager.styleLabel(teleportLabel);
        
        teleportMethodComboBox = new JComboBox<>(new String[]{
            "None",
            "Tablet",
            "Spell"
        });
        StyleManager.styleComboBox(teleportMethodComboBox);

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(teleportLabel, gbc);

        gbc.gridy = 1;
        add(teleportMethodComboBox, gbc);

        teleportMethodComboBox.addActionListener(e -> saveSettings());
    }

    public void loadSettings() {
        String method = config.getTeleportMethod();
        if (method != null) {
            teleportMethodComboBox.setSelectedItem(method);
        } else {
            teleportMethodComboBox.setSelectedItem("None");
        }
    }

    public void saveSettings() {
        String selectedMethod = (String) teleportMethodComboBox.getSelectedItem();
        config.setTeleportMethod(selectedMethod);
    }
} 