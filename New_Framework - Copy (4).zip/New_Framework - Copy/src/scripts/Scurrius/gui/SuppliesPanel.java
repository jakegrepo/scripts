package scripts.Scurrius.gui;

import core.gui.SettingsPanel;
import core.gui.style.StyleManager;
import scripts.Scurrius.ScurriusConfig;
import scripts.Scurrius.gui.components.SupplyField;
import core.gui.components.SettingsCard;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SuppliesPanel extends SettingsPanel {
    private final ScurriusConfig config;
    private final Map<String, SupplyField> supplyFields = new HashMap<>();
    private JComboBox<String> foodTypeComboBox;
    private JSpinner foodQuantitySpinner;
    private JSpinner healthThresholdSpinner;
    private boolean isLoading = false;
    private static final Map<String, String> POTION_MAPPINGS = new HashMap<>();
    private static final String[] FOOD_OPTIONS = {
        "Cooked karambwan",
        "Monkfish",
        "Shark",
        "Lobster",
        "Salmon",
        "Potato with cheese","Tuna"
    };
    
    static {
        POTION_MAPPINGS.put("Super Attack", "Super attack(4)");
        POTION_MAPPINGS.put("Super Strength", "Super strength(4)");
        POTION_MAPPINGS.put("Super Defence", "Super defence(4)");
        POTION_MAPPINGS.put("Super Combat", "Super combat potion(4)");
        POTION_MAPPINGS.put("Ranging", "Ranging potion(4)");
        POTION_MAPPINGS.put("Prayer", "Prayer potion(4)");
        POTION_MAPPINGS.put("Super Restore", "Super restore(4)");
        POTION_MAPPINGS.put("Stamina", "Stamina potion(4)");
    }

    public SuppliesPanel(ScurriusConfig config) {
        super();
        this.config = config;
        initializeComponents();
    }

    private void initializeComponents() {
        setLayout(new BorderLayout());
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);

        // Potions Section Card
        SettingsCard potionsCard = new SettingsCard("Potions");
        JPanel potionsSection = new JPanel(new GridBagLayout());
        potionsSection.setOpaque(false);
        GridBagConstraints potionsGbc = new GridBagConstraints();
        potionsGbc.fill = GridBagConstraints.HORIZONTAL;
        potionsGbc.weightx = 1.0;
        potionsGbc.gridwidth = GridBagConstraints.REMAINDER;

        // Create two columns panel
        JPanel columnsPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        columnsPanel.setOpaque(false);
        columnsPanel.add(createColumn("Combat Potions", new String[]{
            "Super Attack",
            "Super Strength",
            "Super Defence",
            "Super Combat",
            "Ranging"
        }));
        columnsPanel.add(createColumn("Prayer & Special", new String[]{
            "Prayer",
            "Super Restore",
            "Stamina"
        }));
        potionsSection.add(columnsPanel, potionsGbc);
        potionsCard.setContent(potionsSection);
        content.add(potionsCard);
        content.add(Box.createVerticalStrut(16));

        // Food Section Card
        SettingsCard foodCard = new SettingsCard("Food Settings");
        JPanel foodSection = new JPanel(new GridBagLayout());
        foodSection.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;

        // Food settings panel
        JPanel foodSettingsPanel = new JPanel(new GridBagLayout());
        foodSettingsPanel.setOpaque(false);
        GridBagConstraints foodGbc = new GridBagConstraints();
        foodGbc.fill = GridBagConstraints.HORIZONTAL;
        foodGbc.insets = new Insets(2, 4, 2, 4);

        // Food Type field
        foodGbc.gridx = 0;
        foodGbc.gridy = 0;
        foodGbc.weightx = 0.3;
        JLabel foodLabel = new JLabel("Food Type:");
        foodLabel.setFont(StyleManager.HEADER_FONT);
        foodLabel.setForeground(StyleManager.ACCENT);
        foodSettingsPanel.add(foodLabel, foodGbc);
        foodTypeComboBox = new JComboBox<>(FOOD_OPTIONS);
        foodTypeComboBox.setPreferredSize(new Dimension(150, 28));
        StyleManager.styleComboBox(foodTypeComboBox);
        SpinnerNumberModel foodSpinnerModel = new SpinnerNumberModel(0, 0, 999, 1);
        foodQuantitySpinner = new JSpinner(foodSpinnerModel);
        foodQuantitySpinner.setPreferredSize(new Dimension(60, 28));
        StyleManager.styleSpinner(foodQuantitySpinner);
        JPanel foodInputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        foodInputPanel.setOpaque(false);
        foodInputPanel.add(foodTypeComboBox);
        foodInputPanel.add(foodQuantitySpinner);
        foodGbc.gridx = 1;
        foodGbc.weightx = 0.7;
        foodSettingsPanel.add(foodInputPanel, foodGbc);
        // Health threshold
        foodGbc.gridx = 0;
        foodGbc.gridy = 1;
        foodGbc.weightx = 0.3;
        JLabel healthLabel = new JLabel("Eat at HP Level:");
        healthLabel.setFont(StyleManager.HEADER_FONT);
        healthLabel.setForeground(StyleManager.ACCENT);
        foodSettingsPanel.add(healthLabel, foodGbc);
        foodGbc.gridx = 1;
        foodGbc.weightx = 0.7;
        SpinnerNumberModel healthSpinnerModel = new SpinnerNumberModel(50, 1, 99, 1);
        healthThresholdSpinner = new JSpinner(healthSpinnerModel);
        healthThresholdSpinner.setPreferredSize(new Dimension(60, 28));
        StyleManager.styleSpinner(healthThresholdSpinner);
        JPanel healthPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        healthPanel.setOpaque(false);
        healthPanel.add(healthThresholdSpinner);
        foodSettingsPanel.add(healthPanel, foodGbc);
        gbc.insets = new Insets(10, 10, 0, 10);
        foodSection.add(foodSettingsPanel, gbc);
        foodCard.setContent(foodSection);
        content.add(foodCard);
        content.add(Box.createVerticalGlue());

        // Add listeners
        foodTypeComboBox.addActionListener(e -> { if (!isLoading) saveSettings(); });
        foodQuantitySpinner.addChangeListener(e -> { if (!isLoading) saveSettings(); });
        healthThresholdSpinner.addChangeListener(e -> { if (!isLoading) saveSettings(); });

        // Make scrollable if needed
        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        add(scrollPane, BorderLayout.CENTER);
    }

    private JPanel createColumn(String title, String[] potions) {
        JPanel column = new JPanel(new GridBagLayout());
        column.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridy = 0;

        // Add header
        addSectionHeader(column, title, gbc);

        // Add potions
        gbc.gridy = 1;
        JPanel potionsPanel = new JPanel(new GridBagLayout());
        potionsPanel.setOpaque(false);
        GridBagConstraints slotGbc = new GridBagConstraints();
        slotGbc.fill = GridBagConstraints.HORIZONTAL;
        slotGbc.gridy = 0;

        for (int i = 0; i < potions.length; i++) {
            String displayName = potions[i];
            String actualItem = POTION_MAPPINGS.get(displayName);

            SupplyField field = new SupplyField(actualItem);
            field.getItemField().setVisible(false);
            supplyFields.put(displayName, field);

            // Add label
            slotGbc.gridx = 0;
            slotGbc.gridy = i;
            slotGbc.weightx = 0.7;
            slotGbc.insets = new Insets(2, 4, 2, 4);
            JLabel potionLabel = new JLabel(displayName + ":");
            potionLabel.setFont(StyleManager.HEADER_FONT);
            potionLabel.setForeground(StyleManager.ACCENT);
            potionsPanel.add(potionLabel, slotGbc);

            // Add spinner
            JSpinner spinner = field.getQuantitySpinner();
            spinner.setPreferredSize(new Dimension(60, 28));
            slotGbc.gridx = 1;
            slotGbc.weightx = 0.3;
            potionsPanel.add(spinner, slotGbc);

            spinner.addChangeListener(e -> {
                if (!isLoading) saveSettings();
            });
        }

        column.add(potionsPanel, gbc);
        return column;
    }

    private void addSectionHeader(JPanel container, String title, GridBagConstraints gbc) {
        JPanel headerPanel = new JPanel(new BorderLayout(0, 3));
        headerPanel.setOpaque(false);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));

        JLabel headerLabel = new JLabel(title.toUpperCase());
        headerLabel.setFont(StyleManager.SECTION_HEADER_FONT);
        headerLabel.setForeground(StyleManager.ACCENT);
        headerPanel.add(headerLabel, BorderLayout.NORTH);

        JPanel linePanel = new JPanel();
        linePanel.setOpaque(false);
        linePanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.WHITE));
        headerPanel.add(linePanel, BorderLayout.CENTER);

        container.add(headerPanel, gbc);
    }

    public void loadSettings() {
        isLoading = true;
        try {
            // Load potion quantities
            Map<String, Integer> supplies = config.getSupplies();
            for (Map.Entry<String, SupplyField> entry : supplyFields.entrySet()) {
                String potionName = POTION_MAPPINGS.get(entry.getKey());
                int quantity = supplies.getOrDefault(potionName, 0);
                entry.getValue().getQuantitySpinner().setValue(quantity);
            }

            // Load food settings
            List<String> foodNames = config.getFoodNames();
            if (foodNames != null && !foodNames.isEmpty()) {
                foodTypeComboBox.setSelectedItem(foodNames.get(0));
            } else {
                foodTypeComboBox.setSelectedItem(FOOD_OPTIONS[0]);
            }
            foodQuantitySpinner.setValue(config.getTargetFoodCount());
            healthThresholdSpinner.setValue(config.getHealthThreshold());
        } finally {
            isLoading = false;
        }
    }

    public void saveSettings() {
        // Save potion quantities
        Map<String, Integer> supplies = new HashMap<>();
        for (Map.Entry<String, SupplyField> entry : supplyFields.entrySet()) {
            String potionName = POTION_MAPPINGS.get(entry.getKey());
            int quantity = (int) entry.getValue().getQuantitySpinner().getValue();
            if (quantity > 0) {
                supplies.put(potionName, quantity);
            }
        }
        config.setSupplies(supplies);

        // Save food settings
        List<String> foodList = new ArrayList<>();
        String selectedFood = (String) foodTypeComboBox.getSelectedItem();
        if (selectedFood != null && !selectedFood.isEmpty()) {
            foodList.add(selectedFood);
        }
        config.setFoodNames(foodList);
        config.setTargetFoodCount((int) foodQuantitySpinner.getValue());
        config.setHealthThreshold((int) healthThresholdSpinner.getValue());
        
        config.markDirty();
    }

    public void saveToConfig() {
        saveSettings();
    }

    public void updateFromConfig() {
        loadSettings();
    }
} 