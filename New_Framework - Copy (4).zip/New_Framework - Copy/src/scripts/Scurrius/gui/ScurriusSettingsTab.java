package scripts.Scurrius.gui;

import core.base.ScarScript;
import core.context.ScriptContext;
import core.gui.AbstractSettingsTab;
import core.gui.FrameworkGUI;
import core.gui.ScriptGUI;
import core.gui.SettingsPanel;
import core.gui.components.Icons;
import core.gui.style.StyleManager;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.container.impl.equipment.EquipmentSlot;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.items.Item;
import scripts.Scurrius.ScurriusConfig;
import scripts.Scurrius.ScurriusScript;
import scripts.Scurrius.enums.TeleportType;
import core.gui.components.SettingsCard;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class ScurriusSettingsTab extends AbstractSettingsTab {
    private final ScurriusConfig config;
    private final EquipmentPanel equipmentPanel;
    private final SuppliesPanel supplyPanel;
    private GeneralPanel generalPanel;
    private TeleportsPanel teleportsPanel;

    public ScurriusSettingsTab(ScriptContext context) {
        super(context);
        ScurriusScript script = (ScurriusScript) context.getScript();
        this.config = script.getConfig();
        
        // Initialize all panels
        this.equipmentPanel = new EquipmentPanel(config);
        this.supplyPanel = new SuppliesPanel(config);
        this.generalPanel = new GeneralPanel(config);
        this.teleportsPanel = new TeleportsPanel(config);
        
        // Load initial settings
        refreshAllDisplays();
    }

    @Override
    public void createComponents() {
        // Use a tabbed pane for modular sub-tabs
        JTabbedPane subTabs = new JTabbedPane();
        StyleManager.styleTabbedPane(subTabs);
        subTabs.addTab("General", generalPanel);
        subTabs.addTab("Equipment", equipmentPanel);
        subTabs.addTab("Supplies", supplyPanel);

        // Add the tabbed pane to this tab
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        getPanel().add(subTabs, gbc);
    }

    private void handleFetchSetup() {
        if (!Client.isLoggedIn()) {
            JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this.getPanel()),
                    "Please log in first to fetch your current setup.",
                    "Not Logged In",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Only fetch equipment
            Map<String, String> currentEquipment = new HashMap<>();
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                Item equippedItem = Equipment.getItemInSlot(slot);
                if (equippedItem != null) {
                    String slotName = getSlotName(slot);
                    if (slotName != null) {
                        currentEquipment.put(slotName, equippedItem.getName());
                    }
                }
            }
            config.setEquipment(currentEquipment);

            // Only refresh equipment display
            refreshEquipmentDisplay();

            // Save the updated config
            config.saveConfig();

            JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this.getPanel()),
                    "Current equipment has been fetched successfully!",
                    "Equipment Fetched",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            log("Error fetching current equipment: " + e.getMessage());
            JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this.getPanel()),
                    "Error fetching equipment: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    private String getSlotName(EquipmentSlot slot) {
        switch (slot) {
            case HAT: return "helmet";
            case CAPE: return "cape";
            case AMULET: return "necklace";
            case WEAPON: return "weapon";
            case CHEST: return "body";
            case SHIELD: return "shield";
            case LEGS: return "legs";
            case HANDS: return "gloves";
            case FEET: return "boots";
            case RING: return "ring";
            case ARROWS: return "ammo";
            default: return null;
        }
    }

    private void refreshEquipmentDisplay() {
        equipmentPanel.loadSettings();
    }

    @Override
    public void saveSettings() {
        equipmentPanel.saveSettings();
        supplyPanel.saveSettings();
        generalPanel.saveSettings();
        teleportsPanel.saveSettings();
        config.saveConfig();
    }

    @Override
    public void resetToDefaults() {
        config.setDefaults();
        equipmentPanel.loadSettings();
        supplyPanel.loadSettings();
        generalPanel.loadSettings();
        teleportsPanel.loadSettings();
    }

    @Override
    public void updateFromConfig() {
        equipmentPanel.loadSettings();
        supplyPanel.loadSettings();
        generalPanel.loadSettings();
        teleportsPanel.loadSettings();
    }

    public void handleLoadProfile() {
        String selectedProfile = (String) JOptionPane.showInputDialog(
                this.getPanel(),
                "Select a profile to load:",
                "Load Profile",
                JOptionPane.PLAIN_MESSAGE,
                Icons.LOAD,
                config.getAvailableProfiles().toArray(),
                null
        );

        if (selectedProfile != null) {
            try {
                Logger.log("=== LOADING PROFILE: " + selectedProfile + " ===");

                // Load the profile
                config.loadProfile(selectedProfile);

                // Refresh all panels
                Logger.log("=== UPDATING PANELS WITH LOADED SETTINGS ===");
                refreshAllDisplays();

                Logger.log("=== PROFILE LOADED SUCCESSFULLY ===");
                JOptionPane.showMessageDialog(this.getPanel(),
                        "Profile loaded successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                Logger.log("ERROR loading profile: " + e.getMessage());
                e.printStackTrace();
                JOptionPane.showMessageDialog(this.getPanel(),
                        "Error loading profile: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void handleRemoveProfile() {
        String selectedProfile = (String) JOptionPane.showInputDialog(
                this.getPanel(),
                "Select a profile to remove:",
                "Remove Profile",
                JOptionPane.WARNING_MESSAGE,
                Icons.DELETE,
                config.getAvailableProfiles().toArray(),
                null
        );

        if (selectedProfile != null) {
            try {
                int confirm = JOptionPane.showConfirmDialog(
                        this.getPanel(),
                        "Are you sure you want to remove the profile '" + selectedProfile + "'?",
                        "Confirm Removal",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (confirm == JOptionPane.YES_OPTION) {
                    config.deleteProfile(selectedProfile);
                    JOptionPane.showMessageDialog(this.getPanel(),
                            "Profile removed successfully!",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (Exception e) {
                log("Error removing profile: " + e.getMessage());
                JOptionPane.showMessageDialog(this.getPanel(),
                        "Error removing profile: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void handleSaveProfile() {
        String profileName = JOptionPane.showInputDialog(
                this.getPanel(),
                "Enter profile name:",
                "Save Profile",
                JOptionPane.PLAIN_MESSAGE
        );

        if (profileName != null && !profileName.trim().isEmpty()) {
            try {
                Logger.log("=== SAVING PROFILE: " + profileName + " ===");

                // Save all panel settings first
                saveAllPanelSettings();

                // Save to profile
                config.saveProfile(profileName.trim());

                Logger.log("=== PROFILE SAVED SUCCESSFULLY ===");
                JOptionPane.showMessageDialog(this.getPanel(),
                        "Profile saved successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                Logger.log("ERROR saving profile: " + e.getMessage());
                e.printStackTrace();
                JOptionPane.showMessageDialog(this.getPanel(),
                        "Error saving profile: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void refreshAllDisplays() {
        try {
            Logger.log("=== REFRESHING ALL PANELS ===");
            equipmentPanel.loadSettings();
            supplyPanel.loadSettings();
            generalPanel.loadSettings();
            teleportsPanel.loadSettings();
            Logger.log("=== ALL PANELS REFRESHED ===");
        } catch (Exception e) {
            Logger.log("ERROR refreshing panels: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static String getScriptDirectory() {
        String userProfile = System.getenv("USERPROFILE");
        if (userProfile == null) {
            userProfile = System.getProperty("scripts.path");
        }
        return userProfile
                + File.separator + "DreamBot"
                + File.separator + "Scripts"
                + File.separator + "ScarScurrius";
    }
    public File getProfilesDirectory() {
        File profilesDir = new File(getScriptDirectory(), "profiles");
        if (!profilesDir.exists()) {
            boolean created = profilesDir.mkdirs();
            if (created) {
                Logger.log("Created profiles directory at " + profilesDir.getAbsolutePath());
            } else {
                Logger.log("Failed to create profiles directory at " + profilesDir.getAbsolutePath());
            }
        }
        return profilesDir;
    }

    private void saveAllPanelSettings() {
        try {
            Logger.log("=== SAVING PANEL SETTINGS ===");
            equipmentPanel.saveSettings();
            supplyPanel.saveSettings();
            generalPanel.saveSettings();
            teleportsPanel.saveSettings();
            config.markDirty();
            config.saveConfig();
            Logger.log("=== ALL PANEL SETTINGS SAVED ===");
        } catch (Exception e) {
            Logger.log("ERROR saving panel settings: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

class GeneralPanel extends SettingsPanel {
    private final ScurriusConfig config;
    private JCheckBox geCheckbox;
    private JSpinner suppliesSpinner;
    private JComboBox<TeleportType> teleportBox;
    private JCheckBox alchemyCheckbox;
    private boolean isLoading = false;

    public GeneralPanel(ScurriusConfig config) {
        super();
        this.config = config;
        initializeComponents();
        loadSettings();
    }

    private void initializeComponents() {
        setLayout(new GridBagLayout());
        GridBagConstraints outerGbc = new GridBagConstraints();
        outerGbc.gridx = 0;
        outerGbc.gridy = 0;
        outerGbc.weightx = 1.0;
        outerGbc.weighty = 1.0;
        outerGbc.fill = GridBagConstraints.BOTH;
        outerGbc.insets = new Insets(8, 48, 24, 48); // Reduced top margin

        // Card panel for all settings
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(StyleManager.CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0,0,0,30), 1, true),
            BorderFactory.createEmptyBorder(12, 32, 24, 32) // Less top padding
        ));
        card.setOpaque(true);

        // Form panel for all settings
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        int row = 0;
        // --- Trading Section ---
        JLabel tradingHeader = new JLabel("TRADING");
        tradingHeader.setFont(new Font("Segoe UI", Font.BOLD, 18));
        tradingHeader.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2;
        form.add(tradingHeader, gbc);
        JLabel tradingDesc = new JLabel("Configure how the script handles trading and the Grand Exchange.");
        tradingDesc.setFont(StyleManager.SMALL_FONT);
        tradingDesc.setForeground(StyleManager.FOREGROUND_SECONDARY);
        gbc.gridy = row++;
        form.add(tradingDesc, gbc);
        gbc.gridwidth = 1;
        // Use Grand Exchange
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0.0;
        geCheckbox = new JCheckBox("Use Grand Exchange");
        geCheckbox.setToolTipText("Enable to allow the script to use the Grand Exchange for buying/selling.");
        StyleManager.styleCheckBox(geCheckbox);
        form.add(geCheckbox, gbc);
        row++;

        // --- Resources Section ---
        JLabel resourcesHeader = new JLabel("RESOURCES");
        resourcesHeader.setFont(new Font("Segoe UI", Font.BOLD, 18));
        resourcesHeader.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2;
        form.add(resourcesHeader, gbc);
        JLabel resourcesDesc = new JLabel("Manage supply multipliers and teleport options for efficient resource use.");
        resourcesDesc.setFont(StyleManager.SMALL_FONT);
        resourcesDesc.setForeground(StyleManager.FOREGROUND_SECONDARY);
        gbc.gridy = row++;
        form.add(resourcesDesc, gbc);
        gbc.gridwidth = 1;
        // Supplies Multiplier
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0.0;
        JLabel suppliesLabel = new JLabel("Supplies Multiplier:");
        suppliesLabel.setFont(StyleManager.HEADER_FONT);
        suppliesLabel.setForeground(new Color(255, 140, 0));
        suppliesLabel.setToolTipText("Set how many times to multiply supply purchases. Required.");
        form.add(suppliesLabel, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        suppliesSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        suppliesSpinner.setToolTipText("Set how many times to multiply supply purchases. Required.");
        StyleManager.styleSpinner(suppliesSpinner);
        suppliesSpinner.setFont(StyleManager.REGULAR_FONT.deriveFont(Font.PLAIN, 15f));
        suppliesSpinner.setBorder(BorderFactory.createLineBorder(new Color(255, 140, 0), 1));
        form.add(suppliesSpinner, gbc);
        row++;
        // Teleport Method
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0.0;
        JLabel teleportLabel = new JLabel("Teleport Method:");
        teleportLabel.setFont(StyleManager.HEADER_FONT);
        teleportLabel.setForeground(StyleManager.ACCENT);
        teleportLabel.setToolTipText("Choose the teleport method for resource movement.");
        form.add(teleportLabel, gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        teleportBox = new JComboBox<>(TeleportType.values());
        teleportBox.setToolTipText("Choose the teleport method for resource movement.");
        StyleManager.styleComboBox(teleportBox);
        teleportBox.setFont(StyleManager.REGULAR_FONT.deriveFont(Font.PLAIN, 15f));
        form.add(teleportBox, gbc);
        row++;

        // --- Features Section ---
        JLabel featuresHeader = new JLabel("FEATURES");
        featuresHeader.setFont(new Font("Segoe UI", Font.BOLD, 18));
        featuresHeader.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = row++; gbc.gridwidth = 2;
        form.add(featuresHeader, gbc);
        JLabel featuresDesc = new JLabel("Enable or disable special script features.");
        featuresDesc.setFont(StyleManager.SMALL_FONT);
        featuresDesc.setForeground(StyleManager.FOREGROUND_SECONDARY);
        gbc.gridy = row++;
        form.add(featuresDesc, gbc);
        gbc.gridwidth = 1;
        // High Alchemy
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0.0;
        alchemyCheckbox = new JCheckBox("High Alchemy");
        alchemyCheckbox.setToolTipText("Enable to allow the script to use High Alchemy on items.");
        StyleManager.styleCheckBox(alchemyCheckbox);
        form.add(alchemyCheckbox, gbc);
        row++;

        card.add(form, BorderLayout.CENTER);
        add(card, outerGbc);

        // Listeners
        geCheckbox.addActionListener(e -> { if (!isLoading) saveSettings(); });
        suppliesSpinner.addChangeListener(e -> { if (!isLoading) saveSettings(); });
        teleportBox.addActionListener(e -> { if (!isLoading) saveSettings(); });
        alchemyCheckbox.addActionListener(e -> { if (!isLoading) saveSettings(); });
    }

    public void loadSettings() {
        isLoading = true;
        try {
            geCheckbox.setSelected(config.isUsingGrandExchange());
            suppliesSpinner.setValue(config.getSuppliesMultiplier());
            
            // Load teleport method
            String teleportMethod = config.getTeleportMethod();
            for (TeleportType type : TeleportType.values()) {
                if (type.toString().equals(teleportMethod)) {
                    teleportBox.setSelectedItem(type);
                    break;
                }
            }
            
            alchemyCheckbox.setSelected(config.isAlchemyEnabled());
        } finally {
            isLoading = false;
        }
    }

    public void saveSettings() {
        config.setUseGrandExchange(geCheckbox.isSelected());
        config.setSuppliesMultiplier((int) suppliesSpinner.getValue());
        
        // Save teleport method
        TeleportType selectedType = (TeleportType) teleportBox.getSelectedItem();
        if (selectedType != null) {
            config.setTeleportMethod(selectedType.toString());
        }
        
        config.setAlchemyEnabled(alchemyCheckbox.isSelected());
        config.markDirty();
    }

    public void saveToConfig() {
        saveSettings();
    }

    public void updateFromConfig() {
        loadSettings();
    }
}
