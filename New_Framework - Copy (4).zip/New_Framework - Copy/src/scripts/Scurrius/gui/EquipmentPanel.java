package scripts.Scurrius.gui;

import core.gui.components.Icons;
import core.gui.style.StyleManager;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.container.impl.equipment.EquipmentSlot;
import org.dreambot.api.wrappers.items.Item;
import scripts.Scurrius.ScurriusConfig;
import core.gui.components.SettingsCard;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

import static org.dreambot.api.utilities.Logger.log;

public class EquipmentPanel extends JPanel {
    private final ScurriusConfig config;
    private final Map<String, JTextField> equipmentSlots = new HashMap<>();
    private JSpinner ammoQuantitySpinner;

    public EquipmentPanel(ScurriusConfig config) {
        this.config = config;
        initializeComponents();
    }

    private void initializeComponents() {
        setLayout(new BorderLayout());
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);

        // Fetch Button Card
        SettingsCard fetchCard = new SettingsCard("Equipment Setup");
        JPanel fetchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        fetchPanel.setOpaque(false);
        JButton fetchSetupButton = createStyledButton(" Fetch Current Equipment", Icons.REFRESH);
        fetchSetupButton.addActionListener(e -> handleFetchSetup());
        fetchPanel.add(fetchSetupButton);
        fetchCard.setContent(fetchPanel);
        content.add(fetchCard);
        content.add(Box.createVerticalStrut(16));

        // Equipment Slots Card
        SettingsCard slotsCard = new SettingsCard("Equipment Slots");
        JPanel slotsPanel = new JPanel();
        slotsPanel.setLayout(new GridBagLayout());
        slotsPanel.setOpaque(false);
        GridBagConstraints slotGbc = new GridBagConstraints();
        slotGbc.fill = GridBagConstraints.HORIZONTAL;
        slotGbc.insets = new Insets(2, 4, 2, 4);
        slotGbc.weightx = 1.0;

        String[] slots = {
            "Weapon", "Shield", 
            "Helmet", "Body", 
            "Legs", "Boots", 
            "Hands", "Cape",
            "Necklace", "Ring"
        };

        // Add regular slots in 2 columns
        for (int i = 0; i < slots.length; i++) {
            String slot = slots[i];
            JTextField field = createEquipmentTextField(slot);
            equipmentSlots.put(slot.toLowerCase(), field);

            // Calculate grid positions
            slotGbc.gridx = (i % 2) * 2;  // 0 or 2
            slotGbc.gridy = i / 2;
            slotGbc.weightx = 0.15;  // Label gets less space
            JLabel label = new JLabel(slot + ":");
            label.setFont(StyleManager.HEADER_FONT);
            label.setForeground(StyleManager.ACCENT);
            slotsPanel.add(label, slotGbc);
            slotGbc.gridx++;
            slotGbc.weightx = 0.85;  // Field gets more space
            slotGbc.insets = new Insets(2, 2, 2, 8);
            slotsPanel.add(field, slotGbc);
            slotGbc.insets = new Insets(2, 4, 2, 4);  // Reset insets for next label
        }

        // Add ammo row with quantity spinner
        slotGbc.gridy++;
        slotGbc.gridx = 0;
        slotGbc.weightx = 0.15;
        JLabel ammoLabel = new JLabel("Ammo:");
        ammoLabel.setFont(StyleManager.HEADER_FONT);
        ammoLabel.setForeground(StyleManager.ACCENT);
        slotsPanel.add(ammoLabel, slotGbc);
        JPanel ammoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        ammoPanel.setOpaque(false);
        JTextField ammoField = createEquipmentTextField("Ammo");
        ammoField.setPreferredSize(new Dimension(120, 28));
        equipmentSlots.put("ammo", ammoField);
        ammoPanel.add(ammoField);
        SpinnerNumberModel spinnerModel = new SpinnerNumberModel(0, 0, Integer.MAX_VALUE, 100);
        ammoQuantitySpinner = new JSpinner(spinnerModel);
        ammoQuantitySpinner.setPreferredSize(new Dimension(80, 28));
        StyleManager.styleSpinner(ammoQuantitySpinner);
        ammoPanel.add(new JLabel("Qty:"));
        ammoPanel.add(ammoQuantitySpinner);
        slotGbc.gridx = 1;
        slotGbc.weightx = 0.85;
        slotGbc.gridwidth = 3;
        slotsPanel.add(ammoPanel, slotGbc);

        slotsCard.setContent(slotsPanel);
        content.add(slotsCard);
        content.add(Box.createVerticalGlue());

        // Make scrollable if needed
        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void addSectionHeader(JPanel container, String title, GridBagConstraints gbc) {
        JPanel headerPanel = new JPanel(new BorderLayout(0, 3));
        headerPanel.setOpaque(false);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        JLabel headerLabel = new JLabel(title.toUpperCase());
        headerLabel.setFont(StyleManager.SECTION_HEADER_FONT);
        headerLabel.setForeground(StyleManager.ACCENT);
        headerPanel.add(headerLabel, BorderLayout.NORTH);

        JPanel linePanel = new JPanel();
        linePanel.setOpaque(false);
        linePanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.WHITE));
        headerPanel.add(linePanel, BorderLayout.CENTER);

        gbc.insets = new Insets(2, 0, 2, 0);
        container.add(headerPanel, gbc);
    }

    private void addFormField(JPanel container, String label, JComponent field, GridBagConstraints gbc) {
        JPanel fieldPanel = new JPanel(new BorderLayout(15, 0));
        fieldPanel.setOpaque(false);
        fieldPanel.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));

        JLabel jLabel = new JLabel(label);
        jLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        jLabel.setForeground(StyleManager.ACCENT);
        fieldPanel.add(jLabel, BorderLayout.WEST);

        JPanel fieldWrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        fieldWrapper.setOpaque(false);
        fieldWrapper.add(field);
        fieldPanel.add(fieldWrapper, BorderLayout.CENTER);

        gbc.insets = new Insets(0, 0, 0, 0);
        container.add(fieldPanel, gbc);
    }

    private void addVerticalSpace(JPanel container, int height, GridBagConstraints gbc) {
        container.add(Box.createVerticalStrut(height), gbc);
    }

    private JTextField createEquipmentTextField(String slot) {
        JTextField textField = new JTextField(12);
        StyleManager.styleTextField(textField);
        textField.setToolTipText("Enter " + slot.toLowerCase() + " item name");
        textField.setPreferredSize(new Dimension(180, 28));
        return textField;
    }

    private JButton createStyledButton(String text, Icon icon) {
        JButton button = new JButton(text, icon);
        StyleManager.styleButton(button);
        return button;
    }

    private void handleFetchSetup() {
        if (!Client.isLoggedIn()) {
            JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),
                    "Please log in first to fetch your current setup.",
                    "Not Logged In",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Only fetch equipment
            Map<String, String> currentEquipment = new HashMap<>();
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                Item equippedItem = Equipment.getItemInSlot(slot);
                if (equippedItem != null) {
                    String slotName = getSlotName(slot);
                    if (slotName != null) {
                        currentEquipment.put(slotName, equippedItem.getName());
                        // Set ammo quantity if it's the ammo slot
                        if (slot == EquipmentSlot.ARROWS) {
                            ammoQuantitySpinner.setValue(equippedItem.getAmount());
                        }
                    }
                }
            }
            config.setEquipment(currentEquipment);
            config.setAmmoQuantity((Integer) ammoQuantitySpinner.getValue());

            // Refresh equipment display
            loadSettings();

            // Save the updated config
            config.saveConfig();

            JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),
                    "Current equipment has been fetched successfully!",
                    "Equipment Fetched",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            log("Error fetching current equipment: " + e.getMessage());
            JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),
                    "Error fetching equipment: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private String getSlotName(EquipmentSlot slot) {
        switch (slot) {
            case HAT: return "helmet";
            case CAPE: return "cape";
            case AMULET: return "necklace";
            case WEAPON: return "weapon";
            case CHEST: return "body";
            case SHIELD: return "shield";
            case LEGS: return "legs";
            case HANDS: return "hands";
            case FEET: return "boots";
            case RING: return "ring";
            case ARROWS: return "ammo";
            default: return null;
        }
    }

    public void loadSettings() {
        Map<String, String> equipment = config.getEquipment();
        equipmentSlots.forEach((slot, field) -> {
            field.setText(equipment.getOrDefault(slot, ""));
        });
        ammoQuantitySpinner.setValue(config.getAmmoQuantity());
    }

    public void saveSettings() {
        Map<String, String> equipment = new HashMap<>();
        equipmentSlots.forEach((slot, field) -> {
            String item = field.getText().trim();
            if (!item.isEmpty()) {
                equipment.put(slot, item);
            }
        });
        config.setEquipment(equipment);
        config.setAmmoQuantity((Integer) ammoQuantitySpinner.getValue());
    }
} 