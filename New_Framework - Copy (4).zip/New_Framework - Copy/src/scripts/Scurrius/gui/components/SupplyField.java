package scripts.Scurrius.gui.components;

import core.gui.style.StyleManager;

import javax.swing.*;

public class SupplyField {
    private final JTextField itemField;
    private final JSpinner quantitySpinner;
    
    public SupplyField(String defaultItem) {
        this.itemField = new JTextField(10);
        StyleManager.styleTextField(itemField);
        itemField.setText(defaultItem);

        SpinnerNumberModel spinnerModel = new SpinnerNumberModel(0, 0, 999999, 1);
        this.quantitySpinner = new JSpinner(spinnerModel);
        StyleManager.styleSpinner(quantitySpinner);
    }

    public String getItem() {
        return itemField.getText().trim();
    }

    public void setItem(String item) {
        itemField.setText(item);
    }

    public int getQuantity() {
        return (int) quantitySpinner.getValue();
    }

    public void setQuantity(int quantity) {
        quantitySpinner.setValue(quantity);
    }

    public JTextField getItemField() {
        return itemField;
    }

    public JSpinner getQuantitySpinner() {
        return quantitySpinner;
    }
} 