package scripts.Scurrius;

import com.google.gson.annotations.Expose;
import core.config.ScriptConfig;
import core.context.ScriptContext;
import core.grandexchange.GrandExchangeConfig;
import org.dreambot.api.utilities.Logger;
import scripts.Scurrius.enums.TeleportType;
import scripts.Scurrius.gui.ProfileFileManager;
import scripts.Scurrius.gui.data.ProfileData;

import java.io.File;
import java.util.*;

public class ScurriusConfig extends ScriptConfig implements GrandExchangeConfig {
    @Expose private int healthThreshold;
    @Expose private boolean inInstance = false;
    @Expose private boolean equipmentReady;
    @Expose private TeleportType teleportType = TeleportType.NONE;
    @Expose private int ammoQuantity = 0;
    @Expose private boolean useGrandExchange = false;
    @Expose private List<String> foodNames = new ArrayList<>();
    @Expose private int targetFoodCount = 0;
    @Expose private int suppliesMultiplier = 1;
    @Expose private Map<String, String> equipment = new HashMap<>();
    @Expose private Map<String, Integer> supplies = new HashMap<>();
    @Expose private boolean alchemyEnabled = false;
    private transient boolean dirty;

    public ScurriusConfig(ScriptContext context) {
        super(context, "scurrius_config");
        setDefaults();
    }

    @Override
    public boolean isDirty() {
        return dirty;
    }

    @Override
    public void markDirty() {
        this.dirty = true;
    }

    @Override
    public void markClean() {
        this.dirty = false;
    }

    @Override
    public void setDefaults() {
        healthThreshold = 40;
        ammoQuantity = 0;
        useGrandExchange = false;
        suppliesMultiplier = 1;
        foodNames = new ArrayList<>(Arrays.asList(
                "Cooked karambwan",
                "Shark",
                "Monkfish",
                "Lobster",
                "Swordfish",
                "Tuna"
        ));
        equipment = new HashMap<>();
        supplies = new HashMap<>();
        markDirty();
    }

    // GrandExchangeConfig implementation
    @Override
    public boolean isUsingGrandExchange() {
        return useGrandExchange;
    }

    @Override
    public void setUseGrandExchange(boolean use) {
        this.useGrandExchange = use;
        markDirty();
    }

    @Override
    public List<String> getFoodNames() {
        return foodNames;
    }

    @Override
    public void setFoodNames(List<String> foodNames) {
        this.foodNames = new ArrayList<>(foodNames);
        markDirty();
    }

    @Override
    public int getTargetFoodCount() {
        return targetFoodCount;
    }

    @Override
    public void setTargetFoodCount(int count) {
        this.targetFoodCount = count;
        markDirty();
    }

    @Override
    public int getSuppliesMultiplier() {
        return suppliesMultiplier;
    }

    @Override
    public void setSuppliesMultiplier(int multiplier) {
        this.suppliesMultiplier = multiplier;
        markDirty();
    }

    @Override
    public Map<String, Integer> getSupplies() {
        return supplies;
    }

    @Override
    public void setSupplies(Map<String, Integer> supplies) {
        this.supplies = new HashMap<>(supplies);
        markDirty();
    }

    @Override
    public Map<String, String> getEquipment() {
        return equipment;
    }

    @Override
    public void setEquipment(Map<String, String> equipment) {
        this.equipment = new HashMap<>(equipment);
        markDirty();
    }

    @Override
    public String getTeleportMethod() {
        return teleportType != null ? teleportType.toString() : TeleportType.NONE.toString();
    }

    @Override
    public void setTeleportMethod(String method) {
        if (method == null) {
            this.teleportType = TeleportType.NONE;
            markDirty();
            return;
        }
        
        for (TeleportType type : TeleportType.values()) {
            if (type.toString().equals(method)) {
                this.teleportType = type;
                markDirty();
                return;
            }
        }
        this.teleportType = TeleportType.NONE;
        markDirty();
    }

    @Override
    public boolean isAlchemyEnabled() {
        return alchemyEnabled;
    }

    @Override
    public void setAlchemyEnabled(boolean enabled) {
        this.alchemyEnabled = enabled;
        markDirty();
    }

    @Override
    protected void copyConfigValues(ScriptConfig other) {
        if (!(other instanceof ScurriusConfig)) {
            return;
        }

        ScurriusConfig config = (ScurriusConfig) other;

        // Copy basic config values
        this.healthThreshold = config.healthThreshold;
        this.inInstance = config.inInstance;
        this.equipmentReady = config.equipmentReady;
        this.teleportType = config.teleportType != null ? config.teleportType : TeleportType.NONE;
        this.ammoQuantity = config.ammoQuantity;

        // Copy GE-related values, preferring values from geConfig if present
        if (config.getCustomData("geConfig", null) != null) {
            @SuppressWarnings("unchecked")
            Map<String, Object> geConfig = config.getCustomData("geConfig", new HashMap<String, Object>());
            
            this.useGrandExchange = (Boolean) geConfig.getOrDefault("useGrandExchange", config.useGrandExchange);
            this.suppliesMultiplier = ((Number) geConfig.getOrDefault("suppliesMultiplier", config.suppliesMultiplier)).intValue();
            
            @SuppressWarnings("unchecked")
            List<String> loadedFoodNames = (List<String>) geConfig.getOrDefault("foodNames", config.foodNames);
            this.foodNames = new ArrayList<>(loadedFoodNames);
            
            this.targetFoodCount = ((Number) geConfig.getOrDefault("targetFoodCount", config.targetFoodCount)).intValue();
            
            @SuppressWarnings("unchecked")
            Map<String, String> loadedEquipment = (Map<String, String>) geConfig.getOrDefault("equipment", config.equipment);
            this.equipment = new HashMap<>(loadedEquipment);
            
            @SuppressWarnings("unchecked")
            Map<String, Integer> loadedSupplies = (Map<String, Integer>) geConfig.getOrDefault("supplies", config.supplies);
            this.supplies = new HashMap<>(loadedSupplies);
            
            String teleportMethod = (String) geConfig.get("teleportMethod");
            if (teleportMethod != null) {
                setTeleportMethod(teleportMethod);
            }
            
            this.alchemyEnabled = (Boolean) geConfig.getOrDefault("alchemyEnabled", config.alchemyEnabled);
        } else {
            // If no geConfig present, copy values directly
            this.useGrandExchange = config.useGrandExchange;
            this.suppliesMultiplier = config.suppliesMultiplier;
            this.foodNames = new ArrayList<>(config.foodNames);
            this.targetFoodCount = config.targetFoodCount;
            this.equipment = new HashMap<>(config.equipment);
            this.supplies = new HashMap<>(config.supplies);
            this.alchemyEnabled = config.alchemyEnabled;
        }

        markDirty();
    }

    // Additional utility methods
    public int getHealthThreshold() {
        return healthThreshold;
    }

    public void setHealthThreshold(int threshold) {
        this.healthThreshold = Math.min(99, Math.max(1, threshold));
        markDirty();
    }

    public boolean isInInstance() {
        return inInstance;
    }

    public void setInInstance(boolean inInstance) {
        this.inInstance = inInstance;
        markDirty();
    }

    public boolean isEquipmentReady() {
        return equipmentReady;
    }

    public void setEquipmentReady(boolean ready) {
        this.equipmentReady = ready;
        markDirty();
    }

    public TeleportType getTeleportType() {
        return teleportType != null ? teleportType : TeleportType.NONE;
    }

    public void setTeleportType(TeleportType type) {
        this.teleportType = type != null ? type : TeleportType.NONE;
        markDirty();
    }

    public int getAmmoQuantity() {
        return ammoQuantity;
    }

    public void setAmmoQuantity(int quantity) {
        this.ammoQuantity = quantity;
        markDirty();
    }
    public List<String> getAvailableProfiles() {
        Logger.log("Getting available profiles");
        List<String> profiles = ProfileFileManager.getAvailableProfiles();
        Logger.log("Found profiles: " + profiles);
        return profiles;
    }

    public void saveProfile(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }
        Logger.log("Attempting to save profile: " + name);

        ProfileData profileData = new ProfileData();
        profileData.setName(name.trim());
        profileData.setHealthThreshold(this.healthThreshold);
        profileData.setAmmoQuantity(this.ammoQuantity);
        profileData.setTeleportType(this.teleportType);
        profileData.setUseGrandExchange(this.useGrandExchange);
        profileData.setFoodNames(this.foodNames);
        profileData.setSuppliesMultiplier(this.suppliesMultiplier);
        profileData.setAlchemyEnabled(this.alchemyEnabled);
        profileData.setTargetFoodCount(this.targetFoodCount);
        profileData.setEquipment(this.equipment);
        profileData.setSupplies(this.supplies);

        try {
            ProfileFileManager.saveProfile(name.trim(), profileData);
            Logger.log("Profile saved successfully: " + name);
            dirty = true;
            saveConfig();
        } catch (Exception e) {
            Logger.log("Error saving profile: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void loadProfile(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }
        try {
            File profileFile = new File(ProfileFileManager.getProfilesDirectory(), name.trim() + ".json");
            ProfileData profileData = ProfileFileManager.loadProfile(profileFile);
            if (profileData != null) {
                this.healthThreshold = profileData.getHealthThreshold();
                this.ammoQuantity = profileData.getAmmoQuantity();
                this.teleportType = profileData.getTeleportType();
                this.useGrandExchange = profileData.isUseGrandExchange();
                this.foodNames = new ArrayList<>(profileData.getFoodNames());
                this.suppliesMultiplier = profileData.getSuppliesMultiplier();
                this.alchemyEnabled = profileData.isAlchemyEnabled();
                this.targetFoodCount = profileData.getTargetFoodCount();
                this.equipment = new HashMap<>(profileData.getEquipment());
                this.supplies = new HashMap<>(profileData.getSupplies());

                Logger.log("Profile loaded successfully: " + name);
                dirty = true;
                saveConfig();
            }
        } catch (Exception e) {
            Logger.log("Error loading profile: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void deleteProfile(String name) {
        if (name != null && !name.trim().isEmpty()) {
            Logger.log("Removing profile: " + name);

            boolean deleted = ProfileFileManager.deleteProfile(name.trim());
            if (deleted) {
                Logger.log("Deleted profile file: " + name);
            } else {
                Logger.log("Failed to delete profile file: " + name);
            }

            Logger.log("Remaining profiles: " + getAvailableProfiles());
            dirty = true;
            saveConfig();
        }
    }
}