package scripts.Duke;

import core.config.ScriptConfig;
import core.context.ScriptContext;
import org.dreambot.api.methods.prayer.Prayer;

import java.util.Arrays;
import java.util.List;

public class DukeConfig extends ScriptConfig {
    private int healthThreshold = 70;
    private String foodType = "Cooked karambwan";
    private List<Prayer> quickPrayers = Arrays.asList(
            Prayer.PROTECT_FROM_MELEE,
            Prayer.PIETY
    );
    private boolean use4TickCycle = false;
    private boolean use4TickCycleEnrage = true;

    private final int DEFAULT_HEALTH_THRESHOLD = 70;
    private final String DEFAULT_FOOD_TYPE = "Cooked karambwan";
    private final List<Prayer> DEFAULT_QUICK_PRAYERS = Arrays.asList(
            Prayer.PROTECT_FROM_MELEE,
            Prayer.PIETY
    );
    private final boolean DEFAULT_4_TICK_CYCLE = false;
    private final boolean DEFAULT_4_TICK_CYCLE_ENRAGE = true;

    private boolean dirty = false;

    public DukeConfig(ScriptContext context) {
        super(context, "duke_config");
        setDefaults();
    }

    @Override
    public void setDefaults() {
        // Set default configuration values
        healthThreshold = DEFAULT_HEALTH_THRESHOLD;
        foodType = DEFAULT_FOOD_TYPE;
        quickPrayers = DEFAULT_QUICK_PRAYERS;
        use4TickCycle = DEFAULT_4_TICK_CYCLE;
        use4TickCycleEnrage = DEFAULT_4_TICK_CYCLE_ENRAGE;
        markClean();
    }

    @Override
    public void copyConfigValues(ScriptConfig other) {
        if (other instanceof DukeConfig) {
            DukeConfig otherConfig = (DukeConfig) other;
            this.healthThreshold = otherConfig.getHealthThreshold();
            this.foodType = otherConfig.getFoodType();
            this.quickPrayers = otherConfig.getQuickPrayers();
            this.use4TickCycle = otherConfig.shouldUse4TickCycle();
            this.use4TickCycleEnrage = otherConfig.shouldUse4TickCycleEnrage();
            markDirty();
        }
    }

    @Override
    public boolean isDirty() {
        return dirty || 
               healthThreshold != DEFAULT_HEALTH_THRESHOLD ||
               !foodType.equals(DEFAULT_FOOD_TYPE) ||
               !quickPrayers.equals(DEFAULT_QUICK_PRAYERS) ||
               use4TickCycle != DEFAULT_4_TICK_CYCLE ||
               use4TickCycleEnrage != DEFAULT_4_TICK_CYCLE_ENRAGE;
    }

    @Override
    public void markDirty() {
        this.dirty = true;
    }

    @Override
    public void markClean() {
        this.dirty = false;
    }

    public int getHealthThreshold() {
        return healthThreshold;
    }

    public List<Prayer> getQuickPrayers() {
        return quickPrayers;
    }

    public boolean shouldUse4TickCycle() {
        return use4TickCycle;
    }

    public boolean shouldUse4TickCycleEnrage() {
        return use4TickCycleEnrage;
    }

    public void setHealthThreshold(int threshold) {
        this.healthThreshold = threshold;
        markDirty();
    }

    public void setQuickPrayers(List<Prayer> prayers) {
        this.quickPrayers = prayers;
        markDirty();
    }

    public void setUse4TickCycle(boolean use4Tick) {
        this.use4TickCycle = use4Tick;
        markDirty();
    }

    public void setUse4TickCycleEnrage(boolean use4TickEnrage) {
        this.use4TickCycleEnrage = use4TickEnrage;
        markDirty();
    }

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
        markDirty();
    }
} 