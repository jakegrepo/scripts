package scripts.Duke.gui;

import core.base.ScarScript;
import core.context.ScriptContext;
import core.gui.AbstractSettingsTab;
import core.gui.ScriptGUI;
import core.gui.SettingsPanel;
import core.gui.style.StyleManager;
import org.dreambot.api.methods.skills.Skill;
import scripts.Duke.DukeConfig;
import scripts.Duke.DukeScript;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class TestSettingsTab extends AbstractSettingsTab {
    private final DukeConfig config;
    private final GeneralPanel generalPanel;
    private JPanel debugPanel;

    public TestSettingsTab(ScriptContext context) {
        super(context);
        DukeScript script = (DukeScript) context.getScript();
        this.config = script.getConfig();
        this.generalPanel = new GeneralPanel(config);

        // Initialize debug panel
        this.debugPanel = createDebugPanel();

        // Load initial settings
        refreshAllDisplays();
    }

    private JPanel createDebugPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton openTestingButton = new JButton("Open Node Tester");
        StyleManager.styleButton(openTestingButton);

        openTestingButton.addActionListener(e -> {
            ScarScript<?> script = (ScarScript<?>) context.getScript();
            script.openTestingGUI();
        });

        panel.add(openTestingButton);
        return panel;
    }

    @Override
    public void createComponents() {
        // Add sections to this tab
        addSection("Debug Tools", debugPanel);
    }

    @Override
    public String getTitle() {
        return "Debug";
    }

    @Override
    public void saveSettings() {
        generalPanel.saveSettings();
        config.saveConfig();
    }

    @Override
    public void resetToDefaults() {
        config.setDefaults();
        refreshAllDisplays();
    }

    private void refreshAllDisplays() {
        generalPanel.loadSettings();
    }

    @Override
    protected File getProfilesDirectory() {
        File dir = new File("C:/TestScriptConfigs/");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }
}

class GeneralPanel extends SettingsPanel {
    private final DukeConfig config;
    private JComboBox<Skill> skillComboBox;
    private JSpinner levelSpinner;
    private boolean isLoading = false;

    public GeneralPanel(DukeConfig config) {
        super();
        this.config = config;
        initializeComponents();
        loadSettings();
    }

    private void initializeComponents() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.anchor = GridBagConstraints.NORTHWEST;

        // Skill Selection
        skillComboBox = new JComboBox<>(Skill.values());
        StyleManager.styleComboBox(skillComboBox);
        addFormField("Skill to Train", skillComboBox, gbc);

        // Target Level
        levelSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 99, 1));
        StyleManager.styleSpinner(levelSpinner);
        addFormField("Target Level", levelSpinner, gbc);

        // Add listeners
        skillComboBox.addActionListener(e -> {
            if (!isLoading) saveSettings();
        });
        levelSpinner.addChangeListener(e -> {
            if (!isLoading) saveSettings();
        });
    }

    private void addFormField(String label, JComponent field, GridBagConstraints gbc) {
        JPanel fieldPanel = new JPanel(new BorderLayout(15, 0));
        fieldPanel.setOpaque(false);
        fieldPanel.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));

        JLabel jLabel = new JLabel(label);
        StyleManager.styleLabel(jLabel);
        fieldPanel.add(jLabel, BorderLayout.WEST);

        JPanel fieldWrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        fieldWrapper.setOpaque(false);
        fieldWrapper.add(field);
        fieldPanel.add(fieldWrapper, BorderLayout.CENTER);

        add(fieldPanel, gbc);
    }

    public void loadSettings() {
        isLoading = true;
        try {
        } finally {
            isLoading = false;
        }
    }

    public void saveSettings() {
        config.markDirty();
    }
}