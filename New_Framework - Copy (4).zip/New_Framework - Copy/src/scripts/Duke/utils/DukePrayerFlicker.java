package scripts.Duke.utils;

import core.context.ScriptContext;
import org.dreambot.api.Client;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.prayer.Prayer;
import org.dreambot.api.methods.prayer.Prayers;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.widgets.WidgetChild;

public class DukePrayerFlicker implements GameTickListener {
    private int lastGameTick;
    private int gameTick;
    public boolean prayerFlickingRunning = false;
    private Thread prayerThread;
    private boolean shouldFlickPrayer = false;
    private Prayer currentPrayer = null;
    private final ScriptContext context;
    private static final int AWAKENED_DUKE_ID = 12191;
    private static final int DEAD_DUKE_ID = 12192;

    public DukePrayerFlicker(ScriptContext context) {
        this.lastGameTick = Client.getGameTick();
        Logger.log("Initializing CorpPrayerFlicker");
        this.context = context;
        Client.getInstance().getScriptManager().addListener(this);
        Logger.log("CorpPrayerFlicker initialized successfully");
    }

    @Override
    public void onGameTick() {
        NPC awakenedDuke = NPCs.closest(AWAKENED_DUKE_ID);
        NPC deadDuke = NPCs.closest(DEAD_DUKE_ID);

        gameTick++;
        try {
            // Only flick prayer if Duke is alive (not dead or null)
            shouldFlickPrayer = awakenedDuke != null && awakenedDuke.exists() && awakenedDuke.getHealthPercent() > 0;

            // If Duke is dead or not present, make sure prayers are off
            if (!shouldFlickPrayer && Prayers.isQuickPrayerActive()) {
                Logger.log("[PRAYER] Turning OFF prayers - Duke dead or not present");
                Prayers.toggleQuickPrayer(false);
            }
        } catch (Exception e) {
            Logger.error("Error in prayer flicker onGameTick: " + e.getMessage());
        }
    }

    public void startPrayerFlick() {
        if (!prayerFlickingRunning) {
            prayerFlickingRunning = true;
            context.getScript().getScriptManager().addListener(this);
            Thread prayerFlickingThread = new Thread(() -> {
                try {
                    while (prayerFlickingRunning && !Thread.currentThread().isInterrupted()) {
                        if (shouldFlickPrayer && Skills.getBoostedLevel(Skill.PRAYER) > 0) {
                            handlePrayerFlicking();
                        }
                        Sleep.sleep(100); // Add small delay to prevent excessive CPU usage
                    }
                } catch (Exception e) {
                    Logger.error("Prayer flicking thread error: " + e.getMessage());
                } finally {
                    prayerFlickingRunning = false;
                }
            });
            prayerFlickingThread.setDaemon(true);
            prayerFlickingThread.start();
        }
    }

    private void handlePrayerFlicking() {
        int currentGameTick = gameTick;
        if (currentGameTick != lastGameTick) {
            lastGameTick = currentGameTick;
            if (Skills.getBoostedLevel(Skill.PRAYER) > 0) {
                // Check if Duke is present and alive
                NPC awakenedDuke = NPCs.closest(AWAKENED_DUKE_ID);
                NPC deadDuke = NPCs.closest(DEAD_DUKE_ID);

                boolean dukeAlive = awakenedDuke != null && awakenedDuke.exists() && awakenedDuke.getHealthPercent() > 0;
                boolean dukeDead = deadDuke != null && deadDuke.exists();

                if (dukeAlive) {
                    // Duke is alive, make sure prayers are on
                    if (!Prayers.isQuickPrayerActive()) {
                        Logger.log("[PRAYER] Turning ON prayers - Duke alive");
                        Prayers.toggleQuickPrayer(true);
                    }
                } else {
                    // Duke is dead or not present, make sure prayers are off
                    if (Prayers.isQuickPrayerActive()) {
                        Logger.log("[PRAYER] Turning OFF prayers - Duke dead or not present");
                        Prayers.toggleQuickPrayer(false);
                    }
                }

                // If Duke is dead, explicitly log it
                if (dukeDead && Prayers.isQuickPrayerActive()) {
                    Logger.log("[PRAYER] Duke is DEAD - Turning OFF prayers");
                    Prayers.toggleQuickPrayer(false);
                }
            }
        }
    }

    private boolean togglePrayerWidget(Prayer prayer, boolean activate) {
        int child = getWidgetChildForPrayer(prayer);
        if (child == -1) {
            return false;
        }

        WidgetChild wc = Widgets.getWidgetChild(160, child);
        if (wc == null) {
            return false;
        }

        String action = activate ? "Activate" : "Deactivate";
        return wc.interact(action);
    }

    private int getWidgetChildForPrayer(Prayer prayer) {
        switch (prayer) {
            case PROTECT_FROM_MAGIC:
                return 21;
            case PROTECT_FROM_MISSILES:
                return 22;
            case PROTECT_FROM_MELEE:
                return 19;
            default:
                return -1;
        }
    }

    public void stop() {
        if (prayerFlickingRunning) {
            context.getScript().getScriptManager().removeListener(this);
            prayerFlickingRunning = false;
            shouldFlickPrayer = false;

            // Also turn off quick prayers if they're on
            if (Prayers.isQuickPrayerActive()) {
                Logger.log("[PRAYER] Explicitly turning OFF prayers when stopping flicker");
                Prayers.toggleQuickPrayer(false);
            }

            currentPrayer = null;
            Logger.log("Prayer flicker stopped and all protection prayers forcefully deactivated");
        }
    }

    /**
     * Explicitly check if Duke is dead and turn off prayers if needed
     */
    public void checkDukeDeadAndDisablePrayers() {
        NPC deadDuke = NPCs.closest(DEAD_DUKE_ID);
        NPC awakenedDuke = NPCs.closest(AWAKENED_DUKE_ID);

        boolean dukeDead = deadDuke != null && deadDuke.exists();
        boolean dukeAlive = awakenedDuke != null && awakenedDuke.exists() && awakenedDuke.getHealthPercent() > 0;

        if (dukeDead || !dukeAlive) {
            if (Prayers.isQuickPrayerActive()) {
                Logger.log("[PRAYER] Duke is dead or not present - Explicitly turning OFF prayers");
                Prayers.toggleQuickPrayer(false);
            }
        }
    }

}