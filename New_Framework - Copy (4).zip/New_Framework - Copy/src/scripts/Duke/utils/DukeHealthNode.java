package scripts.Duke.utils;

import core.context.ScriptContext;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.item.GroundItems;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.items.GroundItem;
import org.dreambot.api.wrappers.items.Item;

import java.util.Arrays;
import java.util.List;

public class DukeHealthNode implements GameTickListener {
    private static final int UNNOTE_WIDGET_ID = 149;
    private static final int UNNOTE_GROUP_ID = 0;
    private static final int UNNOTE_CHILD_ID = 0;

    private static final List<String> VALUABLE_DROPS = Arrays.asList(
        // Unique drops
        "Virtus robe bottom",
        "Virtus robe top",
        "Virtus mask",
        "Magus ring",
        "Leviathan's lure",
        "Siren's staff",
        "Executioner's axe head",
        "Eye of the duke",
        "Awakener's orb",
        "Nihil shard",
        "Salax salt",
        "Arder mushroom",
        "Musca mushroom",
        "Arder powder",
        "Musca powder",
        // Valuable drops
        "Rune platebody",
        "Rune platelegs",
        "Rune full helm",
        "Rune 2h sword",
        "Dragon med helm",
        "Dragon dagger",
        "Dragon longsword",
        "Dragon platelegs",
        "Dragon plateskirt",
        "Mystic robe top",
        "Mystic robe bottom",
        "Mystic hat",
        "Battlestaff",
        "Lava battlestaff",
        "Adamant platebody",
        "Rune kiteshield",
        "Rune crossbow",
        "Dragonstone",
        "Onyx bolt tips",
        "Uncut dragonstone",
        "Grimy ranarr weed",
        "Grimy snapdragon",
        "Grimy torstol",
        "Ranarr seed",
        "Snapdragon seed",
        "Torstol seed",
        "Yew seed",
        "Magic seed",
        "Palm tree seed",
        "Dragonfruit tree seed",
        "Celastrus seed",
        "Redwood tree seed",
        "Toadflax seed",
        "Dwarf weed seed",
        "Lantadyme seed",
        "Avantoe seed",
        "Kwuarm seed",
        "Cadantine seed",
        "Irit seed",
        "Marrentill seed",
        "Tarromin seed",
        "Harralander seed",
        "Ranarr weed",
        "Snapdragon",
        "Torstol",
        "Super restore(4)",
        "Prayer potion(4)",
        "Saradomin brew(4)",
        "Coins",
        "Rune arrow",
        "Dragon arrow",
        "Blood rune",
        "Death rune",
        "Soul rune",
        "Law rune",
        "Nature rune",
        "Cosmic rune",
        "Chaos rune",
        "Astral rune",
        "Wrath rune",
        "Adamantite bar",
        "Runite bar",
        "Adamantite ore",
        "Runite ore",
        "Coal",
        "Adamant javelin",
        "Rune javelin",
        "Rune javelin heads","Runite ore","Dragon javeline heads","Uncut ruby","Uncut diamond","Dragon arrowtips","Sapphire",
        "Dragon javelin","Emerald","Ruby","Bronze bar","Pineapple pizza","Awakener's orb","Raw sea turtle",
        "Rune dart",
        "Dragon dart",
        "Rune knife",
        "Dragon knife",
        "Clue scroll (elite)",
        "Clue scroll (hard)",
        "Clue scroll (medium)",
        "Clue scroll (easy)"
    );

    private static final int FOOD_ID = 3144;
    private static final int INGREDIENT_ID = 3145;
    private static final int TARGET_ID = 28767;
    private static final int MIN_FOOD_COUNT = 2;
    private static final int[] POTION_IDS = {3024, 3026, 3028, 3030,2434,139,141,143};
    private static final String DIVINE_SUPER_COMBAT_POTION_NAME = "Divine super combat potion";
    private int lastGameTick;
    private int gameTick;
    private boolean healthMonitoringRunning = false;
    private final ScriptContext context;
    private int healthThreshold;
    private String foodType;
    private boolean isTestMode = false;

    private boolean shouldEat = false;
    private boolean shouldDrink = false;
    private boolean shouldDrinkCombat = false;
    private boolean shouldUnnote = false;
    private boolean hasAwakenerOrb = false;
    private boolean shouldLoot = false;
    private GroundItem targetLoot = null;
    private int previousHealth;
    private Thread healthMonitoringThread;

    private static final List<String> VALUABLE_ITEMS_TO_NOTE = Arrays.asList(
        // Unique drops - always note these
        "Virtus robe bottom",
        "Virtus robe top",
        "Virtus mask",
        "Magus ring",
        "Leviathan's lure",
        "Siren's staff",
        "Executioner's axe head",
        "Eye of the duke",
        "Awakener's orb",
        "Nihil shard",
        "Dragon med helm",
        "Dragon dagger",
        "Dragon longsword",
        "Dragon platelegs",
        "Dragon plateskirt",
        "Mystic robe top",
        "Mystic robe bottom",
        "Mystic hat",
        "Battlestaff",
        "Lava battlestaff",
        "Rune platebody",
        "Rune platelegs",
        "Rune full helm",
        "Rune 2h sword",
        "Rune kiteshield",
        "Rune crossbow",
        "Dragonstone",
        "Uncut dragonstone",
        "Adamantite bar",
        "Runite bar");

    public DukeHealthNode(ScriptContext context, int healthThreshold, String foodType) {
        this.lastGameTick = Client.getGameTick();
        this.context = context;
        this.healthThreshold = healthThreshold;
        this.foodType = foodType;
        this.previousHealth = Skills.getBoostedLevel(Skill.HITPOINTS);
        Logger.log("Initializing DukeHealthNode");
        Logger.log("DukeHealthNode initialized successfully");
    }

    @Override
    public void onGameTick() {
        gameTick++;
        try {
            // Track damage taken
            int currentHealth = Skills.getBoostedLevel(Skill.HITPOINTS);
            if (currentHealth < previousHealth) {
                int damageTaken = previousHealth - currentHealth;
                Tile playerTile = Players.getLocal().getTile();
                int regX = playerTile.getX() % 64;
                Logger.log(String.format("[DAMAGE] Took %d damage | RegX: %d | Tile: %s | Tick:%s",
                    damageTaken, regX, playerTile.toString(),Client.getGameTick()));
            }
            previousHealth = currentHealth;

            // Check health and food flags
            shouldEat = isHealthLow();
            shouldDrink = isPrayerLow();
            shouldDrinkCombat = shouldDrinkCombatPotion();
            shouldUnnote = shouldUnnoteFood();

            // Check for valuable drops
            checkForLoot();
        } catch (Exception e) {
            Logger.error("Error in health monitoring: " + e.getMessage());
        }
    }

    // Define tiers of valuable drops for prioritization
    private static final List<String> TIER_1_DROPS = Arrays.asList(
        "Virtus robe bottom", "Virtus robe top", "Virtus mask",
        "Magus ring", "Leviathan's lure", "Siren's staff",
        "Executioner's axe head", "Eye of the duke", "Awakener's orb", "Nihil shard"
    );

    private static final List<String> TIER_2_DROPS = Arrays.asList(
        "Dragon med helm", "Dragon dagger", "Dragon longsword", "Dragon platelegs", "Dragon plateskirt",
        "Mystic robe top", "Mystic robe bottom", "Mystic hat", "Battlestaff", "Lava battlestaff",
        "Rune platebody", "Rune platelegs", "Rune full helm", "Rune 2h sword", "Rune kiteshield", "Rune crossbow",
        "Dragonstone", "Uncut dragonstone", "Adamantite bar", "Runite bar"
    );

    private void checkForLoot() {
        // Reset loot target if previous one is gone
        if (targetLoot != null && !targetLoot.exists()) {
            targetLoot = null;
        }

        // Only look for new loot if we're not already targeting something
        if (targetLoot == null) {
            // First check for tier 1 (most valuable) drops
            targetLoot = GroundItems.closest(item ->
                item != null && TIER_1_DROPS.contains(item.getName()));

            // If no tier 1 drops, check for tier 2 drops
            if (targetLoot == null) {
                targetLoot = GroundItems.closest(item ->
                    item != null && TIER_2_DROPS.contains(item.getName()));
            }

            // If still no target, check for any valuable drop
            if (targetLoot == null) {
                targetLoot = GroundItems.closest(item ->
                    item != null && VALUABLE_DROPS.contains(item.getName()));
            }

            if (targetLoot != null) {
                String tierInfo = "";
                if (TIER_1_DROPS.contains(targetLoot.getName())) {
                    tierInfo = "[TIER 1]";
                } else if (TIER_2_DROPS.contains(targetLoot.getName())) {
                    tierInfo = "[TIER 2]";
                } else {
                    tierInfo = "[TIER 3]";
                }

                Logger.log(String.format("[LOOT] %s Found valuable drop: %s (Quantity: %d)",
                    tierInfo, targetLoot.getName(), targetLoot.getAmount()));
                shouldLoot = true;
            }
        }
    }

    private boolean handleLooting() {
        if (targetLoot == null || !targetLoot.exists()) {
            shouldLoot = false;
            targetLoot = null;
            return false;
        }

        // If inventory is full, handle based on item value
        if (Inventory.isFull()) {
            // For high-value items, try to make space
            if (TIER_1_DROPS.contains(targetLoot.getName())) {
                // First try to eat food
                Item food = Inventory.get(item -> item != null && !item.isNoted() && item.hasAction("Eat"));
                if (food != null) {
                    Logger.log("[LOOT] Eating food to make space for high-value item: " + targetLoot.getName());
                    if (food.interact("Eat")) {
                        Sleep.sleepUntil(() -> !Inventory.isFull(), 1200);
                        return true;
                    }
                } else {
                    // If no food, try to drop a low-value item
                    Item lowValueItem = Inventory.get(item ->
                        item != null &&
                        !TIER_1_DROPS.contains(item.getName()) &&
                        !TIER_2_DROPS.contains(item.getName()) &&
                        !item.getName().equals("Cooked karambwan") &&
                        !item.getName().contains("Super restore") &&
                        !item.getName().contains("Prayer potion") &&
                        !item.getName().contains("Saradomin brew") &&
                        !item.getName().contains("Divine super combat"));

                    if (lowValueItem != null) {
                        Logger.log("[LOOT] Dropping low-value item to make space for: " + targetLoot.getName());
                        if (lowValueItem.interact("Drop")) {
                            Sleep.sleepUntil(() -> !Inventory.isFull(), 1200);
                            return true;
                        }
                    } else {
                        Logger.log("[LOOT] Inventory full of valuable items, can't make space for: " + targetLoot.getName());
                        shouldLoot = false;
                        targetLoot = null;
                        return false;
                    }
                }
            } else {
                // For lower-value items, only try to eat food
                Item food = Inventory.get(item -> item != null && !item.isNoted() && item.hasAction("Eat"));
                if (food != null) {
                    Logger.log("[LOOT] Eating food to make space for: " + targetLoot.getName());
                    if (food.interact("Eat")) {
                        Sleep.sleepUntil(() -> !Inventory.isFull(), 1200);
                        return true;
                    }
                } else {
                    Logger.log("[LOOT] Inventory full and no food to eat!");
                    shouldLoot = false;
                    targetLoot = null;
                    return false;
                }
            }
        }

        // Check if we need to walk to the loot
        if (targetLoot.distance() > 1) {
            Logger.log("[LOOT] Walking to loot: " + targetLoot.getName());
            if (Walking.walk(targetLoot.getTile())) {
                Sleep.sleepUntil(() -> targetLoot.distance() <= 1, 5000);
                return true;
            }
        }

        // Try to take the loot
        if (targetLoot.interact("Take")) {
            String tierInfo = "";
            if (TIER_1_DROPS.contains(targetLoot.getName())) {
                tierInfo = "[TIER 1]";
            } else if (TIER_2_DROPS.contains(targetLoot.getName())) {
                tierInfo = "[TIER 2]";
            } else {
                tierInfo = "[TIER 3]";
            }

            Logger.log(String.format("[LOOT] %s Picking up: %s (Quantity: %d)",
                tierInfo, targetLoot.getName(), targetLoot.getAmount()));

            Sleep.sleepUntil(() -> !targetLoot.exists(), 1200);

            // Check if we need to note the item
            if (VALUABLE_ITEMS_TO_NOTE.contains(targetLoot.getName())) {
                Item pickedItem = Inventory.get(targetLoot.getName());
                if (pickedItem != null && !pickedItem.isNoted()) {
                    Logger.log("[LOOT] Will note this valuable item later: " + targetLoot.getName());
                }
            }

            shouldLoot = false;
            targetLoot = null;
            return true;
        }

        return false;
    }

    private boolean isHealthLow() {
        int currentHealth = Skills.getBoostedLevel(Skill.HITPOINTS);
        return currentHealth <= healthThreshold;
    }
    private boolean isPrayerLow() {
        int currentPrayer = Skills.getBoostedLevel(Skill.PRAYER);
        int prayerThreshold = 30;
        return currentPrayer <= prayerThreshold;
    }
    private boolean shouldUnnoteFood() {
        // Check for unoted karambwan count
        long unnotedKarambwanCount = Inventory.count(item ->
            item != null &&
            item.getName().equals("Cooked karambwan") &&
            !item.isNoted()
        );

        // Check if we have noted karambwans available
        boolean hasNotedKarambwan = Inventory.contains(item ->
            item != null &&
            item.getName().equals("Cooked karambwan") &&
            item.isNoted()
        );

        // Return true if we have 2 or fewer unnoted karambwans and have noted ones available
        return unnotedKarambwanCount <= 2 && hasNotedKarambwan;
    }
    private boolean shouldNoteOrb() {
        // Check for any unnoted valuable items, regardless of whether we have noted versions
        return VALUABLE_ITEMS_TO_NOTE.stream().anyMatch(itemName ->
            Inventory.contains(item ->
                item != null &&
                !item.isNoted() &&
                item.getName().equals(itemName)
            )
        );
    }

    private boolean tryEatFood() {
        Item food = Inventory.get(item -> item != null && !item.isNoted() && item.hasAction("Eat"));
        if (food != null) {
            Logger.log("Eating " + food.getName());
            int initialCount = Inventory.count(food.getName());
            if (food.interact("Eat")) {
                return true;
            }
        }
        return false;
    }
    private boolean tryDrinkPotion() {
        Item potions = Inventory.get(POTION_IDS);
        if (potions != null) {
            Logger.log("Drinking " + potions.getName());
            int initialCount = Inventory.count(potions.getName());
            if (potions.interact("Drink")) {
                return true;
            }
        }
        return false;
    }

    private boolean shouldDrinkCombatPotion() {
        // Check if we have Divine super combat potion in inventory
        boolean hasCombatPotion = Inventory.contains(DIVINE_SUPER_COMBAT_POTION_NAME);

        if (!hasCombatPotion) {
            return false;
        }

        // Check if combat stats are below threshold (e.g., 10% below max)
        int strengthLevel = Skills.getBoostedLevel(Skill.STRENGTH);
        int strengthReal = Skills.getRealLevel(Skill.STRENGTH);
        int strengthThreshold = (int)(strengthReal * 0.9); // 90% of real level

        int attackLevel = Skills.getBoostedLevel(Skill.ATTACK);
        int attackReal = Skills.getRealLevel(Skill.ATTACK);
        int attackThreshold = (int)(attackReal * 0.9); // 90% of real level

        int defenseLevel = Skills.getBoostedLevel(Skill.DEFENCE);
        int defenseReal = Skills.getRealLevel(Skill.DEFENCE);
        int defenseThreshold = (int)(defenseReal * 0.9); // 90% of real level

        return strengthLevel < strengthThreshold ||
               attackLevel < attackThreshold ||
               defenseLevel < defenseThreshold;
    }

    private boolean tryDrinkCombatPotion() {
        Item combatPotion = Inventory.get(DIVINE_SUPER_COMBAT_POTION_NAME);
        if (combatPotion != null) {
            Logger.log("Drinking " + combatPotion.getName());
            if (combatPotion.interact("Drink")) {
                return true;
            }
        }
        return false;
    }



    public void startHealthMonitoring() {
        if (!healthMonitoringRunning) {
            healthMonitoringRunning = true;
            context.getScript().getScriptManager().addListener(this);
            healthMonitoringThread = new Thread(() -> {
                while (healthMonitoringRunning && !Thread.currentThread().isInterrupted()) {
                    try {
                        // First handle critical health-related actions
                        if (shouldDrink) {
                            tryDrinkPotion();
                        } else if (shouldDrinkCombat) {
                            tryDrinkCombatPotion();
                        } else if (shouldEat) {
                            tryEatFood();
                        }


                        boolean hasPotion = false;
                        for (int potionId : POTION_IDS) {
                            if (Inventory.count(potionId) > 0) {
                                hasPotion = true;
                                break;
                            }
                        }
                        boolean hasCombatPotion = Inventory.contains(item ->
                            item != null &&
                            !item.isNoted() &&
                            item.getName().equals(DIVINE_SUPER_COMBAT_POTION_NAME)
                        );

                        // Handle vial dropping
                        if (Inventory.contains("Vial")) {
                            Inventory.dropAll("Vial");
                        }


                        // Handle looting as the last priority
                        if (shouldLoot && targetLoot != null) {
                            try {
                                handleLooting();
                            } catch (Exception e) {
                                Logger.error("Error in handleLooting: " + e.getMessage());
                                // Reset looting state on error
                                shouldLoot = false;
                                targetLoot = null;
                            }
                        }

                        Thread.sleep(100); // Small delay to prevent excessive CPU usage
                    } catch (Exception e) {
                        Logger.error("Error in health monitoring loop: " + e.getMessage());
                        // Don't exit the loop on error, just continue to next iteration
                    }
                }
                Logger.log("Health monitoring thread ended normally");
            });
            healthMonitoringThread.setDaemon(true);
            healthMonitoringThread.start();
            Logger.log("Health monitoring started");
        }
    }

    public void stop() {
        if (healthMonitoringRunning) {
            context.getScript().getScriptManager().removeListener(this);
            healthMonitoringRunning = false;
            Client.getInstance().getScriptManager().removeListener(this);
            // Properly interrupt and wait for thread to finish
            if (healthMonitoringThread != null && healthMonitoringThread.isAlive()) {
                healthMonitoringThread.interrupt();
                try {
                    healthMonitoringThread.join(1000); // Wait up to 1 second for thread to finish
                } catch (InterruptedException e) {
                    Logger.error("Error while stopping health monitoring thread: " + e.getMessage());
                }
            }

            // Clear any state
            shouldEat = false;
            shouldDrink = false;
            shouldDrinkCombat = false;
            shouldUnnote = false;
            hasAwakenerOrb = false;
            shouldLoot = false;
            targetLoot = null;

            Logger.log("Health monitoring stopped and thread cleaned up");
        }
    }

    public void setHealthThreshold(int threshold) {
        this.healthThreshold = threshold;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public void setupTestMode() {
        isTestMode = true;
        if (!healthMonitoringRunning) {
            Logger.log("Test Mode: Starting health monitoring");
            startHealthMonitoring();
        }
    }
}