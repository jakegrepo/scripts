package scripts.Duke.utils;

import core.context.ScriptContext;
import core.paint.debug.DebugOverlay;
import org.dreambot.api.Client;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.GraphicsObjects;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.graphics.GraphicsObject;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * A specialized debug overlay for the Duke script that tracks and displays
 * projectiles, graphics objects, and other Duke-specific elements.
 */
public class DukeDebugOverlay extends DebugOverlay {
    // Duke NPC IDs
    private static final int SLEEPING_DUKE_ID = 12167;
    private static final int AWAKENED_DUKE_ID = 12191;

    // GameObject IDs
    private static final int[] SPECIAL_GAME_OBJECT_IDS = {47546, 47544, 47545};

    // GraphicsObject IDs
    private static final int SPECIAL_GRAPHICS_OBJECT_ID = 538;

    // Colors for different elements
    private static final Color DUKE_COLOR = new Color(255, 0, 255, 100); // Purple
    private static final Color PROJECTILE_PATH_COLOR = new Color(255, 255, 0, 200); // Yellow
    private static final Color PROJECTILE_TARGET_COLOR = new Color(255, 0, 0, 150); // Red
    private static final Color GRAPHICS_OBJECT_COLOR = new Color(0, 255, 255, 150); // Cyan
    private static final Color SPECIAL_OBJECT_COLOR = new Color(0, 255, 0, 150); // Green

    // Track projectiles and graphics objects
    private final List<Projectile> trackedProjectiles = new CopyOnWriteArrayList<>();
    private final ConcurrentHashMap<Integer, Long> graphicsObjectSpawnTimes = new ConcurrentHashMap<>();

    public DukeDebugOverlay(ScriptContext context) {
        super(context);
        // Enable visuals by default for Duke script
        toggle();
    }

    @Override
    public void render(Graphics2D g) {
        // Make sure visuals are enabled
        if (!areVisualsEnabled()) {
            toggle();
        }

        // Clear previous highlights
        clearTileHighlights();
        clearProjectileHighlights();

        // Update Duke-specific elements
        updateDukeHighlights();
        updateProjectileTracking();
        updateGraphicsObjectTracking();
        updateSpecialGameObjects();
        updateSpecialGraphicsObjects();

        // Let the parent class handle rendering
        super.render(g);
    }

    /**
     * Highlight special game objects with IDs 47546, 47544, and 47545
     */
    private void updateSpecialGameObjects() {
        try {
            // Find all game objects with the specified IDs
            List<GameObject> specialObjects = GameObjects.all(obj -> {
                if (obj == null) return false;

                for (int id : SPECIAL_GAME_OBJECT_IDS) {
                    if (obj.getID() == id) return true;
                }
                return false;
            });

            if (!specialObjects.isEmpty()) {
                Logger.info("[DEBUG] Found " + specialObjects.size() + " special game objects");

                for (GameObject obj : specialObjects) {
                    // Create a more visible highlight
                    Tile objTile = obj.getTile();
                    if (objTile != null) {
                        // Highlight the object with a bright color and clear label
                        highlightTile(objTile, SPECIAL_OBJECT_COLOR, "ID: " + obj.getID());

                        // Add a border around the object for better visibility
                        for (int x = -1; x <= 1; x++) {
                            for (int y = -1; y <= 1; y++) {
                                if (x == 0 && y == 0) continue; // Skip the center tile
                                Tile borderTile = objTile.translate(x, y);
                                highlightTile(borderTile, new Color(255, 255, 255, 50), null);
                            }
                        }

                        // Log object details
                        Logger.info(String.format(
                            "[SPECIAL GAME OBJECT] ID: %d, Name: %s, Tile: %s, Actions: %s",
                            obj.getID(),
                            obj.getName(),
                            objTile.toString(),
                            String.join(", ", obj.getActions())
                        ));
                    }
                }
            }
        } catch (Exception e) {
            Logger.error("Error updating special game objects: " + e.getMessage());
        }
    }

    /**
     * Highlight special graphics objects with ID 538
     */
    private void updateSpecialGraphicsObjects() {
        try {
            // Find all graphics objects with ID 538
            List<GraphicsObject> specialGraphics = GraphicsObjects.all(obj ->
                obj != null && obj.getID() == SPECIAL_GRAPHICS_OBJECT_ID);

            if (!specialGraphics.isEmpty()) {
                Logger.info("[DEBUG] Found " + specialGraphics.size() + " special graphics objects (ID: 538)");

                for (GraphicsObject obj : specialGraphics) {
                    Tile objTile = obj.getTile();
                    if (objTile != null) {
                        // Use a bright orange color for better visibility
                        Color gfxColor = new Color(255, 128, 0, 200);

                        // Highlight the object with a clear label
                        highlightTile(objTile, gfxColor, "GFX: 538");

                        // Add a pulsing effect by highlighting surrounding tiles
                        for (int x = -1; x <= 1; x++) {
                            for (int y = -1; y <= 1; y++) {
                                if (x == 0 && y == 0) continue; // Skip the center tile
                                Tile borderTile = objTile.translate(x, y);
                                highlightTile(borderTile, new Color(255, 128, 0, 100), null);
                            }
                        }

                        // Log object details with more information
                        Logger.info(String.format(
                            "[SPECIAL GRAPHICS OBJECT] ID: %d, Tile: %s, Height: %d",
                            obj.getID(),
                            objTile.toString(),
                            obj.getHeight()
                        ));
                    }
                }
            }
        } catch (Exception e) {
            Logger.error("Error updating special graphics objects: " + e.getMessage());
        }
    }

    /**
     * Highlight the Duke NPCs
     */
    private void updateDukeHighlights() {
        try {
            // Highlight Sleeping Duke
            NPC sleepingDuke = NPCs.closest(SLEEPING_DUKE_ID);
            if (sleepingDuke != null) {
                highlightNPCTileArea(sleepingDuke, DUKE_COLOR, "Sleeping Duke");
            }

            // Highlight Awakened Duke
            NPC awakenedDuke = NPCs.closest(AWAKENED_DUKE_ID);
            if (awakenedDuke != null) {
                highlightNPCTileArea(awakenedDuke, DUKE_COLOR, "Awakened Duke");
            }
        } catch (Exception e) {
            Logger.error("Error updating Duke highlights: " + e.getMessage());
        }
    }

    /**
     * Track and highlight projectiles
     */
    private void updateProjectileTracking() {
        try {
            // Get all current projectiles
            List<Projectile> currentProjectiles = Client.getProjectiles();

            // Log all projectiles
            if (!currentProjectiles.isEmpty()) {
                Logger.info("[DEBUG] Found " + currentProjectiles.size() + " projectiles");

                for (Projectile projectile : currentProjectiles) {
                    // Get the player's tile as the start tile
                    Tile startTile = Players.getLocal().getTile();

                    // Calculate an approximate end tile based on projectile's speed
                    // Since we don't have direct velocity components, use a simple offset
                    int dx = 3;
                    int dy = 3;
                    Tile endTile = startTile.translate(dx, dy);

                    // Log projectile details
                    Logger.info(String.format(
                        "[PROJECTILE] ID: %d, Speed: %d, Height: %d",
                        projectile.getID(),
                        projectile.getSpeedX(),
                        projectile.getHeight()
                    ));

                    // Highlight the projectile path and target
                    highlightProjectile(projectile, startTile, endTile,
                        PROJECTILE_PATH_COLOR,
                        PROJECTILE_TARGET_COLOR);
                }
            }

            // Update tracked projectiles
            trackedProjectiles.clear();
            trackedProjectiles.addAll(currentProjectiles);
        } catch (Exception e) {
            Logger.error("Error updating projectile tracking: " + e.getMessage());
        }
    }

    /**
     * Track and highlight graphics objects
     */
    private void updateGraphicsObjectTracking() {
        try {
            // Get all current graphics objects
            List<GraphicsObject> graphicsObjects = GraphicsObjects.all();

            // Log all graphics objects
            if (!graphicsObjects.isEmpty()) {
                Logger.info("[DEBUG] Found " + graphicsObjects.size() + " graphics objects");

                for (GraphicsObject obj : graphicsObjects) {
                    // Log graphics object details
                    Logger.info(String.format(
                        "[GRAPHICS OBJECT] ID: %d, Tile: %s, Height: %d",
                        obj.getID(),
                        obj.getTile().toString(),
                        obj.getHeight()
                    ));

                    // Highlight the graphics object tile
                    highlightTile(obj.getTile(), GRAPHICS_OBJECT_COLOR, "GFX: " + obj.getID());

                    // Record spawn time if new
                    int hash = obj.hashCode();
                    if (!graphicsObjectSpawnTimes.containsKey(hash)) {
                        graphicsObjectSpawnTimes.put(hash, System.currentTimeMillis());
                    }
                }
            }

            // Clean up old graphics objects
            List<Integer> toRemove = new ArrayList<>();
            long currentTime = System.currentTimeMillis();
            graphicsObjectSpawnTimes.forEach((hash, time) -> {
                if (currentTime - time > 5000) { // Remove after 5 seconds
                    toRemove.add(hash);
                }
            });
            toRemove.forEach(graphicsObjectSpawnTimes::remove);
        } catch (Exception e) {
            Logger.error("Error updating graphics object tracking: " + e.getMessage());
        }
    }
}
