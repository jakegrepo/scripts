package scripts.Duke.utils;

import core.context.ScriptContext;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.GraphicsObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.graphics.GraphicsObject;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;

import java.awt.*;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * A specialized debug overlay for the Duke script that highlights
 * specific game objects and graphics objects.
 */
public class DukeDebugOverlay2 {
    private final ScriptContext context;
    private boolean enabled = true;

    // Duke NPC IDs
    private static final int SLEEPING_DUKE_ID = 12167;
    private static final int AWAKENED_DUKE_ID = 12191;

    // GameObject IDs
    private static final int[] SPECIAL_GAME_OBJECT_IDS = {47546, 47544, 47545};

    // GraphicsObject IDs
    private static final int SPECIAL_GRAPHICS_OBJECT_ID = 538;

    // Colors for different elements
    private static final Color DUKE_COLOR = new Color(255, 0, 255, 100); // Purple
    private static final Color SPECIAL_OBJECT_COLOR = new Color(0, 255, 0, 180); // Bright Green
    private static final Color SPECIAL_GRAPHICS_COLOR = new Color(255, 128, 0, 180); // Orange

    // Maps to track object appearance times
    private final Map<Integer, Long> gameObjectTimers = new ConcurrentHashMap<>();
    private final Map<Integer, Long> graphicsObjectTimers = new ConcurrentHashMap<>();

    public DukeDebugOverlay2(ScriptContext context) {
        this.context = context;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Call this method to render the debug overlay.
     * Typically, your main script's paint method would call this.
     */
    public void render(Graphics2D g) {
        if (!enabled) return;

        // Clean up expired timers
        cleanupTimers();

        renderDukeHighlights(g);
        renderSpecialGameObjects(g);
        renderSpecialGraphicsObjects(g);
    }

    /**
     * Renders the Duke NPCs (Sleeping and Awakened).
     */
    private void renderDukeHighlights(Graphics2D g) {
        NPC sleepingDuke = NPCs.closest(SLEEPING_DUKE_ID);
        NPC awakenedDuke = NPCs.closest(AWAKENED_DUKE_ID);

        if (sleepingDuke != null && sleepingDuke.exists()) {
            renderNPCOverlay(g, sleepingDuke, "Sleeping Duke", DUKE_COLOR);
        }

        if (awakenedDuke != null && awakenedDuke.exists()) {
            renderNPCOverlay(g, awakenedDuke, "Awakened Duke", DUKE_COLOR);
        }
    }

    /**
     * Renders special game objects with IDs 47546, 47544, and 47545.
     */
    private void renderSpecialGameObjects(Graphics2D g) {
        List<GameObject> specialObjects = GameObjects.all(obj -> {
            if (obj == null) return false;

            for (int id : SPECIAL_GAME_OBJECT_IDS) {
                if (obj.getID() == id) return true;
            }
            return false;
        });

        if (!specialObjects.isEmpty()) {
            Logger.info("[DEBUG] Found " + specialObjects.size() + " special game objects");

            for (GameObject obj : specialObjects) {
                int objId = obj.getID();

                // Start timer if this is a new object
                if (!gameObjectTimers.containsKey(objId)) {
                    gameObjectTimers.put(objId, System.currentTimeMillis());
                    Logger.info(String.format(
                        "[SPECIAL GAME OBJECT] New object appeared: ID: %d, Name: %s, Tile: %s",
                        objId,
                        obj.getName(),
                        obj.getTile().toString()
                    ));
                }

                // Get the elapsed time
                long startTime = gameObjectTimers.get(objId);
                String elapsedTime = formatElapsedTime(startTime);

                Tile tile = obj.getTile();
                if (tile != null) {
                    Polygon poly = tile.getPolygon();
                    if (poly != null) {
                        // Fill the polygon with the special object color
                        g.setColor(SPECIAL_OBJECT_COLOR);
                        g.fillPolygon(poly);

                        // Draw the outline in black
                        g.setColor(Color.BLACK);
                        g.drawPolygon(poly);

                        // Draw the timer instead of ID
                        Point center = new Point(
                            (poly.xpoints[0] + poly.xpoints[2]) / 2,
                            (poly.ypoints[0] + poly.ypoints[2]) / 2
                        );
                        g.setColor(Color.WHITE);
                        g.drawString(elapsedTime, center.x - 20, center.y);
                    }
                }
            }
        }
    }

    /**
     * Renders special graphics objects with ID 538.
     */
    private void renderSpecialGraphicsObjects(Graphics2D g) {
        List<GraphicsObject> specialGraphics = GraphicsObjects.all(obj ->
            obj != null && obj.getID() == SPECIAL_GRAPHICS_OBJECT_ID);

        if (!specialGraphics.isEmpty()) {
            Logger.info("[DEBUG] Found " + specialGraphics.size() + " special graphics objects (ID: 538)");

            for (GraphicsObject obj : specialGraphics) {
                // Create a unique ID for this graphics object based on its location
                // This allows us to track multiple instances of the same graphics object ID
                int uniqueId = obj.getID() * 31 + obj.getTile().hashCode();

                // Start timer if this is a new graphics object
                if (!graphicsObjectTimers.containsKey(uniqueId)) {
                    graphicsObjectTimers.put(uniqueId, System.currentTimeMillis());
                    Logger.info(String.format(
                        "[SPECIAL GRAPHICS OBJECT] New graphics object appeared: ID: %d, Tile: %s, Height: %d",
                        obj.getID(),
                        obj.getTile().toString(),
                        obj.getHeight()
                    ));
                }

                // Get the elapsed time
                long startTime = graphicsObjectTimers.get(uniqueId);
                String elapsedTime = formatElapsedTime(startTime);

                Tile tile = obj.getTile();
                if (tile != null) {
                    Polygon poly = tile.getPolygon();
                    if (poly != null) {
                        // Fill the polygon with the special graphics color
                        g.setColor(SPECIAL_GRAPHICS_COLOR);
                        g.fillPolygon(poly);

                        // Draw the outline in black
                        g.setColor(Color.BLACK);
                        g.drawPolygon(poly);

                        // Draw the timer instead of ID
                        Point center = new Point(
                            (poly.xpoints[0] + poly.xpoints[2]) / 2,
                            (poly.ypoints[0] + poly.ypoints[2]) / 2
                        );
                        g.setColor(Color.WHITE);
                        g.drawString(elapsedTime, center.x - 20, center.y);
                    }
                }
            }
        } else {
            // If no graphics objects are found, log when the last one disappeared
            if (!graphicsObjectTimers.isEmpty()) {
                Logger.info("[SPECIAL GRAPHICS OBJECT] All graphics objects have disappeared");
                graphicsObjectTimers.clear();
            }
        }
    }

    /**
     * Helper method to render an overlay for the given NPC.
     */
    private void renderNPCOverlay(Graphics2D g, NPC npc, String label, Color fillColor) {
        Tile tile = npc.getTile();
        Polygon poly = tile.getPolygon();
        if (poly != null) {
            g.setColor(fillColor);
            g.fillPolygon(poly);
            g.setColor(Color.BLACK);
            g.drawPolygon(poly);

            Point center = new Point(
                (poly.xpoints[0] + poly.xpoints[2]) / 2,
                (poly.ypoints[0] + poly.ypoints[2]) / 2
            );
            g.setColor(Color.WHITE);
            g.drawString(label, center.x - 30, center.y);
        }
    }

    /**
     * Format elapsed time in seconds and milliseconds
     */
    private String formatElapsedTime(long startTimeMs) {
        long elapsedMs = System.currentTimeMillis() - startTimeMs;
        long seconds = TimeUnit.MILLISECONDS.toSeconds(elapsedMs) % 60;
        long millis = elapsedMs % 1000;
        return String.format("%d.%03ds", seconds, millis);
    }

    /**
     * Clean up expired timers (objects that no longer exist)
     */
    private void cleanupTimers() {
        // Get current objects to check against timers
        List<GameObject> currentGameObjects = GameObjects.all(obj -> {
            if (obj == null) return false;
            for (int id : SPECIAL_GAME_OBJECT_IDS) {
                if (obj.getID() == id) return true;
            }
            return false;
        });

        List<GraphicsObject> currentGraphicsObjects = GraphicsObjects.all(obj ->
            obj != null && obj.getID() == SPECIAL_GRAPHICS_OBJECT_ID);

        // Convert to sets of IDs for faster lookup
        java.util.Set<Integer> currentGameObjectIds = new java.util.HashSet<>();
        java.util.Set<Integer> currentGraphicsObjectIds = new java.util.HashSet<>();

        for (GameObject obj : currentGameObjects) {
            currentGameObjectIds.add(obj.getID());
        }

        for (GraphicsObject obj : currentGraphicsObjects) {
            // Use a unique identifier since graphics objects with same ID can appear in different locations
            int uniqueId = obj.getID() * 31 + obj.getTile().hashCode();
            currentGraphicsObjectIds.add(uniqueId);
        }

        // Remove timers for objects that no longer exist
        gameObjectTimers.keySet().removeIf(id -> !currentGameObjectIds.contains(id));
        graphicsObjectTimers.keySet().removeIf(id -> !currentGraphicsObjectIds.contains(id));
    }
}
