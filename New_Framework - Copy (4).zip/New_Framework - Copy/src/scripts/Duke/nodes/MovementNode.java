package scripts.Duke.nodes;

import core.base.SimpleNode;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.prayer.Prayer;
import org.dreambot.api.methods.prayer.Prayers;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.methods.worldhopper.WorldHopper;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;
import org.dreambot.api.wrappers.widgets.WidgetChild;
import scripts.Duke.DukeConfig;
import scripts.Duke.DukeScript;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MovementNode extends SimpleNode<DukeConfig> {
    private final DukeScript script;
    private volatile boolean isEating = false;
    private boolean needsResupply = false;
    Tile gateTile = new Tile (3039,6433,0);
    Tile targetTile = new Tile (3039,6430,0);
    private static final String FOOD = "Shark";

    public MovementNode(DukeConfig config, DukeScript script) {
        super("Movement", 2, config);
        this.script = script;
    }

    @Override
    public boolean validate() {
        // If we're already in the instance, don't need to move
        if (Client.isDynamicRegion()) {
            return false;
        }
        
        // Check if we're near the gate
        GameObject gate = GameObjects.closest("Gate");
        if (gate != null && gate.hasAction("Open") && 
            Players.getLocal().getTile().distance(gateTile) <= 10) {
            return true;
        }
        int foodCount = Inventory.count(FOOD);
if (foodCount <= 17){
    return false;
}
        // Or if we need to walk to the gate area
        return Players.getLocal().getTile().distance(targetTile) > 3;
    }

    @Override
    protected int onExecute() {
        // If we're close to the gate, attempt to open it
        GameObject gate = GameObjects.closest("Gate");
        if (gate != null && gate.hasAction("Open") && 
            Players.getLocal().getTile().distance(gateTile) <= 10) {
            Logger.log("Opening gate to enter Duke's lair");
            if (gate.interact("Open")) {
                Sleep.sleepUntil(Client::isDynamicRegion, 3000);
                return 600;
            }
        }

        // If we're already at the target area, we're done
        if (Client.isDynamicRegion()) {
            Logger.log("Already at duke area");
            return 600;
        }

        // If we need to walk to the gate
        Logger.log("Walking to Duke gate at " + targetTile);
        if (Walking.walk(targetTile)) {
            Sleep.sleepUntil(() -> Players.getLocal().getTile().distance(targetTile) <= 3, 5000);
        } else {
            Logger.log("Failed to start moving to duke gate");
        }

        return 600;
    }
}
