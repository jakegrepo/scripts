package scripts.Duke.nodes;

import core.base.SimpleNode;
import core.grandexchange.RestockGrandExchangeNode;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.bank.BankLocation;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.prayer.Prayer;
import org.dreambot.api.methods.prayer.Prayers;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import scripts.Duke.DukeConfig;
import scripts.Duke.DukeScript;

import java.util.Arrays;
import java.util.List;

public class BankingNode extends SimpleNode<DukeConfig> {
    private final DukeScript script;

    // Banking states
    private enum BankingState {
        CHECK_SUPPLIES,
        TELEPORT_TO_HOUSE,
        USE_POOL,
        TELEPORT_TO_CASTLE_WARS,
        BANK_AT_CASTLE_WARS,
        FINISHED
    }

    // Items to keep during deposit all
    private static final List<String> ITEMS_TO_KEEP = Arrays.asList(
            "Pestle and mortar",
            "Bandos godsword",
            "Teleport to house"
    );

    // Items to withdraw
    private static final String SUPER_COMBAT_POTION = "Divine super combat potion(4)";
    private static final String SUPER_RESTORE = "Super restore(4)";
    private static final String STAMINA_POTION = "Stamina potion(4)";
    private static final String FOOD = "Shark";
    private static final String BGS = "Bandos godsword";
    private static final String POH = "Teleport to house";



    // Withdraw quantities
    private static final int SUPER_COMBAT_QUANTITY = 1;
    private static final int SUPER_RESTORE_QUANTITY = 4;
    private static final int STAMINA_QUANTITY = 1;
    private static final int FOOD_QUANTITY = 18;

    private BankingState currentState = BankingState.CHECK_SUPPLIES;

    public BankingNode(DukeConfig config, DukeScript script) {
        super("Banking", 1, config); // Priority 2 (higher than movement, lower than combat)
        this.script = script;
    }

    @Override
    public boolean validate() {
        // Check if Duke is dead
        NPC duke = NPCs.closest(12191); // Awakened Duke ID
        NPC deadDuke = NPCs.closest(12192); // Dead Duke ID

        // Check food count
        int foodCount = Inventory.count(FOOD);

        // Check for valuable ground items that need to be looted
        boolean valuableItemsOnGround = hasValuableItemsToLoot();

        // Only validate if:
        // 1. Duke is not present or dead AND
        // 2. We're low on food AND
        // 3. There are NO valuable items to loot
        return (duke == null || deadDuke != null) &&
               (foodCount <= 2 || foodCount == 0) &&
               !valuableItemsOnGround;
    }

    /**
     * Check if there are valuable items on the ground that need to be looted
     */
    private boolean hasValuableItemsToLoot() {
        // Define valuable items to check for
        List<String> valuableItems = Arrays.asList(
            "Virtus robe bottom", "Virtus robe top", "Virtus mask",
            "Magus ring", "Leviathan's lure", "Siren's staff",
            "Executioner's axe head", "Eye of the duke", "Awakener's orb", "Nihil shard"
        );

        // Check if any valuable items are on the ground
        return org.dreambot.api.methods.item.GroundItems.closest(item ->
            item != null && valuableItems.contains(item.getName())) != null;
    }

    private boolean isDukeDead() {
        NPC deadDuke = NPCs.closest(12192); // Dead Duke ID
        return deadDuke != null;
    }

    @Override
    protected int onExecute() {
        try {
            Logger.log("[BANKING] Current state: " + currentState);

            switch (currentState) {
                case CHECK_SUPPLIES:
                    Logger.log("[BANKING] Checking supplies, need to bank");
                    currentState = BankingState.TELEPORT_TO_HOUSE;
                    return 300;

                case TELEPORT_TO_HOUSE:
                    return teleportToHouse();

                case USE_POOL:
                    return usePool();

                case TELEPORT_TO_CASTLE_WARS:
                    return teleportToCastleWars();

                case BANK_AT_CASTLE_WARS:
                    return bankAtCastleWars();

                case FINISHED:
                    resetState();
                    return 100;

                default:
                    resetState();
                    return 600;
            }
        } catch (Exception e) {
            Logger.log("[BANKING] Error: " + e.getMessage());
            resetState();
            return 1000;
        }
    }

    private int teleportToHouse() {
        // Use "Teleport to house" with "Break" action
        if (Inventory.contains("Teleport to house") && !(BankLocation.CASTLE_WARS.getTile().distance(Players.getLocal()) <= 10)) {
            Logger.log("[BANKING] Teleporting to house");
            if (Inventory.interact("Teleport to house", "Break")) {
                // Wait until we're not in the instance and a pool appears
                if (Sleep.sleepUntil(() -> Client.isDynamicRegion() && GameObjects.closest(obj ->
                        obj.getName().toLowerCase().contains("pool")) != null, 8000)) {
                    currentState = BankingState.USE_POOL;
                    return 500;
                }
            }
            return 1000; // Try again
        } else {
            Logger.log("[BANKING] No house teleport found, going to Castle Wars directly");
            currentState = BankingState.TELEPORT_TO_CASTLE_WARS;
            return 300;
        }
    }

    private int usePool() {
        // Use the rejuvenation pool
        GameObject pool = GameObjects.closest(obj -> obj.getName().toLowerCase().contains("pool"));
        if (pool != null) {
            Logger.log("[BANKING] Using pool " + pool.getName());
            if (pool.interact("Drink")) {
                // Wait until health and prayer are fully restored
                if (Sleep.sleepUntil(() ->
                    Skills.getBoostedLevel(Skill.HITPOINTS) == Skills.getRealLevel(Skill.HITPOINTS) &&
                    Skills.getBoostedLevel(Skill.PRAYER) == Skills.getRealLevel(Skill.PRAYER),
                    5000)) {
                    currentState = BankingState.TELEPORT_TO_CASTLE_WARS;
                    return 500;
                }
            }
            return 1000; // Try again
        } else {
            Logger.log("[BANKING] Pool not found, moving to Castle Wars");
            currentState = BankingState.TELEPORT_TO_CASTLE_WARS;
            return 300;
        }
    }

    private int teleportToCastleWars() {
        // Use the jewelery box to teleport to Castle Wars
        GameObject jewelryBox = GameObjects.closest("Basic Jewellery Box");
        if (jewelryBox != null) {
            Logger.log("[BANKING] Using jewelery box to teleport to Castle Wars");
            if (jewelryBox.interact("Castle Wars")) {
                // Wait until we arrive at Castle Wars (bank is visible)
                if (Sleep.sleepUntil(() -> Players.getLocal().distance(BankLocation.CASTLE_WARS.getArea(4).getCenter()) <= 10, 8000)) {
                    currentState = BankingState.BANK_AT_CASTLE_WARS;
                    return 500;
                }
            }
            return 1000; // Try again
        } else {
            Logger.log("[BANKING] Jewelery box not found, going to bank directly");
            currentState = BankingState.BANK_AT_CASTLE_WARS;
            return 300;
        }
    }

    private int bankAtCastleWars() {
        // Check if bank is already open
        if (!Bank.isOpen()) {
            Logger.log("[BANKING] Opening bank at Castle Wars");
            if (Bank.open()) {
                Sleep.sleepUntil(Bank::isOpen, 5000);
                return 600;
            }
            return 1000; // Try again
        }

        // Check if restock is needed
        if (script.getScriptConfig().getRestockConfig().isEnabled()) {
            // Get the RestockGrandExchangeNode from the script
            RestockGrandExchangeNode restockNode = script.getContext().tasks().getNodes().stream()
                .filter(node -> node instanceof RestockGrandExchangeNode)
                .map(node -> (RestockGrandExchangeNode) node)
                .findFirst().orElse(null);

            if (restockNode != null) {
                // Force a restock check
                Logger.log("[BANKING] Checking if restock is needed during banking");
                restockNode.forceRestockCheck();
                Logger.log("[BANKING] Triggered restock check during Duke banking");

                // If restock is needed, let the RestockGrandExchangeNode handle it
                if (!restockNode.isFinished()) {
                    // Close the bank to let the restock node take over
                    Logger.log("[BANKING] Restock needed, closing bank to let RestockNode take over");
                    Bank.close();
                    Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
                    return 0;
                }
            }
        }

        // Deposit all items except those in ITEMS_TO_KEEP
        Logger.log("[BANKING] Depositing inventory except essential items");
        Bank.depositAllExcept(item -> ITEMS_TO_KEEP.contains(item.getName()));
        Sleep.sleepUntil(() -> Inventory.onlyContains(item -> ITEMS_TO_KEEP.contains(item.getName())), 3000);

        // Ensure essential items are present, withdraw if missing
        boolean essentialItemsOk = true;
        if (!Inventory.contains("Pestle and mortar")) {
             essentialItemsOk = withdrawItem("Pestle and mortar", 1);
        }
        if (essentialItemsOk && !Inventory.contains("Bandos godsword")) {
             essentialItemsOk = withdrawItem("Bandos godsword", 1);
        }
        if (essentialItemsOk && !Inventory.contains("Teleport to house")) {
             essentialItemsOk = withdrawItem("Teleport to house", 1);
        }

        if (!essentialItemsOk) {
            Logger.log("[BANKING] Failed to withdraw essential item(s). Retrying.");
            return 1000; // Try banking process again
        }

        // Withdraw standard supplies
        if (withdrawItem(SUPER_COMBAT_POTION, SUPER_COMBAT_QUANTITY) &&
            withdrawItem(SUPER_RESTORE, SUPER_RESTORE_QUANTITY) &&
            withdrawItem(STAMINA_POTION, STAMINA_QUANTITY) &&
            withdrawItem(FOOD, FOOD_QUANTITY)) {

            Logger.log("[BANKING] Successfully withdrew all supplies");
            Bank.close();

            if (Sleep.sleepUntil(() -> !Bank.isOpen(), 3000)) {
                Logger.log("[BANKING] Banking complete, returning to movement node");
                currentState = BankingState.FINISHED;
                return 500;
            }
        }

        Logger.log("[BANKING] Failed to withdraw all supplies. Retrying.");
        return 1000; // Try withdrawing supplies again
    }

    private boolean withdrawItem(String itemName, int quantity) {
        if (Bank.contains(itemName)) {
            Logger.log("[BANKING] Withdrawing " + quantity + "x " + itemName);
            Bank.withdraw(itemName, quantity);
            return Sleep.sleepUntil(() -> Inventory.count(itemName) >= quantity, 2000);
        } else {
            Logger.log("[BANKING] WARNING: Could not find " + itemName + " in bank");
            return false;
        }
    }

    private void resetState() {
        currentState = BankingState.CHECK_SUPPLIES;
    }
}