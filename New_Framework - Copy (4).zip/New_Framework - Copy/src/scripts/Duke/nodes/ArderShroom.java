package scripts.Duke.nodes;

import core.base.SimpleNode;
import core.context.ScriptContext;
import events.listeners.ScarProjectileListener;
import events.listeners.ScarGraphicObjectListener;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.items.Item;
import scripts.Duke.DukeConfig;

public class ArderShroom extends SimpleNode<DukeConfig> {
    private static final int ARDER_ID = 47528;
    private static final String ARDER_MUSHROOM_NAME = "Arder mushroom";
    private static final String ARDER_POWDER_NAME = "Arder powder";
    private static final String PESTLE_NAME = "Pestle and mortar";
    private static final int REQUIRED_POWDER_COUNT = 42;

    // Duke IDs (copied from CombatNode for now)
    private static final int SLEEPING_DUKE_ID = 12167;
    private static final int AWAKENED_DUKE_ID = 12191;

    // Gas vent related - using the same animation ID as CombatNode
    private static final int DUKE_GAS = 10178;
    private int lastGasAnimationTick = 0;
    private static final int GAS_VENT_DURATION = 5; // Ticks that gas vents remain active

    // Flag to track if we've started using powder on Duke
    private boolean startedUsingPowder = false;
    private ScarProjectileListener projectileListener;
    private ScarGraphicObjectListener graphicsListener;
    private ScriptContext context;
    private boolean projectileListenerActive = false;
    private boolean graphicsListenerActive = false;

    public ArderShroom(ScriptContext context, DukeConfig config) {
        super("Gather/Use Arder", 2, config);
        this.context = context;
        this.projectileListener = new ScarProjectileListener(context);
        this.graphicsListener = new ScarGraphicObjectListener(context);
    }

    @Override
    public boolean validate() {
        // Must be in the Duke instance region
        if (!Client.isDynamicRegion()) {
            stopListeners();
            return false;
        }

        // If Awakened Duke exists, this node should not run
        if (NPCs.closest(AWAKENED_DUKE_ID) != null) {
            startedUsingPowder = false; // Reset the flag for next fight
            stopListeners();
            return false;
        }

        int powderCount = Inventory.count(ARDER_POWDER_NAME);
        int mushroomCount = Inventory.count(ARDER_MUSHROOM_NAME);

        // Check if we're in the process of using powder on the Duke
        if (startedUsingPowder) {
            // If we've started using powder, continue with that process
            return NPCs.closest(SLEEPING_DUKE_ID) != null;
        }

        // Case 1: Need more powder (or mushrooms to grind into powder)
        if (powderCount < REQUIRED_POWDER_COUNT) {
            // Need to grind existing mushrooms OR pick more if space/possible
            boolean needToGrind = mushroomCount > 0;
            boolean canPickMore = !Inventory.isFull();
            return needToGrind || canPickMore;
        }

        // Case 2: Have enough powder, need to use it
        if (powderCount >= REQUIRED_POWDER_COUNT) {
            // Only valid if Sleeping Duke exists
            boolean sleepingDukeExists = NPCs.closest(SLEEPING_DUKE_ID) != null;
            if (!sleepingDukeExists) {
                stopListeners();
            }
            return sleepingDukeExists;
        }

        // Default case (shouldn't happen with above logic)
        stopListeners();
        return false;
    }

    /**
     * Helper method to stop all listeners
     */
    private void stopListeners() {
        if (projectileListenerActive) {
            projectileListener.stop();
            projectileListenerActive = false;
        }
        if (graphicsListenerActive) {
            graphicsListener.stop();
            graphicsListenerActive = false;
        }
    }

    @Override
    protected int onExecute() {
        try {
            // Start the listeners if they're not active and this node is executing
            if (!projectileListenerActive) {
                projectileListener.start();
                projectileListenerActive = true;
                Logger.log("[ArderShroom] Started Projectile Listener");
            }

            if (!graphicsListenerActive) {
                graphicsListener.start();
                graphicsListenerActive = true;
                Logger.log("[ArderShroom] Started Graphics Object Listener");
            }

            int powderCount = Inventory.count(ARDER_POWDER_NAME);
            int mushroomCount = Inventory.count(ARDER_MUSHROOM_NAME);

            // Priority 1: Use powder if we have enough
            if (powderCount >= REQUIRED_POWDER_COUNT || startedUsingPowder) {
                return usePowderOnDuke();
            }

            // Priority 2: Grind mushrooms if we have them and need powder
            if (mushroomCount > 0) {
                return grindMushrooms();
            }

            // Priority 3: Pick mushrooms if we need powder/mushrooms and have space
            if (powderCount + mushroomCount < REQUIRED_POWDER_COUNT && !Inventory.isFull()) {
                return pickArder();
            }

            // Fallback/Wait state (e.g., inventory full but don't have mushrooms to grind)
            setStatus("Waiting (Inventory full or no action needed)");
            return 300;

        } catch (Exception e) {
            Logger.error("Error in ArderNode: " + e.getMessage(), e);
            return 600;
        }
    }

    private int pickArder() {
        GameObject arderShrooms = GameObjects.closest(ARDER_ID);

        if (arderShrooms == null || !arderShrooms.exists()) {
            // If we have mushrooms to grind, switch to grinding
            if (Inventory.contains(ARDER_MUSHROOM_NAME)) {
                setStatus("Mushrooms gone, grinding inventory");
                return grindMushrooms();
            }
            setStatus("Arder mushrooms not found");
            return 600; // Wait longer if object isn't there
        }

        // Check if we have enough total potential powder
        if (Inventory.count(ARDER_POWDER_NAME) + Inventory.count(ARDER_MUSHROOM_NAME) >= REQUIRED_POWDER_COUNT) {
            setStatus("Sufficient mushrooms gathered, grinding");
            return grindMushrooms();
        }

        // Check if inventory is full
        if (Inventory.isFull()) {
            // We need more, but inventory is full. Grind existing ones.
            if (Inventory.contains(ARDER_MUSHROOM_NAME)) {
                setStatus("Inventory full, grinding");
                return grindMushrooms();
            } else {
                // Should not happen if validate() is correct, but handle defensively
                setStatus("Inventory full, cannot pick or grind");
                return 500;
            }
        }

        // Walk if needed
        if (!arderShrooms.canReach()) { // Use canReach for better check
            setStatus("Walking to arder shrooms");
            if (Walking.walk(arderShrooms)) {
                Sleep.sleepUntil(() -> arderShrooms.canReach() || Players.getLocal().isMoving(), 2000); // Wait until reachable or moving
            }
            // Separate sleep and return
            Sleep.sleep(300, 400); // Fixed: min and max must be different
            return 100; // Return a standard tick delay after walking attempt
        }

        // Interact if not animating
        if (!Players.getLocal().isAnimating() && !Players.getLocal().isMoving()) {
            setStatus("Picking arder shrooms");
            if (arderShrooms.interact("Pick")) {
                Sleep.sleepUntil(() -> Players.getLocal().isAnimating() || Inventory.isFull(), 2500); // Wait for animation start or inventory full
                // Short sleep after animation starts
                Sleep.sleepUntil(() -> !Players.getLocal().isAnimating(), 5000); // Wait for animation to finish
                // Separate sleep and return
                Sleep.sleep(50, 150);
                return 100; // Return standard delay
            } else {
                setStatus("Failed to interact with mushrooms");
                // Separate sleep and return
                Sleep.sleep(200, 300); // Fixed: min and max must be different
                return 100;
            }
        } else if (Players.getLocal().isAnimating() || Players.getLocal().isMoving()) {
            setStatus("Waiting for current action to finish");
            // Separate sleep and return
            Sleep.sleep(300, 400); // Fixed: min and max must be different
            return 100; // Wait if already doing something
        }

        setStatus("Waiting for mushrooms to regrow or action");
        // Separate sleep and return
        Sleep.sleep(400, 500); // Fixed: min and max must be different
        return 100; // Default wait
    }

    private int grindMushrooms() {
        setStatus("Grinding mushrooms");

        if (!Inventory.contains(ARDER_MUSHROOM_NAME)) {
            setStatus("No mushrooms to grind");
            // If no mushrooms and not enough powder, go back to picking
            if (Inventory.count(ARDER_POWDER_NAME) < REQUIRED_POWDER_COUNT && !Inventory.isFull() && !startedUsingPowder) {
                return pickArder();
            }
            return 100; // No mushrooms, nothing to do here
        }

        if (!Inventory.contains(PESTLE_NAME)) {
            setStatus("Missing pestle and mortar!");
            Logger.error("Missing Pestle and Mortar - stopping script or banking needed");
            // Consider adding logic to stop script or go bank
            return 10000; // Long sleep indicates critical error
        }

        Item pestle = Inventory.get(PESTLE_NAME);
        Item arderMushroom = Inventory.get(ARDER_MUSHROOM_NAME);

        // Grind only until we reach the required count
        if (Inventory.count(ARDER_POWDER_NAME) >= REQUIRED_POWDER_COUNT) {
            setStatus("Reached required powder count");
            // Now check if we should use powder on Duke
            if (NPCs.closest(SLEEPING_DUKE_ID) != null && NPCs.closest(AWAKENED_DUKE_ID) == null) {
                return usePowderOnDuke();
            }
            return 100; // Otherwise, node becomes invalid or waits
        }

        if (pestle != null && arderMushroom != null) {
            setStatus("Using pestle on mushroom");
            if (pestle.useOn(arderMushroom)) {
                // Wait briefly for the action to start/complete one grind cycle
                Sleep.sleepUntil(() -> Inventory.count(ARDER_MUSHROOM_NAME) < Inventory.get(ARDER_MUSHROOM_NAME).getAmount() || Inventory.count(ARDER_POWDER_NAME) >= REQUIRED_POWDER_COUNT, 1200);
                // Separate sleep and return
                Sleep.sleep(50, 100);
                return 100; // Short delay between grinds
            } else {
                setStatus("Failed to use pestle on mushroom");
                // Separate sleep and return
                Sleep.sleep(200, 300); // Fixed: min and max must be different
                return 100;
            }
        }

        // Separate sleep and return
        Sleep.sleep(100, 150);
        return 100; // Default return
    }

    private int usePowderOnDuke() {
        NPC sleepingDuke = NPCs.closest(SLEEPING_DUKE_ID);

        if (sleepingDuke == null || !sleepingDuke.exists()) {
            setStatus("Sleeping Duke not found!");
            // This case should technically be handled by validate(), but good to check
            return 600;
        }

        // Check if Awakened Duke somehow appeared
        if (NPCs.closest(AWAKENED_DUKE_ID) != null) {
            setStatus("Awakened Duke appeared, stopping Arder node");
            startedUsingPowder = false; // Reset flag when Duke is awakened
            return 100; // Let CombatNode take over
        }

        // Check for gas vents and move to a safe tile if needed
        if (isGasVentActive()) {
            setStatus("Gas vent active, moving to safe tile");
            if (moveToSafeTile()) {
                Sleep.sleepUntil(() -> !Players.getLocal().isMoving(), 1500);
                return 100;
            }
        }

        // Get the powder item
        Item powder = Inventory.get(ARDER_POWDER_NAME);
        if (powder == null) {
            setStatus("No powder found in inventory");
            return 600;
        }

        // Set the flag to indicate we've started using powder
        startedUsingPowder = true;

        // Calculate how many doses we've used so far
        int powderCount = Inventory.count(ARDER_POWDER_NAME);
        int dosesUsed = REQUIRED_POWDER_COUNT - powderCount;

        setStatus("Using powder on Sleeping Duke (" + dosesUsed + "/" + REQUIRED_POWDER_COUNT + ")");
        if (powder.useOn(sleepingDuke)) {
            // Wait until the Duke awakens or a short timeout
            Sleep.sleepUntil(() -> NPCs.closest(AWAKENED_DUKE_ID) != null || !Players.getLocal().isAnimating(), 5000);

            // Check if Duke has awakened
            if (NPCs.closest(AWAKENED_DUKE_ID) != null) {
                Logger.log("[Arder] Duke has awakened after using " + dosesUsed + " doses of powder");
                startedUsingPowder = false; // Reset flag when Duke is awakened
                Sleep.sleep(500, 700);
                return 100; // Give time for CombatNode to validate
            }

            // Much shorter delay between uses (4x faster)
            Sleep.sleep(50, 100);
            return 25; // Return a shorter delay to speed up the loop
        } else {
            setStatus("Failed to use powder on Duke");
            // Maybe inventory got rearranged? Retry?
            Sleep.sleep(300, 400); // Fixed: min and max must be different
            return 100;
        }
    }

    /**
     * Check if gas vents are currently active based on the Duke's animation
     */
    private boolean isGasVentActive() {
        // Get the current game tick
        int currentTick = Client.getGameTick();

        // Check if we're within the gas vent duration window
        if (lastGasAnimationTick > 0 && currentTick - lastGasAnimationTick <= GAS_VENT_DURATION) {
            return true;
        }

        // Check if the Duke is currently performing the gas animation
        NPC duke = NPCs.closest(AWAKENED_DUKE_ID);
        if (duke != null && duke.exists() && duke.getAnimation() == DUKE_GAS) {
            lastGasAnimationTick = currentTick;
            return true;
        }

        return false;
    }

    /**
     * Move to a safe tile using the same logic as CombatNode
     */
    private boolean moveToSafeTile() {
        Tile playerTile = Players.getLocal().getTile();
        if (playerTile == null) return false;

        int regX = playerTile.getX() % 64;
        // Determine target X based on current X
        int targetRegX = (regX < 31) ? 27 : 35; // West pillar: 27, East pillar: 35

        // If already behind a pillar, move to the opposite side
        if (regX == 27 || regX == 35) {
            targetRegX = (regX == 27) ? 35 : 27; // Move to opposite pillar
        }

        // Calculate the movement
        int dx = targetRegX - regX;
        if (dx != 0) {
            Tile targetTile = playerTile.translate(dx, 0);
            Logger.log("[ARDER] Moving to safe tile: " + targetTile);
            return Walking.walk(targetTile);
        }

        return false;
    }

    @Override
    public void cleanup() {
        // Reset gas animation tick
        lastGasAnimationTick = 0;
        startedUsingPowder = false; // Reset flag
        stopListeners();
        Logger.log("[ArderShroom] Stopped all listeners");
        Logger.log("ArderNode cleanup.");
    }
}