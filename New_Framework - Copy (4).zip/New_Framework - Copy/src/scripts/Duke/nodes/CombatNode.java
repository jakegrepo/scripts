package scripts.Duke.nodes;

import core.base.SimpleNode;
import org.dreambot.api.Client;
import org.dreambot.api.methods.combat.Combat;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.prayer.Prayers;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.script.listener.AnimationListener;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.NPC;
import scripts.Duke.DukeConfig;
import scripts.Duke.DukeScript;
import scripts.Duke.utils.DukePrayerFlicker;

import java.util.Arrays;
import java.util.List;

public class CombatNode extends SimpleNode<DukeConfig> implements GameTickListener, AnimationListener {
    // NPC IDs
    private static final int SLEEPING_DUKE_ID = 12167;
    private static final int AWAKENED_DUKE_ID = 12191;
    private static final int DEAD_DUKE_ID     = 12192;

    // Animation IDs
    private static final int DUKE_SPIKES = 10176;
    private static final int DUKE_GAS    = 10178;
    private static final int DUKE_EYE    = 10180;

    // Timing trackers
    private int spikeDodgeTick  = 0;
    private int eyeDodgeTick    = 0;
    private int gasDodgeTick    = 0;
    private int gasAttackTick   = 0;
    private int currentTick     = Client.getGameTick();
    private int gasDodgeCompleteTick = 0; // Track when gas dodge sequence is complete

    // Mechanic flags
    private boolean shouldDodgeSpikes       = false;
    private boolean shouldDodgeEye          = false;
    private boolean shouldDodgeGas          = false;
    private boolean shouldAttackAfterSpikes = false;
    private boolean shouldAttackAfterEye    = false;
    private boolean shouldDodgeAcross       = false;
    private boolean gasDodgeInProgress      = false; // Track if we're in the middle of gas dodge sequence

    // Gas positions
    private Tile lastLocationDuringGas      = null;
    private int lastGasTickHandled = 0; // Track the last tick gas mechanic sequence was handled

    // Additional flags
    private boolean handlingMechanics       = false;
    private boolean hasAwakened            = false;
    private boolean hasIncrementedKill      = false;
    private boolean prayerFlickingActive    = false;
    private boolean shouldTurnOffPrayers    = false;
    private boolean isTestMode              = false;
    private long   lastDukeDeathTime        = 0;
    private static final long DUKE_RESPAWN_DELAY = 3000; // 3s

    private final DukePrayerFlicker prayerFlicker;
    private final DukeScript script;

    private static final int SPEC_ENERGY_THRESHOLD = 50;
    private static final String BGS_NAME = "Bandos godsword";
    private static final String HALBERD_NAME = "Noxious halberd";

    public CombatNode(DukeConfig config, DukeScript script) {
        super("Combat", 3, config);
        this.prayerFlicker = new DukePrayerFlicker(getContext());
        this.script        = script;
        Client.getInstance().getScriptManager().addListener(this);
    }

    @Override
    public boolean validate() {
        try {
            if (isTestMode) {
                return true;
            }

            NPC awakenedDuke = NPCs.closest(AWAKENED_DUKE_ID);
            NPC deadDuke = NPCs.closest(DEAD_DUKE_ID);

            // If we're not in the Duke instance, don't validate
            if (!Client.isDynamicRegion()){
                return false;
            }

            // If Duke is dead, we still want to validate to handle looting
            if (deadDuke != null) {
                return true;
            }

            // Only validate if Awakened Duke exists
            return awakenedDuke != null && awakenedDuke.exists();
        } catch (Exception e) {
            context.getLogger().error("Error in CombatNode validate: " + e.getMessage());
            return false;
        }
    }

    public void setupTestMode() {
        isTestMode = true;
        if (!prayerFlicker.prayerFlickingRunning) {
            Logger.log("Test Mode: Starting prayer flicking");
            prayerFlicker.startPrayerFlick();
            prayerFlickingActive = true;
        }
    }

    @Override
    public void onGameTick() {
        NPC awakenedDuke = NPCs.closest(AWAKENED_DUKE_ID);
        NPC deadDuke     = NPCs.closest(DEAD_DUKE_ID);

        // If Duke is dead but we haven't incremented kills yet
        if (awakenedDuke == null && !hasIncrementedKill && deadDuke != null) {
            script.incrementTotalKills();
            hasIncrementedKill = true;
            Logger.log("[KILLS] Incremented kill count - Duke defeated");
            return;
        }

        // If we do have an Awakened Duke with HP
        if (awakenedDuke != null && awakenedDuke.exists() && awakenedDuke.getHealthPercent() > 0) {
            hasAwakened        = true;
            hasIncrementedKill = false;

            // Turn on prayer flicker if not active
            if (!prayerFlickingActive) {
                prayerFlickingActive = true;
                prayerFlicker.startPrayerFlick();
                Logger.log("[PRAYER] Starting prayer management - Duke alive");
            }

            // Handle mechanics
            currentTick = Client.getGameTick();
            processDukeMechanics(awakenedDuke);
        }
    }

    @Override
    public void onNpcAnimation(NPC npc, int animation, int animationDelay) {
        // Only process Duke's animations
        if (npc == null || (npc.getID() != AWAKENED_DUKE_ID)) {
            return;
        }

        currentTick = Client.getGameTick();

        // Set flags based on animations - NO actual mechanic handling here
        if (animation == DUKE_SPIKES) {
            Logger.log("[ANIMATION] Spikes detected at tick " + currentTick);
            spikeDodgeTick = currentTick;
            shouldDodgeSpikes = true;
        }
        else if (animation == DUKE_EYE) {
            Logger.log("[ANIMATION] Eye detected at tick " + currentTick);
            eyeDodgeTick = currentTick;
            shouldDodgeEye = true;
        }
        else if (animation == DUKE_GAS && (currentTick - gasDodgeTick > 5)) {
            Logger.log("[ANIMATION] Gas detected at tick " + currentTick);
            gasDodgeTick = currentTick;
            shouldDodgeGas = true;
            lastLocationDuringGas = Players.getLocal().getTile();
        }
    }

    private void processDukeMechanics(NPC duke) {
        // Remove animation checks since they're now handled by the listener
        // Only handle mechanic timings here

        // Timers for re-attack:
        // Spikes:
        int spikeAttackWait = isEnragePhase(duke) ? 2 : 1;
        if (currentTick == spikeDodgeTick + spikeAttackWait) {
            Logger.log("[MECHANIC] Attack after spikes");
            shouldAttackAfterSpikes = true;
        }
        // Eye:
        int eyeAttackWait = 4;
        if (currentTick == eyeDodgeTick + eyeAttackWait) {
            Logger.log("[MECHANIC] Attack after eye");
            shouldAttackAfterEye = true;
        }
        // Gas "dodge across" remains the same
        if (currentTick == gasDodgeTick + 1) {
            Logger.log("[MECHANIC] Dodge across after gas");
            shouldDodgeAcross = true;
            gasDodgeInProgress = true; // Mark that we're in the gas dodge sequence
            // Ensure gas dodge flag isn't instantly cleared if dodgeAcross happens immediately
            lastGasTickHandled = currentTick;
        }

        // Mark gas dodge sequence as complete after vents are gone
        if (gasDodgeInProgress && currentTick > gasDodgeTick + 5) {
            gasDodgeInProgress = false;
            gasDodgeCompleteTick = currentTick;
            Logger.log("[MECHANIC] Gas dodge sequence complete at tick " + currentTick);
        }
    }

    // Divine super combat potion names
    private static final String[] DIVINE_SUPER_COMBAT_POTIONS = {
        "Divine super combat potion(4)",
        "Divine super combat potion(3)",
        "Divine super combat potion(2)",
        "Divine super combat potion(1)"
    };

    // Track when we last drank a potion
    private long lastPotionTime = 0;
    private static final long POTION_COOLDOWN = 5 * 60 * 1000; // 5 minutes in milliseconds

    @Override
    protected int onExecute() {
        try {
            // Check for dead Duke and disable prayers if needed
            NPC deadDuke = NPCs.closest(DEAD_DUKE_ID);
            if (deadDuke != null && deadDuke.exists()) {
                // Duke is dead, make sure prayers are off
                if (prayerFlicker != null) {
                    prayerFlicker.checkDukeDeadAndDisablePrayers();
                }

                // Check for valuable loot before proceeding
                if (hasValuableLoot()) {
                    Logger.log("[LOOT] Detected valuable loot - prioritizing looting before teleporting");
                    return 100; // Return to allow looting to happen
                }
            }

            // Double-check prayer flicker state
            managePrayerFlickerState();
            if (!Client.isDynamicRegion()) {
                GameObjects.closest("Gate").interact("Open");
                Sleep.sleepUntil(() -> Client.isDynamicRegion(), 1500);
            }

            // Check if we need to drink a divine super combat potion
            NPC awakenedDuke = NPCs.closest(AWAKENED_DUKE_ID);
            if (awakenedDuke != null && shouldDrinkPotion()) {
                if (drinkDivineSuperCombatPotion()) {
                    Logger.log("[POTION] Drank divine super combat potion");
                    lastPotionTime = System.currentTimeMillis();
                    Sleep.sleep(300, 400);
                    return 100;
                }
            }

            currentTick = Client.getGameTick(); // Ensure currentTick is up-to-date

            // Remove the unconditional halberd re-equipping code here that was causing issues
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // --- Mechanic Prioritization ---
        // 1. Handle Gas Dodge Sequence (Behind Pillar -> Across)
        if (shouldDodgeGas) {
            handlingMechanics = true;
            shouldDodgeGas = false; // Consume the flag
            Logger.log("[MECHANIC] Dodging gas (behind pillar)");
            if (dodgeBehindPillar()) {
                // Successfully moved behind pillar, wait for next tick or dodgeAcross trigger
                Sleep.sleepUntil(() -> !Players.getLocal().isMoving(), 1500);
                lastGasTickHandled = currentTick; // Mark that we handled the initial part
                handlingMechanics = false;
                return 50; // Short delay, wait for shouldDodgeAcross
            } else {
                Logger.warn("[MECHANIC] Failed initial gas dodge (behind pillar)");
                handlingMechanics = false;
                return 100; // Retry or handle error
            }
        }

        if (shouldDodgeAcross) {
            handlingMechanics = true;
            shouldDodgeAcross = false; // Consume the flag
            Logger.log("[MOVEMENT] Dodging across (gas)");
            if (dodgeAcross()) {
                // Successfully initiated dodge across
                Sleep.sleepUntil(() -> !Players.getLocal().isMoving(), 1500);
                lastGasTickHandled = currentTick; // Mark that we handled the across part
                handlingMechanics = false;
                // IMPORTANT: Return after dodging across to wait out vents
                return 100; // Wait for vents to clear
            } else {
                Logger.warn("[MECHANIC] Failed gas dodge (across)");
                handlingMechanics = false;
                return 100; // Retry or handle error
            }
        }

        // 2. Check if we need to wait for Gas Vents after dodging across
        if (isGasVentsActive() || gasDodgeInProgress) {
            Logger.log("[MECHANIC] Waiting for gas vents to clear...");
            return 50; // Stay put until vents are gone
        }

        // --- Reset handlingMechanics if gas sequence is complete ---
        // This allows spike/eye dodges if they occur after gas vents clear
        handlingMechanics = false;

        // 3. Handle Spikes / Eye Dodges (only if not handling gas vents)
        if (shouldDodgeSpikes) {
            // If we just completed a gas dodge, wait a bit longer before handling spikes
            if (currentTick - gasDodgeCompleteTick < 2) {
                Logger.log("[MECHANIC] Waiting after gas dodge before handling spikes");
                return 50;
            }

            handlingMechanics = true;
            shouldDodgeSpikes = false;
            Logger.log("[MECHANIC] Dodging spikes");
            if (dodgeBehindPillar()) { // This now checks if already safe
                Sleep.sleepUntil(() -> !Players.getLocal().isMoving(), 1200); // Adjusted sleep
                handlingMechanics = false;
                return 100;
            }
            handlingMechanics = false; // Didn't need to move or failed
            return 50; // Short delay even if no move needed
        }

        if (shouldDodgeEye) {
            handlingMechanics = true;
            shouldDodgeEye = false;
            Logger.log("[MECHANIC] Dodging eye");
            if (dodgeBehindPillar()) { // This now checks if already safe
                Sleep.sleepUntil(() -> !Players.getLocal().isMoving(), 1500);
                handlingMechanics = false;
                return 100;
            }
            handlingMechanics = false; // Didn't need to move or failed
            return 50; // Short delay even if no move needed
        }


        // Check for the Duke's presence and possibly awaken if needed
        NPC duke = NPCs.closest(AWAKENED_DUKE_ID);
        if (duke == null) {
            // If Duke just died, set the death time
            if (lastDukeDeathTime == 0) {
                lastDukeDeathTime = System.currentTimeMillis();
            }
            // Wait for respawn
            if (System.currentTimeMillis() - lastDukeDeathTime > DUKE_RESPAWN_DELAY) {
                // Attempt to find sleeping Duke
                NPC sleepingDuke = NPCs.closest(SLEEPING_DUKE_ID);
                if (sleepingDuke != null) {
                    lastDukeDeathTime = 0;
                    Logger.log("[DUKE] Found sleeping Duke, awakening");
                    return awakenDuke();
                }
            }
            return 600;
        }

        // Post-mechanic immediate attacks (only if not waiting for gas vents)
        if (!isGasVentsActive()) {
            if (shouldAttackAfterSpikes) {
                shouldAttackAfterSpikes = false;
                Logger.log("[COMBAT] Re-attacking after spikes");
                if (duke.interact("Attack")) {
                    Sleep.sleep(100, 120);
                    return 200;
                }
            }
            if (shouldAttackAfterEye) {
                shouldAttackAfterEye = false;
                Logger.log("[COMBAT] Re-attacking after eye");
                if (duke.interact("Attack")) {
                    Sleep.sleep(100, 120);
                    return 200;
                }
            }
        }
        // Removed the redundant shouldDodgeAcross check here

        // Normal combat if we aren't in a dangerous mechanic or waiting for gas vents
        if (!isDuringDangerousMechanic() && !isGasVentsActive()) {
            // Fixed special attack logic flow
            if (Combat.getSpecialPercentage() >= SPEC_ENERGY_THRESHOLD) {
                // If we have enough spec energy
                if (!Equipment.contains(BGS_NAME)) {
                    // If we don't have BGS equipped, equip it
                    Logger.log("[COMBAT] Special attack available, equipping BGS");
                    if (equipItem(BGS_NAME)) {
                        Sleep.sleepTicks(1);
                        return 100;
                    }
                } else {
                    // We have BGS equipped and enough spec energy, use special attack
                    Logger.log("[COMBAT] Activating special attack with BGS");
                    if (!Combat.isSpecialActive()) {
                        Combat.toggleSpecialAttack(true);
                        Sleep.sleepTicks(1);
                        return 100;
                    }
                }
            } else if (Combat.getSpecialPercentage() < SPEC_ENERGY_THRESHOLD && Equipment.contains(BGS_NAME)) {
                // We don't have enough spec energy AND we have BGS equipped, switch back to halberd
                Logger.log("[COMBAT] Special attack depleted, re-equipping " + HALBERD_NAME);
                if (equipItem(HALBERD_NAME)) {
                    Sleep.sleepTicks(1);
                    return 100;
                }
            }

            // Regular attack if not in combat
            if (!Players.getLocal().isInCombat()) {
                Logger.log("[COMBAT] Attacking Duke normally");
                if (duke.interact("Attack")) {
                    Sleep.sleepUntil(() -> Players.getLocal().isInCombat(), 2400);
                }
            }
        }
        return 600;

    }

    /**
     * Additional utility: If no Awakened Duke alive, ensure flicker is off.
     * If Duke is present & HP>0, flicker should be on.
     */
    private void managePrayerFlickerState() {
        NPC awakenedDuke = NPCs.closest(AWAKENED_DUKE_ID);
        // If no living Awakened Duke, turn flicker off
        if (awakenedDuke == null || !awakenedDuke.exists()) {
            if (prayerFlicker.prayerFlickingRunning) {
                prayerFlickingActive = false;
                shouldTurnOffPrayers = true;
                Logger.log("[PRAYER] Forcing flicker off in onExecute");
            }
        } else {
            if (!prayerFlickingActive) {
                prayerFlickingActive = true;
                Logger.log("[PRAYER] Forcing flicker on in onExecute");
            }
        }

        // If flicker should be off but still running, stop it
        if (!prayerFlickingActive && prayerFlicker.prayerFlickingRunning) {
            prayerFlicker.stop();
            Logger.log("[PRAYER] Flicker has been stopped");
            if (shouldTurnOffPrayers) {
                turnOffAllProtectionPrayers();
                shouldTurnOffPrayers = false;
            }
        }
        // If flicker should be on but is not running, start it
        else if (prayerFlickingActive && !prayerFlicker.prayerFlickingRunning) {
            prayerFlicker.startPrayerFlick();
            Logger.log("[PRAYER] Flicker has been started");
        }
    }

    /**
     * Returns true if Duke is at or below 25% health.
     */
    private boolean isEnragePhase(NPC duke) {
        if (duke == null) return false;
        return duke.getHealthPercent() <= 25;
    }

    /**
     * Check if we are in a dangerous mechanic window.
     * Adjusted for enraged timing: 1 tick sooner.
     *
     * - Spikes: normally 4 ticks, 3 if enraged
     * - Eye:    normally 4 ticks, 3 if enraged
     * - Gas:    normally 5 ticks, 4 if enraged
     */
    private boolean isDuringDangerousMechanic() {
        NPC duke = NPCs.closest(AWAKENED_DUKE_ID);
        if (duke == null) return false;

        int spikeWait = isEnragePhase(duke) ? 0 : 4;
        int eyeWait   = isEnragePhase(duke) ? 3 : 4;
        int gasWait   = isEnragePhase(duke) ? 4 : 5;

        return (currentTick - spikeDodgeTick < spikeWait)
                || (currentTick - eyeDodgeTick   < eyeWait)
                || (currentTick - gasDodgeTick   < gasWait);
    }

    /**
     * Check if we are in the gas vent danger window after dodging across.
     * Assumes vents are active for ~4 ticks after the 'dodge across' movement starts (tick gasDodgeTick + 1).
     */
    private boolean isGasVentsActive() {
        // Check if the gas mechanic was the *last* major mechanic handled and if we're still within the vent window.
        // gasDodgeTick is set on animation detection.
        // shouldDodgeAcross is set on gasDodgeTick + 1.
        // We dodge across shortly after shouldDodgeAcross becomes true.
        // Vents seem active for a few ticks after that initial movement.
        // Let's define the vent window from gasDodgeTick + 2 to gasDodgeTick + 5 (inclusive).
        int ventStartTick = gasDodgeTick + 2;
        int ventEndTick   = gasDodgeTick + 5; // Adjust if needed based on observation

        // Only consider vents active if gas dodge occurred recently
        boolean recentlyDodgedGas = (currentTick - lastGasTickHandled <= 5); // Check if gas was handled in last 5 ticks

        if (recentlyDodgedGas && currentTick >= ventStartTick && currentTick <= ventEndTick) {
            // Logger.log("Gas vents active: currentTick=" + currentTick + ", gasDodgeTick=" + gasDodgeTick);
            return true;
        }
        return false;
    }

    private boolean dodgeBehindPillar() {
        Tile playerTile = Players.getLocal().getTile();
        int regX        = playerTile.getX() % 64;
        // Determine target X based on current X
        int targetRegX = (regX < 31) ? 27 : 35; // West pillar: 27, East pillar: 35

        // Check if already behind the correct pillar
        if (regX == targetRegX) {
            Logger.log("[DODGE] Already behind correct pillar (X=" + regX + ")");
            return false; // No need to move
        }

        Logger.log("[DODGE] Need to move behind pillar: currentX=" + regX + ", targetX=" + targetRegX);
        int dx = targetRegX - regX;
        if (dx != 0) {
            Tile targetTile = playerTile.translate(dx, 0);
            Logger.log("[DODGE] Walking behind pillar to " + targetTile);
            return Walking.walk(targetTile);
            // Removed sleep from here, handled in onExecute
        }
        return false; // Should not happen if regX != targetRegX
    }

    private boolean dodgeAcross() {
        Tile playerTile = Players.getLocal().getTile();
        int regX        = playerTile.getX() % 64;
        // Determine target X based on current X (move to opposite pillar)
        int targetRegX = (regX <= 31) ? 35 : 27; // If West or Middle -> East, If East -> West

         // Check if already on the target side (behind the opposite pillar)
         if (regX == targetRegX) {
             Logger.log("[DODGE] Already across (X=" + regX + ")");
             return false; // No need to move
         }

        Logger.log("[DODGE] Need to dodge across: currentX=" + regX + ", targetX=" + targetRegX);
        int dx = targetRegX - regX;
        if (dx != 0) {
            Tile targetTile = playerTile.translate(dx, 0);
            Logger.log("[DODGE] Walking across to " + targetTile);
            return Walking.walk(targetTile);
             // Removed sleep from here, handled in onExecute
        }
        return false; // Should not happen if regX != targetRegX
    }

    private boolean equipItem(String itemName) {
        if (Inventory.contains(itemName)) {
            return Inventory.interact(itemName, "Wield");
        }
        return false;
    }

    /**
     * Check if we should drink a divine super combat potion
     */
    private boolean shouldDrinkPotion() {
        // Check if the cooldown has passed
        if (System.currentTimeMillis() - lastPotionTime < POTION_COOLDOWN) {
            return false;
        }

        // Check if we have a divine super combat potion
        for (String potionName : DIVINE_SUPER_COMBAT_POTIONS) {
            if (Inventory.contains(potionName)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if there are valuable items on the ground that need to be looted
     */
    private boolean hasValuableLoot() {
        // Define valuable items to check for
        List<String> valuableItems = Arrays.asList(
            "Virtus robe bottom", "Virtus robe top", "Virtus mask",
            "Magus ring", "Leviathan's lure", "Siren's staff",
            "Executioner's axe head", "Eye of the duke", "Awakener's orb", "Nihil shard",
            "Rune javelin heads"
        );

        // Check if any valuable items are on the ground
        return org.dreambot.api.methods.item.GroundItems.closest(item ->
            item != null && valuableItems.contains(item.getName())) != null;
    }

    /**
     * Drink a divine super combat potion
     */
    private boolean drinkDivineSuperCombatPotion() {
        for (String potionName : DIVINE_SUPER_COMBAT_POTIONS) {
            if (Inventory.contains(potionName)) {
                return Inventory.interact(potionName, "Drink");
            }
        }
        return false;
    }

    private int awakenDuke() {
        Logger.log("[DUKE] Waking the Duke...");
        NPC awakenedDuke = NPCs.closest(AWAKENED_DUKE_ID);
        if (awakenedDuke != null) {
            Logger.log("[DUKE] Duke has awakened, attacking...");
            hasAwakened = true;
            if (awakenedDuke.interact("Attack")) {
                Sleep.sleepUntil(() -> Players.getLocal().isInCombat(), 2400);
            }
        }
        return 100;
    }

    public void stopPrayerFlicking() {
        if (prayerFlickingActive) {
            prayerFlicker.stop();
            prayerFlickingActive = false;
        }
    }

    private void turnOffAllProtectionPrayers() {
        Logger.log("[PRAYER] Turning off all prayers");
        if (Prayers.isQuickPrayerActive()) {
            Prayers.toggleQuickPrayer(false);
        }

        // Make sure regular prayers are disabled too
        if (Prayers.isQuickPrayerActive()) {
            Prayers.toggleQuickPrayer(false);
        }

        // Also stop the prayer flicker if it's running
        if (prayerFlicker.prayerFlickingRunning) {
            prayerFlicker.stop();
            prayerFlickingActive = false;
        }

        Logger.log("[PRAYER] All prayers disabled");
    }

    @Override
    public void cleanup() {
        if (isTestMode) {
            Logger.log("Test Mode cleanup: Stopping flicker");
            isTestMode = false;
        }
        stopPrayerFlicking();
        Client.getInstance().removeEventListener(this); // This will remove both GameTickListener and AnimationListener
        super.cleanup();
    }
}
