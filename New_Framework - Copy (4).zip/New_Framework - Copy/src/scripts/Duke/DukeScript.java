package scripts.Duke;

import core.base.ScarScript;
import core.context.ScriptContext;
import core.grandexchange.RestockGrandExchangeNode;
import events.EventListener;
import events.EventManager;
import events.EventType;
import events.ScriptEvent;
import core.gui.AbstractSettingsTab;
import core.node.TaskNode;
import core.paint.PaintBuilder;
import core.paint.ScriptPaint;
import core.paint.debug.DebugOverlay;
import scripts.Duke.utils.DukeDebugOverlay;
import scripts.Duke.utils.DukeDebugOverlay2;
import core.state.ScriptState;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.script.Category;
import org.dreambot.api.script.ScriptManifest;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.graphics.GraphicsObject;
import scripts.Duke.gui.TestSettingsTab;
import scripts.Duke.nodes.*;
import scripts.Duke.utils.DukeHealthNode;

import java.awt.*;
import java.awt.Graphics2D;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ImageObserver;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.text.AttributedCharacterIterator;
import java.util.Map;


public class DukeScript extends ScarScript<DukeConfig> implements EventListener {
    private DukeConfig config;
    private ScriptPaint paint;
    private long startXp;
    private long startTime;
    private DukeDebugOverlay debugOverlay;
    private DukeDebugOverlay2 debugOverlay2; // New debug overlay
    private CombatNode combatNode;
    private DukeHealthNode healthNode;
    private MovementNode movementNode;
    private int totalKills = 0;

    @Override
    public void openTestingGUI() {
        if (context.tasks().getNodes().isEmpty()) {
            context.getLogger().info("Initializing nodes for testing...");
            initializeNodes();
        }
        super.openTestingGUI();
    }

    @Override
    protected void onScriptStart() {
        try {
            context.getLogger().info("=== STARTING TEST SCRIPT ===");
            context.initialize();

            config = getScriptConfig();
            context.initializeLogger(getClass().getSimpleName());

            // Initialize Duke-specific debug overlays
            debugOverlay = new DukeDebugOverlay(context);
            debugOverlay2 = new DukeDebugOverlay2(context);
            context.getLogger().info("Duke debug overlays initialized");

            // Set up paint to use our custom debug overlay
            paint = new PaintBuilder(context)
                    .setTitle("ScarDuke")
                    .addRow("Status", this::getScriptStatus)
                    .addRow("Current Node", () -> {
                        TaskNode node = context.tasks().getActiveNode();
                        return node != null ? node.getName() : "None";
                    })
                    .addRow("Runtime", this::getRuntime)
                    .addRow("Duke Kills", this::getKillsStatus)
                    .addRow("Supplies", this::getSuppliesStatus)
                    .build();

            // Set debug overlay in paint
            ((ScriptPaint)paint).setDebugOverlay(debugOverlay);

            // Setup key listener for debug overlay toggle
            setupKeyListener();

            // Store starting XP and time
            startXp = Skills.getExperience(Skill.MAGIC);
            startTime = System.currentTimeMillis();

            // Initialize paint
            paint = new PaintBuilder(context)
                    .setTitle("ScarDuke")
                    .addRow("Status", this::getScriptStatus)
                    .addRow("Current Node", () -> {
                        TaskNode node = context.tasks().getActiveNode();
                        return node != null ? node.getName() : "None";
                    })
                    .addRow("Runtime", this::getRuntime)
                    .addRow("Duke Kills", this::getKillsStatus)
                    .addRow("Supplies", this::getSuppliesStatus)
                    .build();

            // Set debug overlay in paint
            ((ScriptPaint)paint).setDebugOverlay(debugOverlay);

            // Initialize nodes before setting state to RUNNING
            initializeNodes();
            context.getLogger().info("Nodes initialized successfully");
            context.getLogger().info("Health monitoring initialized");
            // Perform initial restock check if restock is enabled
            if (config.getRestockConfig().isEnabled()) {
                context.getLogger().info("=== CHECKING RESTOCK NEEDS ON SCRIPT START ===");

                // Find the RestockGrandExchangeNode
                RestockGrandExchangeNode restockNode = context.tasks().getNodes().stream()
                    .filter(node -> node instanceof RestockGrandExchangeNode)
                    .map(node -> (RestockGrandExchangeNode) node)
                    .findFirst()
                    .orElse(null);

                if (restockNode != null) {
                    context.getLogger().info("Forcing initial restock check on script start");
                    restockNode.forceRestockCheck();
                } else {
                    context.getLogger().warn("RestockGrandExchangeNode not found, cannot check restock needs");
                }
            } else {
                context.getLogger().info("Restock is disabled in settings, skipping initial check");
            }

            setState(ScriptState.RUNNING);
            context.getLogger().info("Test script started successfully!");

            // Register this script as an event listener for all event types
            for (EventType type : EventType.values()) {
                context.getEventManager().addEventListener(type, this);
            }
            context.getLogger().info("Registered DukeScript as event listener for all event types.");

        } catch (Exception e) {
            context.getLogger().error("Error during script start: " + e.getMessage());
            setState(ScriptState.ERROR);
        }

        // Unregister this script as an event listener for all event types
        for (EventType type : EventType.values()) {
            context.getEventManager().removeEventListener(type, this);
        }
        context.getLogger().info("Unregistered DukeScript as event listener for all event types.");

        context.getLogger().info("Test script stopped.");
    }

    private String getRuntime() {
        long millis = System.currentTimeMillis() - startTime;
        long seconds = millis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        minutes %= 60;
        seconds %= 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    private String getSuppliesStatus() {
        int arder = Inventory.count("Arder powder");
        int musca = Inventory.count("Musca powder");
        int salt = Inventory.count("Salax salt");

        return String.format(
            "A: %d%s | M: %d%s | S: %d%s",
            arder, arder >= 300 ? "✓" : "",
            musca, musca >= 300 ? "✓" : "",
            salt, salt >= 300 ? "✓" : ""
        );
    }

    private double getKillsPerHour() {
        long runtime = System.currentTimeMillis() - startTime;
        if (runtime == 0) return 0;
        return (totalKills * 3600000.0) / runtime;
    }

    public synchronized void incrementTotalKills() {
        totalKills++;
        context.getLogger().info("Total Duke kills: " + totalKills);
    }

    private void initializeNodes() {
        context.getLogger().info("=== INITIALIZING NODES ===");
        clearNodes();

        try {
            // Create nodes
            MovementNode movementNode = new MovementNode(config,this);
            ArderShroom arderNode = new ArderShroom(getContext(), config);
            BankingNode bankingNode = new BankingNode(config, this);

            // Add RestockGrandExchangeNode (high priority, but will only execute when needed)
            RestockGrandExchangeNode restockNode = new RestockGrandExchangeNode("RestockGE", 1, config);


            // Initialize health monitoring
            healthNode = new DukeHealthNode(getContext(), config.getHealthThreshold(), config.getFoodType());
            healthNode.startHealthMonitoring();
            context.getLogger().info("Health monitoring started");

            // Create combat node with health monitoring and reference to this script
            combatNode = new CombatNode(config, this);
            context.getLogger().info("Created nodes");

            // Add nodes to the task list in order of priority
            addNode(movementNode);
            addNode(combatNode);  // Priority 1 = highest priority
            addNode(bankingNode);  // Priority 2 = handle banking when needed
            addNode(arderNode);   // Priority 3 = lower priority
            addNode(restockNode); // Add the restock node
            context.getLogger().info("Added nodes to task manager");

            // Log total nodes for verification
            context.getLogger().info("=== NODE INITIALIZATION COMPLETE ===");
            context.getLogger().info("Total nodes initialized: " + context.tasks().getNodes().size());

            // Log each node for debugging
            context.tasks().getNodes().forEach(node ->
                context.getLogger().info("Registered node: " + node.getClass().getSimpleName() +
                    " (Priority: " + node.getPriority() + ")"));
        } catch (Exception e) {
            context.getLogger().error("Error initializing nodes: " + e.getMessage());
            e.printStackTrace();
        }
    }



    @Override
    protected int onScriptLoop() {
        try {
            // Normal script execution
            if (getState().isRunnable()) {
                if (context.tasks().getNodes().isEmpty()) {
                    context.getLogger().error("No nodes available - attempting reinitialization...");
                    initializeNodes();
                    return 600;
                }
                return context.tasks().execute();
            }
            return 600;
        } catch (Exception e) {
            context.getLogger().error("Error in script loop: " + e.getMessage());
            setState(ScriptState.ERROR);
            return 1000;
        }
    }

    @Override
    protected void onScriptStop() {
        context.getLogger().info("Test script stopping...");

        // Remove the combat node from game tick listeners
        if (combatNode != null) {
            context.getLogger().info("Removing CombatNode from GameTickListener");
            Client.getInstance().removeEventListener(combatNode);
        }

        // Stop health monitoring
        if (healthNode != null) {
            context.getLogger().info("Stopping health monitoring");
            healthNode.stop();
            Client.getInstance().removeEventListener(healthNode);
        }

        context.getLogger().info("Test script stopped.");
    }

    @Override
    public void onPaint(Graphics2D g) {
        // Render the standard paint
        if (paint != null) {
            paint.render(g);
        }

        // Render our custom debug overlay
        if (debugOverlay2 != null) {
            debugOverlay2.render(g);
        }
    }

    /**
     * Add a key listener to toggle the debug overlay with F2
     */
    public void setupKeyListener() {
        // This would need to be implemented with a KeyListener
        // Since AbstractScript doesn't have an onKey method, we'd need to add a custom KeyListener
        // For now, we'll just enable the debug overlay by default
        if (debugOverlay != null && !debugOverlay.areVisualsEnabled()) {
            debugOverlay.toggle();
            context.getLogger().info("Debug overlay enabled by default");
        }
    }

    @Override
    public DukeConfig getScriptConfig() {
        if (config == null) {
            config = new DukeConfig(getContext());
        }
        return config;
    }

    @Override
    public boolean requiresGUI() {
        return true;
    }

    @Override
    protected AbstractSettingsTab getScriptTab() {
        return new TestSettingsTab(getContext());
    }

    private String getScriptStatus() {
        TaskNode activeNode = context.tasks().getActiveNode();
        if (activeNode != null) {
            return activeNode.getStatus();
        }
        return "Idle";
    }

    private String getKillsStatus() {
        double killsPerHour = getKillsPerHour();
        return String.format("Kills: %d (%.1f/hr)", totalKills, killsPerHour);
    }

    // Event Handling


    @Override
    public void onEvent(ScriptEvent event) {
        if (event.getType() == EventType.PROJECTILE_CREATED) {
            Projectile projectile = (Projectile) event.getAttribute("projectile");
            Object target = event.getAttribute("target"); // Can be Tile or Entity
            Integer projectileId = (Integer) event.getAttribute("projectileId");

            String targetInfo = "Unknown";
            if (target instanceof org.dreambot.api.methods.map.Tile) {
                targetInfo = "Tile: " + ((org.dreambot.api.methods.map.Tile) target).toString();
            }
            // Add checks for other possible target types if needed, e.g., Entity

            context.getLogger().info(String.format(
                "[PROJECTILE DETECTED] ID: %d, Target: %s, Speed: %d, StartHeight: %d, EndHeight: %d",
                projectileId != null ? projectileId : -1,
                targetInfo,
                projectile != null ? projectile.getSpeedX() : -1,
                projectile != null ? projectile.getHeight() : -1,
                projectile != null ? projectile.getZ() : -1
            ));
        } else if (event.getType() == EventType.GRAPHICS_OBJECT_SPAWNED) {
            // The logging is now done directly in the ScarGraphicObjectListener
        }
    }
}