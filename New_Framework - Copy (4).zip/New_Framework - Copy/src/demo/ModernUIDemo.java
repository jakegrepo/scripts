package demo;

import core.gui.components.ModernCardPanel;
import core.gui.components.LoadingIndicator;
import core.gui.components.ToastNotification;
import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * A demo application to showcase the modern UI components
 */
public class ModernUIDemo extends JFrame {
    
    private JTabbedPane tabbedPane;
    private JButton primaryButton;
    private JButton secondaryButton;
    private JTextField textField;
    private JTable demoTable;
    private LoadingIndicator loadingIndicator;
    
    public ModernUIDemo() {
        setTitle("Modern UI Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(StyleManager.MAIN_WINDOW_SIZE);
        setLocationRelativeTo(null);
        
        // Set up the main panel
        JPanel mainPanel = new JPanel(new BorderLayout(StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING));
        mainPanel.setBackground(StyleManager.BACKGROUND);
        mainPanel.setBorder(BorderFactory.createEmptyBorder());
        
        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        
        // Create tabbed pane
        tabbedPane = new JTabbedPane();
        StyleManager.styleTabbedPane(tabbedPane);
        
        // Add tabs
        tabbedPane.addTab("Cards Demo", createCardsPanel());
        tabbedPane.addTab("Controls Demo", createControlsPanel());
        tabbedPane.addTab("Table Demo", createTablePanel());
        
        // Create status bar
        JPanel statusBar = createStatusBar();
        
        // Add components to main panel
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(statusBar, BorderLayout.SOUTH);
        
        // Set content pane
        setContentPane(mainPanel);
        
        // Initialize event handlers
        initializeEventHandlers();
    }
    
    private JPanel createHeaderPanel() {
        // Create a card panel for the header
        ModernCardPanel headerCard = new ModernCardPanel("Modern UI Demo");
        
        JPanel content = new JPanel(new BorderLayout());
        content.setOpaque(false);
        
        JLabel descLabel = new JLabel("A showcase of modern UI components with improved styling");
        descLabel.setFont(StyleManager.REGULAR_FONT);
        descLabel.setForeground(StyleManager.FOREGROUND);
        
        content.add(descLabel, BorderLayout.CENTER);
        
        headerCard.setContent(content);
        
        return headerCard;
    }
    
    private JPanel createCardsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(StyleManager.PANEL_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING));
        
        // Create first card
        ModernCardPanel card1 = new ModernCardPanel("Card Example 1");
        JPanel card1Content = new JPanel(new BorderLayout());
        card1Content.setOpaque(false);
        
        JLabel card1Label = new JLabel("This is a modern card panel with elevation and rounded corners");
        card1Label.setFont(StyleManager.REGULAR_FONT);
        card1Label.setForeground(StyleManager.FOREGROUND);
        
        card1Content.add(card1Label, BorderLayout.CENTER);
        card1.setContent(card1Content);
        
        // Create second card
        ModernCardPanel card2 = new ModernCardPanel("Card Example 2");
        JPanel card2Content = new JPanel(new BorderLayout());
        card2Content.setOpaque(false);
        
        JLabel card2Label = new JLabel("Cards can contain any components and have a consistent style");
        card2Label.setFont(StyleManager.REGULAR_FONT);
        card2Label.setForeground(StyleManager.FOREGROUND);
        
        JButton cardButton = new JButton("Card Button");
        StyleManager.styleButton(cardButton);
        
        card2Content.add(card2Label, BorderLayout.CENTER);
        card2Content.add(cardButton, BorderLayout.SOUTH);
        card2.setContent(card2Content);
        
        // Add cards to panel with spacing
        panel.add(card1);
        panel.add(Box.createVerticalStrut(StyleManager.COMPONENT_SPACING));
        panel.add(card2);
        panel.add(Box.createVerticalGlue());
        
        return panel;
    }
    
    private JPanel createControlsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(StyleManager.PANEL_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING));
        
        // Create controls card
        ModernCardPanel controlsCard = new ModernCardPanel("UI Controls");
        JPanel controlsContent = new JPanel(new GridBagLayout());
        controlsContent.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Text field
        JLabel textFieldLabel = new JLabel("Text Field:");
        textFieldLabel.setFont(StyleManager.REGULAR_FONT);
        textFieldLabel.setForeground(StyleManager.FOREGROUND);
        
        textField = new JTextField(20);
        StyleManager.styleTextField(textField);
        
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.0;
        gbc.anchor = GridBagConstraints.EAST;
        controlsContent.add(textFieldLabel, gbc);
        
        gbc.gridx = 1; gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        controlsContent.add(textField, gbc);
        
        // Buttons
        JLabel buttonsLabel = new JLabel("Buttons:");
        buttonsLabel.setFont(StyleManager.REGULAR_FONT);
        buttonsLabel.setForeground(StyleManager.FOREGROUND);
        
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttonsPanel.setOpaque(false);
        
        primaryButton = new JButton("Primary Button");
        StyleManager.stylePrimaryButton(primaryButton);
        
        secondaryButton = new JButton("Secondary Button");
        StyleManager.styleButton(secondaryButton);
        
        buttonsPanel.add(primaryButton);
        buttonsPanel.add(secondaryButton);
        
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.0;
        gbc.anchor = GridBagConstraints.EAST;
        controlsContent.add(buttonsLabel, gbc);
        
        gbc.gridx = 1; gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        controlsContent.add(buttonsPanel, gbc);
        
        // Loading indicator
        JLabel loadingLabel = new JLabel("Loading Indicator:");
        loadingLabel.setFont(StyleManager.REGULAR_FONT);
        loadingLabel.setForeground(StyleManager.FOREGROUND);
        
        loadingIndicator = new LoadingIndicator(32, StyleManager.ACCENT);
        
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0.0;
        gbc.anchor = GridBagConstraints.EAST;
        controlsContent.add(loadingLabel, gbc);
        
        gbc.gridx = 1; gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        controlsContent.add(loadingIndicator, gbc);
        
        controlsCard.setContent(controlsContent);
        
        // Add card to panel
        panel.add(controlsCard);
        panel.add(Box.createVerticalGlue());
        
        return panel;
    }
    
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(StyleManager.PANEL_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING));
        
        // Create table model
        String[] columnNames = {"Name", "Type", "Value", "Status"};
        Object[][] data = {
            {"Item 1", "Equipment", "1,500,000", "Active"},
            {"Item 2", "Consumable", "25,000", "Pending"},
            {"Item 3", "Material", "750,000", "Completed"},
            {"Item 4", "Tool", "350,000", "Failed"},
            {"Item 5", "Weapon", "2,100,000", "Active"},
            {"Item 6", "Armor", "1,800,000", "Pending"}
        };
        
        demoTable = new JTable(data, columnNames);
        StyleManager.styleTable(demoTable);
        
        JScrollPane scrollPane = new JScrollPane(demoTable);
        StyleManager.styleScrollPane(scrollPane);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createStatusBar() {
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBackground(StyleManager.CARD_BG);
        statusBar.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        
        JLabel statusLabel = new JLabel("Ready");
        statusLabel.setFont(StyleManager.REGULAR_FONT);
        statusLabel.setForeground(StyleManager.FOREGROUND);
        
        statusBar.add(statusLabel, BorderLayout.WEST);
        
        return statusBar;
    }
    
    private void initializeEventHandlers() {
        primaryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ToastNotification.showSuccess(ModernUIDemo.this, "Primary action completed successfully!");
            }
        });
        
        secondaryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ToastNotification.showInfo(ModernUIDemo.this, "Secondary action performed");
            }
        });
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ModernUIDemo demo = new ModernUIDemo();
                demo.setVisible(true);
            }
        });
    }
}
