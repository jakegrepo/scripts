package demo;

import core.gui.components.*;
import core.gui.style.ModernUITheme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * A standalone demo application that showcases the new GUI components and layout.
 * This allows previewing the UI without needing to run it in DreamBot.
 */
public class GUIPreviewDemo {
    private JFrame frame;
    private SidebarNavigationPanel navigationPanel;

    public static void main(String[] args) {
        // Set system properties for better rendering
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        // Run the demo
        SwingUtilities.invokeLater(() -> {
            try {
                // Create the demo
                GUIPreviewDemo demo = new GUIPreviewDemo();
                demo.initialize();

                // Apply modern UI theme to the demo's frame
                ModernUITheme.apply(demo.frame);

                // Show the demo
                demo.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Initializes the demo application
     */
    private void initialize() {
        // Create the main frame
        frame = new JFrame("GUI Preview Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(ModernUITheme.MAIN_WINDOW_SIZE);
        frame.setMinimumSize(ModernUITheme.MIN_WINDOW_SIZE);
        frame.setLocationRelativeTo(null);

        // Create main panel
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(ModernUITheme.BACKGROUND_DARKEST);

        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Create navigation panel
        navigationPanel = new SidebarNavigationPanel();
        mainPanel.add(navigationPanel, BorderLayout.CENTER);

        // Add tabs to navigation panel
        navigationPanel.addTab("General Settings", createGeneralSettingsPanel());
        navigationPanel.addTab("Break Settings", createBreakSettingsPanel());
        navigationPanel.addTab("Anti-Ban Settings", createAntiBanSettingsPanel());
        navigationPanel.addTab("Muling Settings", createMulingSettingsPanel());
        navigationPanel.addTab("Restock Settings", createRestockSettingsPanel());
        navigationPanel.addTab("Style Settings", createStyleSettingsPanel());

        // Create control panel
        JPanel controlPanel = createControlPanel();
        mainPanel.add(controlPanel, BorderLayout.SOUTH);

        // Set content pane
        frame.setContentPane(mainPanel);
    }

    /**
     * Shows the demo application
     */
    private void show() {
        frame.setVisible(true);
    }

    /**
     * Creates the header panel
     */
    private JPanel createHeaderPanel() {
        // Create modern header with gradient background
        JPanel headerPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Paint gradient background using theme colors
                g2d.setPaint(ModernUITheme.getGradientHeader());
                g2d.fillRect(0, 0, getWidth(), getHeight());
                g2d.dispose();
            }
        };

        headerPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0,
                new Color(ModernUITheme.ACCENT_PRIMARY.getRed(),
                         ModernUITheme.ACCENT_PRIMARY.getGreen(),
                         ModernUITheme.ACCENT_PRIMARY.getBlue(), 40)));
        headerPanel.setOpaque(false);

        // Create logo panel with icon
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, ModernUITheme.SPACING_MEDIUM, ModernUITheme.SPACING_MEDIUM));
        logoPanel.setOpaque(false);

        // Create title with improved styling
        JLabel titleLabel = new JLabel("Framework Demo");
        titleLabel.setFont(ModernUITheme.FONT_TITLE);
        titleLabel.setForeground(ModernUITheme.ACCENT_PRIMARY);
        logoPanel.add(titleLabel);

        // Add subtitle
        JLabel subtitleLabel = new JLabel("UI Preview");
        subtitleLabel.setFont(ModernUITheme.FONT_SMALL);
        subtitleLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        logoPanel.add(subtitleLabel);

        // Add a settings button
        JButton settingsButton = new JButton("Style Settings");
        settingsButton.addActionListener(e -> {
            // Select the Style tab
            navigationPanel.setSelectedTab("Style Settings");
        });
        logoPanel.add(Box.createHorizontalStrut(ModernUITheme.SPACING_LARGE));
        logoPanel.add(settingsButton);

        headerPanel.add(logoPanel, BorderLayout.WEST);

        // Add version info to the right side
        JLabel versionLabel = new JLabel("v1.0");
        versionLabel.setFont(ModernUITheme.FONT_SMALL);
        versionLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        versionLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, ModernUITheme.SPACING_MEDIUM));
        headerPanel.add(versionLabel, BorderLayout.EAST);

        return headerPanel;
    }

    /**
     * Creates the control panel
     */
    private JPanel createControlPanel() {
        // Create modern control panel with glass-like effect
        JPanel controlPanel = new JPanel(new BorderLayout(ModernUITheme.SPACING_MEDIUM, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Paint gradient background
                GradientPaint gradient = new GradientPaint(
                    0, 0, ModernUITheme.BACKGROUND_DARK,
                    0, getHeight(), ModernUITheme.BACKGROUND_DARKEST);
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                g2d.dispose();
            }
        };

        controlPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0,
                new Color(ModernUITheme.ACCENT_PRIMARY.getRed(),
                         ModernUITheme.ACCENT_PRIMARY.getGreen(),
                         ModernUITheme.ACCENT_PRIMARY.getBlue(), 40)),
            BorderFactory.createEmptyBorder(ModernUITheme.SPACING_MEDIUM, ModernUITheme.SPACING_LARGE,
                                          ModernUITheme.SPACING_MEDIUM, ModernUITheme.SPACING_LARGE)
        ));
        controlPanel.setOpaque(false);

        // Create profile panel with improved layout
        JPanel profilePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, ModernUITheme.SPACING_SMALL, 0));
        profilePanel.setOpaque(false);
        profilePanel.setBorder(null);

        // Create profile selector with label
        JLabel profileLabel = new JLabel("Profile:");
        profileLabel.setFont(ModernUITheme.FONT_REGULAR);
        profileLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        profilePanel.add(profileLabel);

        // Create modern profile selector
        ModernComboBox<String> profileSelector = new ModernComboBox<>(new String[]{"Default", "Profile 1", "Profile 2"});
        profileSelector.setPreferredSize(new Dimension(200, 28));
        profilePanel.add(profileSelector);

        // Create profile management buttons with improved styling
        AnimatedButton loadButton = new AnimatedButton("Load", AnimatedButton.ButtonStyle.GHOST);
        AnimatedButton saveButton = new AnimatedButton("Save", AnimatedButton.ButtonStyle.GHOST);
        AnimatedButton removeButton = new AnimatedButton("Remove", AnimatedButton.ButtonStyle.GHOST);

        // Apply consistent styling to buttons
        Dimension buttonSize = new Dimension(80, 28);
        loadButton.setPreferredSize(buttonSize);
        saveButton.setPreferredSize(buttonSize);
        removeButton.setPreferredSize(buttonSize);

        profilePanel.add(loadButton);
        profilePanel.add(saveButton);
        profilePanel.add(removeButton);

        // Add profile panel to control panel
        controlPanel.add(profilePanel, BorderLayout.WEST);

        // Create action buttons panel
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, ModernUITheme.SPACING_SMALL, 0));
        actionPanel.setOpaque(false);
        actionPanel.setBorder(null);

        // Create start button with improved styling
        AnimatedButton startButton = new AnimatedButton("Start Script", AnimatedButton.ButtonStyle.PRIMARY);
        startButton.setPreferredSize(new Dimension(140, 36));
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame,
                    "This is just a UI preview demo.\nNo actual functionality is implemented.",
                    "Demo Information",
                    JOptionPane.INFORMATION_MESSAGE);
            }
        });

        actionPanel.add(startButton);

        // Add buttons panel to control panel
        controlPanel.add(actionPanel, BorderLayout.EAST);

        return controlPanel;
    }

    /**
     * Creates the general settings panel
     */
    private JPanel createGeneralSettingsPanel() {
        // Create a content panel that will hold all the components
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(ModernUITheme.BACKGROUND_DARK);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE
        ));

        // Create a scroll pane to hold the content panel
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getVerticalScrollBar().setUI(new ModernScrollBarUI());
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setBackground(ModernUITheme.BACKGROUND_DARK);

        // Create the main panel that will hold the scroll pane
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ModernUITheme.BACKGROUND_DARK);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Create general settings card
        GlassCard generalCard = new GlassCard("General Settings");
        generalCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Don't set maximum size to allow the card to grow with its content

        // Create form panel for general settings
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_MEDIUM);

        // Add form fields
        addFormField(formPanel, gbc, "Script Name:", new ModernTextField("Demo Script"));
        gbc.gridy++;
        addFormField(formPanel, gbc, "Run Time:", new ModernSpinner(new SpinnerNumberModel(60, 1, 999, 1)));
        gbc.gridy++;
        addFormField(formPanel, gbc, "World:", new ModernComboBox<>(new String[]{"Any world", "Members only", "F2P only"}));
        gbc.gridy++;

        // Add toggle switches
        ModernToggleSwitch toggleSwitch1 = new ModernToggleSwitch();
        toggleSwitch1.setSelected(true);
        addFormField(formPanel, gbc, "Enable Debugging:", toggleSwitch1);
        gbc.gridy++;

        ModernToggleSwitch toggleSwitch2 = new ModernToggleSwitch();
        addFormField(formPanel, gbc, "Show Overlay:", toggleSwitch2);

        generalCard.addContent(formPanel);
        contentPanel.add(generalCard);

        // Add some spacing
        contentPanel.add(Box.createVerticalStrut(ModernUITheme.SPACING_LARGE));

        // Create advanced settings card
        GlassCard advancedCard = new GlassCard("Advanced Settings");
        advancedCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Don't set maximum size to allow the card to grow with its content

        // Create form panel for advanced settings
        JPanel advancedFormPanel = new JPanel(new GridBagLayout());
        advancedFormPanel.setOpaque(false);
        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.gridx = 0;
        gbc2.gridy = 0;
        gbc2.anchor = GridBagConstraints.WEST;
        gbc2.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_MEDIUM);

        // Add form fields
        ModernCheckBox checkBox1 = new ModernCheckBox("Enable custom mouse movement");
        checkBox1.setSelected(true);
        gbc2.gridwidth = 2;
        advancedFormPanel.add(checkBox1, gbc2);

        gbc2.gridy++;
        ModernCheckBox checkBox2 = new ModernCheckBox("Enable custom camera movement");
        advancedFormPanel.add(checkBox2, gbc2);

        gbc2.gridy++;
        ModernCheckBox checkBox3 = new ModernCheckBox("Enable custom inventory management");
        advancedFormPanel.add(checkBox3, gbc2);

        gbc2.gridy++;
        ModernCheckBox checkBox4 = new ModernCheckBox("Enable custom banking behavior");
        advancedFormPanel.add(checkBox4, gbc2);

        gbc2.gridy++;
        ModernCheckBox checkBox5 = new ModernCheckBox("Enable custom object interaction");
        advancedFormPanel.add(checkBox5, gbc2);

        gbc2.gridy++;
        ModernCheckBox checkBox6 = new ModernCheckBox("Enable custom NPC interaction");
        advancedFormPanel.add(checkBox6, gbc2);

        gbc2.gridy++;
        ModernCheckBox checkBox7 = new ModernCheckBox("Enable custom player interaction");
        advancedFormPanel.add(checkBox7, gbc2);

        gbc2.gridy++;
        gbc2.gridwidth = 1;
        addFormField(advancedFormPanel, gbc2, "Mouse Speed:", new ModernSpinner(new SpinnerNumberModel(50, 1, 100, 1)));

        gbc2.gridy++;
        addFormField(advancedFormPanel, gbc2, "Camera Speed:", new ModernSpinner(new SpinnerNumberModel(50, 1, 100, 1)));

        gbc2.gridy++;
        addFormField(advancedFormPanel, gbc2, "Interaction Delay:", new ModernSpinner(new SpinnerNumberModel(150, 0, 500, 10)));

        gbc2.gridy++;
        addFormField(advancedFormPanel, gbc2, "Banking Delay:", new ModernSpinner(new SpinnerNumberModel(200, 0, 500, 10)));

        advancedCard.addContent(advancedFormPanel);
        contentPanel.add(advancedCard);

        return panel;
    }

    /**
     * Creates the break settings panel
     */
    private JPanel createBreakSettingsPanel() {
        // Create a content panel that will hold all the components
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(ModernUITheme.BACKGROUND_DARK);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE
        ));

        // Create a scroll pane to hold the content panel
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getVerticalScrollBar().setUI(new ModernScrollBarUI());
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setBackground(ModernUITheme.BACKGROUND_DARK);

        // Create the main panel that will hold the scroll pane
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ModernUITheme.BACKGROUND_DARK);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Create break settings card
        GlassCard breakCard = new GlassCard("Break Settings");
        breakCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Don't set maximum size to allow the card to grow with its content

        // Create form panel for break settings
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_MEDIUM);

        // Add toggle switch
        ModernToggleSwitch enableBreaks = new ModernToggleSwitch();
        enableBreaks.setSelected(true);
        addFormField(formPanel, gbc, "Enable Breaks:", enableBreaks);
        gbc.gridy++;

        // Add form fields
        addFormField(formPanel, gbc, "Break After (minutes):", new ModernSpinner(new SpinnerNumberModel(60, 1, 999, 1)));
        gbc.gridy++;
        addFormField(formPanel, gbc, "Break For (minutes):", new ModernSpinner(new SpinnerNumberModel(15, 1, 999, 1)));
        gbc.gridy++;
        addFormField(formPanel, gbc, "Randomization (%):", new ModernSpinner(new SpinnerNumberModel(10, 0, 100, 1)));

        // Add more break settings
        gbc.gridy++;
        gbc.gridwidth = 2;
        ModernCheckBox logoutDuringBreak = new ModernCheckBox("Logout during breaks");
        logoutDuringBreak.setSelected(true);
        formPanel.add(logoutDuringBreak, gbc);

        gbc.gridy++;
        ModernCheckBox randomizeBreaks = new ModernCheckBox("Randomize break intervals");
        randomizeBreaks.setSelected(true);
        formPanel.add(randomizeBreaks, gbc);

        gbc.gridy++;
        ModernCheckBox progressiveBreaks = new ModernCheckBox("Progressive break duration");
        formPanel.add(progressiveBreaks, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        addFormField(formPanel, gbc, "Min Break (minutes):", new ModernSpinner(new SpinnerNumberModel(5, 1, 60, 1)));

        gbc.gridy++;
        addFormField(formPanel, gbc, "Max Break (minutes):", new ModernSpinner(new SpinnerNumberModel(30, 1, 120, 1)));

        // Add break schedule section
        gbc.gridy++;
        gbc.gridwidth = 2;
        JLabel scheduleLabel = new JLabel("Break Schedule");
        scheduleLabel.setFont(ModernUITheme.FONT_TITLE);
        scheduleLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        scheduleLabel.setBorder(BorderFactory.createEmptyBorder(ModernUITheme.SPACING_MEDIUM, 0, ModernUITheme.SPACING_SMALL, 0));
        formPanel.add(scheduleLabel, gbc);

        gbc.gridy++;
        ModernCheckBox enableSchedule = new ModernCheckBox("Enable scheduled breaks");
        formPanel.add(enableSchedule, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        addFormField(formPanel, gbc, "Break at (time):", new ModernTextField("12:00"));

        gbc.gridy++;
        addFormField(formPanel, gbc, "Break duration (min):", new ModernSpinner(new SpinnerNumberModel(30, 5, 120, 5)));

        breakCard.addContent(formPanel);
        contentPanel.add(breakCard);

        return panel;
    }

    /**
     * Creates the anti-ban settings panel
     */
    private JPanel createAntiBanSettingsPanel() {
        // Create a content panel that will hold all the components
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(ModernUITheme.BACKGROUND_DARK);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE
        ));

        // Create a scroll pane to hold the content panel
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getVerticalScrollBar().setUI(new ModernScrollBarUI());
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setBackground(ModernUITheme.BACKGROUND_DARK);

        // Create the main panel that will hold the scroll pane
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ModernUITheme.BACKGROUND_DARK);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Create anti-ban settings card
        GlassCard antiBanCard = new GlassCard("Anti-Ban Settings");
        antiBanCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Don't set maximum size to allow the card to grow with its content

        // Create form panel for anti-ban settings
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_MEDIUM);

        // Add toggle switch
        ModernToggleSwitch enableAntiBan = new ModernToggleSwitch();
        enableAntiBan.setSelected(true);
        addFormField(formPanel, gbc, "Enable Anti-Ban:", enableAntiBan);
        gbc.gridy++;

        // Add checkboxes
        gbc.gridwidth = 2;
        ModernCheckBox checkBox1 = new ModernCheckBox("Random Camera Movement");
        checkBox1.setSelected(true);
        formPanel.add(checkBox1, gbc);

        gbc.gridy++;
        ModernCheckBox checkBox2 = new ModernCheckBox("Random Mouse Movement");
        checkBox2.setSelected(true);
        formPanel.add(checkBox2, gbc);

        gbc.gridy++;
        ModernCheckBox checkBox3 = new ModernCheckBox("Examine Random Objects");
        checkBox3.setSelected(true);
        formPanel.add(checkBox3, gbc);

        gbc.gridy++;
        ModernCheckBox checkBox4 = new ModernCheckBox("Open Random Tabs");
        formPanel.add(checkBox4, gbc);

        gbc.gridy++;
        ModernCheckBox checkBox5 = new ModernCheckBox("Random AFK Periods");
        checkBox5.setSelected(true);
        formPanel.add(checkBox5, gbc);

        gbc.gridy++;
        ModernCheckBox checkBox6 = new ModernCheckBox("Random Misclicks");
        formPanel.add(checkBox6, gbc);

        gbc.gridy++;
        ModernCheckBox checkBox7 = new ModernCheckBox("Random Right-Clicks");
        formPanel.add(checkBox7, gbc);

        gbc.gridy++;
        ModernCheckBox checkBox8 = new ModernCheckBox("Check XP Randomly");
        checkBox8.setSelected(true);
        formPanel.add(checkBox8, gbc);

        gbc.gridy++;
        ModernCheckBox checkBox9 = new ModernCheckBox("Check Inventory Randomly");
        checkBox9.setSelected(true);
        formPanel.add(checkBox9, gbc);

        gbc.gridy++;
        ModernCheckBox checkBox10 = new ModernCheckBox("Check Equipment Randomly");
        formPanel.add(checkBox10, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        addFormField(formPanel, gbc, "Anti-Ban Frequency:", new ModernSpinner(new SpinnerNumberModel(50, 1, 100, 1)));

        gbc.gridy++;
        addFormField(formPanel, gbc, "AFK Min Duration (ms):", new ModernSpinner(new SpinnerNumberModel(500, 100, 5000, 100)));

        gbc.gridy++;
        addFormField(formPanel, gbc, "AFK Max Duration (ms):", new ModernSpinner(new SpinnerNumberModel(2000, 500, 10000, 100)));

        gbc.gridy++;
        addFormField(formPanel, gbc, "Misclick Chance (%):", new ModernSpinner(new SpinnerNumberModel(5, 0, 20, 1)));

        // Add advanced anti-ban section
        gbc.gridy++;
        gbc.gridwidth = 2;
        JLabel advancedLabel = new JLabel("Advanced Anti-Ban Settings");
        advancedLabel.setFont(ModernUITheme.FONT_TITLE);
        advancedLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        advancedLabel.setBorder(BorderFactory.createEmptyBorder(ModernUITheme.SPACING_MEDIUM, 0, ModernUITheme.SPACING_SMALL, 0));
        formPanel.add(advancedLabel, gbc);

        gbc.gridy++;
        ModernCheckBox advancedAntiBan = new ModernCheckBox("Enable advanced anti-ban measures");
        formPanel.add(advancedAntiBan, gbc);

        gbc.gridy++;
        ModernCheckBox humanPatterns = new ModernCheckBox("Use human behavior patterns");
        humanPatterns.setSelected(true);
        formPanel.add(humanPatterns, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        addFormField(formPanel, gbc, "Pattern Complexity:", new ModernSpinner(new SpinnerNumberModel(3, 1, 5, 1)));

        antiBanCard.addContent(formPanel);
        contentPanel.add(antiBanCard);

        return panel;
    }

    /**
     * Creates the muling settings panel
     */
    private JPanel createMulingSettingsPanel() {
        // Create a content panel that will hold all the components
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(ModernUITheme.BACKGROUND_DARK);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE
        ));

        // Create a scroll pane to hold the content panel
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getVerticalScrollBar().setUI(new ModernScrollBarUI());
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setBackground(ModernUITheme.BACKGROUND_DARK);

        // Create the main panel that will hold the scroll pane
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ModernUITheme.BACKGROUND_DARK);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Create muling settings card
        GlassCard mulingCard = new GlassCard("Muling Settings");
        mulingCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Don't set maximum size to allow the card to grow with its content

        // Create form panel for muling settings
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_MEDIUM);

        // Add toggle switch
        ModernToggleSwitch enableMuling = new ModernToggleSwitch();
        addFormField(formPanel, gbc, "Enable Muling:", enableMuling);
        gbc.gridy++;

        // Add form fields
        addFormField(formPanel, gbc, "Mule Username:", new ModernTextField("MuleAccount"));
        gbc.gridy++;
        addFormField(formPanel, gbc, "Threshold:", new ModernSpinner(new SpinnerNumberModel(1000, 1, 10000, 100)));
        gbc.gridy++;
        addFormField(formPanel, gbc, "World:", new ModernSpinner(new SpinnerNumberModel(301, 301, 599, 1)));
        gbc.gridy++;
        addFormField(formPanel, gbc, "Location:", new ModernComboBox<>(new String[]{"Grand Exchange", "Varrock West Bank", "Edgeville Bank"}));

        // Add more muling settings
        gbc.gridy++;
        gbc.gridwidth = 2;
        ModernCheckBox tradeOnlyWhenFull = new ModernCheckBox("Trade only when inventory is full");
        formPanel.add(tradeOnlyWhenFull, gbc);

        gbc.gridy++;
        ModernCheckBox useTradeChat = new ModernCheckBox("Use trade chat messages");
        useTradeChat.setSelected(true);
        formPanel.add(useTradeChat, gbc);

        gbc.gridy++;
        ModernCheckBox hopToMuleWorld = new ModernCheckBox("Hop to mule's world");
        hopToMuleWorld.setSelected(true);
        formPanel.add(hopToMuleWorld, gbc);

        gbc.gridy++;
        ModernCheckBox waitForMule = new ModernCheckBox("Wait for mule if offline");
        formPanel.add(waitForMule, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        addFormField(formPanel, gbc, "Max Wait Time (min):", new ModernSpinner(new SpinnerNumberModel(5, 1, 30, 1)));

        // Add security section
        gbc.gridy++;
        gbc.gridwidth = 2;
        JLabel securityLabel = new JLabel("Muling Security");
        securityLabel.setFont(ModernUITheme.FONT_TITLE);
        securityLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        securityLabel.setBorder(BorderFactory.createEmptyBorder(ModernUITheme.SPACING_MEDIUM, 0, ModernUITheme.SPACING_SMALL, 0));
        formPanel.add(securityLabel, gbc);

        gbc.gridy++;
        ModernCheckBox verifyMule = new ModernCheckBox("Verify mule account");
        verifyMule.setSelected(true);
        formPanel.add(verifyMule, gbc);

        gbc.gridy++;
        ModernCheckBox useTradeCode = new ModernCheckBox("Use trade verification code");
        useTradeCode.setSelected(true);
        formPanel.add(useTradeCode, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        addFormField(formPanel, gbc, "Trade Code:", new ModernTextField("1234"));

        gbc.gridy++;
        addFormField(formPanel, gbc, "Trade Timeout (sec):", new ModernSpinner(new SpinnerNumberModel(30, 5, 120, 5)));

        mulingCard.addContent(formPanel);
        contentPanel.add(mulingCard);

        return panel;
    }

    /**
     * Creates the restock settings panel
     */
    private JPanel createRestockSettingsPanel() {
        // Create a content panel that will hold all the components
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(ModernUITheme.BACKGROUND_DARK);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE
        ));

        // Create a scroll pane to hold the content panel
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getVerticalScrollBar().setUI(new ModernScrollBarUI());
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setBackground(ModernUITheme.BACKGROUND_DARK);

        // Create the main panel that will hold the scroll pane
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ModernUITheme.BACKGROUND_DARK);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Create restock settings card
        GlassCard restockCard = new GlassCard("Restock Settings");
        restockCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Don't set maximum size to allow the card to grow with its content

        // Create form panel for restock settings
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_MEDIUM);

        // Add toggle switch
        ModernToggleSwitch enableRestock = new ModernToggleSwitch();
        enableRestock.setSelected(true);
        addFormField(formPanel, gbc, "Enable Restocking:", enableRestock);
        gbc.gridy++;

        // Add form fields
        addFormField(formPanel, gbc, "GE World:", new ModernSpinner(new SpinnerNumberModel(301, 301, 599, 1)));
        gbc.gridy++;
        addFormField(formPanel, gbc, "Price Multiplier:", new ModernSpinner(new SpinnerNumberModel(1.1, 1.0, 2.0, 0.1)));

        // Add more restock settings
        gbc.gridy++;
        gbc.gridwidth = 2;
        ModernCheckBox useGE = new ModernCheckBox("Use Grand Exchange");
        useGE.setSelected(true);
        formPanel.add(useGE, gbc);

        gbc.gridy++;
        ModernCheckBox waitForOffers = new ModernCheckBox("Wait for offers to complete");
        waitForOffers.setSelected(true);
        formPanel.add(waitForOffers, gbc);

        gbc.gridy++;
        ModernCheckBox increaseOfferPrice = new ModernCheckBox("Increase offer price if stalled");
        increaseOfferPrice.setSelected(true);
        formPanel.add(increaseOfferPrice, gbc);

        gbc.gridy++;
        ModernCheckBox decantPotions = new ModernCheckBox("Decant potions after purchase");
        formPanel.add(decantPotions, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        addFormField(formPanel, gbc, "Max Price Increase (%):", new ModernSpinner(new SpinnerNumberModel(20, 5, 50, 5)));

        gbc.gridy++;
        addFormField(formPanel, gbc, "Stall Timeout (sec):", new ModernSpinner(new SpinnerNumberModel(30, 10, 120, 5)));

        // Add advanced restock section
        gbc.gridy++;
        gbc.gridwidth = 2;
        JLabel advancedLabel = new JLabel("Advanced Restock Settings");
        advancedLabel.setFont(ModernUITheme.FONT_TITLE);
        advancedLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        advancedLabel.setBorder(BorderFactory.createEmptyBorder(ModernUITheme.SPACING_MEDIUM, 0, ModernUITheme.SPACING_SMALL, 0));
        formPanel.add(advancedLabel, gbc);

        gbc.gridy++;
        ModernCheckBox useAlternativeSources = new ModernCheckBox("Use alternative sources if GE fails");
        formPanel.add(useAlternativeSources, gbc);

        gbc.gridy++;
        ModernCheckBox trackPrices = new ModernCheckBox("Track price history");
        trackPrices.setSelected(true);
        formPanel.add(trackPrices, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        addFormField(formPanel, gbc, "Max Buy Attempts:", new ModernSpinner(new SpinnerNumberModel(3, 1, 10, 1)));

        gbc.gridy++;
        addFormField(formPanel, gbc, "Price Data Source:", new ModernComboBox<>(new String[]{"Live Prices API", "GE Tracker", "RuneLite"}));

        restockCard.addContent(formPanel);
        contentPanel.add(restockCard);

        // Add some spacing
        contentPanel.add(Box.createVerticalStrut(ModernUITheme.SPACING_LARGE));

        // Create items table card
        GlassCard itemsCard = new GlassCard("Restock Items");
        itemsCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Don't set maximum size to allow the card to grow with its content

        // Create table for items
        String[] columnNames = {"Item Name", "Threshold", "Quantity", "Actions"};
        Object[][] data = {
            {"Nature rune", 100, 1000, "Remove"},
            {"Pure essence", 500, 5000, "Remove"},
            {"Stamina potion(4)", 2, 10, "Remove"},
            {"Prayer potion(4)", 3, 15, "Remove"},
            {"Super combat potion(4)", 2, 8, "Remove"},
            {"Antidote++(4)", 1, 5, "Remove"},
            {"Ranging potion(4)", 2, 10, "Remove"},
            {"Super restore(4)", 3, 15, "Remove"},
            {"Shark", 50, 200, "Remove"},
            {"Monkfish", 50, 200, "Remove"},
            {"Lobster", 50, 200, "Remove"},
            {"Law rune", 100, 1000, "Remove"},
            {"Cosmic rune", 100, 1000, "Remove"},
            {"Death rune", 100, 1000, "Remove"},
            {"Blood rune", 100, 1000, "Remove"},
            {"Soul rune", 100, 1000, "Remove"},
            {"Astral rune", 100, 1000, "Remove"},
            {"Mind rune", 100, 1000, "Remove"},
            {"Chaos rune", 100, 1000, "Remove"},
            {"Fire rune", 100, 1000, "Remove"},
            {"Water rune", 100, 1000, "Remove"},
            {"Air rune", 100, 1000, "Remove"},
            {"Earth rune", 100, 1000, "Remove"}
        };

        JTable table = new JTable(data, columnNames);
        table.setBackground(ModernUITheme.BACKGROUND_MEDIUM);
        table.setForeground(ModernUITheme.TEXT_PRIMARY);
        table.setGridColor(new Color(50, 50, 60));
        table.setRowHeight(30);
        table.getTableHeader().setBackground(ModernUITheme.BACKGROUND_DARK);
        table.getTableHeader().setForeground(ModernUITheme.TEXT_PRIMARY);

        JScrollPane tableScrollPane = new JScrollPane(table);
        tableScrollPane.setBorder(BorderFactory.createEmptyBorder());
        tableScrollPane.getViewport().setBackground(ModernUITheme.BACKGROUND_MEDIUM);
        tableScrollPane.getVerticalScrollBar().setUI(new ModernScrollBarUI());

        itemsCard.addContent(tableScrollPane);

        // Add fetch button
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setOpaque(false);
        AnimatedButton fetchButton = new AnimatedButton("Fetch Current Items", AnimatedButton.ButtonStyle.PRIMARY);
        buttonPanel.add(fetchButton);

        itemsCard.getFooterPanel().add(buttonPanel);

        contentPanel.add(itemsCard);

        return panel;
    }

    /**
     * Helper method to add a form field with label
     */
    private void addFormField(JPanel panel, GridBagConstraints gbc, String labelText, JComponent field) {
        JLabel label = new JLabel(labelText);
        label.setForeground(ModernUITheme.TEXT_PRIMARY);
        label.setFont(ModernUITheme.FONT_REGULAR);

        gbc.gridx = 0;
        gbc.weightx = 0.0;
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;

        // Handle toggle switches differently to prevent stretching
        if (field instanceof ModernToggleSwitch) {
            gbc.fill = GridBagConstraints.NONE;
            gbc.anchor = GridBagConstraints.WEST;

            // Create a wrapper panel to prevent stretching
            JPanel wrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            wrapper.setOpaque(false);
            wrapper.add(field);
            panel.add(wrapper, gbc);
        } else {
            gbc.fill = GridBagConstraints.HORIZONTAL;
            panel.add(field, gbc);
        }
    }

    /**
     * Creates the style settings panel
     */
    private JPanel createStyleSettingsPanel() {
        // Create a content panel that will hold all the components
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(ModernUITheme.BACKGROUND_DARK);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE,
            ModernUITheme.SPACING_LARGE
        ));

        // Create a scroll pane to hold the content panel
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getVerticalScrollBar().setUI(new ModernScrollBarUI());
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setBackground(ModernUITheme.BACKGROUND_DARK);

        // Create the main panel that will hold the scroll pane
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ModernUITheme.BACKGROUND_DARK);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Create style panel
        StylePanel stylePanel = new StylePanel();
        contentPanel.add(stylePanel);

        // Add preview section
        GlassCard previewCard = new GlassCard("Preview");
        previewCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel previewPanel = new JPanel();
        previewPanel.setLayout(new BoxLayout(previewPanel, BoxLayout.Y_AXIS));
        previewPanel.setOpaque(false);

        // Add preview components
        JLabel titleLabel = new JLabel("This is a title");
        titleLabel.setFont(ModernUITheme.FONT_TITLE);
        titleLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        previewPanel.add(titleLabel);

        previewPanel.add(Box.createVerticalStrut(ModernUITheme.SPACING_MEDIUM));

        JLabel regularLabel = new JLabel("This is regular text");
        regularLabel.setFont(ModernUITheme.FONT_REGULAR);
        regularLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        regularLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        previewPanel.add(regularLabel);

        previewPanel.add(Box.createVerticalStrut(ModernUITheme.SPACING_SMALL));

        JLabel secondaryLabel = new JLabel("This is secondary text");
        secondaryLabel.setFont(ModernUITheme.FONT_REGULAR);
        secondaryLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        secondaryLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        previewPanel.add(secondaryLabel);

        previewPanel.add(Box.createVerticalStrut(ModernUITheme.SPACING_MEDIUM));

        JButton button = new JButton("Button");
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        previewPanel.add(button);

        previewCard.addContent(previewPanel);
        contentPanel.add(Box.createVerticalStrut(ModernUITheme.SPACING_LARGE));
        contentPanel.add(previewCard);

        return panel;
    }
}
