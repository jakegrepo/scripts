package examples;

import core.config.RestockConfig;
import core.utils.RestockItemUtils;

/**
 * Test class to verify the simplified restock system is working
 */
public class TestSimplifiedRestock {
    
    public static void main(String[] args) {
        System.out.println("=== TESTING SIMPLIFIED RESTOCK SYSTEM ===\n");
        
        // Test 1: Basic RestockConfig functionality
        System.out.println("1. Testing RestockConfig basic functionality:");
        RestockConfig config = new RestockConfig();
        
        // Add some items
        config.addItem("Karambwan", 20);
        config.addItem("Super combat potion(4)", 1, 8.0);
        config.addItem("Prayer potion(4)", 2);
        
        System.out.println("✓ Added items successfully");
        System.out.println("Items in config: " + config.getAllItems().size());
        
        // Test 2: Verify automatic calculations
        System.out.println("\n2. Testing automatic min/max calculations:");
        for (RestockConfig.RestockItem item : config.getAllItems().values()) {
            System.out.printf("  %s: Usage=%d, Multiplier=%.1fx, Min=%d, Max=%d%n", 
                item.itemName, item.usagePerTrip, item.multiplier, 
                item.getMinStock(), item.getMaxStock());
        }
        
        // Test 3: Legacy compatibility
        System.out.println("\n3. Testing legacy compatibility:");
        System.out.println("Legacy getInventoryItemsToRestock(): " + config.getInventoryItemsToRestock());
        System.out.println("Legacy getInventoryItemMinimumQuantity('Karambwan'): " + 
                          config.getInventoryItemMinimumQuantity("Karambwan"));
        System.out.println("Legacy getInventoryItemDesiredQuantity('Karambwan'): " + 
                          config.getInventoryItemDesiredQuantity("Karambwan"));
        
        // Test 4: RestockItemUtils functionality
        System.out.println("\n4. Testing RestockItemUtils:");
        String[] testItems = {
            "Shark", "Dragon arrow", "Death rune", "Ring of wealth(5)",
            "Super strength(4)", "Varrock teleport", "Coins", "Rune pickaxe"
        };
        
        for (String item : testItems) {
            String category = RestockItemUtils.getItemCategory(item);
            boolean excluded = RestockItemUtils.shouldExclude(item);
            int estimate = RestockItemUtils.getUsageEstimate(item, 100);
            
            System.out.printf("  %-20s | Category: %-10s | Estimate: %3d/trip | Excluded: %s%n", 
                item, category, estimate, excluded);
        }
        
        // Test 5: Multiplier updates
        System.out.println("\n5. Testing multiplier updates:");
        config.updateAllMultipliers(10.0);
        System.out.println("After changing multiplier to 10x:");
        for (RestockConfig.RestockItem item : config.getAllItems().values()) {
            System.out.printf("  %s: Min=%d, Max=%d%n", 
                item.itemName, item.getMinStock(), item.getMaxStock());
        }
        
        // Test 6: Sell functionality
        System.out.println("\n6. Testing sell functionality:");
        RestockConfig.RestockItem karambwan = config.getItem("Karambwan");
        karambwan.sellExcess = true;
        karambwan.updateSellThreshold();
        System.out.printf("Karambwan with sell excess enabled: sell threshold = %d%n", 
                         karambwan.sellThreshold);
        
        System.out.println("\n=== ALL TESTS COMPLETED SUCCESSFULLY ===");
        System.out.println("The simplified restock system is working correctly!");
    }
} 