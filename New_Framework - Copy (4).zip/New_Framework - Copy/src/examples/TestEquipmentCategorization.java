package examples;

import core.utils.RestockItemUtils;

/**
 * Test for equipment categorization functionality
 */
public class TestEquipmentCategorization {
    
    public static void main(String[] args) {
        System.out.println("=== TESTING EQUIPMENT CATEGORIZATION ===\n");
        
        // Test standard item categorization
        System.out.println("1. Testing standard item categorization:");
        testStandardItems();
        
        // Test equipment categorization
        System.out.println("\n2. Testing equipment categorization:");
        testEquipmentItems();
        
        // Test charged jewelry detection
        System.out.println("\n3. Testing charged jewelry detection:");
        testChargedJewelry();
        
        System.out.println("\n=== ALL TESTS COMPLETED ===");
    }
    
    private static void testStandardItems() {
        String[] testItems = {
            "Shark",
            "Super combat potion(4)", 
            "Death rune",
            "Dragon arrow",
            "Varrock teleport"
        };
        
        for (String item : testItems) {
            String category = RestockItemUtils.getItemCategory(item);
            System.out.printf("  %-25s | Category: %-12s%n", item, category);
        }
        
        // Test the fixed potion detection
        System.out.println("\n  Testing fixed potion detection:");
        String[] potionTestItems = {
            "Amulet of strength",      // Should be "Other" or "Jewelry" (not Potion)
            "Ring of strength",        // Should be "Jewelry" (not Potion)  
            "Super strength(4)",       // Should be "Potion" (has parentheses)
            "Strength potion(4)",      // Should be "Potion"
            "Combat potion(3)",        // Should be "Potion"
            "Combat bracelet"          // Should be "Other" or "Jewelry" (not Potion)
        };
        
        for (String item : potionTestItems) {
            String category = RestockItemUtils.getItemCategory(item);
            System.out.printf("    %-25s | Category: %-12s%n", item, category);
        }
    }
    
    private static void testEquipmentItems() {
        // Test equipment items that should be categorized as "Gear"
        String[] equipmentItems = {
            "Dragon scimitar",
            "Rune platebody", 
            "Dragon boots",
            "Barrows gloves",
            "Fire cape",
            "Dragon defender"
        };
        
        for (String item : equipmentItems) {
            String category = RestockItemUtils.getEquipmentCategory(item, "WEAPON");
            System.out.printf("  %-25s | Equipment Category: %-12s%n", item, category);
        }
    }
    
    private static void testChargedJewelry() {
        // Test charged jewelry (rings and amulets with parentheses)
        System.out.println("  Rings with charges:");
        testJewelryItem("Ring of wealth(5)", "RING");
        testJewelryItem("Dueling ring(8)", "RING");
        testJewelryItem("Ring of life", "RING"); // No charges
        
        System.out.println("\n  Amulets with charges:");
        testJewelryItem("Amulet of glory(6)", "AMULET");
        testJewelryItem("Skills necklace(6)", "AMULET");
        testJewelryItem("Amulet of power", "AMULET"); // No charges
        
        System.out.println("\n  Other equipment in jewelry slots:");
        testJewelryItem("Dragon boots", "BOOTS"); // Not a jewelry slot
        testJewelryItem("Dragon scimitar", "WEAPON"); // Not a jewelry slot
    }
    
    private static void testJewelryItem(String itemName, String slot) {
        String category = RestockItemUtils.getEquipmentCategory(itemName, slot);
        boolean hasCharges = itemName.contains("(");
        System.out.printf("    %-25s | Slot: %-7s | Has charges: %-5s | Category: %-12s%n", 
            itemName, slot, hasCharges, category);
    }
} 