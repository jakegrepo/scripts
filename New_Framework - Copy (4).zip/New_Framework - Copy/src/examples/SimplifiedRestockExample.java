package examples;

import core.config.RestockConfig;
import core.utils.RestockItemUtils;

/**
 * Example demonstrating the new simplified restock system
 */
public class SimplifiedRestockExample {
    
    public static void main(String[] args) {
        // Create a new restock configuration
        RestockConfig config = new RestockConfig();
        
        System.out.println("=== SIMPLIFIED RESTOCK SYSTEM EXAMPLE ===\n");
        
        // Example 1: Adding items the simple way
        System.out.println("1. Adding items with usage per trip:");
        config.addItem("Karambwan", 20);  // Use 20 karambwan per trip
        config.addItem("Super combat potion(4)", 1);  // Use 1 potion per trip
        config.addItem("Prayer potion(4)", 2);  // Use 2 prayer potions per trip
        config.addItem("Teleport to house", 5);  // Use 5 house teleports per trip
        
        // With default multiplier of 6x:
        // - Karambwan: Min=20, Max=120 (restock when below 20, buy up to 120)
        // - Combat potion: Min=1, Max=6 (restock when below 1, buy up to 6)
        // - Prayer potion: Min=2, Max=12 (restock when below 2, buy up to 12)
        // - House teleports: Min=5, Max=30 (restock when below 5, buy up to 30)
        
        System.out.println("Added items with automatic calculation:");
        for (RestockConfig.RestockItem item : config.getAllItems().values()) {
            System.out.printf("  %s: %d/trip × %.1fx = Min:%d, Max:%d%n", 
                item.itemName, item.usagePerTrip, item.multiplier, 
                item.getMinStock(), item.getMaxStock());
        }
        
        System.out.println("\n2. Smart item categorization:");
        String[] testItems = {
            "Shark", "Dragon arrow", "Death rune", "Ring of wealth(5)",
            "Super strength(4)", "Varrock teleport", "Coins", "Rune pickaxe"
        };
        
        for (String item : testItems) {
            String category = RestockItemUtils.getItemCategory(item);
            boolean excluded = RestockItemUtils.shouldExclude(item);
            int estimate = RestockItemUtils.getUsageEstimate(item, 100);
            
            System.out.printf("  %-20s | Category: %-10s | Estimate: %3d/trip | Excluded: %s%n", 
                item, category, estimate, excluded);
        }
        
        System.out.println("\n3. Changing multiplier affects all items:");
        config.updateAllMultipliers(10.0);  // Change to 10x multiplier
        
        System.out.println("After changing multiplier to 10x:");
        for (RestockConfig.RestockItem item : config.getAllItems().values()) {
            System.out.printf("  %s: %d/trip × %.1fx = Min:%d, Max:%d%n", 
                item.itemName, item.usagePerTrip, item.multiplier, 
                item.getMinStock(), item.getMaxStock());
        }
        
        System.out.println("\n4. Selling excess items:");
        RestockConfig.RestockItem karambwan = config.getItem("Karambwan");
        karambwan.sellExcess = true;
        karambwan.updateSellThreshold();  // Auto-calculates sell threshold
        
        System.out.printf("Karambwan sell threshold: %d (auto-calculated as max + 2 trips worth)%n", 
            karambwan.sellThreshold);
        
        System.out.println("\n=== BENEFITS OF NEW SYSTEM ===");
        System.out.println("✓ Simple: Just set usage per trip + multiplier");
        System.out.println("✓ Automatic: Min/max calculated automatically");
        System.out.println("✓ Smart detection: Categorizes items with intelligent estimates");
        System.out.println("✓ Flexible: Easy to adjust multiplier for all items");
        System.out.println("✓ User-friendly: Clear understanding of what each value means");
        System.out.println("✓ Example: 20 food/trip × 6 multiplier = restock when <20, buy up to 120");
        
        config.logConfig();
    }
} 