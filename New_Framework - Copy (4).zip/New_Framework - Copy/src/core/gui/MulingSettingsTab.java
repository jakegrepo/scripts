package core.gui;

import core.base.ScarScript;
import core.context.ScriptContext;
import core.gui.panels.MulingSettingsPanel;
import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.io.File;

/**
 * Muling settings tab for framework-wide muling settings
 */
public class MulingSettingsTab extends AbstractSettingsTab {
    private MulingSettingsPanel mulingPanel;

    /**
     * Creates a new muling settings tab
     */
    public MulingSettingsTab(ScriptContext context) {
        super(context);
        
        // Create panel
        mulingPanel = new MulingSettingsPanel(((ScarScript<?>) context.getScript()).getConfig());
        
        // Add panel to main panel
        addSection("Muling Settings", mulingPanel);
    }

    @Override
    public void createComponents() {
        // No additional components needed
    }

    @Override
    public void saveSettings() {
        debug("Saving muling settings");
        // Save panel settings
        mulingPanel.saveSettings();
        
        // Save config to file
        ((ScarScript<?>) context.getScript()).getConfig().saveConfig();
    }

    @Override
    public void loadSettings() {
        debug("Loading muling settings");
        // Load panel settings
        mulingPanel.loadSettings();
    }

    @Override
    public void resetToDefaults() {
        debug("Resetting muling settings to defaults");
        // Reset panel to defaults
        mulingPanel.loadSettings();
    }

    @Override
    public String getTitle() {
        return "Muling";
    }

    @Override
    protected File getProfilesDirectory() {
        File dir = new File("ScarFramework/profiles/framework/");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }
}
