package core.gui;

import core.base.ScarScript;
import core.config.RestockConfig;
import core.config.ScriptConfig;
import core.context.ScriptContext;
import core.gui.panels.RestockSettingsPanel;
import org.dreambot.api.utilities.Logger;

import java.io.File;

/**
 * Restock settings tab for framework-wide restock settings using simplified multiplier system
 */
public class RestockSettingsTab extends AbstractSettingsTab {
    private RestockSettingsPanel restockPanel;
    private ScriptConfig config;

    /**
     * Creates a new restock settings tab
     */
    public RestockSettingsTab(ScriptContext context) {
        super(context);
        this.config = ((ScarScript<?>) context.getScript()).getConfig();

        // Create the new simplified panel
        restockPanel = new RestockSettingsPanel(config);

        // Add panel to main panel - remove "Simplified" from header
        addSection("Restock Settings", restockPanel);
    }

    @Override
    public void createComponents() {
        // No additional components needed - the RestockSettingsPanel handles everything
    }

    @Override
    public void saveSettings() {
        debug("Saving restock settings");
        
        // Save panel settings
        restockPanel.saveSettings();

        // Log the restock configuration for debugging
        RestockConfig restockConfig = config.getRestockConfig();
        debug("Restock enabled: " + restockConfig.isEnabled());
        debug("Default multiplier: " + restockConfig.getDefaultMultiplier());
        debug("Items configured: " + restockConfig.getAllItems().size());

        // Save config to file
        config.saveConfig();
        debug("Config saved to file");
    }

    @Override
    public void loadSettings() {
        debug("Loading restock settings");
        
        // Load panel settings
        restockPanel.loadSettings();
        
        // Log loaded configuration
        RestockConfig restockConfig = config.getRestockConfig();
        debug("Loaded " + restockConfig.getAllItems().size() + " restock items");
    }

    @Override
    public void resetToDefaults() {
        debug("Resetting restock settings to defaults");
        
        // Clear all items and reset to defaults
        RestockConfig restockConfig = config.getRestockConfig();
        restockConfig.getAllItems().clear();
        restockConfig.setDefaultMultiplier(6.0);
        restockConfig.setEnabled(true);
        
        // Reload the panel
        restockPanel.loadSettings();
        
        debug("Reset to defaults complete");
    }

    @Override
    public String getTitle() {
        return "Restock";
    }

    @Override
    protected File getProfilesDirectory() {
        File dir = new File("ScarFramework/profiles/framework/");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }
}
