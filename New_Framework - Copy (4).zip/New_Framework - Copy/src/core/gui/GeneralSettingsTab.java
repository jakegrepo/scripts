package core.gui;

import core.base.ScarScript;
import core.context.ScriptContext;
import core.gui.panels.GeneralSettingsPanel;
import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.io.File;

/**
 * General settings tab for framework-wide general settings
 */
public class GeneralSettingsTab extends AbstractSettingsTab {
    private GeneralSettingsPanel generalPanel;

    /**
     * Creates a new general settings tab
     */
    public GeneralSettingsTab(ScriptContext context) {
        super(context);
        
        // Create panel
        generalPanel = new GeneralSettingsPanel(((ScarScript<?>) context.getScript()).getConfig());
        
        // Add panel to main panel
        addSection("General Settings", generalPanel);
    }

    @Override
    public void createComponents() {
        // No additional components needed
    }

    @Override
    public void saveSettings() {
        debug("Saving general settings");
        // Save panel settings
        generalPanel.saveSettings();
        
        // Save config to file
        ((ScarScript<?>) context.getScript()).getConfig().saveConfig();
    }

    @Override
    public void loadSettings() {
        debug("Loading general settings");
        // Load panel settings
        generalPanel.loadSettings();
    }

    @Override
    public void resetToDefaults() {
        debug("Resetting general settings to defaults");
        // Reset panel to defaults
        generalPanel.loadSettings();
    }

    @Override
    public String getTitle() {
        return "General";
    }

    @Override
    protected File getProfilesDirectory() {
        File dir = new File("ScarFramework/profiles/framework/");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }
}
