package core.gui;

import core.base.ScarScript;
import core.context.ScriptContext;
import core.gui.panels.AntiBanSettingsPanel;
import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.io.File;

/**
 * Anti-Ban settings tab for framework-wide anti-ban settings
 */
public class AntiBanSettingsTab extends AbstractSettingsTab {
    private AntiBanSettingsPanel antiBanPanel;

    /**
     * Creates a new anti-ban settings tab
     */
    public AntiBanSettingsTab(ScriptContext context) {
        super(context);
        
        // Create panel
        antiBanPanel = new AntiBanSettingsPanel(((ScarScript<?>) context.getScript()).getConfig());
        
        // Add panel to main panel
        addSection("Anti-Ban Settings", antiBanPanel);
    }

    @Override
    public void createComponents() {
        // No additional components needed
    }

    @Override
    public void saveSettings() {
        debug("Saving anti-ban settings");
        // Save panel settings
        antiBanPanel.saveSettings();
        
        // Save config to file
        ((ScarScript<?>) context.getScript()).getConfig().saveConfig();
    }

    @Override
    public void loadSettings() {
        debug("Loading anti-ban settings");
        // Load panel settings
        antiBanPanel.loadSettings();
    }

    @Override
    public void resetToDefaults() {
        debug("Resetting anti-ban settings to defaults");
        // Reset panel to defaults
        antiBanPanel.loadSettings();
    }

    @Override
    public String getTitle() {
        return "Anti-Ban";
    }

    @Override
    protected File getProfilesDirectory() {
        File dir = new File("ScarFramework/profiles/framework/");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }
}
