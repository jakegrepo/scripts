package core.gui;

import core.gui.components.FormPanel;
import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Panel for grouping related settings components with improved layout
 */
public class SettingsPanel extends JPanel {
    private final List<ConfigComponent<?>> components;
    private final FormPanel formPanel;

    public SettingsPanel() {
        this.components = new ArrayList<>();
        this.formPanel = new FormPanel();

        setupPanel();
    }

    private void setupPanel() {
        // Use BorderLayout to ensure FormPanel fills the entire space
        setLayout(new BorderLayout());
        setBackground(StyleManager.CARD_BG);
        setBorder(null);
        
        // Add the form panel to the center
        add(formPanel, BorderLayout.CENTER);
    }

    /**
     * Adds a labeled component to this panel
     */
    public void addLabeledComponent(String label, JComponent component) {
        // Style the component
        StyleManager.applyStyle(component);
        
        // Add the component to the form panel
        formPanel.addField(label, component);
        
        // Register config component if applicable
        if (component instanceof ConfigComponent) {
            components.add((ConfigComponent<?>) component);
        }
    }
    
    /**
     * Adds a config-bound component to this panel
     */
    public void addConfigComponent(String label, ConfigComponent<?> component) {
        addLabeledComponent(label, component.getComponent());
        components.add(component);
    }
    
    /**
     * Adds a section header to this panel
     */
    public void addSectionHeader(String text) {
        // Add the section header to the form panel
        formPanel.addSectionHeader(text);
    }
    
    /**
     * Adds a component that spans the full width of the panel
     */
    public void addFullWidthComponent(JComponent component) {
        // Style the component
        StyleManager.applyStyle(component);
        
        // Add the component to the form panel
        formPanel.addFullWidthComponent(component);
        
        // Register config component if applicable
        if (component instanceof ConfigComponent) {
            components.add((ConfigComponent<?>) component);
        }
    }
    
    /**
     * Adds vertical spacing
     */
    public void addSpacing() {
        formPanel.addVerticalSpacing(StyleManager.FIELD_SPACING);
    }
    
    /**
     * Adds vertical spacing to this panel
     */
    public void addVerticalSpacing(int height) {
        formPanel.addVerticalSpacing(height);
    }

    /**
     * Updates all components from config
     */
    public void updateFromConfig() {
        debug("Updating all components from config");
        for (ConfigComponent<?> component : components) {
            try {
                component.updateFromConfig();
            } catch (Exception e) {
                error("Error updating component from config", e);
            }
        }
    }

    /**
     * Saves all component values to config
     */
    public void saveToConfig() {
        debug("Saving all component values to config");
        for (ConfigComponent<?> component : components) {
            try {
                component.saveToConfig();
            } catch (Exception e) {
                error("Error saving component to config", e);
            }
        }
    }

    // Helper methods for logging
    protected void debug(String message) {
        System.out.println("[DEBUG] [SettingsPanel] " + message);
    }

    protected void error(String message, Exception e) {
        System.err.println("[ERROR] [SettingsPanel] " + message);
        if (e != null) {
            e.printStackTrace();
        }
    }
}
