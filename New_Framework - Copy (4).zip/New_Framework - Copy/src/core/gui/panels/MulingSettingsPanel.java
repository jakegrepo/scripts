package core.gui.panels;

import core.config.MulingConfig;
import core.config.ScriptConfig;
import core.gui.SettingsPanel;
import core.gui.style.ModernUITheme;
import core.gui.style.StyleManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * World-class Muling Settings Panel with efficient two-column layout
 */
public class MulingSettingsPanel extends SettingsPanel {
    private final ScriptConfig config;
    private final MulingConfig mulingConfig;

    // Core muling settings
    private JCheckBox enableMulingCheckbox;

    // Connection settings
    private JSpinner muleWorldSpinner;
    private JSpinner mulePortSpinner;
    private JComboBox<String> muleMeetingSpotComboBox;

    // Value settings
    private JSpinner muleTriggerValueSpinner;
    private JSpinner muleCoinsToKeepSpinner;

    // Item management
    private JTable itemsTable;
    private DefaultTableModel itemsTableModel;
    private JTextField newItemField;
    private JButton addItemButton;
    private JButton removeItemButton;

    private boolean isLoading = false;

    // Config keys for muling settings
    private static final String KEY_ENABLE_MULING = "enableMuling";
    private static final String KEY_MULE_WORLD = "muleWorld";
    private static final String KEY_MULE_PORT = "mulePort";
    private static final String KEY_MEETING_SPOT = "meetingSpot";
    private static final String KEY_TRIGGER_VALUE = "triggerValue";
    private static final String KEY_COINS_TO_KEEP = "coinsToKeep";
    private static final String KEY_ITEMS_TO_MULE = "itemsToMule";
    private static final String KEY_ITEM_THRESHOLDS = "itemThresholds";

    /**
     * Creates a new world-class muling settings panel
     */
    public MulingSettingsPanel(ScriptConfig config) {
        super();
        this.config = config;
        this.mulingConfig = config.getMulingConfig();

        initializeComponents();
        setupLayout();
        addListeners();
        loadSettings();
    }

    /**
     * Initializes components for muling settings
     */
    private void initializeComponents() {
        // Core muling settings
        enableMulingCheckbox = new JCheckBox("Enable Muling");

        // Connection settings
        muleWorldSpinner = new JSpinner(new SpinnerNumberModel(301, 301, 580, 1));
        mulePortSpinner = new JSpinner(new SpinnerNumberModel(61616, 1024, 65535, 1));
        JSpinner.NumberEditor portEditor = new JSpinner.NumberEditor(mulePortSpinner, "#");
        mulePortSpinner.setEditor(portEditor);

        String[] meetingSpots = {"Grand Exchange", "Ferox Enclave", "Lumbridge", "Varrock", "Falador", "Edgeville"};
        muleMeetingSpotComboBox = new JComboBox<>(meetingSpots);

        // Value settings
        muleTriggerValueSpinner = new JSpinner(new SpinnerNumberModel(1000000, 20, 2000000000, 10000));
        muleCoinsToKeepSpinner = new JSpinner(new SpinnerNumberModel(1000000, 0, 2000000000, 10000));

        // Item management
        itemsTableModel = new DefaultTableModel(new Object[]{"Item Name", "Threshold"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 0 || column == 1;
            }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 1 ? Integer.class : String.class;
            }
        };
        itemsTable = new JTable(itemsTableModel);
        newItemField = new JTextField();
        addItemButton = new JButton("Add");
        removeItemButton = new JButton("Remove Selected");

        // Apply styling to all components
        styleComponents();
    }

    /**
     * Applies modern styling to components
     */
    private void styleComponents() {
        // Style checkboxes
        StyleManager.styleCheckBox(enableMulingCheckbox);

        // Style spinners
        StyleManager.styleSpinner(muleWorldSpinner);
        StyleManager.styleSpinner(mulePortSpinner);
        StyleManager.styleSpinner(muleTriggerValueSpinner);
        StyleManager.styleSpinner(muleCoinsToKeepSpinner);

        // Style combo box
        StyleManager.styleComboBox(muleMeetingSpotComboBox);

        // Style table and text field
        StyleManager.styleTable(itemsTable);
        StyleManager.styleTextField(newItemField);

        // Style buttons
        StyleManager.styleButton(addItemButton);
        StyleManager.styleButton(removeItemButton);
    }

    /**
     * Sets up a tabbed interface to eliminate scrolling and improve usability
     */
    private void setupLayout() {
        setLayout(new BorderLayout());
        setBackground(ModernUITheme.BACKGROUND_DARKEST);

        // Create main panel with clean layout like BreakSettingsPanel
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(ModernUITheme.BACKGROUND_DARKEST);
        mainPanel.setBorder(new EmptyBorder(8, 8, 8, 8));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.insets = new Insets(2, 0, 2, 8);

        // Enable muling checkbox spans both columns
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 4; gbc.fill = GridBagConstraints.HORIZONTAL;
        enableMulingCheckbox.setFont(ModernUITheme.FONT_HEADER);
        enableMulingCheckbox.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(enableMulingCheckbox, gbc);

        // === CONNECTION SETTINGS SECTION ===
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 4; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 4, 0);
        JLabel connectionLabel = new JLabel("Connection Settings");
        connectionLabel.setFont(ModernUITheme.FONT_HEADER);
        connectionLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(connectionLabel, gbc);

        // World setting
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(2, 0, 2, 8);
        JLabel worldLabel = createFieldLabel("Mule World:");
        mainPanel.add(worldLabel, gbc);

        gbc.gridx = 1; gbc.weightx = 0;
        muleWorldSpinner.setPreferredSize(new Dimension(60, 26));
        mainPanel.add(muleWorldSpinner, gbc);

        gbc.gridx = 2; gbc.weightx = 0;
        gbc.insets = new Insets(2, 16, 2, 8);
        JLabel portLabel = createFieldLabel("Port:");
        mainPanel.add(portLabel, gbc);

        gbc.gridx = 3; gbc.weightx = 0;
        gbc.insets = new Insets(2, 0, 2, 0);
        mulePortSpinner.setPreferredSize(new Dimension(80, 26));
        mainPanel.add(mulePortSpinner, gbc);

        // Meeting spot
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 1; gbc.weightx = 0;
        gbc.insets = new Insets(2, 0, 2, 8);
        JLabel meetingLabel = createFieldLabel("Meeting Location:");
        mainPanel.add(meetingLabel, gbc);

        gbc.gridx = 1; gbc.gridwidth = 3; gbc.weightx = 0;
        gbc.insets = new Insets(2, 0, 2, 0);
        muleMeetingSpotComboBox.setPreferredSize(new Dimension(150, 26));
        mainPanel.add(muleMeetingSpotComboBox, gbc);

        // === VALUE SETTINGS SECTION ===
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 4; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0;
        gbc.insets = new Insets(12, 0, 4, 0);
        JLabel valuesLabel = new JLabel("Value Settings");
        valuesLabel.setFont(ModernUITheme.FONT_HEADER);
        valuesLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(valuesLabel, gbc);

        // Trigger value
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(2, 0, 2, 8);
        JLabel triggerLabel = createFieldLabel("Trigger Value (GP):");
        mainPanel.add(triggerLabel, gbc);

        gbc.gridx = 1; gbc.weightx = 0;
        muleTriggerValueSpinner.setPreferredSize(new Dimension(100, 26));
        mainPanel.add(muleTriggerValueSpinner, gbc);

        // Coins to keep
        gbc.gridx = 2; gbc.weightx = 0;
        gbc.insets = new Insets(2, 16, 2, 8);
        JLabel coinsLabel = createFieldLabel("Coins to Keep (GP):");
        mainPanel.add(coinsLabel, gbc);

        gbc.gridx = 3; gbc.weightx = 0;
        gbc.insets = new Insets(2, 0, 2, 0);
        muleCoinsToKeepSpinner.setPreferredSize(new Dimension(100, 26));
        mainPanel.add(muleCoinsToKeepSpinner, gbc);

        // === ITEMS SECTION ===
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 4; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0;
        gbc.insets = new Insets(12, 0, 4, 0);
        JLabel itemsLabel = new JLabel("Items to Mule");
        itemsLabel.setFont(ModernUITheme.FONT_HEADER);
        itemsLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(itemsLabel, gbc);

        // Items table
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 4; gbc.fill = GridBagConstraints.BOTH; gbc.weightx = 1.0; gbc.weighty = 1.0;
        gbc.insets = new Insets(2, 0, 2, 0);
        itemsTable.setRowHeight(22);
        itemsTable.getTableHeader().setPreferredSize(new Dimension(0, 24));
        JScrollPane itemsScrollPane = new JScrollPane(itemsTable);
        itemsScrollPane.setBorder(BorderFactory.createLineBorder(ModernUITheme.TEXT_SECONDARY.darker(), 1));
        itemsScrollPane.setPreferredSize(new Dimension(400, 120));
        mainPanel.add(itemsScrollPane, gbc);

        // Controls panel at bottom
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 4; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0; gbc.weighty = 0;
        gbc.insets = new Insets(2, 0, 0, 0);
        JPanel controlsPanel = new JPanel(new BorderLayout(4, 0));
        controlsPanel.setOpaque(false);

        // Add item panel
        JPanel addPanel = new JPanel(new BorderLayout(4, 0));
        addPanel.setOpaque(false);

        JLabel addLabel = createFieldLabel("Add Item:");
        addPanel.add(addLabel, BorderLayout.WEST);

        newItemField.setPreferredSize(new Dimension(180, 26));
        addPanel.add(newItemField, BorderLayout.CENTER);

        addItemButton.setPreferredSize(new Dimension(70, 26));
        addPanel.add(addItemButton, BorderLayout.EAST);

        controlsPanel.add(addPanel, BorderLayout.CENTER);

        removeItemButton.setPreferredSize(new Dimension(110, 26));
        controlsPanel.add(removeItemButton, BorderLayout.EAST);

        mainPanel.add(controlsPanel, gbc);

        add(mainPanel, BorderLayout.CENTER);
    }

    /**
     * Creates a styled field label
     */
    private JLabel createFieldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(ModernUITheme.FONT_REGULAR);
        label.setForeground(ModernUITheme.TEXT_SECONDARY);
        return label;
    }

    /**
     * Adds event listeners to components
     */
    private void addListeners() {
        enableMulingCheckbox.addActionListener(e -> {
            if (!isLoading) {
                updateComponentStates();
                saveSettings();
            }
        });

        muleWorldSpinner.addChangeListener(e -> {
            if (!isLoading) saveSettings();
        });

        mulePortSpinner.addChangeListener(e -> {
            if (!isLoading) saveSettings();
        });

        muleTriggerValueSpinner.addChangeListener(e -> {
            if (!isLoading) saveSettings();
        });

        muleCoinsToKeepSpinner.addChangeListener(e -> {
            if (!isLoading) saveSettings();
        });

        muleMeetingSpotComboBox.addActionListener(e -> {
            if (!isLoading) saveSettings();
        });

        addItemButton.addActionListener(e -> {
            String newItem = newItemField.getText().trim();
            if (!newItem.isEmpty()) {
                boolean exists = false;
                for (int i = 0; i < itemsTableModel.getRowCount(); i++) {
                    if (itemsTableModel.getValueAt(i, 0).equals(newItem)) {
                        exists = true;
                        break;
                    }
                }
                if (!exists) {
                    itemsTableModel.addRow(new Object[]{newItem, 1});
                    newItemField.setText("");
                    saveSettings();
                }
            }
        });

        removeItemButton.addActionListener(e -> {
            int selectedRow = itemsTable.getSelectedRow();
            if (selectedRow != -1) {
                itemsTableModel.removeRow(selectedRow);
                saveSettings();
            }
        });
    }

    /**
     * Updates component states based on enabled status
     */
    private void updateComponentStates() {
        boolean enabled = enableMulingCheckbox.isSelected();

        muleWorldSpinner.setEnabled(enabled);
        mulePortSpinner.setEnabled(enabled);
        muleTriggerValueSpinner.setEnabled(enabled);
        muleCoinsToKeepSpinner.setEnabled(enabled);
        muleMeetingSpotComboBox.setEnabled(enabled);

        itemsTable.setEnabled(enabled);
        newItemField.setEnabled(enabled);
        addItemButton.setEnabled(enabled);
        removeItemButton.setEnabled(enabled);
    }

    /**
     * Loads settings from config
     */
    public void loadSettings() {
        isLoading = true;
        try {
            // Get the latest muling configuration from the config
            MulingConfig latestConfig = config.getMulingConfig();

            // Update UI components with the latest values
            enableMulingCheckbox.setSelected(latestConfig.isEnabled());
            muleWorldSpinner.setValue(latestConfig.getMuleWorld());
            mulePortSpinner.setValue(latestConfig.getPort());
            muleTriggerValueSpinner.setValue(latestConfig.getTriggerValue());
            muleCoinsToKeepSpinner.setValue(latestConfig.getCoinsToKeep());
            muleMeetingSpotComboBox.setSelectedItem(latestConfig.getMeetingSpot());

            // Load items
            itemsTableModel.setRowCount(0);
            for (String item : latestConfig.getItemsToMule()) {
                int threshold = 1;
                if (latestConfig.getItemThresholds().containsKey(item)) {
                    threshold = latestConfig.getItemThresholds().get(item);
                }
                itemsTableModel.addRow(new Object[]{item, threshold});
            }

            updateComponentStates();
        } finally {
            isLoading = false;
        }
    }

    /**
     * Updates from config - called when loading a profile
     */
    public void updateFromConfig() {
        // We can't refresh the mulingConfig reference because it's final,
        // but we can still call loadSettings to update all components
        // The loadSettings method will use the latest values from mulingConfig
        loadSettings();
    }

    /**
     * Saves settings to config
     */
    public void saveSettings() {
        if (isLoading) return;

        // Get the latest muling configuration from the config
        MulingConfig latestConfig = config.getMulingConfig();

        // Update the configuration with the UI values
        latestConfig.setEnabled(enableMulingCheckbox.isSelected());
        latestConfig.setMuleWorld((int) muleWorldSpinner.getValue());
        latestConfig.setPort((int) mulePortSpinner.getValue());
        latestConfig.setTriggerValue((int) muleTriggerValueSpinner.getValue());
        latestConfig.setCoinsToKeep((int) muleCoinsToKeepSpinner.getValue());
        latestConfig.setMeetingSpot((String) muleMeetingSpotComboBox.getSelectedItem());

        // Save items
        List<String> itemsToMule = new ArrayList<>();
        java.util.Map<String, Integer> itemThresholds = new java.util.HashMap<>();
        for (int i = 0; i < itemsTableModel.getRowCount(); i++) {
            String item = (String) itemsTableModel.getValueAt(i, 0);
            int threshold = 1;
            try {
                threshold = Integer.parseInt(itemsTableModel.getValueAt(i, 1).toString());
            } catch (Exception ignored) {}
            itemsToMule.add(item);
            itemThresholds.put(item, threshold);
        }
        latestConfig.setItemsToMule(itemsToMule);
        latestConfig.setItemThresholds(itemThresholds);

        // Mark config as dirty
        config.markDirty();
    }
}
