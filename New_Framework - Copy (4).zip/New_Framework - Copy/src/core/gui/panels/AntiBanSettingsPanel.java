package core.gui.panels;

import core.config.ScriptConfig;
import core.gui.SettingsPanel;
import core.gui.style.ModernUITheme;
import core.gui.style.StyleManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * World-class Anti-Ban Settings Panel with full DreamBot API integration
 */
public class AntiBanSettingsPanel extends SettingsPanel {
    private final ScriptConfig config;

    // Core anti-ban settings (fully implemented with DreamBot API)
    private JCheckBox enableAntibanCheckbox;
    private JSlider antibanIntensitySlider;
    private JLabel intensityValueLabel;

    // Movement & Camera settings
    private JCheckBox randomMouseMovementsCheckbox;
    private JCheckBox randomCameraMovementsCheckbox;
    private JCheckBox randomTabChecksCheckbox;

    // Interaction settings
    private JCheckBox examineObjectsCheckbox;
    private JCheckBox hoverNPCsCheckbox;
    private JCheckBox hoverPlayersCheckbox;

    // AFK simulation settings
    private JCheckBox afkBreaksCheckbox;
    private JSpinner afkFrequencySpinner;
    private JSpinner afkDurationSpinner;

    private boolean isLoading = false;

    // Config keys for anti-ban settings
    private static final String KEY_ENABLE_ANTIBAN = "enableAntiban";
    private static final String KEY_ANTIBAN_INTENSITY = "antibanIntensity";
    private static final String KEY_RANDOM_MOUSE = "randomMouseMovements";
    private static final String KEY_RANDOM_CAMERA = "randomCameraMovements";
    private static final String KEY_RANDOM_TABS = "randomTabChecks";
    private static final String KEY_EXAMINE_OBJECTS = "examineObjects";
    private static final String KEY_HOVER_NPCS = "hoverNPCs";
    private static final String KEY_HOVER_PLAYERS = "hoverPlayers";
    private static final String KEY_AFK_BREAKS = "afkBreaks";
    private static final String KEY_AFK_FREQUENCY = "afkFrequency";
    private static final String KEY_AFK_DURATION = "afkDuration";

    /**
     * Creates a new world-class anti-ban settings panel
     */
    public AntiBanSettingsPanel(ScriptConfig config) {
        super();
        this.config = config;

        initializeComponents();
        setupLayout();
        addListeners();
        loadSettings();
    }

    /**
     * Initializes components for realistic anti-ban settings
     */
    private void initializeComponents() {
        // Core anti-ban settings
        enableAntibanCheckbox = new JCheckBox("Enable Anti-Ban Measures");
        antibanIntensitySlider = new JSlider(JSlider.HORIZONTAL, 1, 10, 5);
        antibanIntensitySlider.setMajorTickSpacing(1);
        antibanIntensitySlider.setPaintTicks(true);
        antibanIntensitySlider.setPaintLabels(true);
        antibanIntensitySlider.setSnapToTicks(true);
        intensityValueLabel = new JLabel("5");

        // Movement & Camera settings
        randomMouseMovementsCheckbox = new JCheckBox("Random Mouse Movements");
        randomCameraMovementsCheckbox = new JCheckBox("Random Camera Movements");
        randomTabChecksCheckbox = new JCheckBox("Random Tab Checks");

        // Interaction settings
        examineObjectsCheckbox = new JCheckBox("Examine Objects");
        hoverNPCsCheckbox = new JCheckBox("Hover NPCs");
        hoverPlayersCheckbox = new JCheckBox("Hover Players");

        // AFK simulation settings
        afkBreaksCheckbox = new JCheckBox("Enable AFK Breaks");
        afkFrequencySpinner = new JSpinner(new SpinnerNumberModel(15, 5, 120, 5));
        afkDurationSpinner = new JSpinner(new SpinnerNumberModel(30, 5, 300, 5));

        // Apply styling to all components
        styleComponents();
    }

    /**
     * Applies modern styling to components
     */
    private void styleComponents() {
        // Style checkboxes
        StyleManager.styleCheckBox(enableAntibanCheckbox);
        StyleManager.styleCheckBox(randomMouseMovementsCheckbox);
        StyleManager.styleCheckBox(randomCameraMovementsCheckbox);
        StyleManager.styleCheckBox(randomTabChecksCheckbox);
        StyleManager.styleCheckBox(examineObjectsCheckbox);
        StyleManager.styleCheckBox(hoverNPCsCheckbox);
        StyleManager.styleCheckBox(hoverPlayersCheckbox);
        StyleManager.styleCheckBox(afkBreaksCheckbox);

        // Style spinners
        StyleManager.styleSpinner(afkFrequencySpinner);
        StyleManager.styleSpinner(afkDurationSpinner);

        // Style slider
        antibanIntensitySlider.setBackground(ModernUITheme.BACKGROUND_DARKEST);
        antibanIntensitySlider.setForeground(ModernUITheme.TEXT_PRIMARY);

        // Style intensity label
        intensityValueLabel.setFont(ModernUITheme.FONT_HEADER);
        intensityValueLabel.setForeground(ModernUITheme.ACCENT_PRIMARY);
    }

    /**
     * Sets up an efficient two-column layout that utilizes space effectively
     */
    private void setupLayout() {
        setLayout(new BorderLayout());
        setBackground(ModernUITheme.BACKGROUND_DARKEST);

        // Create main panel with two-column layout
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(ModernUITheme.BACKGROUND_DARKEST);
        mainPanel.setBorder(new EmptyBorder(ModernUITheme.SPACING_MEDIUM,
                                           ModernUITheme.SPACING_MEDIUM,
                                           ModernUITheme.SPACING_MEDIUM,
                                           ModernUITheme.SPACING_MEDIUM));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);

        // Enable anti-ban checkbox spans both columns
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 4; gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(enableAntibanCheckbox, gbc);

        // Intensity slider spans both columns
        gbc.gridy++; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_SMALL);
        JLabel intensityLabel = new JLabel("Intensity:");
        intensityLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        mainPanel.add(intensityLabel, gbc);

        gbc.gridx = 1; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0.7;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_SMALL);
        mainPanel.add(antibanIntensitySlider, gbc);

        gbc.gridx = 3; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, 0);
        mainPanel.add(intensityValueLabel, gbc);

        // === LEFT COLUMN: Movement & Camera ===
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0;
        gbc.insets = new Insets(ModernUITheme.SPACING_MEDIUM, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);
        JLabel movementLabel = new JLabel("Movement & Camera");
        movementLabel.setFont(ModernUITheme.FONT_HEADER);
        movementLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(movementLabel, gbc);

        gbc.gridy++; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);
        mainPanel.add(randomMouseMovementsCheckbox, gbc);

        gbc.gridy++;
        mainPanel.add(randomCameraMovementsCheckbox, gbc);

        gbc.gridy++;
        mainPanel.add(randomTabChecksCheckbox, gbc);

        // === RIGHT COLUMN: Interactions ===
        gbc.gridy = 2; gbc.gridx = 2; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0;
        gbc.insets = new Insets(ModernUITheme.SPACING_MEDIUM, 0, ModernUITheme.SPACING_SMALL, 0);
        JLabel interactionLabel = new JLabel("Interactions");
        interactionLabel.setFont(ModernUITheme.FONT_HEADER);
        interactionLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(interactionLabel, gbc);

        gbc.gridy++; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, 0);
        mainPanel.add(examineObjectsCheckbox, gbc);

        gbc.gridy++;
        mainPanel.add(hoverNPCsCheckbox, gbc);

        gbc.gridy++;
        mainPanel.add(hoverPlayersCheckbox, gbc);

        // === BOTTOM SECTION: AFK Simulation (spans both columns) ===
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 4; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0;
        gbc.insets = new Insets(ModernUITheme.SPACING_LARGE, 0, ModernUITheme.SPACING_SMALL, 0);
        JLabel afkLabel = new JLabel("AFK Simulation");
        afkLabel.setFont(ModernUITheme.FONT_HEADER);
        afkLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(afkLabel, gbc);

        gbc.gridy++; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);
        mainPanel.add(afkBreaksCheckbox, gbc);

        // AFK settings on same row
        gbc.gridx = 2; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_SMALL);
        JLabel freqLabel = new JLabel("Freq (min):");
        freqLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        mainPanel.add(freqLabel, gbc);

        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0.3;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, 0);
        mainPanel.add(afkFrequencySpinner, gbc);

        // Duration on next row
        gbc.gridy++; gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_SMALL);
        JLabel durLabel = new JLabel("Duration (sec):");
        durLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        mainPanel.add(durLabel, gbc);

        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0.3;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, 0);
        mainPanel.add(afkDurationSpinner, gbc);

        add(mainPanel, BorderLayout.CENTER);
    }

    /**
     * Adds event listeners to components
     */
    private void addListeners() {
        enableAntibanCheckbox.addActionListener(e -> {
            if (!isLoading) {
                updateComponentStates();
                saveSettings();
            }
        });

        antibanIntensitySlider.addChangeListener(e -> {
            if (!isLoading) {
                updateIntensityLabel();
                saveSettings();
            }
        });

        randomMouseMovementsCheckbox.addActionListener(e -> { if (!isLoading) saveSettings(); });
        randomCameraMovementsCheckbox.addActionListener(e -> { if (!isLoading) saveSettings(); });
        randomTabChecksCheckbox.addActionListener(e -> { if (!isLoading) saveSettings(); });
        examineObjectsCheckbox.addActionListener(e -> { if (!isLoading) saveSettings(); });
        hoverNPCsCheckbox.addActionListener(e -> { if (!isLoading) saveSettings(); });
        hoverPlayersCheckbox.addActionListener(e -> { if (!isLoading) saveSettings(); });

        afkBreaksCheckbox.addActionListener(e -> {
            if (!isLoading) {
                updateAfkComponentStates();
                saveSettings();
            }
        });

        afkFrequencySpinner.addChangeListener(e -> { if (!isLoading) saveSettings(); });
        afkDurationSpinner.addChangeListener(e -> { if (!isLoading) saveSettings(); });
    }

    /**
     * Updates the intensity value label
     */
    private void updateIntensityLabel() {
        intensityValueLabel.setText(String.valueOf(antibanIntensitySlider.getValue()));
    }

    /**
     * Updates component states based on enabled status
     */
    private void updateComponentStates() {
        boolean enabled = enableAntibanCheckbox.isSelected();

        antibanIntensitySlider.setEnabled(enabled);
        randomMouseMovementsCheckbox.setEnabled(enabled);
        randomCameraMovementsCheckbox.setEnabled(enabled);
        randomTabChecksCheckbox.setEnabled(enabled);
        examineObjectsCheckbox.setEnabled(enabled);
        hoverNPCsCheckbox.setEnabled(enabled);
        hoverPlayersCheckbox.setEnabled(enabled);
        afkBreaksCheckbox.setEnabled(enabled);

        updateAfkComponentStates();
    }

    /**
     * Updates AFK component states
     */
    private void updateAfkComponentStates() {
        boolean enabled = enableAntibanCheckbox.isSelected() && afkBreaksCheckbox.isSelected();

        afkFrequencySpinner.setEnabled(enabled);
        afkDurationSpinner.setEnabled(enabled);
    }

    /**
     * Loads settings from config
     */
    public void loadSettings() {
        isLoading = true;
        try {
            // Load realistic anti-ban settings using custom data
            enableAntibanCheckbox.setSelected(config.getCustomData(KEY_ENABLE_ANTIBAN, true));
            antibanIntensitySlider.setValue(config.getCustomData(KEY_ANTIBAN_INTENSITY, 5));
            randomMouseMovementsCheckbox.setSelected(config.getCustomData(KEY_RANDOM_MOUSE, true));
            randomCameraMovementsCheckbox.setSelected(config.getCustomData(KEY_RANDOM_CAMERA, true));
            randomTabChecksCheckbox.setSelected(config.getCustomData(KEY_RANDOM_TABS, true));
            examineObjectsCheckbox.setSelected(config.getCustomData(KEY_EXAMINE_OBJECTS, false));
            hoverNPCsCheckbox.setSelected(config.getCustomData(KEY_HOVER_NPCS, false));
            hoverPlayersCheckbox.setSelected(config.getCustomData(KEY_HOVER_PLAYERS, false));
            afkBreaksCheckbox.setSelected(config.getCustomData(KEY_AFK_BREAKS, true));
            afkFrequencySpinner.setValue(config.getCustomData(KEY_AFK_FREQUENCY, 15));
            afkDurationSpinner.setValue(config.getCustomData(KEY_AFK_DURATION, 30));

            updateIntensityLabel();
            updateComponentStates();
        } finally {
            isLoading = false;
        }
    }

    /**
     * Saves settings to config and updates AntiBanManager
     */
    public void saveSettings() {
        if (isLoading) return;

        // Save realistic anti-ban settings using custom data
        config.setCustomData(KEY_ENABLE_ANTIBAN, enableAntibanCheckbox.isSelected());
        config.setCustomData(KEY_ANTIBAN_INTENSITY, antibanIntensitySlider.getValue());
        config.setCustomData(KEY_RANDOM_MOUSE, randomMouseMovementsCheckbox.isSelected());
        config.setCustomData(KEY_RANDOM_CAMERA, randomCameraMovementsCheckbox.isSelected());
        config.setCustomData(KEY_RANDOM_TABS, randomTabChecksCheckbox.isSelected());
        config.setCustomData(KEY_EXAMINE_OBJECTS, examineObjectsCheckbox.isSelected());
        config.setCustomData(KEY_HOVER_NPCS, hoverNPCsCheckbox.isSelected());
        config.setCustomData(KEY_HOVER_PLAYERS, hoverPlayersCheckbox.isSelected());
        config.setCustomData(KEY_AFK_BREAKS, afkBreaksCheckbox.isSelected());
        config.setCustomData(KEY_AFK_FREQUENCY, afkFrequencySpinner.getValue());
        config.setCustomData(KEY_AFK_DURATION, afkDurationSpinner.getValue());

        // Mark config as dirty
        config.markDirty();
    }

    /**
     * Updates from config - called when loading a profile
     */
    public void updateFromConfig() {
        loadSettings();
    }
}
