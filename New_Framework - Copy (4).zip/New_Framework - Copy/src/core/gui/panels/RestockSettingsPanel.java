package core.gui.panels;

import core.config.RestockConfig;
import core.config.ScriptConfig;
import core.gui.SettingsPanel;
import core.gui.style.StyleManager;
import core.utils.RestockItemUtils;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.wrappers.items.Item;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import javax.swing.AbstractCellEditor;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.ListSelectionModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;
import java.util.List;

/**
 * Simplified panel for restock settings using multiplier approach
 */
public class RestockSettingsPanel extends SettingsPanel {
    private final ScriptConfig config;

    // UI Components
    private JCheckBox enableRestockCheckbox;
    private JSpinner defaultMultiplierSpinner;
    private JTable restockTable;
    private DefaultTableModel tableModel;
    private JButton addItemButton;
    private JButton removeItemButton;
    private JButton detectItemsButton;
    private JButton updateAllMultipliersButton;
    private JTextArea infoArea;
    private JPopupMenu tablePopupMenu;

    private boolean isLoading = false;

    public RestockSettingsPanel(ScriptConfig config) {
        super();
        this.config = config;
        initializeComponents();
    }

    private void initializeComponents() {
        setLayout(new BorderLayout());
        setBackground(StyleManager.BACKGROUND_COLOR);

        JPanel mainPanel = new JPanel(new BorderLayout());
        StyleManager.applyStyle(mainPanel);
        mainPanel.setBorder(new EmptyBorder(12, 12, 12, 12));

        // Top panel - settings
        JPanel topPanel = createTopPanel();
        mainPanel.add(topPanel, BorderLayout.NORTH);

        // Center panel - table
        JPanel centerPanel = createCenterPanel();
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        // Bottom panel - info
        JPanel bottomPanel = createBottomPanel();
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);
        updateComponentStates();
    }

    private JPanel createTopPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        // Enable checkbox
        enableRestockCheckbox = new JCheckBox("Enable Automatic Restocking");
        StyleManager.styleCheckBox(enableRestockCheckbox);
        enableRestockCheckbox.setFont(enableRestockCheckbox.getFont().deriveFont(Font.BOLD, 14f));
        enableRestockCheckbox.addActionListener(e -> {
            if (!isLoading) {
                updateComponentStates();
                saveSettings();
            }
        });
        panel.add(enableRestockCheckbox);
        panel.add(Box.createVerticalStrut(8));

        // Multiplier setting
        JPanel multiplierPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        multiplierPanel.setOpaque(false);
        
        multiplierPanel.add(new JLabel("Default Multiplier: "));
        defaultMultiplierSpinner = new JSpinner(new SpinnerNumberModel(6.0, 1.0, 50.0, 0.5));
        defaultMultiplierSpinner.setPreferredSize(new Dimension(80, 26));
        defaultMultiplierSpinner.addChangeListener(e -> {
            if (!isLoading) {
                saveSettings();
            }
        });
        multiplierPanel.add(defaultMultiplierSpinner);
        
        multiplierPanel.add(Box.createHorizontalStrut(12));
        updateAllMultipliersButton = new JButton("Apply to All Items");
        updateAllMultipliersButton.setPreferredSize(new Dimension(120, 26));
        updateAllMultipliersButton.addActionListener(e -> updateAllMultipliers());
        multiplierPanel.add(updateAllMultipliersButton);
        
        panel.add(multiplierPanel);
        panel.add(Box.createVerticalStrut(8));

        return panel;
    }

    private JPanel createCenterPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        // Create table
        tableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Item name (column 0), Category (column 1), and calculated fields (columns 4,5) are read-only
                return column != 0 && column != 1 && column != 4 && column != 5;
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                switch (columnIndex) {
                    case 0: return String.class;   // Item Name
                    case 1: return String.class;   // Category
                    case 2: return Integer.class;  // Usage Per Trip
                    case 3: return Double.class;   // Multiplier
                    case 4: return Integer.class;  // Min Stock (calculated)
                    case 5: return Integer.class;  // Max Stock (calculated)
                    case 6: return Boolean.class;  // Enabled
                    default: return Object.class;
                }
            }
            
            @Override
            public void setValueAt(Object value, int row, int col) {
                super.setValueAt(value, row, col);
                // Update calculated fields when usage or multiplier changes
                if (col == 2 || col == 3) {
                    SwingUtilities.invokeLater(() -> updateCalculatedFields(row));
                }
            }
        };
        
        tableModel.addColumn("Item Name");
        tableModel.addColumn("Category");
        tableModel.addColumn("Usage/Trip");
        tableModel.addColumn("Multiplier");
        tableModel.addColumn("Min Stock");
        tableModel.addColumn("Max Stock");
        tableModel.addColumn("Enabled");

        restockTable = new JTable(tableModel);
        restockTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Enhanced table styling
        restockTable.setBackground(new Color(248, 250, 252)); // Light blue-gray background
        restockTable.setGridColor(new Color(220, 228, 235)); // Softer grid lines
        restockTable.setRowHeight(24); // Slightly taller rows for better readability
        restockTable.setSelectionBackground(new Color(59, 130, 246)); // Modern blue selection
        restockTable.setSelectionForeground(Color.WHITE);
        restockTable.setFont(restockTable.getFont().deriveFont(12f)); // Slightly larger font
        
        // Alternating row colors
        restockTable.setDefaultRenderer(Object.class, new AlternatingRowRenderer());
        
        // Configure custom editors for each column type
        restockTable.setDefaultEditor(Integer.class, new SpinnerEditor());
        restockTable.setDefaultEditor(Double.class, new DoubleSpinnerEditor());
        
        // Ensure proper checkbox editor for Boolean values
        JCheckBox checkBox = new JCheckBox();
        checkBox.setHorizontalAlignment(JCheckBox.CENTER);
        restockTable.setDefaultEditor(Boolean.class, new DefaultCellEditor(checkBox));
        
        // Set up proper renderers for center alignment
        restockTable.setDefaultRenderer(Boolean.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JCheckBox checkBox = new JCheckBox();
                checkBox.setSelected(value != null && (Boolean) value);
                checkBox.setHorizontalAlignment(JCheckBox.CENTER);
                checkBox.setOpaque(true);
                
                if (isSelected) {
                    checkBox.setBackground(table.getSelectionBackground());
                } else {
                    // Use alternating row colors
                    if (row % 2 == 0) {
                        checkBox.setBackground(new Color(248, 250, 252)); // Light blue-gray for even rows
                    } else {
                        checkBox.setBackground(new Color(240, 245, 251)); // Slightly darker blue-gray for odd rows
                    }
                }
                return checkBox;
            }
        });
        
        // Add custom renderer for Category column with color coding
        restockTable.setDefaultRenderer(String.class, new CategoryCellRenderer());
        
        // Set column widths
        restockTable.getColumnModel().getColumn(0).setPreferredWidth(150); // Item Name
        restockTable.getColumnModel().getColumn(1).setPreferredWidth(80);  // Category
        restockTable.getColumnModel().getColumn(2).setPreferredWidth(80);  // Usage/Trip
        restockTable.getColumnModel().getColumn(3).setPreferredWidth(80);  // Multiplier
        restockTable.getColumnModel().getColumn(4).setPreferredWidth(70);  // Min Stock
        restockTable.getColumnModel().getColumn(5).setPreferredWidth(70);  // Max Stock
        restockTable.getColumnModel().getColumn(6).setPreferredWidth(60);  // Enabled

        // Listen for table changes
        tableModel.addTableModelListener(e -> {
            if (isLoading) return;
            
            int row = e.getFirstRow();
            int col = e.getColumn();
            
            if (row >= 0) {
                // Save settings when any value changes
                SwingUtilities.invokeLater(() -> saveSettings());
            }
        });

        // Enable single-click editing for all editable cells
        restockTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
        
        // Enable table sorting
        restockTable.setAutoCreateRowSorter(true);
        
        // Create and configure right-click popup menu
        createTablePopupMenu();
        
        JScrollPane scrollPane = new JScrollPane(restockTable);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 210, 220), 1),
            BorderFactory.createEmptyBorder(1, 1, 1, 1)
        ));
        scrollPane.setBackground(new Color(248, 250, 252));
        scrollPane.getViewport().setBackground(new Color(248, 250, 252));
        scrollPane.setPreferredSize(new Dimension(600, 200));
        panel.add(scrollPane, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);
        
        addItemButton = new JButton("Add Item");
        StyleManager.styleButton(addItemButton);
        addItemButton.addActionListener(e -> addNewItem());
        buttonPanel.add(addItemButton);
        
        removeItemButton = new JButton("Remove Selected");
        StyleManager.styleButton(removeItemButton);
        removeItemButton.addActionListener(e -> removeSelectedItem());
        buttonPanel.add(removeItemButton);
        
        // Make detect items button more prominent
        detectItemsButton = new JButton("◉ Detect Items");
        StyleManager.stylePrimaryButton(detectItemsButton); // Use primary button styling
        detectItemsButton.setFont(detectItemsButton.getFont().deriveFont(Font.BOLD, 13f));
        detectItemsButton.setPreferredSize(new Dimension(140, 32));
        detectItemsButton.addActionListener(e -> detectItems());
        buttonPanel.add(Box.createHorizontalStrut(10)); // Add some spacing
        buttonPanel.add(detectItemsButton);
        
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createBottomPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        
        // Info area
        infoArea = new JTextArea(4, 50);
        infoArea.setEditable(false);
        infoArea.setOpaque(false);
        infoArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 11));
        infoArea.setText(
            "SIMPLIFIED RESTOCK SYSTEM:\n" +
            "• Set how many items you use per trip (Usage/Trip)\n" +
            "• Set multiplier (e.g., 6x means stock 6 trips worth)\n" +
            "• System automatically calculates Min (triggers restock) and Max (restock target)\n" +
            "• Categories are color-coded and table is sortable by clicking column headers\n" +
            "• Example: 20 food/trip × 6 multiplier = restock when below 20, buy up to 120"
        );
        infoArea.setBorder(BorderFactory.createTitledBorder("How It Works"));
        
        panel.add(infoArea, BorderLayout.CENTER);
        
        return panel;
    }

    private void updateCalculatedFields(int row) {
        if (row < 0 || row >= tableModel.getRowCount()) return;
        
        try {
            int usagePerTrip = (Integer) tableModel.getValueAt(row, 2);
            double multiplier = (Double) tableModel.getValueAt(row, 3);
            
            int minStock = usagePerTrip;
            int maxStock = (int) (usagePerTrip * multiplier);
            
            tableModel.setValueAt(minStock, row, 4);
            tableModel.setValueAt(maxStock, row, 5);
        } catch (Exception e) {
            Logger.warn("Error updating calculated fields: " + e.getMessage());
        }
    }

    private void addNewItem() {
        String itemName = JOptionPane.showInputDialog(this, 
            "Enter item name:", 
            "Add Restock Item", 
            JOptionPane.QUESTION_MESSAGE);
        
        if (itemName != null && !itemName.trim().isEmpty()) {
            itemName = itemName.trim();
            
            // Check if item already exists
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (itemName.equals(tableModel.getValueAt(i, 0))) {
                    JOptionPane.showMessageDialog(this, "Item already exists!", "Duplicate Item", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
            
            // Ask for usage per trip
            String usageStr = JOptionPane.showInputDialog(this, 
                "How many " + itemName + " do you use per trip?", 
                "Usage Per Trip", 
                JOptionPane.QUESTION_MESSAGE);
            
            if (usageStr != null) {
                try {
                    int usagePerTrip = Integer.parseInt(usageStr.trim());
                    if (usagePerTrip > 0) {
                        addItemToTable(itemName, usagePerTrip, (Double) defaultMultiplierSpinner.getValue());
                        saveSettings();
                    } else {
                        JOptionPane.showMessageDialog(this, "Usage per trip must be greater than 0!", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid number!", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private void addItemToTable(String itemName, int usagePerTrip, double multiplier) {
        int minStock = usagePerTrip;
        int maxStock = (int) (usagePerTrip * multiplier);
        
        tableModel.addRow(new Object[]{
            itemName,
            RestockItemUtils.getItemCategory(itemName),
            usagePerTrip,
            multiplier,
            minStock,
            maxStock,
            true  // enabled
        });
    }

    private void removeSelectedItem() {
        int selectedRow = restockTable.getSelectedRow();
        if (selectedRow >= 0) {
            String itemName = (String) tableModel.getValueAt(selectedRow, 0);
            int result = JOptionPane.showConfirmDialog(this, 
                "Remove " + itemName + " from restock list?", 
                "Confirm Removal", 
                JOptionPane.YES_NO_OPTION);
            
            if (result == JOptionPane.YES_OPTION) {
                tableModel.removeRow(selectedRow);
                saveSettings();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an item to remove.", "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void detectItems() {
        Set<String> detectedItems = new HashSet<>();
        Map<String, Integer> itemCounts = new HashMap<>();
        Map<String, String> itemSources = new HashMap<>(); // Track where items came from
        Map<String, String> equipmentSlots = new HashMap<>(); // Track equipment slots
        
        // Get items from inventory
        for (Item item : Inventory.all()) {
            if (item != null && item.getName() != null && !item.getName().equals("null")) {
                String name = item.getName();
                if (!RestockItemUtils.shouldExclude(name)) {
                    detectedItems.add(name);
                    itemCounts.put(name, itemCounts.getOrDefault(name, 0) + item.getAmount());
                    itemSources.put(name, "inventory");
                }
            }
        }
        
        // Get items from equipment
        for (Item item : Equipment.all()) {
            if (item != null && item.getName() != null && !item.getName().equals("null")) {
                String name = item.getName();
                if (!RestockItemUtils.shouldExclude(name)) {
                    detectedItems.add(name);
                    itemCounts.put(name, itemCounts.getOrDefault(name, 0) + item.getAmount());
                    itemSources.put(name, "equipment");
                    
                    // For equipment items, we'll determine the slot based on common naming patterns
                    // since getSlot() method may not be available or reliable
                    String estimatedSlot = "UNKNOWN";
                    String lowerName = name.toLowerCase();
                    
                    // Detect common equipment slots by name patterns
                    if (lowerName.contains("ring")) {
                        estimatedSlot = "RING";
                    } else if (lowerName.contains("amulet") || lowerName.contains("necklace")) {
                        estimatedSlot = "AMULET";
                    } else if (lowerName.contains("helmet") || lowerName.contains("hat") || lowerName.contains("coif")) {
                        estimatedSlot = "HELMET";
                    } else if (lowerName.contains("platebody") || lowerName.contains("chainbody") || lowerName.contains("top")) {
                        estimatedSlot = "CHEST";
                    } else if (lowerName.contains("platelegs") || lowerName.contains("skirt") || lowerName.contains("bottom")) {
                        estimatedSlot = "LEGS";
                    } else if (lowerName.contains("boots")) {
                        estimatedSlot = "BOOTS";
                    } else if (lowerName.contains("gloves") || lowerName.contains("gauntlets")) {
                        estimatedSlot = "GLOVES";
                    } else if (lowerName.contains("cape") || lowerName.contains("cloak")) {
                        estimatedSlot = "CAPE";
                    } else if (lowerName.contains("shield")) {
                        estimatedSlot = "SHIELD";
                    } else {
                        estimatedSlot = "WEAPON";
                    }
                    
                    equipmentSlots.put(name, estimatedSlot);
                }
            }
        }
        
        // Get items from bank (if open)
        if (Bank.isOpen()) {
            for (Item item : Bank.all()) {
                if (item != null && item.getName() != null && !item.getName().equals("null")) {
                    String name = item.getName();
                    if (!RestockItemUtils.shouldExclude(name)) {
                        detectedItems.add(name);
                        itemCounts.put(name, itemCounts.getOrDefault(name, 0) + item.getAmount());
                        // Don't override equipment source if already set
                        if (!itemSources.containsKey(name)) {
                            itemSources.put(name, "bank");
                        }
                    }
                }
            }
        }
        
        if (detectedItems.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "No suitable items detected. Make sure you have consumable items in your inventory, equipment, or bank open.", 
                "No Items Found", 
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        // Show selection dialog
        ItemSelectionDialog dialog = new ItemSelectionDialog(this, detectedItems, itemCounts, itemSources, equipmentSlots);
        List<ItemSelectionDialog.ItemSelection> selectedItems = dialog.showDialog();
        
        if (selectedItems != null && !selectedItems.isEmpty()) {
            for (ItemSelectionDialog.ItemSelection selection : selectedItems) {
                // Check if item already exists
                boolean exists = false;
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    if (selection.itemName.equals(tableModel.getValueAt(i, 0))) {
                        exists = true;
                        break;
                    }
                }
                
                if (!exists) {
                    addItemToTable(selection.itemName, selection.usagePerTrip, (Double) defaultMultiplierSpinner.getValue());
                }
            }
            saveSettings();
        }
    }

    private void updateAllMultipliers() {
        double newMultiplier = (Double) defaultMultiplierSpinner.getValue();
        
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            tableModel.setValueAt(newMultiplier, i, 3);
            updateCalculatedFields(i);
        }
        
        saveSettings();
    }

    public void loadSettings() {
        isLoading = true;
        try {
            RestockConfig restockConfig = config.getRestockConfig();
            
            // Load basic settings
            enableRestockCheckbox.setSelected(restockConfig.isEnabled());
            defaultMultiplierSpinner.setValue(restockConfig.getDefaultMultiplier());
            
            // Load items
            tableModel.setRowCount(0);
            for (RestockConfig.RestockItem item : restockConfig.getAllItems().values()) {
                tableModel.addRow(new Object[]{
                    item.itemName,
                    RestockItemUtils.getItemCategory(item.itemName),
                    item.usagePerTrip,
                    item.multiplier,
                    item.getMinStock(),
                    item.getMaxStock(),
                    item.enabled
                });
            }
            
            updateComponentStates();
        } catch (Exception e) {
            Logger.error("Error loading restock settings: " + e.getMessage());
        } finally {
            isLoading = false;
        }
    }

    public void saveSettings() {
        if (isLoading) return;
        
        try {
            RestockConfig restockConfig = config.getRestockConfig();
            
            // Save basic settings
            restockConfig.setEnabled(enableRestockCheckbox.isSelected());
            restockConfig.setDefaultMultiplier((Double) defaultMultiplierSpinner.getValue());
            
            // Clear existing items
            restockConfig.getAllItems().clear();
            
            // Save items from table
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String itemName = (String) tableModel.getValueAt(i, 0);
                int usagePerTrip = (Integer) tableModel.getValueAt(i, 2);
                double multiplier = (Double) tableModel.getValueAt(i, 3);
                boolean enabled = (Boolean) tableModel.getValueAt(i, 6);
                
                RestockConfig.RestockItem item = new RestockConfig.RestockItem(itemName, usagePerTrip, multiplier);
                item.enabled = enabled;
                item.updateSellThreshold();
                
                restockConfig.getAllItems().put(itemName, item);
            }
            
            config.markDirty();
            Logger.info("Saved restock settings - " + restockConfig.getAllItems().size() + " items configured");
        } catch (Exception e) {
            Logger.error("Error saving restock settings: " + e.getMessage());
        }
    }

    public void updateFromConfig() {
        loadSettings();
    }

    private void updateComponentStates() {
        boolean enabled = enableRestockCheckbox.isSelected();
        
        defaultMultiplierSpinner.setEnabled(enabled);
        restockTable.setEnabled(enabled);
        addItemButton.setEnabled(enabled);
        removeItemButton.setEnabled(enabled);
        detectItemsButton.setEnabled(enabled);
        updateAllMultipliersButton.setEnabled(enabled);
        
        // Enable/disable popup menu items
        if (tablePopupMenu != null) {
            for (int i = 0; i < tablePopupMenu.getComponentCount(); i++) {
                tablePopupMenu.getComponent(i).setEnabled(enabled);
            }
        }
    }

    // Custom cell editors
    private static class SpinnerEditor extends AbstractCellEditor implements TableCellEditor {
        private final JSpinner spinner;

        public SpinnerEditor() {
            spinner = new JSpinner(new SpinnerNumberModel(1, 1, 10000, 1));
            
            // Enable single-click editing
            spinner.addChangeListener(e -> stopCellEditing());
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            spinner.setValue(value != null ? value : 1);
            return spinner;
        }

        @Override
        public Object getCellEditorValue() {
            return spinner.getValue();
        }
        
        @Override
        public boolean isCellEditable(java.util.EventObject e) {
            return true;
        }
        
        @Override
        public boolean shouldSelectCell(java.util.EventObject e) {
            return true;
        }
    }

    private static class DoubleSpinnerEditor extends AbstractCellEditor implements TableCellEditor {
        private final JSpinner spinner;

        public DoubleSpinnerEditor() {
            spinner = new JSpinner(new SpinnerNumberModel(1.0, 0.1, 50.0, 0.1));
            
            // Enable single-click editing
            spinner.addChangeListener(e -> stopCellEditing());
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            spinner.setValue(value != null ? value : 1.0);
            return spinner;
        }

        @Override
        public Object getCellEditorValue() {
            return spinner.getValue();
        }
        
        @Override
        public boolean isCellEditable(java.util.EventObject e) {
            return true;
        }
        
        @Override
        public boolean shouldSelectCell(java.util.EventObject e) {
            return true;
        }
    }

    // Custom alternating row renderer for better table readability
    private static class AlternatingRowRenderer extends javax.swing.table.DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (!isSelected) {
                if (row % 2 == 0) {
                    setBackground(new Color(248, 250, 252)); // Light blue-gray for even rows
                } else {
                    setBackground(new Color(240, 245, 251)); // Slightly darker blue-gray for odd rows
                }
            } else {
                setBackground(table.getSelectionBackground());
            }
            
            return this;
        }
    }

    // Custom category cell renderer for color-coded categories
    private static class CategoryCellRenderer extends javax.swing.table.DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (value instanceof String) {
                String category = (String) value;
                setHorizontalAlignment(CENTER);
                
                // Set alternating background colors
                if (!isSelected) {
                    if (row % 2 == 0) {
                        setBackground(new Color(248, 250, 252)); // Light blue-gray for even rows
                    } else {
                        setBackground(new Color(240, 245, 251)); // Slightly darker blue-gray for odd rows
                    }
                    
                    // Color code by category
                    switch (category) {
                        case "Food":
                            setForeground(new Color(0, 120, 0)); // Dark green
                            break;
                        case "Potion":
                            setForeground(new Color(0, 0, 180)); // Blue
                            break;
                        case "Rune":
                            setForeground(new Color(150, 0, 150)); // Purple
                            break;
                        case "Ammunition":
                            setForeground(new Color(180, 90, 0)); // Orange
                            break;
                        case "Teleport":
                            setForeground(new Color(0, 150, 150)); // Teal
                            break;
                        case "Jewelry":
                            setForeground(new Color(200, 150, 0)); // Gold
                            break;
                        case "Gear":
                            setForeground(new Color(100, 100, 100)); // Gray
                            break;
                        default:
                            setForeground(Color.BLACK);
                            break;
                    }
                } else {
                    setBackground(table.getSelectionBackground());
                    setForeground(table.getSelectionForeground());
                }
            }
            
            return this;
        }
    }

    // Item selection dialog for detected items
    private static class ItemSelectionDialog extends JDialog {
        private final Set<String> detectedItems;
        private final Map<String, Integer> itemCounts;
        private final Map<String, String> itemSources;
        private final Map<String, String> equipmentSlots;
        private List<ItemSelection> selectedItems = null;
        private JList<ItemSelection> itemList;
        private DefaultListModel<ItemSelection> listModel;

        public static class ItemSelection {
            public String itemName;
            public int usagePerTrip;
            public int currentCount;
            public String category;

            public ItemSelection(String itemName, int currentCount, String source, String equipmentSlot) {
                this.itemName = itemName;
                this.currentCount = currentCount;
                
                // Use equipment-based categorization if item comes from equipment
                if ("equipment".equals(source) && equipmentSlot != null) {
                    this.category = RestockItemUtils.getEquipmentCategory(itemName, equipmentSlot);
                } else {
                    this.category = RestockItemUtils.getItemCategory(itemName);
                }
                
                this.usagePerTrip = RestockItemUtils.getUsageEstimate(itemName, currentCount);
            }

            @Override
            public String toString() {
                return String.format("[%s] %s (have: %d, suggest: %d/trip)", 
                    category, itemName, currentCount, usagePerTrip);
            }
        }

        public ItemSelectionDialog(Component parent, Set<String> detectedItems, Map<String, Integer> itemCounts, Map<String, String> itemSources, Map<String, String> equipmentSlots) {
            super(SwingUtilities.getWindowAncestor(parent), "Select Items to Add", ModalityType.APPLICATION_MODAL);
            this.detectedItems = detectedItems;
            this.itemCounts = itemCounts;
            this.itemSources = itemSources;
            this.equipmentSlots = equipmentSlots;
            initDialog();
            setLocationRelativeTo(parent);
        }

        private void initDialog() {
            setLayout(new BorderLayout());
            
            // Create list model
            listModel = new DefaultListModel<>();
            
            // Sort items by category then by name
            List<ItemSelection> allItems = new ArrayList<>();
            for (String itemName : detectedItems) {
                int count = itemCounts.getOrDefault(itemName, 0);
                allItems.add(new ItemSelection(itemName, count, itemSources.get(itemName), equipmentSlots.get(itemName)));
            }
            
            // Sort by category first, then by name
            allItems.sort((a, b) -> {
                int categoryCompare = a.category.compareTo(b.category);
                if (categoryCompare != 0) return categoryCompare;
                return a.itemName.compareTo(b.itemName);
            });
            
            for (ItemSelection item : allItems) {
                listModel.addElement(item);
            }
            
            itemList = new JList<>(listModel);
            itemList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            itemList.setCellRenderer(new ItemSelectionRenderer());
            
            add(new JScrollPane(itemList), BorderLayout.CENTER);
            
            // Buttons
            JPanel buttonPanel = new JPanel(new FlowLayout());
            JButton okButton = new JButton("Add Selected");
            JButton cancelButton = new JButton("Cancel");
            JButton selectAllButton = new JButton("Select All");
            
            okButton.addActionListener(e -> {
                selectedItems = itemList.getSelectedValuesList();
                setVisible(false);
            });
            
            cancelButton.addActionListener(e -> setVisible(false));
            
            selectAllButton.addActionListener(e -> {
                itemList.setSelectionInterval(0, listModel.getSize() - 1);
            });
            
            buttonPanel.add(selectAllButton);
            buttonPanel.add(okButton);
            buttonPanel.add(cancelButton);
            add(buttonPanel, BorderLayout.SOUTH);
            
            // Info label
            JLabel infoLabel = new JLabel("<html><b>Smart Item Detection</b><br>" +
                "Items are categorized and usage estimates are provided based on common patterns.<br>" +
                "You can adjust usage per trip values after adding items.</html>");
            infoLabel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
            add(infoLabel, BorderLayout.NORTH);
            
            setSize(500, 400);
        }

        public List<ItemSelection> showDialog() {
            setVisible(true);
            dispose();
            return selectedItems;
        }

        private static class ItemSelectionRenderer extends DefaultListCellRenderer {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                
                if (value instanceof ItemSelection) {
                    ItemSelection item = (ItemSelection) value;
                    
                    // Color code by category
                    if (!isSelected) {
                        switch (item.category) {
                            case "Food":
                                setForeground(new Color(0, 120, 0)); // Dark green
                                break;
                            case "Potion":
                                setForeground(new Color(0, 0, 180)); // Blue
                                break;
                            case "Rune":
                                setForeground(new Color(150, 0, 150)); // Purple
                                break;
                            case "Ammunition":
                                setForeground(new Color(180, 90, 0)); // Orange
                                break;
                            case "Teleport":
                                setForeground(new Color(0, 150, 150)); // Teal
                                break;
                            case "Jewelry":
                                setForeground(new Color(200, 200, 0)); // Yellow
                                break;
                            default:
                                setForeground(Color.BLACK);
                                break;
                        }
                    }
                }
                
                return this;
            }
        }
    }

    /**
     * Creates the right-click popup menu for the table
     */
    private void createTablePopupMenu() {
        tablePopupMenu = new JPopupMenu();
        
        JMenuItem removeItem = new JMenuItem("Remove Item");
        removeItem.addActionListener(e -> removeSelectedItem());
        tablePopupMenu.add(removeItem);
        
        // Add mouse listener to show popup menu
        restockTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    showPopupMenu(e);
                }
            }
            
            @Override
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    showPopupMenu(e);
                }
            }
            
            private void showPopupMenu(MouseEvent e) {
                // Find the row that was clicked
                int row = restockTable.rowAtPoint(e.getPoint());
                
                // Only show popup if clicking on a valid row
                if (row >= 0 && row < restockTable.getRowCount()) {
                    // Select the row that was right-clicked
                    restockTable.setRowSelectionInterval(row, row);
                    
                    // Show the popup menu
                    tablePopupMenu.show(restockTable, e.getX(), e.getY());
                }
            }
        });
    }
}
