package core.gui.panels;

import core.config.ScriptConfig;
import core.gui.SettingsPanel;
import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;

/**
 * Panel for safety settings
 */
public class SafetySettingsPanel extends SettingsPanel {
    private final ScriptConfig config;

    // UI Components
    private JCheckBox enableSafetyCheckbox;
    private JCheckBox logoutOnPKerCheckbox;
    private JCheckBox logoutOnLowHealthCheckbox;
    private JSpinner healthThresholdSpinner;
    private JCheckBox logoutOnStaffCheckbox;
    private JCheckBox pauseOnChatMessageCheckbox;
    private JTextField chatKeywordsField;
    private JCheckBox enableEmergencyTeleportCheckbox;

    private boolean isLoading = false;

    /**
     * Creates a new safety settings panel
     */
    public SafetySettingsPanel(ScriptConfig config) {
        super();
        this.config = config;

        initializeComponents();
        loadSettings();
    }

    /**
     * Initializes the panel components
     */
    private void initializeComponents() {
        setLayout(new BorderLayout(10, 10));

        // Create main panel with GridBagLayout for precise control
        JPanel mainPanel = new JPanel(new GridBagLayout());
        StyleManager.applyStyle(mainPanel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(3, 3, 3, 3);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Master safety switch
        enableSafetyCheckbox = new JCheckBox("Enable Safety Features");
        StyleManager.styleCheckBox(enableSafetyCheckbox);
        mainPanel.add(enableSafetyCheckbox, gbc);

        // PK safety
        gbc.gridy++;
        logoutOnPKerCheckbox = new JCheckBox("Logout on PKer Detection");
        StyleManager.styleCheckBox(logoutOnPKerCheckbox);
        mainPanel.add(logoutOnPKerCheckbox, gbc);

        // Health safety
        gbc.gridy++;
        logoutOnLowHealthCheckbox = new JCheckBox("Logout on Low Health");
        StyleManager.styleCheckBox(logoutOnLowHealthCheckbox);
        mainPanel.add(logoutOnLowHealthCheckbox, gbc);

        // Health threshold
        gbc.gridy++;
        gbc.gridwidth = 1;
        mainPanel.add(new JLabel("Health Threshold (%):"), gbc);

        gbc.gridx = 1;
        healthThresholdSpinner = new JSpinner(new SpinnerNumberModel(25, 1, 99, 5));
        StyleManager.styleSpinner(healthThresholdSpinner);
        mainPanel.add(healthThresholdSpinner, gbc);

        // Staff detection
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        logoutOnStaffCheckbox = new JCheckBox("Logout on Staff Detection");
        StyleManager.styleCheckBox(logoutOnStaffCheckbox);
        mainPanel.add(logoutOnStaffCheckbox, gbc);

        // Chat message detection
        gbc.gridy++;
        pauseOnChatMessageCheckbox = new JCheckBox("Pause on Chat Message");
        StyleManager.styleCheckBox(pauseOnChatMessageCheckbox);
        mainPanel.add(pauseOnChatMessageCheckbox, gbc);

        // Chat keywords
        gbc.gridy++;
        gbc.gridwidth = 1;
        mainPanel.add(new JLabel("Chat Keywords (comma separated):"), gbc);

        gbc.gridy++;
        gbc.gridwidth = 2;
        chatKeywordsField = new JTextField();
        StyleManager.styleTextField(chatKeywordsField);
        mainPanel.add(chatKeywordsField, gbc);

        // Emergency teleport
        gbc.gridy++;
        enableEmergencyTeleportCheckbox = new JCheckBox("Enable Emergency Teleport");
        StyleManager.styleCheckBox(enableEmergencyTeleportCheckbox);
        mainPanel.add(enableEmergencyTeleportCheckbox, gbc);

        // Add the main panel to a scroll pane
        JScrollPane scrollPane = new JScrollPane(mainPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane, BorderLayout.CENTER);

        // Add listeners
        addListeners();
    }

    /**
     * Adds event listeners to components
     */
    private void addListeners() {
        enableSafetyCheckbox.addActionListener(e -> {
            if (!isLoading) {
                updateComponentStates();
                saveSettings();
            }
        });

        logoutOnPKerCheckbox.addActionListener(e -> {
            if (!isLoading) saveSettings();
        });

        logoutOnLowHealthCheckbox.addActionListener(e -> {
            if (!isLoading) {
                updateHealthComponentStates();
                saveSettings();
            }
        });

        healthThresholdSpinner.addChangeListener(e -> {
            if (!isLoading) saveSettings();
        });

        logoutOnStaffCheckbox.addActionListener(e -> {
            if (!isLoading) saveSettings();
        });

        pauseOnChatMessageCheckbox.addActionListener(e -> {
            if (!isLoading) {
                updateChatComponentStates();
                saveSettings();
            }
        });

        chatKeywordsField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                if (!isLoading) saveSettings();
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                if (!isLoading) saveSettings();
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                if (!isLoading) saveSettings();
            }
        });

        enableEmergencyTeleportCheckbox.addActionListener(e -> {
            if (!isLoading) saveSettings();
        });
    }

    /**
     * Updates component states based on master switch
     */
    private void updateComponentStates() {
        boolean enabled = enableSafetyCheckbox.isSelected();

        logoutOnPKerCheckbox.setEnabled(enabled);
        logoutOnLowHealthCheckbox.setEnabled(enabled);
        healthThresholdSpinner.setEnabled(enabled && logoutOnLowHealthCheckbox.isSelected());
        logoutOnStaffCheckbox.setEnabled(enabled);
        pauseOnChatMessageCheckbox.setEnabled(enabled);
        chatKeywordsField.setEnabled(enabled && pauseOnChatMessageCheckbox.isSelected());
        enableEmergencyTeleportCheckbox.setEnabled(enabled);
    }

    /**
     * Updates health component states
     */
    private void updateHealthComponentStates() {
        boolean enabled = enableSafetyCheckbox.isSelected() && logoutOnLowHealthCheckbox.isSelected();
        healthThresholdSpinner.setEnabled(enabled);
    }

    /**
     * Updates chat component states
     */
    private void updateChatComponentStates() {
        boolean enabled = enableSafetyCheckbox.isSelected() && pauseOnChatMessageCheckbox.isSelected();
        chatKeywordsField.setEnabled(enabled);
    }

    /**
     * Loads settings from config
     */
    public void loadSettings() {
        isLoading = true;
        try {
            // For now, set default values
            // In a real implementation, these would be loaded from config
            enableSafetyCheckbox.setSelected(true);
            logoutOnPKerCheckbox.setSelected(true);
            logoutOnLowHealthCheckbox.setSelected(true);
            healthThresholdSpinner.setValue(25);
            logoutOnStaffCheckbox.setSelected(true);
            pauseOnChatMessageCheckbox.setSelected(true);
            chatKeywordsField.setText("hey, hello, hi, bot");
            enableEmergencyTeleportCheckbox.setSelected(true);

            updateComponentStates();
        } finally {
            isLoading = false;
        }
    }

    /**
     * Saves settings to config
     */
    public void saveSettings() {
        if (isLoading) return;

        // For now, just print the settings
        // In a real implementation, these would be saved to config
        System.out.println("Safety enabled: " + enableSafetyCheckbox.isSelected());
        System.out.println("Logout on PKer: " + logoutOnPKerCheckbox.isSelected());
        System.out.println("Logout on low health: " + logoutOnLowHealthCheckbox.isSelected());
        System.out.println("Health threshold: " + healthThresholdSpinner.getValue() + "%");
        System.out.println("Logout on staff: " + logoutOnStaffCheckbox.isSelected());
        System.out.println("Pause on chat message: " + pauseOnChatMessageCheckbox.isSelected());
        System.out.println("Chat keywords: " + chatKeywordsField.getText());
        System.out.println("Emergency teleport: " + enableEmergencyTeleportCheckbox.isSelected());

        // Mark config as dirty
        config.markDirty();
    }
}
