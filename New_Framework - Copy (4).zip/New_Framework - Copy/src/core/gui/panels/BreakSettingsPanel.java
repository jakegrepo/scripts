package core.gui.panels;

import core.config.ScriptConfig;
import core.gui.SettingsPanel;
import core.gui.style.ModernUITheme;
import core.gui.style.StyleManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * World-class Break Settings Panel with proper DreamBot API integration
 */
public class BreakSettingsPanel extends SettingsPanel {
    private final ScriptConfig config;

    // Core break settings (actually implemented)
    private JCheckBox enableBreaksCheckbox;
    private JSpinner minRunTimeSpinner;
    private JSpinner maxRunTimeSpinner;
    private JSpinner minBreakTimeSpinner;
    private JSpinner maxBreakTimeSpinner;
    private JCheckBox logoutDuringBreaksCheckbox;

    // Advanced break settings
    private JCheckBox enableRandomBreaksCheckbox;
    private JSpinner breakVarianceSpinner;

    private boolean isLoading = false;

    // Config keys for break settings
    private static final String KEY_ENABLE_BREAKS = "enableBreaks";
    private static final String KEY_MIN_RUN_TIME = "minRunTime";
    private static final String KEY_MAX_RUN_TIME = "maxRunTime";
    private static final String KEY_MIN_BREAK_TIME = "minBreakTime";
    private static final String KEY_MAX_BREAK_TIME = "maxBreakTime";
    private static final String KEY_LOGOUT_DURING_BREAKS = "logoutDuringBreaks";
    private static final String KEY_ENABLE_RANDOM_BREAKS = "enableRandomBreaks";
    private static final String KEY_BREAK_VARIANCE = "breakVariance";

    /**
     * Creates a new world-class break settings panel
     */
    public BreakSettingsPanel(ScriptConfig config) {
        super();
        this.config = config;

        initializeComponents();
        setupLayout();
        addListeners();
        loadSettings();
    }

    /**
     * Initializes components for realistic break settings
     */
    private void initializeComponents() {
        // Core break settings (actually implemented)
        enableBreaksCheckbox = new JCheckBox("Enable Breaks");
        minRunTimeSpinner = new JSpinner(new SpinnerNumberModel(45, 15, 180, 5));
        maxRunTimeSpinner = new JSpinner(new SpinnerNumberModel(90, 30, 240, 5));
        minBreakTimeSpinner = new JSpinner(new SpinnerNumberModel(3, 1, 30, 1));
        maxBreakTimeSpinner = new JSpinner(new SpinnerNumberModel(8, 2, 60, 1));
        logoutDuringBreaksCheckbox = new JCheckBox("Logout During Breaks");

        // Advanced break settings
        enableRandomBreaksCheckbox = new JCheckBox("Enable Random Break Timing");
        breakVarianceSpinner = new JSpinner(new SpinnerNumberModel(15, 5, 60, 5));

        // Apply styling to all components
        styleComponents();
    }

    /**
     * Applies modern styling to components
     */
    private void styleComponents() {
        // Style checkboxes
        StyleManager.styleCheckBox(enableBreaksCheckbox);
        StyleManager.styleCheckBox(logoutDuringBreaksCheckbox);
        StyleManager.styleCheckBox(enableRandomBreaksCheckbox);

        // Style spinners
        StyleManager.styleSpinner(minRunTimeSpinner);
        StyleManager.styleSpinner(maxRunTimeSpinner);
        StyleManager.styleSpinner(minBreakTimeSpinner);
        StyleManager.styleSpinner(maxBreakTimeSpinner);
        StyleManager.styleSpinner(breakVarianceSpinner);
    }

    /**
     * Sets up an efficient two-column layout that utilizes space effectively
     */
    private void setupLayout() {
        setLayout(new BorderLayout());
        setBackground(ModernUITheme.BACKGROUND_DARKEST);

        // Create main panel with two-column layout
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(ModernUITheme.BACKGROUND_DARKEST);
        mainPanel.setBorder(new EmptyBorder(ModernUITheme.SPACING_MEDIUM,
                                           ModernUITheme.SPACING_MEDIUM,
                                           ModernUITheme.SPACING_MEDIUM,
                                           ModernUITheme.SPACING_MEDIUM));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);

        // Enable breaks checkbox spans both columns
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 4; gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(enableBreaksCheckbox, gbc);

        // === LEFT COLUMN: Runtime Settings ===
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(ModernUITheme.SPACING_MEDIUM, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);
        JLabel runtimeLabel = new JLabel("Runtime Settings");
        runtimeLabel.setFont(ModernUITheme.FONT_HEADER);
        runtimeLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(runtimeLabel, gbc);

        // Min Run Time
        gbc.gridy++; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_SMALL);
        JLabel minRunLabel = new JLabel("Min Runtime (min):");
        minRunLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        mainPanel.add(minRunLabel, gbc);

        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0.5;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);
        mainPanel.add(minRunTimeSpinner, gbc);

        // Max Run Time
        gbc.gridy++; gbc.gridx = 0; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_SMALL);
        JLabel maxRunLabel = new JLabel("Max Runtime (min):");
        maxRunLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        mainPanel.add(maxRunLabel, gbc);

        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0.5;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);
        mainPanel.add(maxRunTimeSpinner, gbc);

        // === RIGHT COLUMN: Break Duration ===
        gbc.gridy = 1; gbc.gridx = 2; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0;
        gbc.insets = new Insets(ModernUITheme.SPACING_MEDIUM, 0, ModernUITheme.SPACING_SMALL, 0);
        JLabel breakLabel = new JLabel("Break Duration");
        breakLabel.setFont(ModernUITheme.FONT_HEADER);
        breakLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(breakLabel, gbc);

        // Min Break Time
        gbc.gridy++; gbc.gridx = 2; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_SMALL);
        JLabel minBreakLabel = new JLabel("Min Break (min):");
        minBreakLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        mainPanel.add(minBreakLabel, gbc);

        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0.5;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, 0);
        mainPanel.add(minBreakTimeSpinner, gbc);

        // Max Break Time
        gbc.gridy++; gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_SMALL);
        JLabel maxBreakLabel = new JLabel("Max Break (min):");
        maxBreakLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        mainPanel.add(maxBreakLabel, gbc);

        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0.5;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, 0);
        mainPanel.add(maxBreakTimeSpinner, gbc);

        // === BOTTOM SECTION: Advanced Settings (spans both columns) ===
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 4; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0;
        gbc.insets = new Insets(ModernUITheme.SPACING_LARGE, 0, ModernUITheme.SPACING_SMALL, 0);
        JLabel advancedLabel = new JLabel("Advanced Settings");
        advancedLabel.setFont(ModernUITheme.FONT_HEADER);
        advancedLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(advancedLabel, gbc);

        // Random breaks and variance on same row
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);
        mainPanel.add(enableRandomBreaksCheckbox, gbc);

        gbc.gridx = 2; gbc.gridwidth = 2;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, 0);
        JPanel variancePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        variancePanel.setBackground(ModernUITheme.BACKGROUND_DARKEST);
        JLabel varianceLabel = new JLabel("Variance (±min): ");
        varianceLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        variancePanel.add(varianceLabel);
        variancePanel.add(breakVarianceSpinner);
        mainPanel.add(variancePanel, gbc);

        // Logout during breaks
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 4;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, 0);
        mainPanel.add(logoutDuringBreaksCheckbox, gbc);

        add(mainPanel, BorderLayout.CENTER);
    }

    /**
     * Adds event listeners to components
     */
    private void addListeners() {
        enableBreaksCheckbox.addActionListener(e -> {
            if (!isLoading) {
                updateComponentStates();
                saveSettings();
            }
        });

        minRunTimeSpinner.addChangeListener(e -> { if (!isLoading) saveSettings(); });
        maxRunTimeSpinner.addChangeListener(e -> { if (!isLoading) saveSettings(); });
        minBreakTimeSpinner.addChangeListener(e -> { if (!isLoading) saveSettings(); });
        maxBreakTimeSpinner.addChangeListener(e -> { if (!isLoading) saveSettings(); });

        enableRandomBreaksCheckbox.addActionListener(e -> {
            if (!isLoading) {
                updateRandomBreakComponentStates();
                saveSettings();
            }
        });

        breakVarianceSpinner.addChangeListener(e -> { if (!isLoading) saveSettings(); });
        logoutDuringBreaksCheckbox.addActionListener(e -> { if (!isLoading) saveSettings(); });
    }

    /**
     * Updates component states based on enabled status
     */
    private void updateComponentStates() {
        boolean enabled = enableBreaksCheckbox.isSelected();

        minRunTimeSpinner.setEnabled(enabled);
        maxRunTimeSpinner.setEnabled(enabled);
        minBreakTimeSpinner.setEnabled(enabled);
        maxBreakTimeSpinner.setEnabled(enabled);
        enableRandomBreaksCheckbox.setEnabled(enabled);
        logoutDuringBreaksCheckbox.setEnabled(enabled);

        updateRandomBreakComponentStates();
    }

    /**
     * Updates random break component states
     */
    private void updateRandomBreakComponentStates() {
        boolean enabled = enableBreaksCheckbox.isSelected() && enableRandomBreaksCheckbox.isSelected();
        breakVarianceSpinner.setEnabled(enabled);
    }

    /**
     * Loads settings from config
     */
    public void loadSettings() {
        isLoading = true;
        try {
            // Load realistic break settings using custom data
            enableBreaksCheckbox.setSelected(config.getCustomData(KEY_ENABLE_BREAKS, true));
            minRunTimeSpinner.setValue(config.getCustomData(KEY_MIN_RUN_TIME, 45));
            maxRunTimeSpinner.setValue(config.getCustomData(KEY_MAX_RUN_TIME, 90));
            minBreakTimeSpinner.setValue(config.getCustomData(KEY_MIN_BREAK_TIME, 3));
            maxBreakTimeSpinner.setValue(config.getCustomData(KEY_MAX_BREAK_TIME, 8));
            logoutDuringBreaksCheckbox.setSelected(config.getCustomData(KEY_LOGOUT_DURING_BREAKS, true));
            enableRandomBreaksCheckbox.setSelected(config.getCustomData(KEY_ENABLE_RANDOM_BREAKS, true));
            breakVarianceSpinner.setValue(config.getCustomData(KEY_BREAK_VARIANCE, 15));

            updateComponentStates();
        } finally {
            isLoading = false;
        }
    }

    /**
     * Saves settings to config and updates SafetyManager
     */
    public void saveSettings() {
        if (isLoading) return;

        // Save realistic break settings using custom data
        config.setCustomData(KEY_ENABLE_BREAKS, enableBreaksCheckbox.isSelected());
        config.setCustomData(KEY_MIN_RUN_TIME, minRunTimeSpinner.getValue());
        config.setCustomData(KEY_MAX_RUN_TIME, maxRunTimeSpinner.getValue());
        config.setCustomData(KEY_MIN_BREAK_TIME, minBreakTimeSpinner.getValue());
        config.setCustomData(KEY_MAX_BREAK_TIME, maxBreakTimeSpinner.getValue());
        config.setCustomData(KEY_LOGOUT_DURING_BREAKS, logoutDuringBreaksCheckbox.isSelected());
        config.setCustomData(KEY_ENABLE_RANDOM_BREAKS, enableRandomBreaksCheckbox.isSelected());
        config.setCustomData(KEY_BREAK_VARIANCE, breakVarianceSpinner.getValue());

        // Mark config as dirty
        config.markDirty();
    }

    /**
     * Updates from config - called when loading a profile
     */
    public void updateFromConfig() {
        loadSettings();
    }
}
