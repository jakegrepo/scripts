package core.gui.panels;

import core.config.ScriptConfig;
import core.gui.SettingsPanel;
import core.gui.style.ModernUITheme;
import core.gui.style.StyleManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * World-class General Settings Panel for framework-wide configuration
 */
public class GeneralSettingsPanel extends SettingsPanel {
    private final ScriptConfig config;

    // Logging Settings (actually implemented)
    private JCheckBox enableLoggingCheckbox;
    private JComboBox<String> logLevelComboBox;

    // Debug Overlay Settings (actually implemented)
    private JCheckBox enableDebugOverlayCheckbox;
    private JCheckBox enableVisualsCheckbox;

    // Testing & Development
    private JCheckBox enableTestModeCheckbox;

    private boolean isLoading = false;

    // Config keys for realistic settings only
    private static final String KEY_ENABLE_LOGGING = "enableLogging";
    private static final String KEY_LOG_LEVEL = "logLevel";
    private static final String KEY_ENABLE_DEBUG_OVERLAY = "enableDebugOverlay";
    private static final String KEY_ENABLE_VISUALS = "enableVisuals";
    private static final String KEY_ENABLE_TEST_MODE = "enableTestMode";

    /**
     * Creates a new world-class general settings panel
     */
    public GeneralSettingsPanel(ScriptConfig config) {
        super();
        this.config = config;

        initializeComponents();
        setupLayout();
        addListeners();
        loadSettings();
    }

    /**
     * Initializes components for realistic framework settings
     */
    private void initializeComponents() {
        // Logging Settings (actually implemented)
        enableLoggingCheckbox = new JCheckBox("Enable Detailed Logging");
        logLevelComboBox = new JComboBox<>(new String[]{"INFO", "DEBUG", "WARN", "ERROR"});

        // Debug Overlay Settings (actually implemented)
        enableDebugOverlayCheckbox = new JCheckBox("Enable Debug Overlay");
        enableVisualsCheckbox = new JCheckBox("Enable Visual Highlights");

        // Testing & Development (actually implemented)
        enableTestModeCheckbox = new JCheckBox("Enable Test Mode");

        // Apply styling to all components
        styleComponents();
    }

    /**
     * Applies modern styling to components
     */
    private void styleComponents() {
        // Style checkboxes
        StyleManager.styleCheckBox(enableLoggingCheckbox);
        StyleManager.styleCheckBox(enableDebugOverlayCheckbox);
        StyleManager.styleCheckBox(enableVisualsCheckbox);
        StyleManager.styleCheckBox(enableTestModeCheckbox);

        // Style combo box
        StyleManager.styleComboBox(logLevelComboBox);
    }

    /**
     * Sets up an efficient two-column layout that utilizes space effectively
     */
    private void setupLayout() {
        setLayout(new BorderLayout());
        setBackground(ModernUITheme.BACKGROUND_DARKEST);

        // Create main panel with two-column layout
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(ModernUITheme.BACKGROUND_DARKEST);
        mainPanel.setBorder(new EmptyBorder(ModernUITheme.SPACING_MEDIUM,
                                           ModernUITheme.SPACING_MEDIUM,
                                           ModernUITheme.SPACING_MEDIUM,
                                           ModernUITheme.SPACING_MEDIUM));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);

        // === LEFT COLUMN: Logging & Debug Settings ===
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);
        JLabel loggingLabel = new JLabel("Logging & Debug");
        loggingLabel.setFont(ModernUITheme.FONT_HEADER);
        loggingLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(loggingLabel, gbc);

        // Enable Logging
        gbc.gridy++; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_SMALL);
        mainPanel.add(enableLoggingCheckbox, gbc);

        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0.5;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);
        JPanel logLevelPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        logLevelPanel.setBackground(ModernUITheme.BACKGROUND_DARKEST);
        JLabel logLevelLabel = new JLabel("Level: ");
        logLevelLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        logLevelPanel.add(logLevelLabel);
        logLevelPanel.add(logLevelComboBox);
        mainPanel.add(logLevelPanel, gbc);

        // Debug Overlay
        gbc.gridy++; gbc.gridx = 0; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_SMALL);
        mainPanel.add(enableDebugOverlayCheckbox, gbc);

        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0.5;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, ModernUITheme.SPACING_LARGE);
        mainPanel.add(enableVisualsCheckbox, gbc);

        // === RIGHT COLUMN: Development & Testing ===
        gbc.gridy = 0; gbc.gridx = 2; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 0;
        gbc.insets = new Insets(0, 0, ModernUITheme.SPACING_SMALL, 0);
        JLabel testingLabel = new JLabel("Development & Testing");
        testingLabel.setFont(ModernUITheme.FONT_HEADER);
        testingLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        mainPanel.add(testingLabel, gbc);

        // Test Mode
        gbc.gridy++; gbc.gridx = 2; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(ModernUITheme.SPACING_SMALL, 0, ModernUITheme.SPACING_SMALL, 0);
        mainPanel.add(enableTestModeCheckbox, gbc);

        // Add some additional development settings to better utilize the right column
        gbc.gridy++;
        JLabel placeholderLabel = new JLabel("Additional settings can be added here");
        placeholderLabel.setForeground(ModernUITheme.TEXT_SECONDARY);
        placeholderLabel.setFont(ModernUITheme.FONT_SMALL);
        mainPanel.add(placeholderLabel, gbc);

        add(mainPanel, BorderLayout.CENTER);
    }

    /**
     * Adds event listeners to components
     */
    private void addListeners() {
        enableLoggingCheckbox.addActionListener(e -> {
            if (!isLoading) {
                updateLoggingComponentStates();
                saveSettings();
            }
        });
        logLevelComboBox.addActionListener(e -> { if (!isLoading) saveSettings(); });
        enableDebugOverlayCheckbox.addActionListener(e -> {
            if (!isLoading) {
                updateDebugOverlayComponentStates();
                saveSettings();
            }
        });
        enableVisualsCheckbox.addActionListener(e -> { if (!isLoading) saveSettings(); });
        enableTestModeCheckbox.addActionListener(e -> { if (!isLoading) saveSettings(); });
    }

    /**
     * Updates logging component states based on enabled status
     */
    private void updateLoggingComponentStates() {
        boolean enabled = enableLoggingCheckbox.isSelected();
        logLevelComboBox.setEnabled(enabled);
    }

    /**
     * Updates debug overlay component states based on enabled status
     */
    private void updateDebugOverlayComponentStates() {
        boolean enabled = enableDebugOverlayCheckbox.isSelected();
        enableVisualsCheckbox.setEnabled(enabled);
    }

    /**
     * Loads settings from config
     */
    public void loadSettings() {
        isLoading = true;
        try {
            // Load realistic settings only
            enableLoggingCheckbox.setSelected(config.getCustomData(KEY_ENABLE_LOGGING, true));
            logLevelComboBox.setSelectedItem(config.getCustomData(KEY_LOG_LEVEL, "INFO"));
            enableDebugOverlayCheckbox.setSelected(config.getCustomData(KEY_ENABLE_DEBUG_OVERLAY, true));
            enableVisualsCheckbox.setSelected(config.getCustomData(KEY_ENABLE_VISUALS, true));
            enableTestModeCheckbox.setSelected(config.getCustomData(KEY_ENABLE_TEST_MODE, false));

            // Update component states
            updateLoggingComponentStates();
            updateDebugOverlayComponentStates();
        } finally {
            isLoading = false;
        }
    }

    /**
     * Saves settings to config
     */
    public void saveSettings() {
        if (isLoading) return;

        // Save realistic settings only
        config.setCustomData(KEY_ENABLE_LOGGING, enableLoggingCheckbox.isSelected());
        config.setCustomData(KEY_LOG_LEVEL, logLevelComboBox.getSelectedItem());
        config.setCustomData(KEY_ENABLE_DEBUG_OVERLAY, enableDebugOverlayCheckbox.isSelected());
        config.setCustomData(KEY_ENABLE_VISUALS, enableVisualsCheckbox.isSelected());
        config.setCustomData(KEY_ENABLE_TEST_MODE, enableTestModeCheckbox.isSelected());

        // Mark config as dirty
        config.markDirty();
    }

    /**
     * Updates from config - called when loading a profile
     */
    public void updateFromConfig() {
        loadSettings();
    }


}
