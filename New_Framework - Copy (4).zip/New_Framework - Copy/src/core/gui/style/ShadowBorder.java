package core.gui.style;

import javax.swing.border.AbstractBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/**
 * A custom border that adds a shadow effect to components
 */
public class ShadowBorder extends AbstractBorder {
    private final int radius;
    private final int shadowSize = 4;
    private final Color shadowColor = new Color(0, 0, 0, 50);
    
    public ShadowBorder(int radius) {
        this.radius = radius;
    }
    
    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw shadow
        for (int i = 0; i < shadowSize; i++) {
            int alpha = 50 - (i * 10);
            if (alpha < 0) alpha = 0;
            
            g2.setColor(new Color(shadowColor.getRed(), 
                                 shadowColor.getGreen(), 
                                 shadowColor.getBlue(), 
                                 alpha));
            
            g2.draw(new RoundRectangle2D.Double(x + i, y + i, 
                                              width - (i * 2), 
                                              height - (i * 2), 
                                              radius, radius));
        }
        
        // Draw border
        g2.setColor(StyleManager.BORDER_COLOR);
        g2.draw(new RoundRectangle2D.Double(x, y, width - 1, height - 1, radius, radius));
        
        g2.dispose();
    }
    
    @Override
    public Insets getBorderInsets(Component c) {
        return new Insets(shadowSize, shadowSize, shadowSize, shadowSize);
    }
    
    @Override
    public Insets getBorderInsets(Component c, Insets insets) {
        insets.left = insets.top = insets.right = insets.bottom = shadowSize;
        return insets;
    }
}
