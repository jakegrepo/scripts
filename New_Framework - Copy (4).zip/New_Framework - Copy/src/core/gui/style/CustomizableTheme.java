package core.gui.style;

import java.awt.*;

/**
 * A customizable theme that wraps another theme and allows for overriding specific properties.
 * This is used for on-the-fly customization of fonts and colors.
 */
public class CustomizableTheme implements ColorTheme {
    private final ColorTheme baseTheme;

    // Customizable properties
    private Font fontRegular;
    private Font fontBold;
    private Font fontTitle;
    private Font fontSmall;

    private Color textPrimary;
    private Color textSecondary;
    private Color textDisabled;

    private Color backgroundDarkest;
    private Color backgroundDark;
    private Color backgroundMedium;
    private Color backgroundLight;

    private Color accentPrimary;
    private Color accentSecondary;

    /**
     * Creates a new customizable theme based on the provided theme
     */
    public CustomizableTheme(ColorTheme baseTheme) {
        this.baseTheme = baseTheme;

        // Initialize with base theme values
        this.fontRegular = baseTheme.getFontRegular();
        this.fontBold = baseTheme.getFontBold();
        this.fontTitle = baseTheme.getFontTitle();
        this.fontSmall = baseTheme.getFontSmall();

        this.textPrimary = baseTheme.getTextPrimary();
        this.textSecondary = baseTheme.getTextSecondary();
        this.textDisabled = baseTheme.getTextDisabled();

        this.backgroundDarkest = baseTheme.getBackgroundDarkest();
        this.backgroundDark = baseTheme.getBackgroundDark();
        this.backgroundMedium = baseTheme.getBackgroundMedium();
        this.backgroundLight = baseTheme.getBackgroundLight();

        this.accentPrimary = baseTheme.getAccentPrimary();
        this.accentSecondary = baseTheme.getAccentSecondary();
    }

    // Setters for customizable properties

    public void setFontRegular(Font fontRegular) {
        this.fontRegular = fontRegular;
    }

    public void setFontBold(Font fontBold) {
        this.fontBold = fontBold;
    }

    public void setFontTitle(Font fontTitle) {
        this.fontTitle = fontTitle;
    }

    public void setFontSmall(Font fontSmall) {
        this.fontSmall = fontSmall;
    }

    public void setTextPrimary(Color textPrimary) {
        this.textPrimary = textPrimary;
    }

    public void setTextSecondary(Color textSecondary) {
        this.textSecondary = textSecondary;
    }

    public void setTextDisabled(Color textDisabled) {
        this.textDisabled = textDisabled;
    }

    public void setBackgroundDarkest(Color backgroundDarkest) {
        this.backgroundDarkest = backgroundDarkest;
    }

    public void setBackgroundDark(Color backgroundDark) {
        this.backgroundDark = backgroundDark;
    }

    public void setBackgroundMedium(Color backgroundMedium) {
        this.backgroundMedium = backgroundMedium;
    }

    public void setBackgroundLight(Color backgroundLight) {
        this.backgroundLight = backgroundLight;
    }

    public void setAccentPrimary(Color accentPrimary) {
        this.accentPrimary = accentPrimary;
    }

    public void setAccentSecondary(Color accentSecondary) {
        this.accentSecondary = accentSecondary;
    }

    // ColorTheme implementation - override customizable properties, delegate the rest to base theme

    @Override
    public Color getBackgroundDarkest() {
        return backgroundDarkest != null ? backgroundDarkest : baseTheme.getBackgroundDarkest();
    }

    @Override
    public Color getBackgroundDark() {
        return backgroundDark != null ? backgroundDark : baseTheme.getBackgroundDark();
    }

    @Override
    public Color getBackgroundMedium() {
        return backgroundMedium != null ? backgroundMedium : baseTheme.getBackgroundMedium();
    }

    @Override
    public Color getBackgroundLight() {
        return backgroundLight != null ? backgroundLight : baseTheme.getBackgroundLight();
    }

    @Override
    public Color getAccentPrimary() {
        return accentPrimary != null ? accentPrimary : baseTheme.getAccentPrimary();
    }

    @Override
    public Color getAccentSecondary() {
        return accentSecondary != null ? accentSecondary : baseTheme.getAccentSecondary();
    }

    @Override
    public Color getAccentSuccess() {
        return baseTheme.getAccentSuccess();
    }

    @Override
    public Color getAccentWarning() {
        return baseTheme.getAccentWarning();
    }

    @Override
    public Color getAccentDanger() {
        return baseTheme.getAccentDanger();
    }

    @Override
    public Color getTextPrimary() {
        return textPrimary;
    }

    @Override
    public Color getTextSecondary() {
        return textSecondary;
    }

    @Override
    public Color getTextDisabled() {
        return textDisabled;
    }

    @Override
    public String getName() {
        return "Custom " + baseTheme.getName();
    }

    @Override
    public Font getFontRegular() {
        return fontRegular;
    }

    @Override
    public Font getFontBold() {
        return fontBold;
    }

    @Override
    public Font getFontTitle() {
        return fontTitle;
    }

    @Override
    public Font getFontSmall() {
        return fontSmall;
    }

    @Override
    public int getSpacingSmall() {
        return baseTheme.getSpacingSmall();
    }

    @Override
    public int getSpacingMedium() {
        return baseTheme.getSpacingMedium();
    }

    @Override
    public int getSpacingLarge() {
        return baseTheme.getSpacingLarge();
    }

    @Override
    public int getShadowSize() {
        return baseTheme.getShadowSize();
    }

    @Override
    public int getShadowOffset() {
        return baseTheme.getShadowOffset();
    }

    @Override
    public float getShadowOpacity() {
        return baseTheme.getShadowOpacity();
    }

    @Override
    public int getBorderRadiusSmall() {
        return baseTheme.getBorderRadiusSmall();
    }

    @Override
    public int getBorderRadiusMedium() {
        return baseTheme.getBorderRadiusMedium();
    }

    @Override
    public int getBorderRadiusLarge() {
        return baseTheme.getBorderRadiusLarge();
    }
}
