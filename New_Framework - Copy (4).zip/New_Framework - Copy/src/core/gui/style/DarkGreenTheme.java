package core.gui.style;

import java.awt.*;

/**
 * Dark theme with green accents.
 */
public class DarkGreenTheme extends BaseTheme {
    // Color Palette - Dark Theme with Green Accents
    private static final Color BACKGROUND_DARKEST = new Color(15, 22, 15);
    private static final Color BACKGROUND_DARK = new Color(20, 28, 20);
    private static final Color BACKGROUND_MEDIUM = new Color(25, 35, 25);
    private static final Color BACKGROUND_LIGHT = new Color(32, 45, 32);
    
    // Accent Colors
    private static final Color ACCENT_PRIMARY = new Color(46, 204, 113);      // Green
    private static final Color ACCENT_SECONDARY = new Color(26, 188, 156);    // Teal
    private static final Color ACCENT_SUCCESS = new Color(39, 174, 96);       // Dark Green
    private static final Color ACCENT_WARNING = new Color(241, 196, 15);      // Yellow
    private static final Color ACCENT_DANGER = new Color(231, 76, 60);        // Red
    
    // Text Colors
    private static final Color TEXT_PRIMARY = new Color(240, 245, 240);
    private static final Color TEXT_SECONDARY = new Color(200, 210, 200);
    private static final Color TEXT_DISABLED = new Color(130, 140, 130);
    
    @Override
    public Color getBackgroundDarkest() {
        return BACKGROUND_DARKEST;
    }
    
    @Override
    public Color getBackgroundDark() {
        return BACKGROUND_DARK;
    }
    
    @Override
    public Color getBackgroundMedium() {
        return BACKGROUND_MEDIUM;
    }
    
    @Override
    public Color getBackgroundLight() {
        return BACKGROUND_LIGHT;
    }
    
    @Override
    public Color getAccentPrimary() {
        return ACCENT_PRIMARY;
    }
    
    @Override
    public Color getAccentSecondary() {
        return ACCENT_SECONDARY;
    }
    
    @Override
    public Color getAccentSuccess() {
        return ACCENT_SUCCESS;
    }
    
    @Override
    public Color getAccentWarning() {
        return ACCENT_WARNING;
    }
    
    @Override
    public Color getAccentDanger() {
        return ACCENT_DANGER;
    }
    
    @Override
    public Color getTextPrimary() {
        return TEXT_PRIMARY;
    }
    
    @Override
    public Color getTextSecondary() {
        return TEXT_SECONDARY;
    }
    
    @Override
    public Color getTextDisabled() {
        return TEXT_DISABLED;
    }
    
    @Override
    public String getName() {
        return "Dark Green";
    }
}
