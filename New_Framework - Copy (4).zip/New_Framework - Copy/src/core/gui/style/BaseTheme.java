package core.gui.style;

import java.awt.*;

/**
 * Base implementation of ColorTheme with default values.
 * Extend this class to create custom themes with minimal code.
 */
public abstract class BaseTheme implements ColorTheme {
    // Font settings
    private static final Font FONT_REGULAR = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font FONT_BOLD = new Font("Segoe UI", Font.BOLD, 12);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_SMALL = new Font("Segoe UI", Font.PLAIN, 11);
    
    // Spacing values
    private static final int SPACING_SMALL = 5;
    private static final int SPACING_MEDIUM = 10;
    private static final int SPACING_LARGE = 15;
    
    // Shadow settings
    private static final int SHADOW_SIZE = 10;
    private static final int SHADOW_OFFSET = 2;
    private static final float SHADOW_OPACITY = 0.2f;
    
    // Border radius
    private static final int BORDER_RADIUS_SMALL = 3;
    private static final int BORDER_RADIUS_MEDIUM = 6;
    private static final int BORDER_RADIUS_LARGE = 10;
    
    @Override
    public Font getFontRegular() {
        return FONT_REGULAR;
    }
    
    @Override
    public Font getFontBold() {
        return FONT_BOLD;
    }
    
    @Override
    public Font getFontTitle() {
        return FONT_TITLE;
    }
    
    @Override
    public Font getFontSmall() {
        return FONT_SMALL;
    }
    
    @Override
    public int getSpacingSmall() {
        return SPACING_SMALL;
    }
    
    @Override
    public int getSpacingMedium() {
        return SPACING_MEDIUM;
    }
    
    @Override
    public int getSpacingLarge() {
        return SPACING_LARGE;
    }
    
    @Override
    public int getShadowSize() {
        return SHADOW_SIZE;
    }
    
    @Override
    public int getShadowOffset() {
        return SHADOW_OFFSET;
    }
    
    @Override
    public float getShadowOpacity() {
        return SHADOW_OPACITY;
    }
    
    @Override
    public int getBorderRadiusSmall() {
        return BORDER_RADIUS_SMALL;
    }
    
    @Override
    public int getBorderRadiusMedium() {
        return BORDER_RADIUS_MEDIUM;
    }
    
    @Override
    public int getBorderRadiusLarge() {
        return BORDER_RADIUS_LARGE;
    }
}
