package core.gui.style;

import java.awt.*;

/**
 * Light theme with blue accents.
 */
public class LightBlueTheme extends BaseTheme {
    // Color Palette - Light Theme with Blue Accents
    private static final Color BACKGROUND_DARKEST = new Color(200, 200, 210);
    private static final Color BACKGROUND_DARK = new Color(220, 220, 230);
    private static final Color BACKGROUND_MEDIUM = new Color(235, 235, 245);
    private static final Color BACKGROUND_LIGHT = new Color(245, 245, 255);
    
    // Accent Colors
    private static final Color ACCENT_PRIMARY = new Color(41, 128, 185);      // Blue
    private static final Color ACCENT_SECONDARY = new Color(142, 68, 173);    // Purple
    private static final Color ACCENT_SUCCESS = new Color(39, 174, 96);       // Green
    private static final Color ACCENT_WARNING = new Color(243, 156, 18);      // Orange
    private static final Color ACCENT_DANGER = new Color(192, 57, 43);        // Red
    
    // Text Colors
    private static final Color TEXT_PRIMARY = new Color(40, 40, 45);
    private static final Color TEXT_SECONDARY = new Color(80, 80, 90);
    private static final Color TEXT_DISABLED = new Color(150, 150, 160);
    
    @Override
    public Color getBackgroundDarkest() {
        return BACKGROUND_DARKEST;
    }
    
    @Override
    public Color getBackgroundDark() {
        return BACKGROUND_DARK;
    }
    
    @Override
    public Color getBackgroundMedium() {
        return BACKGROUND_MEDIUM;
    }
    
    @Override
    public Color getBackgroundLight() {
        return BACKGROUND_LIGHT;
    }
    
    @Override
    public Color getAccentPrimary() {
        return ACCENT_PRIMARY;
    }
    
    @Override
    public Color getAccentSecondary() {
        return ACCENT_SECONDARY;
    }
    
    @Override
    public Color getAccentSuccess() {
        return ACCENT_SUCCESS;
    }
    
    @Override
    public Color getAccentWarning() {
        return ACCENT_WARNING;
    }
    
    @Override
    public Color getAccentDanger() {
        return ACCENT_DANGER;
    }
    
    @Override
    public Color getTextPrimary() {
        return TEXT_PRIMARY;
    }
    
    @Override
    public Color getTextSecondary() {
        return TEXT_SECONDARY;
    }
    
    @Override
    public Color getTextDisabled() {
        return TEXT_DISABLED;
    }
    
    @Override
    public String getName() {
        return "Light Blue";
    }
}
