package core.gui.style;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

/**
 * A modern, sleek UI theme with vibrant accents and clean design.
 * This class provides a complete set of colors, fonts, and styling elements
 * for a cohesive and professional look across the application.
 *
 * This class now acts as a facade for the ThemeManager, providing static access
 * to the current theme's colors and styles.
 */
public class ModernUITheme {
    // Get the current theme from the ThemeManager
    private static ColorTheme getCurrentTheme() {
        return ThemeManager.getInstance().getCurrentTheme();
    }

    // Color Palette - Background Colors
    public static Color BACKGROUND_DARKEST = getCurrentTheme().getBackgroundDarkest();
    public static Color BACKGROUND_DARK = getCurrentTheme().getBackgroundDark();
    public static Color BACKGROUND_MEDIUM = getCurrentTheme().getBackgroundMedium();
    public static Color BACKGROUND_LIGHT = getCurrentTheme().getBackgroundLight();

    // Accent Colors
    public static Color ACCENT_PRIMARY = getCurrentTheme().getAccentPrimary();
    public static Color ACCENT_SECONDARY = getCurrentTheme().getAccentSecondary();
    public static Color ACCENT_SUCCESS = getCurrentTheme().getAccentSuccess();
    public static Color ACCENT_WARNING = getCurrentTheme().getAccentWarning();
    public static Color ACCENT_DANGER = getCurrentTheme().getAccentDanger();

    // Text Colors
    public static Color TEXT_PRIMARY = getCurrentTheme().getTextPrimary();
    public static Color TEXT_SECONDARY = getCurrentTheme().getTextSecondary();
    public static Color TEXT_DISABLED = getCurrentTheme().getTextDisabled();

    // Gradients
    public static GradientPaint getGradientSidebar() {
        return new GradientPaint(
            0, 0, new Color(getCurrentTheme().getBackgroundMedium().getRGB()),
            0, 1000, new Color(getCurrentTheme().getBackgroundDark().getRGB()));
    }

    public static GradientPaint getGradientHeader() {
        return new GradientPaint(
            0, 0, new Color(getCurrentTheme().getBackgroundLight().getRGB()),
            0, 100, new Color(getCurrentTheme().getBackgroundMedium().getRGB()));
    }

    public static GradientPaint getGradientButton() {
        Color accentPrimary = getCurrentTheme().getAccentPrimary();
        return new GradientPaint(
            0, 0, accentPrimary,
            0, 40, new Color(accentPrimary.getRed() - 20,
                           accentPrimary.getGreen() - 20,
                           accentPrimary.getBlue()));
    }

    // For backward compatibility
    public static final GradientPaint GRADIENT_SIDEBAR = getGradientSidebar();
    public static final GradientPaint GRADIENT_HEADER = getGradientHeader();
    public static final GradientPaint GRADIENT_BUTTON = getGradientButton();

    // Fonts
    public static Font getFontHeader() {
        return new Font(getCurrentTheme().getFontTitle().getName(), Font.BOLD, 18);
    }

    public static Font getFontSubheader() {
        return new Font(getCurrentTheme().getFontTitle().getName(), Font.BOLD, 16);
    }

    public static Font getFontTitle() {
        return getCurrentTheme().getFontTitle();
    }

    public static Font getFontRegular() {
        return getCurrentTheme().getFontRegular();
    }

    public static Font getFontSmall() {
        return getCurrentTheme().getFontSmall();
    }

    public static Font getFontTiny() {
        return new Font(getCurrentTheme().getFontSmall().getName(), Font.PLAIN, 11);
    }

    public static Font getFontMonospace() {
        return new Font("Consolas", Font.PLAIN, 13);
    }

    // Mutable font variables that can be updated
    public static Font FONT_HEADER = getFontHeader();
    public static Font FONT_SUBHEADER = getFontSubheader();
    public static Font FONT_TITLE = getFontTitle();
    public static Font FONT_REGULAR = getFontRegular();
    public static Font FONT_SMALL = getFontSmall();
    public static Font FONT_TINY = getFontTiny();
    public static Font FONT_MONOSPACE = getFontMonospace();

    // Dimensions
    public static int getBorderRadius() {
        return getCurrentTheme().getBorderRadiusMedium();
    }

    public static int getButtonRadius() {
        return getCurrentTheme().getBorderRadiusSmall();
    }

    public static int getFieldRadius() {
        return getCurrentTheme().getBorderRadiusSmall() - 2;
    }

    public static int getCardRadius() {
        return getCurrentTheme().getBorderRadiusLarge();
    }

    // For backward compatibility
    public static final int BORDER_RADIUS = getBorderRadius();
    public static final int BUTTON_RADIUS = getButtonRadius();
    public static final int FIELD_RADIUS = getFieldRadius();
    public static final int CARD_RADIUS = getCardRadius();

    public static final Dimension MAIN_WINDOW_SIZE = new Dimension(1000, 575);
    public static final Dimension MIN_WINDOW_SIZE = new Dimension(800, 550);
    public static final Dimension BUTTON_SIZE = new Dimension(120, 32);
    public static final Dimension ICON_BUTTON_SIZE = new Dimension(32, 32);
    public static final Dimension SPINNER_SIZE = new Dimension(100, 28);
    public static final Dimension COMBO_SIZE = new Dimension(140, 28);

    // Spacing
    public static int getSpacingTiny() {
        return getCurrentTheme().getSpacingSmall() / 2;
    }

    public static int getSpacingSmall() {
        return getCurrentTheme().getSpacingSmall();
    }

    public static int getSpacingMedium() {
        return getCurrentTheme().getSpacingMedium();
    }

    public static int getSpacingLarge() {
        return getCurrentTheme().getSpacingLarge();
    }

    public static int getSpacingXLarge() {
        return getCurrentTheme().getSpacingLarge() + getCurrentTheme().getSpacingMedium();
    }

    // For backward compatibility
    public static final int SPACING_TINY = getSpacingTiny();
    public static final int SPACING_SMALL = getSpacingSmall();
    public static final int SPACING_MEDIUM = getSpacingMedium();
    public static final int SPACING_LARGE = getSpacingLarge();
    public static final int SPACING_XLARGE = getSpacingXLarge();

    public static Insets getInsetsSmall() {
        return new Insets(getSpacingTiny(), getSpacingSmall(), getSpacingTiny(), getSpacingSmall());
    }

    public static Insets getInsetsMedium() {
        return new Insets(getSpacingSmall(), getSpacingMedium(), getSpacingSmall(), getSpacingMedium());
    }

    public static Insets getInsetsLarge() {
        return new Insets(getSpacingMedium(), getSpacingLarge(), getSpacingMedium(), getSpacingLarge());
    }

    // For backward compatibility
    public static final Insets INSETS_SMALL = getInsetsSmall();
    public static final Insets INSETS_MEDIUM = getInsetsMedium();
    public static final Insets INSETS_LARGE = getInsetsLarge();

    // Borders
    public static Border getBorderCard() {
        return BorderFactory.createCompoundBorder(
                new ShadowBorder(getCardRadius()),
                BorderFactory.createEmptyBorder(getSpacingMedium(), getSpacingMedium(),
                                              getSpacingMedium(), getSpacingMedium())
        );
    }

    public static Border getBorderField() {
        Color borderColor = new Color(
            getCurrentTheme().getBackgroundLight().getRed() + 15,
            getCurrentTheme().getBackgroundLight().getGreen() + 15,
            getCurrentTheme().getBackgroundLight().getBlue() + 15
        );
        return BorderFactory.createCompoundBorder(
                new RoundedBorder(borderColor, getFieldRadius()),
                BorderFactory.createEmptyBorder(getSpacingTiny(), getSpacingSmall(),
                                              getSpacingTiny(), getSpacingSmall())
        );
    }

    public static Border getBorderButton() {
        return new RoundedBorder(getCurrentTheme().getAccentPrimary(), getButtonRadius());
    }

    // For backward compatibility
    public static final Border BORDER_CARD = getBorderCard();
    public static final Border BORDER_FIELD = getBorderField();
    public static final Border BORDER_BUTTON = getBorderButton();

    // Effects
    public static float getShadowOpacity() {
        return getCurrentTheme().getShadowOpacity();
    }

    public static int getShadowSize() {
        return getCurrentTheme().getShadowSize();
    }

    public static int getShadowOffset() {
        return getCurrentTheme().getShadowOffset();
    }

    // For backward compatibility
    public static final float SHADOW_OPACITY = getShadowOpacity();
    public static final int SHADOW_SIZE = getShadowSize();
    public static final int SHADOW_OFFSET = getShadowOffset();

    // Animation
    public static final int ANIMATION_DURATION_SHORT = 150;
    public static final int ANIMATION_DURATION_MEDIUM = 250;
    public static final int ANIMATION_DURATION_LONG = 350;

    /**
     * Applies the modern UI theme to the specified window
     *
     * @param window The window to apply the theme to
     */
    public static void apply(Window window) {
        apply(ThemeManager.getInstance().getCurrentTheme().getName(), window);
    }

    /**
     * Applies the modern UI theme to the entire application
     * Note: This method is kept for backward compatibility but should be avoided
     * as it affects all windows including the DreamBot client
     */
    public static void apply() {
        // Update the theme in the ThemeManager
        ThemeManager.getInstance().setCurrentTheme(ThemeManager.getInstance().getCurrentTheme().getName());

        // Update all static fields to reflect the new theme
        updateStaticFields();
    }

    /**
     * Applies the specified theme to the specified window
     *
     * @param themeName The name of the theme to apply
     * @param window The window to apply the theme to
     */
    public static void apply(String themeName, Window window) {
        try {
            // Set the theme in the ThemeManager
            ThemeManager.getInstance().setCurrentTheme(themeName);

            // Update all static fields to reflect the new theme
            updateStaticFields();

            // Set system properties for better rendering
            System.setProperty("awt.useSystemAAFontSettings", "on");
            System.setProperty("swing.aatext", "true");

            // Create a temporary UIDefaults to store our theme settings
            UIDefaults uiDefaults = new UIDefaults();

            // Configure UI defaults
            uiDefaults.put("Panel.background", BACKGROUND_MEDIUM);
            uiDefaults.put("Panel.foreground", TEXT_PRIMARY);

            uiDefaults.put("Label.foreground", TEXT_PRIMARY);
            uiDefaults.put("Label.font", FONT_REGULAR);

            uiDefaults.put("Button.background", ACCENT_PRIMARY);
            uiDefaults.put("Button.foreground", TEXT_PRIMARY);
            uiDefaults.put("Button.font", FONT_REGULAR);
            uiDefaults.put("Button.focus", ACCENT_PRIMARY);

            uiDefaults.put("TextField.background", BACKGROUND_LIGHT);
            uiDefaults.put("TextField.foreground", TEXT_PRIMARY);
            uiDefaults.put("TextField.caretForeground", TEXT_PRIMARY);
            uiDefaults.put("TextField.selectionBackground", ACCENT_PRIMARY);
            uiDefaults.put("TextField.selectionForeground", TEXT_PRIMARY);
            uiDefaults.put("TextField.font", FONT_REGULAR);

            uiDefaults.put("ComboBox.background", BACKGROUND_LIGHT);
            uiDefaults.put("ComboBox.foreground", TEXT_PRIMARY);
            uiDefaults.put("ComboBox.selectionBackground", ACCENT_PRIMARY);
            uiDefaults.put("ComboBox.selectionForeground", TEXT_PRIMARY);
            uiDefaults.put("ComboBox.font", FONT_REGULAR);

            uiDefaults.put("CheckBox.background", BACKGROUND_MEDIUM);
            uiDefaults.put("CheckBox.foreground", TEXT_PRIMARY);
            uiDefaults.put("CheckBox.font", FONT_REGULAR);

            uiDefaults.put("RadioButton.background", BACKGROUND_MEDIUM);
            uiDefaults.put("RadioButton.foreground", TEXT_PRIMARY);
            uiDefaults.put("RadioButton.font", FONT_REGULAR);

            uiDefaults.put("Spinner.background", BACKGROUND_LIGHT);
            uiDefaults.put("Spinner.foreground", TEXT_PRIMARY);
            uiDefaults.put("Spinner.font", FONT_REGULAR);

            uiDefaults.put("List.background", BACKGROUND_LIGHT);
            uiDefaults.put("List.foreground", TEXT_PRIMARY);
            uiDefaults.put("List.selectionBackground", ACCENT_PRIMARY);
            uiDefaults.put("List.selectionForeground", TEXT_PRIMARY);
            uiDefaults.put("List.font", FONT_REGULAR);

            uiDefaults.put("Table.background", BACKGROUND_LIGHT);
            uiDefaults.put("Table.foreground", TEXT_PRIMARY);
            uiDefaults.put("Table.selectionBackground", ACCENT_PRIMARY);
            uiDefaults.put("Table.selectionForeground", TEXT_PRIMARY);
            uiDefaults.put("Table.gridColor", new Color(50, 50, 60));
            uiDefaults.put("Table.font", FONT_REGULAR);
            uiDefaults.put("TableHeader.background", BACKGROUND_DARK);
            uiDefaults.put("TableHeader.foreground", TEXT_PRIMARY);
            uiDefaults.put("TableHeader.font", FONT_REGULAR);

            uiDefaults.put("ScrollPane.background", BACKGROUND_MEDIUM);
            uiDefaults.put("ScrollPane.border", BorderFactory.createEmptyBorder());

            uiDefaults.put("ScrollBar.thumb", ACCENT_PRIMARY);
            uiDefaults.put("ScrollBar.thumbDarkShadow", ACCENT_PRIMARY);
            uiDefaults.put("ScrollBar.thumbHighlight", ACCENT_PRIMARY);
            uiDefaults.put("ScrollBar.thumbShadow", ACCENT_PRIMARY);
            uiDefaults.put("ScrollBar.track", BACKGROUND_DARK);
            uiDefaults.put("ScrollBar.trackHighlight", BACKGROUND_DARK);
            uiDefaults.put("ScrollBar.width", 8);

            uiDefaults.put("TabbedPane.background", BACKGROUND_MEDIUM);
            uiDefaults.put("TabbedPane.foreground", TEXT_PRIMARY);
            uiDefaults.put("TabbedPane.selected", BACKGROUND_LIGHT);
            uiDefaults.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0));
            uiDefaults.put("TabbedPane.tabAreaInsets", new Insets(4, 4, 0, 4));
            uiDefaults.put("TabbedPane.font", FONT_REGULAR);

            uiDefaults.put("OptionPane.background", BACKGROUND_MEDIUM);
            uiDefaults.put("OptionPane.foreground", TEXT_PRIMARY);
            uiDefaults.put("OptionPane.messageForeground", TEXT_PRIMARY);

            uiDefaults.put("ToolTip.background", BACKGROUND_DARK);
            uiDefaults.put("ToolTip.foreground", TEXT_PRIMARY);
            uiDefaults.put("ToolTip.border", BorderFactory.createLineBorder(ACCENT_PRIMARY, 1));
            uiDefaults.put("ToolTip.font", FONT_SMALL);

            // Apply the defaults to the specified window only
            if (window != null) {
                // Apply the defaults to all components in the window
                applyUIDefaultsToComponent(window, uiDefaults);

                // Update the component tree UI for the window
                SwingUtilities.updateComponentTreeUI(window);

                // Recursively update all components
                updateComponentFontsAndColors(window);

                // Repaint the window
                window.repaint();
            }
        } catch (Exception e) {
            System.err.println("Failed to apply modern UI theme: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Recursively applies UI defaults to a component and its children
     */
    private static void applyUIDefaultsToComponent(Component component, UIDefaults defaults) {
        if (component instanceof JComponent) {
            JComponent jComponent = (JComponent) component;
            jComponent.putClientProperty("UI_DEFAULTS_KEY", defaults);
        }

        if (component instanceof Container) {
            Container container = (Container) component;
            for (Component child : container.getComponents()) {
                applyUIDefaultsToComponent(child, defaults);
            }
        }
    }

    /**
     * Applies the specified theme to the entire application
     * Note: This method is kept for backward compatibility but should be avoided
     * as it affects all windows including the DreamBot client
     *
     * @param themeName The name of the theme to apply
     */
    public static void apply(String themeName) {
        // Update the theme in the ThemeManager
        ThemeManager.getInstance().setCurrentTheme(themeName);

        // Update all static fields to reflect the new theme
        updateStaticFields();
    }

    /**
     * Recursively updates fonts and colors for all components in the container
     */
    private static void updateComponentFontsAndColors(Container container) {
        for (Component component : container.getComponents()) {
            // Update font for all components
            if (component instanceof JComponent) {
                JComponent jComponent = (JComponent) component;

                // Update font based on component type
                if (component instanceof JLabel) {
                    if (((JLabel) component).getFont().isBold()) {
                        component.setFont(FONT_TITLE);
                    } else {
                        component.setFont(FONT_REGULAR);
                    }
                } else if (component instanceof JButton) {
                    component.setFont(FONT_REGULAR);
                } else if (component instanceof JTextField || component instanceof JTextArea) {
                    component.setFont(FONT_REGULAR);
                } else if (component instanceof JComboBox) {
                    component.setFont(FONT_REGULAR);
                } else if (component instanceof JCheckBox || component instanceof JRadioButton) {
                    component.setFont(FONT_REGULAR);
                }

                // Update text colors
                if (component instanceof JLabel) {
                    if (component.getForeground().equals(TEXT_SECONDARY) ||
                        component.getForeground().getRGB() == new Color(200, 200, 210).getRGB()) {
                        component.setForeground(TEXT_SECONDARY);
                    } else {
                        component.setForeground(TEXT_PRIMARY);
                    }
                }
            }

            // Recursively update child components
            if (component instanceof Container) {
                updateComponentFontsAndColors((Container) component);
            }
        }
    }

    /**
     * Updates all static fields to reflect the current theme
     */
    private static void updateStaticFields() {
        // Update background colors
        BACKGROUND_DARKEST = getCurrentTheme().getBackgroundDarkest();
        BACKGROUND_DARK = getCurrentTheme().getBackgroundDark();
        BACKGROUND_MEDIUM = getCurrentTheme().getBackgroundMedium();
        BACKGROUND_LIGHT = getCurrentTheme().getBackgroundLight();

        // Update accent colors
        ACCENT_PRIMARY = getCurrentTheme().getAccentPrimary();
        ACCENT_SECONDARY = getCurrentTheme().getAccentSecondary();
        ACCENT_SUCCESS = getCurrentTheme().getAccentSuccess();
        ACCENT_WARNING = getCurrentTheme().getAccentWarning();
        ACCENT_DANGER = getCurrentTheme().getAccentDanger();

        // Update text colors
        TEXT_PRIMARY = getCurrentTheme().getTextPrimary();
        TEXT_SECONDARY = getCurrentTheme().getTextSecondary();
        TEXT_DISABLED = getCurrentTheme().getTextDisabled();

        // Update font constants directly
        FONT_HEADER = getFontHeader();
        FONT_SUBHEADER = getFontSubheader();
        FONT_TITLE = getFontTitle();
        FONT_REGULAR = getFontRegular();
        FONT_SMALL = getFontSmall();
        FONT_TINY = getFontTiny();
        FONT_MONOSPACE = getFontMonospace();
    }
}
