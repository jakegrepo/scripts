package core.gui.style;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Manages color themes for the application.
 * Allows for easy switching between different color schemes.
 */
public class ThemeManager {
    private static ThemeManager instance;
    private ColorTheme currentTheme;
    private final Map<String, ColorTheme> availableThemes = new HashMap<>();
    private final java.util.List<ThemeChangeListener> listeners = new java.util.ArrayList<>();

    /**
     * Private constructor for singleton pattern
     */
    private ThemeManager() {
        // Initialize with default themes
        registerTheme("Dark Blue", new DarkBlueTheme());
        registerTheme("Dark Purple", new DarkPurpleTheme());
        registerTheme("Dark Green", new DarkGreenTheme());
        registerTheme("Light Blue", new LightBlueTheme());

        // Set default theme
        currentTheme = availableThemes.get("Dark Blue");
    }

    /**
     * Get the singleton instance
     */
    public static synchronized ThemeManager getInstance() {
        if (instance == null) {
            instance = new ThemeManager();
        }
        return instance;
    }

    /**
     * Register a new theme
     */
    public void registerTheme(String name, ColorTheme theme) {
        availableThemes.put(name, theme);
    }

    /**
     * Get the current theme
     */
    public ColorTheme getCurrentTheme() {
        return currentTheme;
    }

    /**
     * Get all available theme names
     */
    public String[] getAvailableThemeNames() {
        return availableThemes.keySet().toArray(new String[0]);
    }

    /**
     * Get a theme by name
     */
    public ColorTheme getTheme(String name) {
        return availableThemes.get(name);
    }

    /**
     * Set the current theme
     */
    public void setCurrentTheme(String themeName) {
        if (availableThemes.containsKey(themeName)) {
            currentTheme = availableThemes.get(themeName);
            notifyListeners();
            updateUIComponents();
        }
    }

    /**
     * Update fonts for the current theme
     */
    public void updateFonts(Font regularFont, Font boldFont, Font titleFont, Font smallFont) {
        // Create a custom theme with updated fonts
        CustomizableTheme customTheme = new CustomizableTheme(currentTheme);
        customTheme.setFontRegular(regularFont);
        customTheme.setFontBold(boldFont);
        customTheme.setFontTitle(titleFont);
        customTheme.setFontSmall(smallFont);

        // Set as current theme
        currentTheme = customTheme;
        notifyListeners();
        updateUIComponents();
    }

    /**
     * Update text colors for the current theme
     */
    public void updateTextColors(Color primaryColor, Color secondaryColor, Color disabledColor) {
        // Create a custom theme with updated text colors
        CustomizableTheme customTheme = new CustomizableTheme(currentTheme);
        customTheme.setTextPrimary(primaryColor);
        customTheme.setTextSecondary(secondaryColor);
        customTheme.setTextDisabled(disabledColor);

        // Set as current theme
        currentTheme = customTheme;
        notifyListeners();
        updateUIComponents();
    }

    /**
     * Update background colors in the current theme
     */
    public void updateBackgroundColors(Color darkestColor, Color darkColor, Color mediumColor, Color lightColor) {
        // Create a custom theme with updated background colors
        CustomizableTheme customTheme = new CustomizableTheme(currentTheme);
        customTheme.setBackgroundDarkest(darkestColor);
        customTheme.setBackgroundDark(darkColor);
        customTheme.setBackgroundMedium(mediumColor);
        customTheme.setBackgroundLight(lightColor);

        // Set as current theme
        currentTheme = customTheme;
        notifyListeners();
        updateUIComponents();
    }

    /**
     * Update accent colors in the current theme
     */
    public void updateAccentColors(Color primaryColor, Color secondaryColor) {
        // Create a custom theme with updated accent colors
        CustomizableTheme customTheme = new CustomizableTheme(currentTheme);
        customTheme.setAccentPrimary(primaryColor);
        customTheme.setAccentSecondary(secondaryColor);

        // Set as current theme
        currentTheme = customTheme;
        notifyListeners();
        updateUIComponents();
    }

    /**
     * Add a theme change listener
     */
    public void addThemeChangeListener(ThemeChangeListener listener) {
        listeners.add(listener);
    }

    /**
     * Remove a theme change listener
     */
    public void removeThemeChangeListener(ThemeChangeListener listener) {
        listeners.remove(listener);
    }

    /**
     * Notify all listeners of a theme change
     */
    private void notifyListeners() {
        for (ThemeChangeListener listener : listeners) {
            listener.onThemeChanged(currentTheme);
        }
    }

    /**
     * Update all UI components with the new theme
     */
    private void updateUIComponents() {
        // We don't need to update UIManager defaults here anymore
        // as we're using the window-specific apply method in ModernUITheme
        // This method is kept for backward compatibility

        // Notify listeners that the theme has changed
        // They can then apply the theme to their specific windows
        notifyListeners();
    }

    /**
     * Interface for theme change listeners
     */
    public interface ThemeChangeListener {
        void onThemeChanged(ColorTheme newTheme);
    }
}
