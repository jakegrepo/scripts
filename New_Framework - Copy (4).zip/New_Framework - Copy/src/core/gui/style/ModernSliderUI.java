package core.gui.style;

import javax.swing.*;
import javax.swing.plaf.basic.BasicSliderUI;
import java.awt.*;

public class ModernSliderUI extends BasicSliderUI {
    private final Color accentColor;

    public ModernSliderUI(JSlider slider, Color accentColor) {
        super(slider);
        this.accentColor = accentColor;
    }

    @Override
    public void paintTrack(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Rectangle trackBounds = trackRect;
        int cy = (trackBounds.height / 2) - 2;
        int w = trackBounds.width;

        // Draw background track
        g2d.setColor(StyleManager.FIELD_BG);
        g2d.fillRoundRect(trackBounds.x, trackBounds.y + cy, w, 4, 4, 4);

        // Draw filled part
        int thumbPos = thumbRect.x + (thumbRect.width / 2);
        g2d.setColor(accentColor);
        g2d.fillRoundRect(trackBounds.x, trackBounds.y + cy, thumbPos - trackBounds.x, 4, 4, 4);
    }

    @Override
    public void paintThumb(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Rectangle thumbBounds = thumbRect;
        int diameter = thumbBounds.height - 2;

        g2d.setColor(accentColor);
        g2d.fillOval(thumbBounds.x, thumbBounds.y + 1, diameter, diameter);
    }
} 