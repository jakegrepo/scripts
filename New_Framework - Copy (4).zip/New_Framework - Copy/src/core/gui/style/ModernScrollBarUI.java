package core.gui.style;

import javax.swing.*;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;

/**
 * A modern, minimal scrollbar UI with improved visuals
 */
public class ModernScrollBarUI extends BasicScrollBarUI {
    private final int THUMB_SIZE = 8;

    @Override
    protected void configureScrollBarColors() {
        this.thumbColor = StyleManager.ACCENT;
        this.thumbDarkShadowColor = StyleManager.ACCENT_DARKER;
        this.thumbHighlightColor = StyleManager.ACCENT_LIGHTER;
        this.thumbLightShadowColor = StyleManager.ACCENT;
        this.trackColor = StyleManager.PANEL_BG;
        this.trackHighlightColor = StyleManager.PANEL_BG;
    }

    @Override
    protected JButton createDecreaseButton(int orientation) {
        return createZeroButton();
    }

    @Override
    protected JButton createIncreaseButton(int orientation) {
        return createZeroButton();
    }

    private JButton createZeroButton() {
        JButton button = new JButton();
        button.setPreferredSize(new Dimension(0, 0));
        button.setMinimumSize(new Dimension(0, 0));
        button.setMaximumSize(new Dimension(0, 0));
        return button;
    }

    @Override
    protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
        if (thumbBounds.isEmpty() || !scrollbar.isEnabled()) {
            return;
        }

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Create thumb shape
        int x = thumbBounds.x + (thumbBounds.width - THUMB_SIZE) / 2;
        int y = thumbBounds.y;
        int width = THUMB_SIZE;
        int height = thumbBounds.height;

        if (scrollbar.getOrientation() == JScrollBar.HORIZONTAL) {
            x = thumbBounds.x;
            y = thumbBounds.y + (thumbBounds.height - THUMB_SIZE) / 2;
            width = thumbBounds.width;
            height = THUMB_SIZE;
        }

        // Draw thumb with subtle gradient
        GradientPaint gradient = new GradientPaint(
            x, y, StyleManager.ACCENT_LIGHTER,
            x + width, y + height, StyleManager.ACCENT
        );
        g2.setPaint(gradient);
        g2.fillRoundRect(x, y, width, height, THUMB_SIZE, THUMB_SIZE);

        g2.dispose();
    }

    @Override
    protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setColor(StyleManager.PANEL_BG);
        g2.fillRect(trackBounds.x, trackBounds.y, trackBounds.width, trackBounds.height);
        g2.dispose();
    }

    @Override
    public Dimension getPreferredSize(JComponent c) {
        if (scrollbar.getOrientation() == JScrollBar.VERTICAL) {
            return new Dimension(THUMB_SIZE + 2, scrollbar.getHeight());
        } else {
            return new Dimension(scrollbar.getWidth(), THUMB_SIZE + 2);
        }
    }
}