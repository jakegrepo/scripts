package core.gui.style;

import java.awt.*;

/**
 * Dark theme with purple accents.
 */
public class DarkPurpleTheme extends BaseTheme {
    // Color Palette - Dark Theme with Purple Accents
    private static final Color BACKGROUND_DARKEST = new Color(20, 15, 25);
    private static final Color BACKGROUND_DARK = new Color(25, 20, 30);
    private static final Color BACKGROUND_MEDIUM = new Color(32, 25, 38);
    private static final Color BACKGROUND_LIGHT = new Color(40, 32, 48);
    
    // Accent Colors
    private static final Color ACCENT_PRIMARY = new Color(138, 43, 226);      // Purple
    private static final Color ACCENT_SECONDARY = new Color(86, 124, 242);    // Blue
    private static final Color ACCENT_SUCCESS = new Color(46, 204, 113);      // Green
    private static final Color ACCENT_WARNING = new Color(241, 196, 15);      // Yellow
    private static final Color ACCENT_DANGER = new Color(231, 76, 60);        // Red
    
    // Text Colors
    private static final Color TEXT_PRIMARY = new Color(240, 240, 245);
    private static final Color TEXT_SECONDARY = new Color(200, 200, 210);
    private static final Color TEXT_DISABLED = new Color(130, 130, 140);
    
    @Override
    public Color getBackgroundDarkest() {
        return BACKGROUND_DARKEST;
    }
    
    @Override
    public Color getBackgroundDark() {
        return BACKGROUND_DARK;
    }
    
    @Override
    public Color getBackgroundMedium() {
        return BACKGROUND_MEDIUM;
    }
    
    @Override
    public Color getBackgroundLight() {
        return BACKGROUND_LIGHT;
    }
    
    @Override
    public Color getAccentPrimary() {
        return ACCENT_PRIMARY;
    }
    
    @Override
    public Color getAccentSecondary() {
        return ACCENT_SECONDARY;
    }
    
    @Override
    public Color getAccentSuccess() {
        return ACCENT_SUCCESS;
    }
    
    @Override
    public Color getAccentWarning() {
        return ACCENT_WARNING;
    }
    
    @Override
    public Color getAccentDanger() {
        return ACCENT_DANGER;
    }
    
    @Override
    public Color getTextPrimary() {
        return TEXT_PRIMARY;
    }
    
    @Override
    public Color getTextSecondary() {
        return TEXT_SECONDARY;
    }
    
    @Override
    public Color getTextDisabled() {
        return TEXT_DISABLED;
    }
    
    @Override
    public String getName() {
        return "Dark Purple";
    }
}
