package core.gui.style;

import java.awt.*;

/**
 * Interface for color themes.
 * All color themes must implement this interface to provide a consistent set of colors.
 */
public interface ColorTheme {
    // Background colors
    Color getBackgroundDarkest();
    Color getBackgroundDark();
    Color getBackgroundMedium();
    Color getBackgroundLight();
    
    // Accent colors
    Color getAccentPrimary();
    Color getAccentSecondary();
    Color getAccentSuccess();
    Color getAccentWarning();
    Color getAccentDanger();
    
    // Text colors
    Color getTextPrimary();
    Color getTextSecondary();
    Color getTextDisabled();
    
    // Get theme name
    String getName();
    
    // Get font settings
    Font getFontRegular();
    Font getFontBold();
    Font getFontTitle();
    Font getFontSmall();
    
    // Get spacing values
    int getSpacingSmall();
    int getSpacingMedium();
    int getSpacingLarge();
    
    // Get shadow settings
    int getShadowSize();
    int getShadowOffset();
    float getShadowOpacity();
    
    // Get border radius
    int getBorderRadiusSmall();
    int getBorderRadiusMedium();
    int getBorderRadiusLarge();
}
