package core.gui.style;

import javax.swing.plaf.basic.BasicTabbedPaneUI;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class ModernTabbedPaneUI extends BasicTabbedPaneUI {

    private final Color SELECTED_TAB_COLOR = new Color(32, 32, 36); // Match card background
    private final Color HOVER_TAB_COLOR = new Color(30, 30, 34); // Subtle hover effect
    private final int TAB_RADIUS = 8; // Slightly reduced radius for tabs
    private final Stroke BORDER_STROKE = new BasicStroke(1.5f); // Slightly thicker border for emphasis

    // Track the tab the mouse is currently over
    private int rolloverTab = -1;

    @Override
    protected void installDefaults() {
        super.installDefaults();
        shadow = StyleManager.BACKGROUND;
        darkShadow = StyleManager.BACKGROUND;
        lightHighlight = StyleManager.PANEL_BG;
        focus = StyleManager.ACCENT;
    }

    @Override
    protected void installListeners() {
        super.installListeners();
        tabPane.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent e) {
                int tabIndex = tabForCoordinate(tabPane, e.getX(), e.getY());
                if (rolloverTab != tabIndex) {
                    rolloverTab = tabIndex;
                    tabPane.repaint();
                }
            }
        });

        tabPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent e) {
                if (rolloverTab != -1) {
                    rolloverTab = -1;
                    tabPane.repaint();
                }
            }
        });
    }

    /**
     * Gets the index of the tab the mouse is currently over
     *
     * @return The index of the tab the mouse is over, or -1 if none
     */
    protected int getRolloverTab() {
        return rolloverTab;
    }

    @Override
    protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex,
                                int x, int y, int w, int h, boolean isSelected) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

        // Save original stroke
        Stroke originalStroke = g2.getStroke();

        // Draw rounded rectangle for tab with improved styling
        if (isSelected) {
            // Use accent color for selected tab with thicker border
            g2.setColor(StyleManager.ACCENT);
            g2.setStroke(BORDER_STROKE);
            g2.draw(new RoundRectangle2D.Double(x + 1, y + 1, w - 3, h - 1, TAB_RADIUS, TAB_RADIUS));

            // Draw a subtle indicator line at the bottom of the selected tab
            g2.setStroke(new BasicStroke(2.5f));
            g2.drawLine(x + 6, y + h - 1, x + w - 6, y + h - 1);
        } else {
            // Use border color for unselected tabs with normal border
            g2.setColor(StyleManager.BORDER_COLOR);
            g2.draw(new RoundRectangle2D.Double(x + 1, y + 1, w - 3, h - 1, TAB_RADIUS, TAB_RADIUS));
        }

        // Restore original stroke
        g2.setStroke(originalStroke);
        g2.dispose();
    }

    @Override
    protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex,
                                    int x, int y, int w, int h, boolean isSelected) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Create gradient paint for more depth
        GradientPaint gradient;

        // Fill tab background with gradient for better visual depth
        if (isSelected) {
            // Selected tab has a slightly lighter gradient
            gradient = new GradientPaint(
                x, y, SELECTED_TAB_COLOR,
                x, y + h, new Color(SELECTED_TAB_COLOR.getRed() + 5,
                                   SELECTED_TAB_COLOR.getGreen() + 5,
                                   SELECTED_TAB_COLOR.getBlue() + 5));
            g2.setPaint(gradient);
        } else {
            // Check if mouse is over this tab
            if (getRolloverTab() == tabIndex) {
                // Hover state
                gradient = new GradientPaint(
                    x, y, HOVER_TAB_COLOR,
                    x, y + h, new Color(HOVER_TAB_COLOR.getRed() + 3,
                                       HOVER_TAB_COLOR.getGreen() + 3,
                                       HOVER_TAB_COLOR.getBlue() + 3));
                g2.setPaint(gradient);
            } else {
                // Normal state
                gradient = new GradientPaint(
                    x, y, StyleManager.PANEL_BG,
                    x, y + h, new Color(StyleManager.PANEL_BG.getRed() + 2,
                                       StyleManager.PANEL_BG.getGreen() + 2,
                                       StyleManager.PANEL_BG.getBlue() + 2));
                g2.setPaint(gradient);
            }
        }

        // Fill with rounded corners
        g2.fill(new RoundRectangle2D.Double(x + 1, y + 1, w - 3, h - 1, TAB_RADIUS, TAB_RADIUS));

        g2.dispose();
    }

    @Override
    protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
        // Override to remove the content border
    }

    @Override
    protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rects,
                                     int tabIndex, Rectangle iconRect, Rectangle textRect,
                                     boolean isSelected) {
        // Override to remove the focus indicator
    }

    @Override
    protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
        // Slightly reduced height for more compact layout
        return super.calculateTabHeight(tabPlacement, tabIndex, fontHeight) + 2;
    }

    @Override
    protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics) {
        // Slightly increased width for better spacing
        return super.calculateTabWidth(tabPlacement, tabIndex, metrics) + 20;
    }

    @Override
    protected void paintText(Graphics g, int tabPlacement, Font font, FontMetrics metrics,
                           int tabIndex, String title, Rectangle textRect, boolean isSelected) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Use different colors for selected and unselected tabs
        if (isSelected) {
            g2.setColor(StyleManager.ACCENT_LIGHTER);
            g2.setFont(StyleManager.REGULAR_FONT_BOLD);
        } else {
            g2.setColor(StyleManager.FOREGROUND);
            g2.setFont(StyleManager.REGULAR_FONT);
        }

        // Draw text
        g2.drawString(title, textRect.x, textRect.y + metrics.getAscent());
        g2.dispose();
    }
}