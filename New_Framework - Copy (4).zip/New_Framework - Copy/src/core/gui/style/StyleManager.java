package core.gui.style;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

// Import ModernUITheme for consistent styling
import core.gui.style.ModernUITheme;

// Substance-compatible styling
import java.util.HashMap;
import java.util.Map;

/**
 * Modern style manager that provides consistent styling across the application
 * Uses ModernUITheme for colors, fonts, and dimensions
 */
public class StyleManager {
    // Use ModernUITheme for colors
    public static final Color BACKGROUND = ModernUITheme.BACKGROUND_DARKEST;
    public static final Color PANEL_BG = ModernUITheme.BACKGROUND_DARK;
    public static final Color COMPONENT_BG = ModernUITheme.BACKGROUND_MEDIUM;
    public static final Color CARD_BG = ModernUITheme.BACKGROUND_MEDIUM;
    public static final Color FOREGROUND = ModernUITheme.TEXT_PRIMARY;
    public static final Color FOREGROUND_SECONDARY = ModernUITheme.TEXT_SECONDARY;

    // Accent colors
    public static final Color ACCENT = ModernUITheme.ACCENT_PRIMARY;
    public static final Color ACCENT_DARKER = new Color(
            Math.max(0, ModernUITheme.ACCENT_PRIMARY.getRed() - 20),
            Math.max(0, ModernUITheme.ACCENT_PRIMARY.getGreen() - 20),
            Math.max(0, ModernUITheme.ACCENT_PRIMARY.getBlue() - 20));
    public static final Color ACCENT_LIGHTER = new Color(
            Math.min(255, ModernUITheme.ACCENT_PRIMARY.getRed() + 20),
            Math.min(255, ModernUITheme.ACCENT_PRIMARY.getGreen() + 20),
            Math.min(255, ModernUITheme.ACCENT_PRIMARY.getBlue() + 20));

    // Status colors with improved visibility
    public static final Color SUCCESS = new Color(40, 167, 69); // Green
    public static final Color WARNING = new Color(255, 152, 0); // Orange
    public static final Color ERROR = new Color(220, 53, 69); // Red
    public static final Color INFO = new Color(23, 162, 184); // Info blue

    // Additional accent colors for data visualization
    public static final Color ACCENT_PURPLE = new Color(111, 66, 193); // Purple accent
    public static final Color ACCENT_TEAL = new Color(32, 201, 151); // Teal accent
    public static final Color ACCENT_PINK = new Color(232, 62, 140); // Pink accent
    public static final Color ACCENT_YELLOW = new Color(255, 193, 7); // Yellow accent

    // Flag to check if we're using Substance look and feel
    private static boolean isUsingSubstance = false;

    // Initialize the style manager
    static {
        try {
            // Check if Substance is active
            Class.forName("org.pushingpixels.substance.api.SubstanceCortex");
            isUsingSubstance = UIManager.getLookAndFeel().getClass().getName().contains("Substance");
        } catch (ClassNotFoundException e) {
            // Substance is not available
            isUsingSubstance = false;
        }
    }

    // Enhanced Component Colors with better contrast and visual feedback
    public static final Color BUTTON_BG = new Color(45, 45, 55); // Slightly lighter button background
    public static final Color BUTTON_HOVER = new Color(55, 55, 70); // More noticeable hover state
    public static final Color BUTTON_PRESSED = new Color(35, 35, 45); // Darker pressed state for feedback
    public static final Color FIELD_BG = new Color(34, 34, 38); // Slightly lighter input field background
    public static final Color FIELD_FOCUS_BG = new Color(38, 38, 44); // More noticeable focused background

    // Refined Border and selection colors
    public static final Color BORDER_COLOR = new Color(60, 60, 70); // Slightly more visible border color
    public static final Color BORDER_FOCUS = ACCENT; // Focused border color
    public static final Color LIST_SELECTION_BG = new Color(56, 114, 250); // Match accent color
    public static final Color LIST_SELECTION_FG = FOREGROUND; // List selection foreground
    public static final Color LIST_HOVER_BG = new Color(45, 45, 55); // More noticeable hover background

    // Use ModernUITheme for fonts
    public static final String PRIMARY_FONT = "Segoe UI";
    public static final String MONOSPACE_FONT = "JetBrains Mono";

    // Header fonts
    public static final Font HEADER_FONT_LARGE = ModernUITheme.FONT_HEADER;
    public static final Font HEADER_FONT = ModernUITheme.FONT_SUBHEADER;
    public static final Font HEADER_FONT_SMALL = ModernUITheme.FONT_TITLE;

    // Body text fonts
    public static final Font REGULAR_FONT = ModernUITheme.FONT_REGULAR;
    public static final Font REGULAR_FONT_BOLD = new Font(ModernUITheme.FONT_REGULAR.getName(), Font.BOLD, ModernUITheme.FONT_REGULAR.getSize());
    public static final Font SMALL_FONT = ModernUITheme.FONT_SMALL;
    public static final Font SMALL_FONT_BOLD = new Font(ModernUITheme.FONT_SMALL.getName(), Font.BOLD, ModernUITheme.FONT_SMALL.getSize());

    // Special purpose fonts
    public static final Font LABEL_FONT = ModernUITheme.FONT_TITLE;
    public static final Font MONOSPACE_REGULAR = ModernUITheme.FONT_MONOSPACE;
    public static final Font STATS_FONT = ModernUITheme.FONT_TITLE;

    // Text colors for different purposes
    public static final Color TEXT_COLOR = FOREGROUND; // Primary text color
    public static final Color TEXT_SECONDARY = FOREGROUND_SECONDARY; // Secondary text color
    public static final Color TEXT_DISABLED = new Color(120, 120, 130); // Disabled text color
    public static final Color BACKGROUND_COLOR = PANEL_BG; // Main background color

    // Use ModernUITheme for dimensions
    public static final Dimension MAIN_WINDOW_SIZE = ModernUITheme.MAIN_WINDOW_SIZE;
    public static final Dimension MIN_WINDOW_SIZE = ModernUITheme.MIN_WINDOW_SIZE;
    public static final int CARD_RADIUS = ModernUITheme.CARD_RADIUS;
    public static final int BUTTON_RADIUS = ModernUITheme.BUTTON_RADIUS;
    public static final int FIELD_RADIUS = ModernUITheme.FIELD_RADIUS;

    // Refined border system for a cleaner, more modern look
    private static final Border EMPTY_BORDER = BorderFactory.createEmptyBorder(6, 6, 6, 6); // Reduced padding
    private static final Border LINE_BORDER = BorderFactory.createLineBorder(BORDER_COLOR, 1);
    public static final Border COMPONENT_BORDER = BorderFactory.createCompoundBorder(
            new RoundedBorder(BORDER_COLOR, FIELD_RADIUS),
            BorderFactory.createEmptyBorder(5, 10, 5, 10) // Reduced vertical padding
    );

    // Enhanced card borders with improved shadow effect
    public static final Border CARD_BORDER = BorderFactory.createCompoundBorder(
            new ShadowBorder(CARD_RADIUS),
            BorderFactory.createEmptyBorder(6, 12, 6, 12) // Further reduced vertical padding
    );

    // Optimized panel borders
    public static final Border PANEL_BORDER = BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10) // Further reduced padding
    );

    // Use ModernUITheme for sidebar colors
    public static final Color SIDEBAR_BG = ModernUITheme.BACKGROUND_DARKEST;
    public static final Color SIDEBAR_ITEM_HOVER = new Color(ModernUITheme.ACCENT_PRIMARY.getRed(),
                                                         ModernUITheme.ACCENT_PRIMARY.getGreen(),
                                                         ModernUITheme.ACCENT_PRIMARY.getBlue(), 40);
    public static final Color SIDEBAR_ITEM_SELECTED = new Color(ModernUITheme.ACCENT_PRIMARY.getRed(),
                                                           ModernUITheme.ACCENT_PRIMARY.getGreen(),
                                                           ModernUITheme.ACCENT_PRIMARY.getBlue(), 80);
    public static final Color SIDEBAR_ITEM_SELECTED_BORDER = ModernUITheme.ACCENT_PRIMARY;
    public static final Font BUTTON_FONT = ModernUITheme.FONT_REGULAR;

    // Use ModernUITheme for fonts
    public static final Font SECTION_HEADER_FONT = ModernUITheme.FONT_TITLE;
    public static final Font FIELD_LABEL_FONT = ModernUITheme.FONT_REGULAR;

    // Use ModernUITheme for spacing
    public static final int SECTION_SPACING = ModernUITheme.SPACING_MEDIUM;
    public static final int COMPONENT_SPACING = ModernUITheme.SPACING_MEDIUM;
    public static final int FIELD_SPACING = ModernUITheme.SPACING_SMALL;
    public static final Insets CONTENT_PADDING = ModernUITheme.INSETS_LARGE;
    public static final Insets CARD_PADDING = ModernUITheme.INSETS_MEDIUM;
    public static final Insets FIELD_PADDING = ModernUITheme.INSETS_SMALL;

    // Use ModernUITheme for component sizes
    public static final Dimension SPINNER_SIZE = ModernUITheme.SPINNER_SIZE;
    public static final Dimension COMBO_SIZE = ModernUITheme.COMBO_SIZE;
    public static final Dimension BUTTON_SIZE = ModernUITheme.BUTTON_SIZE;
    public static final Dimension ICON_BUTTON_SIZE = ModernUITheme.ICON_BUTTON_SIZE;

    // Enhanced list styling with hover effects
    public static void styleList(JList<?> list) {
        list.setBackground(FIELD_BG);
        list.setForeground(FOREGROUND);
        list.setSelectionBackground(ACCENT);
        list.setSelectionForeground(FOREGROUND);
        list.setBorder(COMPONENT_BORDER);
        list.setFont(REGULAR_FONT);

        // Add cell renderer with hover effect
        list.setCellRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (isSelected) {
                    c.setBackground(ACCENT);
                    c.setForeground(FOREGROUND);
                } else {
                    c.setBackground(index % 2 == 0 ? FIELD_BG : COMPONENT_BG);
                    c.setForeground(FOREGROUND);
                }
                setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
                return c;
            }
        });
    }

    // Enhanced table styling with alternating row colors and better headers
    public static void styleTable(JTable table) {
        table.setBackground(FIELD_BG);
        table.setForeground(FOREGROUND);
        table.setSelectionBackground(ACCENT);
        table.setSelectionForeground(FOREGROUND);
        table.setGridColor(new Color(BORDER_COLOR.getRed(), BORDER_COLOR.getGreen(), BORDER_COLOR.getBlue(), 100));
        table.setFont(REGULAR_FONT);
        table.setRowHeight(32); // Increased row height for better readability
        table.setIntercellSpacing(new Dimension(1, 1));
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setFillsViewportHeight(true);

        // Style header
        javax.swing.table.JTableHeader header = table.getTableHeader();
        header.setBackground(CARD_BG);
        header.setForeground(FOREGROUND);
        header.setFont(REGULAR_FONT_BOLD);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, BORDER_COLOR));

        // Add row color renderer
        table.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (isSelected) {
                    c.setBackground(ACCENT);
                    c.setForeground(FOREGROUND);
                } else {
                    c.setBackground(row % 2 == 0 ? FIELD_BG : COMPONENT_BG);
                    c.setForeground(FOREGROUND);
                }
                setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));
                return c;
            }
        });
    }

    // Enhanced button styling with modern look and animations
    // Compatible with Substance look and feel
    public static void styleButton(JButton button) {
        // Set font regardless of look and feel
        button.setFont(REGULAR_FONT);

        // Don't override Substance's styling
        if (isUsingSubstance) {
            return;
        }

        // Apply our custom styling when not using Substance
        button.setBackground(COMPONENT_BG);
        button.setForeground(FOREGROUND);
        button.setFocusPainted(false);
        button.setBorderPainted(true);
        button.setContentAreaFilled(true);

        // Modern subtle border with padding
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(4, 10, 4, 10)
        ));

        // Enhanced hover and press effects
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                if (button.isEnabled()) {
                    button.setBackground(new Color(60, 60, 65));
                    button.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(ACCENT, 1),
                            BorderFactory.createEmptyBorder(4, 10, 4, 10)
                    ));
                }
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                if (button.isEnabled()) {
                    button.setBackground(COMPONENT_BG);
                    button.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(BORDER_COLOR, 1),
                            BorderFactory.createEmptyBorder(4, 10, 4, 10)
                    ));
                }
            }

            public void mousePressed(java.awt.event.MouseEvent evt) {
                if (button.isEnabled()) {
                    button.setBackground(new Color(40, 40, 45));
                }
            }

            public void mouseReleased(java.awt.event.MouseEvent evt) {
                if (button.isEnabled()) {
                    if (button.getModel().isRollover()) {
                        button.setBackground(new Color(60, 60, 65));
                    } else {
                        button.setBackground(COMPONENT_BG);
                    }
                }
            }
        });
    }

    // Style a primary action button
    // Compatible with Substance look and feel
    public static void stylePrimaryButton(JButton button) {
        // Set font regardless of look and feel
        button.setFont(REGULAR_FONT_BOLD);

        // Don't override Substance's styling
        if (isUsingSubstance) {
            button.putClientProperty("substancelaf.buttonShaper.defaultButtonMark", Boolean.TRUE);
            return;
        }

        // Apply our custom styling when not using Substance
        button.setBackground(ACCENT);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(true);
        button.setContentAreaFilled(true);

        // Modern subtle border with padding
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ACCENT_DARKER, 1),
                BorderFactory.createEmptyBorder(4, 10, 4, 10)
        ));

        // Enhanced hover and press effects
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                if (button.isEnabled()) {
                    button.setBackground(ACCENT_LIGHTER);
                    button.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(ACCENT_DARKER, 1),
                            BorderFactory.createEmptyBorder(4, 10, 4, 10)
                    ));
                }
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                if (button.isEnabled()) {
                    button.setBackground(ACCENT);
                    button.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(ACCENT_DARKER, 1),
                            BorderFactory.createEmptyBorder(4, 10, 4, 10)
                    ));
                }
            }

            public void mousePressed(java.awt.event.MouseEvent evt) {
                if (button.isEnabled()) {
                    button.setBackground(ACCENT_DARKER);
                }
            }

            public void mouseReleased(java.awt.event.MouseEvent evt) {
                if (button.isEnabled()) {
                    if (button.getModel().isRollover()) {
                        button.setBackground(ACCENT_LIGHTER);
                    } else {
                        button.setBackground(ACCENT);
                    }
                }
            }
        });
    }

    // Enhanced text field styling with focus effects
    // Compatible with Substance look and feel
    public static void styleTextField(JTextField textField) {
        // Set font regardless of look and feel
        textField.setFont(REGULAR_FONT);

        // Don't override Substance's styling
        if (isUsingSubstance) {
            return;
        }

        // Apply our custom styling when not using Substance
        // Use dark theme colors
        textField.setBackground(COMPONENT_BG);
        textField.setForeground(FOREGROUND);
        textField.setCaretColor(ACCENT);
        textField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(4, 6, 4, 6)
        ));
        textField.setSelectionColor(ACCENT);
        textField.setSelectedTextColor(Color.WHITE);

        // Add focus listener for visual feedback
        textField.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                textField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(ACCENT, 1),
                    BorderFactory.createEmptyBorder(4, 6, 4, 6)
                ));
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                textField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER_COLOR, 1),
                    BorderFactory.createEmptyBorder(4, 6, 4, 6)
                ));
            }
        });
    }

    // Enhanced panel styling with consistent backgrounds
    // Compatible with Substance look and feel
    public static void stylePanel(JPanel panel) {
        if (!isUsingSubstance) {
            panel.setBackground(PANEL_BG);
            panel.setForeground(FOREGROUND);
        }
        panel.setBorder(BorderFactory.createEmptyBorder(5, 8, 5, 8));
    }

    // Style a combo box with modern appearance
    // Compatible with Substance look and feel
    public static void styleComboBox(JComboBox<?> comboBox) {
        if (!isUsingSubstance) {
            comboBox.setBackground(FIELD_BG);
            comboBox.setForeground(FOREGROUND);
            comboBox.setBorder(new RoundedBorder(BORDER_COLOR, FIELD_RADIUS));
        }
        comboBox.setFont(REGULAR_FONT);

        // Set preferred height for consistency (reduced height)
        Dimension size = comboBox.getPreferredSize();
        if (size.height < 28) {
            comboBox.setPreferredSize(new Dimension(size.width, 28));
        }
    }

    // Card panel styling with elevation effect
    // Compatible with Substance look and feel
    public static void styleCardPanel(JPanel panel) {
        if (!isUsingSubstance) {
            panel.setBackground(CARD_BG);
            panel.setForeground(FOREGROUND);
            panel.setBorder(CARD_BORDER);
        } else {
            // Use a simpler border with Substance
            panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)
            ));
        }
    }

    // Tabbed pane styling (updated for a modern look)
    // Compatible with Substance look and feel
    public static void styleTabbedPane(JTabbedPane tabbedPane) {
        // Set font regardless of look and feel
        tabbedPane.setFont(REGULAR_FONT);

        // Only apply custom styling if not using Substance
        if (!isUsingSubstance) {
            tabbedPane.setBackground(PANEL_BG);
            tabbedPane.setForeground(FOREGROUND);
            tabbedPane.setBorder(null);

            // Enhanced tab colors
            UIManager.put("TabbedPane.selected", new Color(40, 40, 45));
            UIManager.put("TabbedPane.background", PANEL_BG);
            UIManager.put("TabbedPane.foreground", FOREGROUND);
            UIManager.put("TabbedPane.focus", ACCENT);
            UIManager.put("TabbedPane.highlight", ACCENT);
            UIManager.put("TabbedPane.light", PANEL_BG);
            UIManager.put("TabbedPane.shadow", BACKGROUND);
            UIManager.put("TabbedPane.darkShadow", BACKGROUND);
            UIManager.put("TabbedPane.selectedForeground", ACCENT_LIGHTER);

            // Modern tab styling with further reduced padding for compact layout
            UIManager.put("TabbedPane.tabInsets", new Insets(4, 10, 4, 10));
            UIManager.put("TabbedPane.contentBorderInsets", new Insets(0, 0, 0, 0));
            UIManager.put("TabbedPane.tabAreaInsets", new Insets(1, 1, 0, 1));
            UIManager.put("TabbedPane.selectedTabPadInsets", new Insets(0, 0, 0, 0));
        }
        UIManager.put("TabbedPane.tabsOverlapBorder", true);
        UIManager.put("TabbedPane.contentOpaque", false);

        // Add custom tab area painter
        tabbedPane.setUI(new ModernTabbedPaneUI());
    }

    // Label styling
    public static void styleLabel(JLabel label) {
        label.setForeground(FOREGROUND);
        label.setFont(REGULAR_FONT);
    }

    // Combo box styling (legacy version - replaced by enhanced version above)
    private static void styleComboBoxLegacy(JComboBox<?> comboBox) {
        comboBox.setBackground(FIELD_BG);
        comboBox.setForeground(FOREGROUND);
        comboBox.setFont(REGULAR_FONT);
        comboBox.setBorder(COMPONENT_BORDER);
    }

    /**
     * Applies styles recursively to all components in a container
     */
    public static void applyStyleRecursively(Container container) {
        for (Component component : container.getComponents()) {
            if (component instanceof JPanel) {
                JPanel panel = (JPanel) component;
                if (!isUsingSubstance) {
                    panel.setBackground(PANEL_BG);
                    panel.setForeground(FOREGROUND);
                }
                applyStyleRecursively(panel);
            } else if (component instanceof JButton) {
                styleButton((JButton) component);
            } else if (component instanceof JTextField) {
                styleTextField((JTextField) component);
            } else if (component instanceof JComboBox) {
                styleComboBox((JComboBox<?>) component);
            } else if (component instanceof JLabel) {
                JLabel label = (JLabel) component;
                label.setForeground(FOREGROUND);
                label.setFont(REGULAR_FONT);
            } else if (component instanceof Container) {
                applyStyleRecursively((Container) component);
            }
        }
    }

    // Spinner styling
    public static void styleSpinner(JSpinner spinner) {
        spinner.setBackground(FIELD_BG);
        spinner.setForeground(FOREGROUND);
        spinner.setFont(REGULAR_FONT);
        spinner.setBorder(COMPONENT_BORDER);
    }

    // Checkbox styling
    public static void styleCheckBox(JCheckBox checkBox) {
        checkBox.setBackground(PANEL_BG);
        checkBox.setForeground(FOREGROUND);
        checkBox.setFont(REGULAR_FONT);
        checkBox.setFocusPainted(false);
    }

    // Scroll pane styling (legacy version)
    private static void styleScrollPaneBasic(JScrollPane scrollPane) {
        scrollPane.setBackground(PANEL_BG);
        scrollPane.setBorder(COMPONENT_BORDER);
        scrollPane.getViewport().setBackground(FIELD_BG);
    }

    // Scroll pane styling with custom scrollbars
    // Compatible with Substance look and feel
    public static void styleScrollPane(JScrollPane scrollPane) {
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        if (!isUsingSubstance) {
            scrollPane.setBackground(PANEL_BG);
            scrollPane.getViewport().setBackground(PANEL_BG);

            // Custom scrollbar UI
            scrollPane.getVerticalScrollBar().setUI(new ModernScrollBarUI());
            scrollPane.getHorizontalScrollBar().setUI(new ModernScrollBarUI());

            // Set scrollbar colors
            scrollPane.getVerticalScrollBar().setBackground(PANEL_BG);
            scrollPane.getHorizontalScrollBar().setBackground(PANEL_BG);
        }
    }

    // Apply styles to components with enhanced detection
    public static void applyStyle(JComponent component) {
        if (component instanceof JButton) {
            styleButton((JButton) component);
        } else if (component instanceof JTextField) {
            styleTextField((JTextField) component);
        } else if (component instanceof JPanel) {
            stylePanel((JPanel) component);
        } else if (component instanceof JTabbedPane) {
            styleTabbedPane((JTabbedPane) component);
        } else if (component instanceof JLabel) {
            styleLabel((JLabel) component);
        } else if (component instanceof JComboBox) {
            styleComboBox((JComboBox<?>) component);
        } else if (component instanceof JSpinner) {
            styleSpinner((JSpinner) component);
        } else if (component instanceof JCheckBox) {
            styleCheckBox((JCheckBox) component);
        } else if (component instanceof JScrollPane) {
            styleScrollPane((JScrollPane) component);
        } else if (component instanceof JList) {
            styleList((JList<?>) component);
        } else if (component instanceof JTable) {
            styleTable((JTable) component);
        }
    }

    // This method was a duplicate of the one above
    // Removed to fix ambiguous method call issue
}