package core.gui;

import javax.swing.*;

/**
 * Interface for components that can be bound to config values
 * @param <T> The type of value this component handles
 */
public interface ConfigComponent<T> {
    /**
     * Gets the Swing component
     */
    JComponent getComponent();
    
    /**
     * Updates the component's value from config
     */
    void updateFromConfig();
    
    /**
     * Saves the component's value to config
     */
    void saveToConfig();
    
    /**
     * Gets the current value from the component
     */
    T getConfigValue();
    
    /**
     * Sets the component's value
     */
    void setConfigValue(T value);
} 