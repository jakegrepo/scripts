package core.gui.components;

import core.gui.style.ModernUITheme;

import javax.swing.*;
import javax.swing.colorchooser.AbstractColorChooserPanel;
import java.awt.*;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 * A button that opens a color picker dialog when clicked.
 */
public class ColorPickerButton extends JButton {
    private PropertyChangeSupport propertyChangeSupport;
    private Color selectedColor;
    private String colorType;
    private JColorChooser colorChooser;
    private JDialog dialog;

    /**
     * Creates a new color picker button
     *
     * @param label The button label
     * @param initialColor The initial color
     * @param colorType The type of color (e.g., "primary", "background")
     */
    public ColorPickerButton(String label, Color initialColor, String colorType) {
        super(label);
        
        // Initialize fields
        this.propertyChangeSupport = new PropertyChangeSupport(this);
        this.selectedColor = initialColor;
        this.colorType = colorType;
        this.colorChooser = new JColorChooser(selectedColor);

        // Configure color chooser
        AbstractColorChooserPanel[] panels = colorChooser.getChooserPanels();
        for (AbstractColorChooserPanel panel : panels) {
            String displayName = panel.getDisplayName();
            if (!displayName.equals("HSV") && !displayName.equals("RGB") && !displayName.equals("HSL")) {
                colorChooser.removeChooserPanel(panel);
            }
        }
        colorChooser.setPreviewPanel(new JPanel());

        // Create color preview panel
        JPanel colorPreview = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(selectedColor);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(Color.DARK_GRAY);
                g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
            }
        };
        colorPreview.setPreferredSize(new Dimension(24, 24));
        colorPreview.setBorder(BorderFactory.createEmptyBorder());

        // Setup button layout
        setLayout(new BorderLayout(5, 0));
        add(new JLabel(label), BorderLayout.CENTER);
        add(colorPreview, BorderLayout.EAST);

        // Add action listener
        addActionListener(e -> showColorChooserDialog());
    }

    /**
     * Sets the selected color
     *
     * @param newColor The new color to set
     */
    public void setSelectedColor(Color newColor) {
        Color oldColor = this.selectedColor;
        this.selectedColor = newColor;
        if (colorChooser != null) {
            colorChooser.setColor(newColor);
        }
        propertyChangeSupport.firePropertyChange("selectedColor", oldColor, newColor);
        repaint();
    }

    @Override
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        if (propertyChangeSupport == null) {
            propertyChangeSupport = new PropertyChangeSupport(this);
        }
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    @Override
    public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener) {
        if (propertyChangeSupport == null) {
            propertyChangeSupport = new PropertyChangeSupport(this);
        }
        propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
    }

    /**
     * Shows the color chooser dialog
     */
    private void showColorChooserDialog() {
        if (dialog == null) {
            Window window = SwingUtilities.getWindowAncestor(this);
            dialog = JColorChooser.createDialog(
                window,
                "Choose " + colorType + " color",
                true,
                colorChooser,
                e -> {
                    setSelectedColor(colorChooser.getColor());
                },
                null
            );
        }
        dialog.setVisible(true);
    }

    /**
     * Gets the currently selected color
     */
    public Color getSelectedColor() {
        return selectedColor;
    }

    /**
     * Gets the color type
     */
    public String getColorType() {
        return colorType;
    }
}




