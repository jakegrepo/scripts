package core.gui.components;

import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.lang.reflect.Method;

/**
 * A modern circular loading indicator
 * Compatible with Substance look and feel
 */
public class LoadingIndicator extends JPanel {
    private static final int DEFAULT_SIZE = 40;
    private static final int DEFAULT_STROKE = 4;

    private final Timer timer;
    private final int size;
    private final int strokeWidth;
    private final Color color;
    private int angle = 0;

    /**
     * Creates a loading indicator with default size and color
     */
    public LoadingIndicator() {
        // Check if we're using Substance
        boolean isUsingSubstance = false;
        try {
            Class<?> substanceClass = Class.forName("org.pushingpixels.substance.api.SubstanceCortex");
            Method getCurrentSkinMethod = substanceClass.getMethod("getCurrentSkin");
            isUsingSubstance = getCurrentSkinMethod.invoke(null) != null;
        } catch (Exception e) {
            // Not using Substance or error occurred
            isUsingSubstance = false;
        }

        // Use appropriate color based on look and feel
        Color indicatorColor = isUsingSubstance ? new Color(100, 150, 255) : StyleManager.ACCENT;
        this.size = DEFAULT_SIZE;
        this.color = indicatorColor;
        this.strokeWidth = size >= 40 ? DEFAULT_STROKE : 2;

        setOpaque(false);
        setPreferredSize(new Dimension(size, size));

        // Create animation timer
        timer = new Timer(50, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                angle = (angle + 10) % 360;
                repaint();
            }
        });
        timer.start();
    }

    /**
     * Creates a loading indicator with custom size and color
     */
    public LoadingIndicator(int size, Color color) {
        this.size = size;
        this.color = color;
        this.strokeWidth = size >= 40 ? DEFAULT_STROKE : 2;

        setOpaque(false);
        setPreferredSize(new Dimension(size, size));

        // Create animation timer
        timer = new Timer(50, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                angle = (angle + 10) % 360;
                repaint();
            }
        });
        timer.start();
    }

    /**
     * Creates a loading indicator with default size and custom color
     */
    public LoadingIndicator(Color color) {
        this(DEFAULT_SIZE, color);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Calculate center and radius
        int centerX = getWidth() / 2;
        int centerY = getHeight() / 2;
        int radius = Math.min(centerX, centerY) - strokeWidth;

        // Create arc shape
        Arc2D.Double arc = new Arc2D.Double(
            centerX - radius,
            centerY - radius,
            radius * 2,
            radius * 2,
            angle,
            270,
            Arc2D.OPEN
        );

        // Draw arc with gradient
        g2.setStroke(new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        // Create gradient from transparent to full color
        Color transparent = new Color(color.getRed(), color.getGreen(), color.getBlue(), 50);
        Color full = new Color(color.getRed(), color.getGreen(), color.getBlue(), 255);

        // Rotate the gradient with the arc
        AffineTransform transform = new AffineTransform();
        transform.rotate(Math.toRadians(angle), centerX, centerY);

        // Create gradient that rotates with the arc
        GradientPaint gradient = new GradientPaint(
            centerX, centerY - radius, transparent,
            centerX, centerY + radius, full
        );

        g2.setPaint(gradient);
        g2.draw(arc);

        g2.dispose();
    }

    /**
     * Starts the animation
     */
    public void start() {
        if (!timer.isRunning()) {
            timer.start();
        }
    }

    /**
     * Stops the animation
     */
    public void stop() {
        if (timer.isRunning()) {
            timer.stop();
        }
    }

    @Override
    public void removeNotify() {
        stop();
        super.removeNotify();
    }
}
