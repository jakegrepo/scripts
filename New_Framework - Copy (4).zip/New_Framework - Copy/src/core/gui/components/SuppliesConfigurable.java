package core.gui.components;

import java.util.List;
import java.util.Map;

public interface SuppliesConfigurable {
    Map<String, Integer> getSupplies();
    void setSupplies(Map<String, Integer> supplies);
    List<String> getFoodNames();
    void setFoodNames(List<String> foodNames);
    int getTargetFoodCount();
    void setTargetFoodCount(int count);
} 