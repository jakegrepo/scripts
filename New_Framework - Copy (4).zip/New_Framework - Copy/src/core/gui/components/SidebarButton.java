package core.gui.components;

import core.gui.style.ModernUITheme;
import core.gui.style.StyleManager;

import javax.swing.*;
import javax.swing.plaf.basic.BasicToggleButtonUI;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SidebarButton extends JToggleButton {
    private static final int BUTTON_HEIGHT = 40;
    private static final int HORIZONTAL_PADDING = 15;
    private static final int ICON_TEXT_GAP = 10;

    public SidebarButton(String text) {
        this(text, null);
    }

    public SidebarButton(String text, Icon icon) {
        super(text, icon);
        setup();
    }

    private void setup() {
        setFont(ModernUITheme.getFontRegular());
        setBorderPainted(false);
        setFocusPainted(false);
        setContentAreaFilled(false);
        setHorizontalAlignment(SwingConstants.LEFT);
        setIconTextGap(ICON_TEXT_GAP);

        // Set size constraints
        setPreferredSize(new Dimension(200, BUTTON_HEIGHT));
        setMaximumSize(new Dimension(Short.MAX_VALUE, BUTTON_HEIGHT));
        setBorder(BorderFactory.createEmptyBorder(5, HORIZONTAL_PADDING, 5, HORIZONTAL_PADDING));

        // Initial colors
        setForeground(ModernUITheme.TEXT_PRIMARY);
        setBackground(ModernUITheme.BACKGROUND_DARKEST);

        // Add hover and selection effects
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (!isSelected()) {
                    setBackground(new Color(
                        ModernUITheme.BACKGROUND_LIGHT.getRed(),
                        ModernUITheme.BACKGROUND_LIGHT.getGreen(),
                        ModernUITheme.BACKGROUND_LIGHT.getBlue(), 80));
                    repaint();
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (!isSelected()) {
                    setBackground(ModernUITheme.BACKGROUND_DARKEST);
                    repaint();
                }
            }
        });

        // Custom painting for modern look
        setUI(new BasicToggleButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                // Clear the entire background first to prevent text overlapping
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

                // Fill the entire background with the sidebar color
                g2.setColor(ModernUITheme.BACKGROUND_DARKEST);
                g2.fillRect(0, 0, c.getWidth(), c.getHeight());

                // Paint background
                if (isSelected()) {
                    // Selected state
                    g2.setColor(new Color(
                            ModernUITheme.ACCENT_PRIMARY.getRed(),
                            ModernUITheme.ACCENT_PRIMARY.getGreen(),
                            ModernUITheme.ACCENT_PRIMARY.getBlue(), 80));
                    g2.fillRect(0, 0, c.getWidth(), c.getHeight());

                    // Draw accent border on the left
                    g2.setColor(ModernUITheme.ACCENT_PRIMARY);
                    g2.fillRect(0, 0, 3, c.getHeight());
                } else if (getModel().isRollover()) {
                    // Hover state
                    g2.setColor(new Color(
                            ModernUITheme.ACCENT_PRIMARY.getRed(),
                            ModernUITheme.ACCENT_PRIMARY.getGreen(),
                            ModernUITheme.ACCENT_PRIMARY.getBlue(), 40));
                    g2.fillRect(0, 0, c.getWidth(), c.getHeight());
                }

                // Paint icon if present
                Icon icon = getIcon();
                if (icon != null) {
                    icon.paintIcon(c, g2, HORIZONTAL_PADDING,
                        (getHeight() - icon.getIconHeight()) / 2);
                }

                // Paint text
                FontMetrics fm = g2.getFontMetrics(getFont());
                if (isSelected()) {
                    g2.setColor(ModernUITheme.TEXT_PRIMARY);
                } else if (getModel().isRollover()) {
                    g2.setColor(ModernUITheme.TEXT_PRIMARY);
                } else {
                    g2.setColor(ModernUITheme.TEXT_SECONDARY);
                }

                int textX = HORIZONTAL_PADDING;
                if (icon != null) {
                    textX += icon.getIconWidth() + ICON_TEXT_GAP;
                }

                int textY = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                g2.drawString(getText(), textX, textY);

                g2.dispose();
            }
        });
    }

    @Override
    public void setSelected(boolean selected) {
        super.setSelected(selected);
        if (selected) {
            setBackground(StyleManager.ACCENT);
            setForeground(Color.WHITE);
        } else {
            setBackground(StyleManager.SIDEBAR_BG);
            setForeground(StyleManager.TEXT_COLOR);
        }
        repaint();
    }
}