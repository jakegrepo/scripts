package core.gui.components;

import core.gui.style.ModernUITheme;

import javax.swing.*;
import java.awt.*;

/**
 * A panel that combines theme, font, and text color selectors for easy styling of the application.
 */
public class StylePanel extends JPanel {
    private final ThemeSelector themeSelector;
    private final FontSelector fontSelector;
    private final ColorPickerPanel colorPickerPanel;

    // Preview components
    private JLabel titlePreview;
    private JLabel regularPreview;
    private JLabel secondaryPreview;
    private JButton buttonPreview;

    /**
     * Creates a new style panel
     */
    public StylePanel() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(
            ModernUITheme.SPACING_MEDIUM,
            ModernUITheme.SPACING_MEDIUM,
            ModernUITheme.SPACING_MEDIUM,
            ModernUITheme.SPACING_MEDIUM
        ));

        // Create title
        JLabel titleLabel = new JLabel("Style Customization");
        titleLabel.setFont(ModernUITheme.FONT_TITLE);
        titleLabel.setForeground(ModernUITheme.ACCENT_PRIMARY);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        add(titleLabel);

        // Add spacing
        add(Box.createVerticalStrut(ModernUITheme.SPACING_MEDIUM));

        // Create theme selector panel
        JPanel themeSelectorPanel = createSectionPanel("Theme");
        themeSelector = new ThemeSelector();
        themeSelector.addActionListener(e -> updatePreview());
        themeSelectorPanel.add(themeSelector);
        add(themeSelectorPanel);

        // Add spacing
        add(Box.createVerticalStrut(ModernUITheme.SPACING_MEDIUM));

        // Create font selector panel
        JPanel fontSelectorPanel = createSectionPanel("Font");
        fontSelector = new FontSelector();
        fontSelector.addPropertyChangeListener("fontChanged", e -> updatePreview());
        fontSelectorPanel.add(fontSelector);
        add(fontSelectorPanel);

        // Add spacing
        add(Box.createVerticalStrut(ModernUITheme.SPACING_MEDIUM));

        // Create color picker panel
        JPanel colorPickerSectionPanel = createSectionPanel("Colors");
        colorPickerPanel = new ColorPickerPanel();
        colorPickerPanel.addPropertyChangeListener("colorChanged", e -> updatePreview());
        colorPickerSectionPanel.add(colorPickerPanel);
        add(colorPickerSectionPanel);

        // Add spacing
        add(Box.createVerticalStrut(ModernUITheme.SPACING_MEDIUM));

        // Add preview panel
        JPanel previewPanel = createSectionPanel("Preview");

        // Create a glass card for the preview
        GlassCard previewCard = new GlassCard("Live Preview");
        previewCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Create preview content
        JPanel previewContent = new JPanel();
        previewContent.setLayout(new BoxLayout(previewContent, BoxLayout.Y_AXIS));
        previewContent.setOpaque(false);

        // Add preview components
        JLabel titlePreview = new JLabel("This is a title");
        titlePreview.setFont(ModernUITheme.FONT_TITLE);
        titlePreview.setForeground(ModernUITheme.TEXT_PRIMARY);
        titlePreview.setAlignmentX(Component.LEFT_ALIGNMENT);
        previewContent.add(titlePreview);

        previewContent.add(Box.createVerticalStrut(ModernUITheme.SPACING_MEDIUM));

        JLabel regularPreview = new JLabel("This is regular text");
        regularPreview.setFont(ModernUITheme.FONT_REGULAR);
        regularPreview.setForeground(ModernUITheme.TEXT_PRIMARY);
        regularPreview.setAlignmentX(Component.LEFT_ALIGNMENT);
        previewContent.add(regularPreview);

        previewContent.add(Box.createVerticalStrut(ModernUITheme.SPACING_SMALL));

        JLabel secondaryPreview = new JLabel("This is secondary text");
        secondaryPreview.setFont(ModernUITheme.FONT_REGULAR);
        secondaryPreview.setForeground(ModernUITheme.TEXT_SECONDARY);
        secondaryPreview.setAlignmentX(Component.LEFT_ALIGNMENT);
        previewContent.add(secondaryPreview);

        previewContent.add(Box.createVerticalStrut(ModernUITheme.SPACING_MEDIUM));

        JButton buttonPreview = new JButton("Button");
        buttonPreview.setAlignmentX(Component.LEFT_ALIGNMENT);
        previewContent.add(buttonPreview);

        // Add the preview content to the card
        previewCard.addContent(previewContent);
        previewPanel.add(previewCard);
        add(previewPanel);

        // Add spacing
        add(Box.createVerticalStrut(ModernUITheme.SPACING_MEDIUM));

        // Add reset button
        JButton resetButton = new JButton("Reset to Default");
        resetButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        resetButton.addActionListener(e -> resetToDefault());
        add(resetButton);

        // Add filler to push everything to the top
        add(Box.createVerticalGlue());

        // Store preview components for later updates
        this.titlePreview = titlePreview;
        this.regularPreview = regularPreview;
        this.secondaryPreview = secondaryPreview;
        this.buttonPreview = buttonPreview;
    }

    /**
     * Creates a section panel with a title
     */
    private JPanel createSectionPanel(String title) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add section title
        JLabel sectionTitle = new JLabel(title);
        sectionTitle.setFont(ModernUITheme.FONT_TITLE);
        sectionTitle.setForeground(ModernUITheme.TEXT_PRIMARY);
        sectionTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(sectionTitle);

        // Add spacing
        panel.add(Box.createVerticalStrut(ModernUITheme.SPACING_SMALL));

        return panel;
    }

    /**
     * Resets all style settings to default
     */
    public void resetToDefault() {
        // Reset theme
        themeSelector.setSelectedTheme("Dark Blue");

        // Reset font
        fontSelector.setSelectedFontFamily("Segoe UI");
        fontSelector.setSelectedFontSize(12);

        // Reset colors
        colorPickerPanel.resetToDefault();
    }

    /**
     * Gets the theme selector
     */
    public ThemeSelector getThemeSelector() {
        return themeSelector;
    }

    /**
     * Gets the font selector
     */
    public FontSelector getFontSelector() {
        return fontSelector;
    }

    /**
     * Gets the color picker panel
     */
    public ColorPickerPanel getColorPickerPanel() {
        return colorPickerPanel;
    }

    /**
     * Updates the preview components with the current theme settings
     */
    private void updatePreview() {
        // Update fonts
        titlePreview.setFont(ModernUITheme.FONT_TITLE);
        regularPreview.setFont(ModernUITheme.FONT_REGULAR);
        secondaryPreview.setFont(ModernUITheme.FONT_REGULAR);
        buttonPreview.setFont(ModernUITheme.FONT_REGULAR);

        // Update colors
        titlePreview.setForeground(ModernUITheme.TEXT_PRIMARY);
        regularPreview.setForeground(ModernUITheme.TEXT_PRIMARY);
        secondaryPreview.setForeground(ModernUITheme.TEXT_SECONDARY);

        // Repaint the preview components
        titlePreview.repaint();
        regularPreview.repaint();
        secondaryPreview.repaint();
        buttonPreview.repaint();
    }
}
