package core.gui.components;

import core.gui.style.ModernUITheme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;

/**
 * A modern checkbox with rounded corners, smooth animation,
 * and a sleek design.
 */
public class ModernCheckBox extends JCheckBox {
    private boolean hovered = false;
    private boolean pressed = false;
    private final Timer animationTimer;
    private float animationProgress = 0.0f;
    private final int animationDuration = ModernUITheme.ANIMATION_DURATION_SHORT;
    private final int animationSteps = 10;
    private final float animationStepSize = 1.0f / animationSteps;
    
    /**
     * Creates a new modern checkbox
     */
    public ModernCheckBox() {
        this("");
    }
    
    /**
     * Creates a new modern checkbox with the specified text
     * 
     * @param text The checkbox text
     */
    public ModernCheckBox(String text) {
        super(text);
        
        // Configure checkbox
        setOpaque(false);
        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setFont(ModernUITheme.FONT_REGULAR);
        setForeground(ModernUITheme.TEXT_PRIMARY);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Create animation timer
        animationTimer = new Timer(animationDuration / animationSteps, e -> {
            if (isSelected()) {
                animationProgress = Math.min(1.0f, animationProgress + animationStepSize);
            } else {
                animationProgress = Math.max(0.0f, animationProgress - animationStepSize);
            }
            
            if ((animationProgress >= 1.0f && isSelected()) || 
                (animationProgress <= 0.0f && !isSelected())) {
                ((Timer) e.getSource()).stop();
            }
            
            repaint();
        });
        
        // Add model listener for animation
        getModel().addChangeListener(e -> {
            animationTimer.start();
        });
        
        // Add mouse listeners for hover and press effects
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hovered = true;
                repaint();
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                hovered = false;
                repaint();
            }
            
            @Override
            public void mousePressed(MouseEvent e) {
                pressed = true;
                repaint();
            }
            
            @Override
            public void mouseReleased(MouseEvent e) {
                pressed = false;
                repaint();
            }
        });
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Calculate checkbox dimensions
        int size = 18;
        int x = 0;
        int y = (getHeight() - size) / 2;
        
        // Draw checkbox background
        Color bgColor = blendColors(
                ModernUITheme.BACKGROUND_LIGHT,
                ModernUITheme.ACCENT_PRIMARY,
                animationProgress
        );
        
        g2.setColor(bgColor);
        g2.fill(new RoundRectangle2D.Double(x, y, size, size, 4, 4));
        
        // Draw checkbox border
        Color borderColor = blendColors(
                new Color(ModernUITheme.BACKGROUND_LIGHT.getRed() + 20, 
                        ModernUITheme.BACKGROUND_LIGHT.getGreen() + 20, 
                        ModernUITheme.BACKGROUND_LIGHT.getBlue() + 20),
                ModernUITheme.ACCENT_PRIMARY,
                animationProgress
        );
        
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(1.5f));
        g2.draw(new RoundRectangle2D.Double(x + 0.75, y + 0.75, size - 1.5, size - 1.5, 4, 4));
        
        // Draw checkmark with animation
        if (animationProgress > 0) {
            g2.setColor(ModernUITheme.TEXT_PRIMARY);
            g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            
            Path2D checkmark = new Path2D.Double();
            checkmark.moveTo(x + 4, y + 9);
            checkmark.lineTo(x + 8, y + 13);
            checkmark.lineTo(x + 14, y + 5);
            
            g2.setComposite(AlphaComposite.SrcOver.derive(animationProgress));
            g2.draw(checkmark);
            g2.setComposite(AlphaComposite.SrcOver);
        }
        
        // Draw hover effect
        if (hovered && !pressed) {
            g2.setColor(new Color(255, 255, 255, 30));
            g2.fill(new RoundRectangle2D.Double(x, y, size, size, 4, 4));
        }
        
        // Draw pressed effect
        if (pressed) {
            g2.setColor(new Color(0, 0, 0, 30));
            g2.fill(new RoundRectangle2D.Double(x, y, size, size, 4, 4));
        }
        
        g2.dispose();
        
        // Draw text
        FontMetrics fm = getFontMetrics(getFont());
        int textX = size + 6;
        int textY = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
        
        g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setFont(getFont());
        g2.setColor(getForeground());
        g2.drawString(getText(), textX, textY);
        g2.dispose();
    }
    
    @Override
    public Dimension getPreferredSize() {
        Dimension size = super.getPreferredSize();
        return new Dimension(size.width, Math.max(size.height, 24));
    }
    
    /**
     * Blends two colors based on the specified ratio
     */
    private Color blendColors(Color c1, Color c2, float ratio) {
        int r = (int) (c1.getRed() + (c2.getRed() - c1.getRed()) * ratio);
        int g = (int) (c1.getGreen() + (c2.getGreen() - c1.getGreen()) * ratio);
        int b = (int) (c1.getBlue() + (c2.getBlue() - c1.getBlue()) * ratio);
        
        return new Color(r, g, b);
    }
}
