package core.gui.components;

import core.gui.style.ModernUITheme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

/**
 * A modern toggle switch component with smooth animation and sleek design.
 * Provides a more visually appealing alternative to checkboxes.
 */
public class ModernToggleSwitch extends JComponent {
    private boolean selected = false;
    private boolean hovered = false;
    private boolean pressed = false;

    private final Timer animationTimer;
    private float animationProgress = 0.0f;
    private final int animationDuration = ModernUITheme.ANIMATION_DURATION_SHORT;
    private final int animationSteps = 10;
    private final float animationStepSize = 1.0f / animationSteps;

    private final Color trackColor = new Color(80, 80, 90);
    private final Color trackSelectedColor = ModernUITheme.ACCENT_PRIMARY;
    private final Color thumbColor = new Color(240, 240, 245);
    private final Color thumbShadowColor = new Color(0, 0, 0, 30);

    private final int trackHeight = 14;
    private final int thumbSize = 20;
    private final int thumbMargin = 2;

    /**
     * Creates a new toggle switch
     */
    public ModernToggleSwitch() {
        setPreferredSize(new Dimension(32, 20));
        setMinimumSize(new Dimension(32, 20));
        setMaximumSize(new Dimension(32, 20));
        setOpaque(false);
        setFocusable(true);

        // Create animation timer
        animationTimer = new Timer(animationDuration / animationSteps, e -> {
            if (selected) {
                animationProgress = Math.min(1.0f, animationProgress + animationStepSize);
            } else {
                animationProgress = Math.max(0.0f, animationProgress - animationStepSize);
            }

            if ((animationProgress >= 1.0f && selected) ||
                (animationProgress <= 0.0f && !selected)) {
                ((Timer) e.getSource()).stop();
            }

            repaint();
        });

        // Add mouse listeners for interaction
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                setSelected(!selected);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                pressed = true;
                repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                pressed = false;
                repaint();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                hovered = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hovered = false;
                repaint();
            }
        });
    }

    /**
     * Sets the selected state of the toggle switch
     *
     * @param selected The selected state
     */
    public void setSelected(boolean selected) {
        if (this.selected != selected) {
            this.selected = selected;
            animationTimer.start();
            firePropertyChange("selected", !selected, selected);
        }
    }

    /**
     * Gets the selected state of the toggle switch
     *
     * @return The selected state
     */
    public boolean isSelected() {
        return selected;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        // Calculate track bounds
        int trackY = (height - trackHeight) / 2;
        int trackWidth = width - thumbMargin * 2;

        // Calculate thumb position based on animation progress
        int thumbX = thumbMargin + (int)((width - thumbSize - thumbMargin * 2) * animationProgress);
        int thumbY = (height - thumbSize) / 2;

        // Draw track with gradient
        Color trackBaseColor = blendColors(trackColor, trackSelectedColor, animationProgress);
        GradientPaint trackGradient = new GradientPaint(
                0, trackY, trackBaseColor,
                0, trackY + trackHeight,
                new Color(
                    Math.max(0, trackBaseColor.getRed() - 15),
                    Math.max(0, trackBaseColor.getGreen() - 15),
                    Math.max(0, trackBaseColor.getBlue() - 15)
                )
        );

        g2.setPaint(trackGradient);
        g2.fill(new RoundRectangle2D.Double(
                thumbMargin, trackY, trackWidth, trackHeight, trackHeight, trackHeight));

        // Draw thumb shadow
        g2.setColor(thumbShadowColor);
        g2.fill(new RoundRectangle2D.Double(
                thumbX + 1, thumbY + 1, thumbSize, thumbSize, thumbSize, thumbSize));

        // Draw thumb with gradient
        GradientPaint thumbGradient = new GradientPaint(
                0, thumbY, thumbColor,
                0, thumbY + thumbSize,
                new Color(
                    Math.max(0, thumbColor.getRed() - 20),
                    Math.max(0, thumbColor.getGreen() - 20),
                    Math.max(0, thumbColor.getBlue() - 20)
                )
        );

        g2.setPaint(thumbGradient);
        g2.fill(new RoundRectangle2D.Double(
                thumbX, thumbY, thumbSize, thumbSize, thumbSize, thumbSize));

        // Draw hover effect
        if (hovered && !pressed) {
            g2.setColor(new Color(0, 0, 0, 20));
            g2.fill(new RoundRectangle2D.Double(
                    thumbX, thumbY, thumbSize, thumbSize, thumbSize, thumbSize));
        }

        // Draw pressed effect
        if (pressed) {
            g2.setColor(new Color(0, 0, 0, 30));
            g2.fill(new RoundRectangle2D.Double(
                    thumbX, thumbY, thumbSize, thumbSize, thumbSize, thumbSize));
        }

        g2.dispose();
    }

    /**
     * Blends two colors based on the specified ratio
     */
    private Color blendColors(Color c1, Color c2, float ratio) {
        int r = (int) (c1.getRed() + (c2.getRed() - c1.getRed()) * ratio);
        int g = (int) (c1.getGreen() + (c2.getGreen() - c1.getGreen()) * ratio);
        int b = (int) (c1.getBlue() + (c2.getBlue() - c1.getBlue()) * ratio);

        return new Color(r, g, b);
    }
}
