package core.gui.components;

import core.gui.style.ModernUITheme;
import core.gui.style.ThemeManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

/**
 * A component that allows users to select and apply different fonts.
 */
public class FontSelector extends JPanel {
    private final java.beans.PropertyChangeSupport propertyChangeSupport = new java.beans.PropertyChangeSupport(this);
    private final JComboBox<String> fontFamilyComboBox;
    private final JComboBox<Integer> fontSizeComboBox;

    /**
     * Creates a new font selector
     */
    public FontSelector() {
        setLayout(new FlowLayout(FlowLayout.LEFT));
        setOpaque(false);

        // Create font label
        JLabel fontLabel = new JLabel("Font:");
        fontLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        fontLabel.setFont(ModernUITheme.FONT_REGULAR);
        add(fontLabel);

        // Get available font families
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        String[] fontFamilies = ge.getAvailableFontFamilyNames();

        // Filter to common fonts for better usability
        java.util.List<String> commonFontsList = new java.util.ArrayList<>();

        // Add system fonts first
        commonFontsList.add("System Default");

        // Add common sans-serif fonts
        commonFontsList.add("Arial");
        commonFontsList.add("Calibri");
        commonFontsList.add("Segoe UI");
        commonFontsList.add("Tahoma");
        commonFontsList.add("Verdana");
        commonFontsList.add("Helvetica");
        commonFontsList.add("Trebuchet MS");
        commonFontsList.add("Century Gothic");

        // Add common serif fonts
        commonFontsList.add("Times New Roman");
        commonFontsList.add("Georgia");
        commonFontsList.add("Garamond");
        commonFontsList.add("Book Antiqua");
        commonFontsList.add("Palatino Linotype");

        // Add common monospace fonts
        commonFontsList.add("Consolas");
        commonFontsList.add("Courier New");
        commonFontsList.add("Lucida Console");

        // Add common decorative fonts
        commonFontsList.add("Comic Sans MS");
        commonFontsList.add("Impact");
        commonFontsList.add("Brush Script MT");

        // Filter to only include fonts that are actually available on the system
        java.util.List<String> availableFonts = new java.util.ArrayList<>();
        java.util.Set<String> availableFontSet = new java.util.HashSet<>(java.util.Arrays.asList(fontFamilies));

        for (String font : commonFontsList) {
            if (font.equals("System Default") || availableFontSet.contains(font)) {
                availableFonts.add(font);
            }
        }

        String[] commonFonts = availableFonts.toArray(new String[0]);

        // Create font family combo box
        fontFamilyComboBox = new JComboBox<>(commonFonts);
        fontFamilyComboBox.setSelectedItem("Segoe UI"); // Default font
        fontFamilyComboBox.setPreferredSize(new Dimension(150, 28));
        fontFamilyComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateFonts();
            }
        });
        add(fontFamilyComboBox);

        // Add spacing
        add(Box.createHorizontalStrut(10));

        // Create size label
        JLabel sizeLabel = new JLabel("Size:");
        sizeLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        sizeLabel.setFont(ModernUITheme.FONT_REGULAR);
        add(sizeLabel);

        // Create font size combo box
        Integer[] fontSizes = {10, 11, 12, 13, 14, 16, 18, 20, 22, 24};
        fontSizeComboBox = new JComboBox<>(fontSizes);
        fontSizeComboBox.setSelectedItem(12); // Default size
        fontSizeComboBox.setPreferredSize(new Dimension(60, 28));
        fontSizeComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateFonts();
            }
        });
        add(fontSizeComboBox);
    }

    /**
     * Updates all fonts in the application
     */
    private void updateFonts() {
        String fontFamily = (String) fontFamilyComboBox.getSelectedItem();
        Integer fontSize = (Integer) fontSizeComboBox.getSelectedItem();

        if (fontFamily != null && fontSize != null) {
            // Create new fonts
            Font regularFont;
            Font boldFont;
            Font titleFont;
            Font smallFont;

            if ("System Default".equals(fontFamily)) {
                // Use the system default font
                Font defaultFont = UIManager.getDefaults().getFont("Label.font");
                String defaultFontFamily = defaultFont != null ? defaultFont.getFamily() : "Dialog";

                regularFont = new Font(defaultFontFamily, Font.PLAIN, fontSize);
                boldFont = new Font(defaultFontFamily, Font.BOLD, fontSize);
                titleFont = new Font(defaultFontFamily, Font.BOLD, fontSize + 2);
                smallFont = new Font(defaultFontFamily, Font.PLAIN, fontSize - 1);
            } else {
                regularFont = new Font(fontFamily, Font.PLAIN, fontSize);
                boldFont = new Font(fontFamily, Font.BOLD, fontSize);
                titleFont = new Font(fontFamily, Font.BOLD, fontSize + 2);
                smallFont = new Font(fontFamily, Font.PLAIN, fontSize - 1);
            }

            // Update fonts in ThemeManager
            ThemeManager.getInstance().updateFonts(regularFont, boldFont, titleFont, smallFont);

            // Force UI update by applying the theme
            SwingUtilities.invokeLater(() -> {
                // Get the window containing this component
                Window window = SwingUtilities.getWindowAncestor(FontSelector.this);
                if (window != null) {
                    // Apply the current theme to this window only
                    ModernUITheme.apply(window);
                } else {
                    // Just update the theme in the ThemeManager if window not found
                    ModernUITheme.apply();
                }

                // Fire property change event
                propertyChangeSupport.firePropertyChange("fontChanged", null, regularFont);

                // Get the window and repaint it
                Window ancestorWindow = SwingUtilities.getWindowAncestor(FontSelector.this);
                if (ancestorWindow != null) {
                    ancestorWindow.repaint();
                }
            });
        }
    }

    /**
     * Gets the currently selected font family
     */
    public String getSelectedFontFamily() {
        return (String) fontFamilyComboBox.getSelectedItem();
    }

    /**
     * Gets the currently selected font size
     */
    public int getSelectedFontSize() {
        return (Integer) fontSizeComboBox.getSelectedItem();
    }

    /**
     * Sets the selected font family
     */
    public void setSelectedFontFamily(String fontFamily) {
        fontFamilyComboBox.setSelectedItem(fontFamily);
    }

    /**
     * Sets the selected font size
     */
    public void setSelectedFontSize(int fontSize) {
        fontSizeComboBox.setSelectedItem(fontSize);
    }

    /**
     * Adds a property change listener
     */
    public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    /**
     * Adds a property change listener for a specific property
     */
    public void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
    }

    /**
     * Removes a property change listener
     */
    public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }

    /**
     * Removes a property change listener for a specific property
     */
    public void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(propertyName, listener);
    }
}
