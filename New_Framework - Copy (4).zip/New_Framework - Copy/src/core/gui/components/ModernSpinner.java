package core.gui.components;

import core.gui.style.ModernUITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicSpinnerUI;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;

/**
 * A modern spinner with rounded corners, custom arrow buttons,
 * and animated focus effect.
 */
public class ModernSpinner extends JSpinner {
    private boolean focused = false;
    private Timer animationTimer; // Removed final to allow initialization in initialize()
    private float animationProgress = 0.0f;
    private final int animationDuration = ModernUITheme.ANIMATION_DURATION_SHORT;
    private final int animationSteps = 10;
    private final float animationStepSize = 1.0f / animationSteps;

    /**
     * Creates a new modern spinner
     */
    public ModernSpinner() {
        super();
        initialize();
    }

    /**
     * Creates a new modern spinner with the specified model
     *
     * @param model The spinner model
     */
    public ModernSpinner(SpinnerModel model) {
        super(model);
        initialize();
    }

    /**
     * Initializes the spinner
     */
    private void initialize() {
        // Configure spinner
        setOpaque(false);
        setBorder(new EmptyBorder(ModernUITheme.SPACING_SMALL,
                                ModernUITheme.SPACING_MEDIUM,
                                ModernUITheme.SPACING_SMALL,
                                ModernUITheme.SPACING_MEDIUM));
        setFont(ModernUITheme.FONT_REGULAR);

        // Set custom UI
        setUI(new ModernSpinnerUI());

        // Create animation timer
        animationTimer = new Timer(animationDuration / animationSteps, e -> {
            if (focused) {
                animationProgress = Math.min(1.0f, animationProgress + animationStepSize);
            } else {
                animationProgress = Math.max(0.0f, animationProgress - animationStepSize);
            }

            if ((animationProgress >= 1.0f && focused) ||
                (animationProgress <= 0.0f && !focused)) {
                ((Timer) e.getSource()).stop();
            }

            repaint();
        });

        // Add focus listener for animation
        addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                focused = true;
                animationTimer.start();
            }

            @Override
            public void focusLost(FocusEvent e) {
                focused = false;
                animationTimer.start();
            }
        });
    }

    /**
     * Custom UI for the modern spinner
     */
    private class ModernSpinnerUI extends BasicSpinnerUI {
        @Override
        protected Component createNextButton() {
            return new ArrowButton(SwingConstants.NORTH);
        }

        @Override
        protected Component createPreviousButton() {
            return new ArrowButton(SwingConstants.SOUTH);
        }

        @Override
        public void installUI(JComponent c) {
            super.installUI(c);

            // Style the editor
            JComponent editor = spinner.getEditor();
            if (editor instanceof JSpinner.DefaultEditor) {
                JSpinner.DefaultEditor defaultEditor = (JSpinner.DefaultEditor) editor;
                defaultEditor.getTextField().setForeground(ModernUITheme.TEXT_PRIMARY);
                defaultEditor.getTextField().setBackground(ModernUITheme.BACKGROUND_LIGHT);
                defaultEditor.getTextField().setBorder(null);
                defaultEditor.getTextField().setOpaque(false);
            }
        }

        @Override
        public void paint(Graphics g, JComponent c) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = c.getWidth();
            int height = c.getHeight();

            // Draw background
            g2.setColor(ModernUITheme.BACKGROUND_LIGHT);
            g2.fill(new RoundRectangle2D.Double(0, 0, width, height,
                    ModernUITheme.FIELD_RADIUS, ModernUITheme.FIELD_RADIUS));

            // Draw border with animation
            Color borderColor = blendColors(
                    new Color(ModernUITheme.BACKGROUND_LIGHT.getRed() + 20,
                            ModernUITheme.BACKGROUND_LIGHT.getGreen() + 20,
                            ModernUITheme.BACKGROUND_LIGHT.getBlue() + 20),
                    ModernUITheme.ACCENT_PRIMARY,
                    animationProgress
            );

            g2.setColor(borderColor);
            g2.setStroke(new BasicStroke(1.5f));
            g2.draw(new RoundRectangle2D.Double(0.75, 0.75, width - 1.5, height - 1.5,
                    ModernUITheme.FIELD_RADIUS, ModernUITheme.FIELD_RADIUS));

            g2.dispose();

            super.paint(g, c);
        }

        /**
         * Custom arrow button for the spinner
         */
        private class ArrowButton extends JButton {
            private final int direction;

            public ArrowButton(int direction) {
                this.direction = direction;
                setOpaque(false);
                setContentAreaFilled(false);
                setBorderPainted(false);
                setFocusPainted(false);
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(16, 12);
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int width = getWidth();
                int height = getHeight();

                // Draw arrow
                int arrowSize = 6;
                int x = (width - arrowSize) / 2;
                int y = (height - arrowSize / 2) / 2;

                Path2D arrow = new Path2D.Double();
                if (direction == SwingConstants.NORTH) {
                    arrow.moveTo(x, y + arrowSize / 2);
                    arrow.lineTo(x + arrowSize, y + arrowSize / 2);
                    arrow.lineTo(x + arrowSize / 2, y);
                } else {
                    arrow.moveTo(x, y);
                    arrow.lineTo(x + arrowSize, y);
                    arrow.lineTo(x + arrowSize / 2, y + arrowSize / 2);
                }
                arrow.closePath();

                g2.setColor(isEnabled() ? ModernUITheme.TEXT_SECONDARY : ModernUITheme.TEXT_DISABLED);
                g2.fill(arrow);

                g2.dispose();
            }
        }
    }

    /**
     * Blends two colors based on the specified ratio
     */
    private Color blendColors(Color c1, Color c2, float ratio) {
        int r = (int) (c1.getRed() + (c2.getRed() - c1.getRed()) * ratio);
        int g = (int) (c1.getGreen() + (c2.getGreen() - c1.getGreen()) * ratio);
        int b = (int) (c1.getBlue() + (c2.getBlue() - c1.getBlue()) * ratio);

        return new Color(r, g, b);
    }
}
