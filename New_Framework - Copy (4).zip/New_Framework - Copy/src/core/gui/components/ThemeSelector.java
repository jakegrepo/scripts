package core.gui.components;

import core.gui.style.ModernUITheme;
import core.gui.style.ThemeManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * A component that allows users to select and apply different themes.
 */
public class ThemeSelector extends JPanel implements ActionListener {
    private final JComboBox<String> themeComboBox;
    private final java.util.List<ActionListener> actionListeners = new java.util.ArrayList<>();

    /**
     * Creates a new theme selector
     */
    public ThemeSelector() {
        setLayout(new FlowLayout(FlowLayout.LEFT));
        setOpaque(false);

        // Create theme label
        JLabel themeLabel = new JLabel("Theme:");
        themeLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        themeLabel.setFont(ModernUITheme.FONT_REGULAR);
        add(themeLabel);

        // Create theme combo box
        themeComboBox = new JComboBox<>(ThemeManager.getInstance().getAvailableThemeNames());
        themeComboBox.setSelectedItem(ThemeManager.getInstance().getCurrentTheme().getName());
        themeComboBox.setPreferredSize(new Dimension(150, 28));
        themeComboBox.addActionListener(this);
        add(themeComboBox);
    }

    /**
     * Gets the currently selected theme
     */
    public String getSelectedTheme() {
        return (String) themeComboBox.getSelectedItem();
    }

    /**
     * Sets the selected theme
     */
    public void setSelectedTheme(String themeName) {
        themeComboBox.setSelectedItem(themeName);
    }

    /**
     * Adds an action listener to this component
     */
    public void addActionListener(ActionListener listener) {
        actionListeners.add(listener);
    }

    /**
     * Removes an action listener from this component
     */
    public void removeActionListener(ActionListener listener) {
        actionListeners.remove(listener);
    }

    /**
     * Notifies all listeners that an action occurred
     */
    protected void fireActionPerformed(ActionEvent e) {
        for (ActionListener listener : actionListeners) {
            listener.actionPerformed(e);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == themeComboBox) {
            String selectedTheme = (String) themeComboBox.getSelectedItem();
            if (selectedTheme != null) {
                // Get the window containing this component
                Window window = SwingUtilities.getWindowAncestor(ThemeSelector.this);
                if (window != null) {
                    // Apply theme to this window only
                    ModernUITheme.apply(selectedTheme, window);
                } else {
                    // Just update the theme in the ThemeManager if window not found
                    ModernUITheme.apply(selectedTheme);
                }

                // Fire action event to notify listeners
                fireActionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "themeChanged"));

                // Force repaint of all components
                SwingUtilities.invokeLater(() -> {
                    Window ancestorWindow = SwingUtilities.getWindowAncestor(ThemeSelector.this);
                    if (ancestorWindow != null) {
                        ancestorWindow.repaint();
                    }
                });
            }
        }
    }
}
