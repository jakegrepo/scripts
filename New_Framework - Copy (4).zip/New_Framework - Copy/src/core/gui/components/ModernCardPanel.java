package core.gui.components;

import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.lang.reflect.Method;

/**
 * A modern card panel with elevation and rounded corners
 * Compatible with Substance look and feel
 */
public class ModernCardPanel extends JPanel {
    private String title;
    private JLabel titleLabel;
    private JPanel contentPanel;

    /**
     * Creates a card panel with a title and content
     */
    public ModernCardPanel(String title) {
        this.title = title;
        initializePanel();
    }

    /**
     * Creates a card panel with a title and content
     */
    public ModernCardPanel(String title, JComponent content) {
        this.title = title;
        initializePanel();
        setContent(content);
    }

    private void initializePanel() {
        setLayout(new BorderLayout(0, 0));
        setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        // Check if we're using Substance
        boolean isUsingSubstance = false;
        try {
            Class<?> substanceClass = Class.forName("org.pushingpixels.substance.api.SubstanceCortex");
            Method getCurrentSkinMethod = substanceClass.getMethod("getCurrentSkin");
            isUsingSubstance = getCurrentSkinMethod.invoke(null) != null;
        } catch (Exception e) {
            // Not using Substance or error occurred
            isUsingSubstance = false;
        }

        // Set background color based on look and feel
        if (!isUsingSubstance) {
            setBackground(StyleManager.PANEL_BG);
        }

        // Create header with title
        JPanel headerPanel = new JPanel(new BorderLayout());
        if (!isUsingSubstance) {
            headerPanel.setBackground(StyleManager.CARD_BG);
        }
        headerPanel.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));

        titleLabel = new JLabel(title);
        titleLabel.setFont(StyleManager.HEADER_FONT_SMALL);
        if (!isUsingSubstance) {
            titleLabel.setForeground(StyleManager.FOREGROUND);
        }
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Create content panel
        contentPanel = new JPanel(new BorderLayout());
        if (!isUsingSubstance) {
            contentPanel.setBackground(StyleManager.CARD_BG);
        }
        contentPanel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        // Create main card panel with shadow border
        JPanel cardPanel = new JPanel(new BorderLayout(0, 0));
        if (!isUsingSubstance) {
            cardPanel.setBackground(StyleManager.CARD_BG);
            cardPanel.setBorder(StyleManager.CARD_BORDER);
        } else {
            // Use a simpler border with Substance
            cardPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 100, 100), 1),
                BorderFactory.createEmptyBorder(1, 1, 1, 1)
            ));
        }

        // Add components to card
        cardPanel.add(headerPanel, BorderLayout.NORTH);
        cardPanel.add(contentPanel, BorderLayout.CENTER);

        // Add card to main panel with margin
        add(cardPanel, BorderLayout.CENTER);
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    }

    /**
     * Sets the content of the card
     */
    public void setContent(JComponent content) {
        contentPanel.removeAll();
        contentPanel.add(content, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    /**
     * Sets the title of the card
     */
    public void setTitle(String title) {
        this.title = title;
        titleLabel.setText(title);
    }

    /**
     * Adds a component to the right side of the header
     */
    public void addHeaderComponent(JComponent component) {
        Container headerPanel = titleLabel.getParent();
        headerPanel.add(component, BorderLayout.EAST);
    }

    /**
     * Gets the title of this card panel
     */
    public String getTitle() {
        return title;
    }

    /**
     * Gets the content panel of this card
     */
    public JPanel getContentPanel() {
        return contentPanel;
    }
}
