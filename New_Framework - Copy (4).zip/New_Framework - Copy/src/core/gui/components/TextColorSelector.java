package core.gui.components;

import core.gui.style.ModernUITheme;
import core.gui.style.ThemeManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

/**
 * A component that allows users to select and apply different text colors.
 */
public class TextColorSelector extends JPanel {
    private final java.beans.PropertyChangeSupport propertyChangeSupport = new java.beans.PropertyChangeSupport(this);
    private final JComboBox<String> primaryColorComboBox;
    private final JComboBox<String> secondaryColorComboBox;
    private final Map<String, Color> colorMap;

    /**
     * Creates a new text color selector
     */
    public TextColorSelector() {
        setLayout(new FlowLayout(FlowLayout.LEFT));
        setOpaque(false);

        // Initialize color map
        colorMap = new HashMap<>();
        colorMap.put("White", new Color(240, 240, 245));
        colorMap.put("Light Gray", new Color(200, 200, 210));
        colorMap.put("Gray", new Color(150, 150, 160));
        colorMap.put("Dark Gray", new Color(100, 100, 110));
        colorMap.put("Black", new Color(20, 20, 25));
        colorMap.put("Blue", new Color(86, 124, 242));
        colorMap.put("Purple", new Color(138, 43, 226));
        colorMap.put("Green", new Color(46, 204, 113));
        colorMap.put("Yellow", new Color(241, 196, 15));
        colorMap.put("Red", new Color(231, 76, 60));
        colorMap.put("Orange", new Color(230, 126, 34));
        colorMap.put("Cyan", new Color(26, 188, 156));

        // Create primary text color label
        JLabel primaryLabel = new JLabel("Primary Text:");
        primaryLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        primaryLabel.setFont(ModernUITheme.FONT_REGULAR);
        add(primaryLabel);

        // Create primary text color combo box
        primaryColorComboBox = new JComboBox<>(colorMap.keySet().toArray(new String[0]));
        primaryColorComboBox.setSelectedItem("White"); // Default color
        primaryColorComboBox.setPreferredSize(new Dimension(120, 28));
        primaryColorComboBox.setRenderer(new ColorListRenderer());
        primaryColorComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateTextColors();
            }
        });
        add(primaryColorComboBox);

        // Add spacing
        add(Box.createHorizontalStrut(10));

        // Create secondary text color label
        JLabel secondaryLabel = new JLabel("Secondary Text:");
        secondaryLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        secondaryLabel.setFont(ModernUITheme.FONT_REGULAR);
        add(secondaryLabel);

        // Create secondary text color combo box
        secondaryColorComboBox = new JComboBox<>(colorMap.keySet().toArray(new String[0]));
        secondaryColorComboBox.setSelectedItem("Light Gray"); // Default color
        secondaryColorComboBox.setPreferredSize(new Dimension(120, 28));
        secondaryColorComboBox.setRenderer(new ColorListRenderer());
        secondaryColorComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateTextColors();
            }
        });
        add(secondaryColorComboBox);
    }

    /**
     * Updates all text colors in the application
     */
    private void updateTextColors() {
        String primaryColorName = (String) primaryColorComboBox.getSelectedItem();
        String secondaryColorName = (String) secondaryColorComboBox.getSelectedItem();

        if (primaryColorName != null && secondaryColorName != null) {
            Color primaryColor = colorMap.get(primaryColorName);
            Color secondaryColor = colorMap.get(secondaryColorName);
            Color disabledColor = new Color(
                (primaryColor.getRed() + secondaryColor.getRed()) / 4,
                (primaryColor.getGreen() + secondaryColor.getGreen()) / 4,
                (primaryColor.getBlue() + secondaryColor.getBlue()) / 4
            );

            // Update text colors in ThemeManager
            ThemeManager.getInstance().updateTextColors(primaryColor, secondaryColor, disabledColor);

            // Force UI update by applying the theme
            SwingUtilities.invokeLater(() -> {
                // Get the window containing this component
                Window window = SwingUtilities.getWindowAncestor(TextColorSelector.this);
                if (window != null) {
                    // Apply the current theme to this window only
                    ModernUITheme.apply(window);
                } else {
                    // Just update the theme in the ThemeManager if window not found
                    ModernUITheme.apply();
                }

                // Fire property change event
                propertyChangeSupport.firePropertyChange("colorChanged", null, primaryColor);

                // Get the window and repaint it
                Window ancestorWindow = SwingUtilities.getWindowAncestor(TextColorSelector.this);
                if (ancestorWindow != null) {
                    ancestorWindow.repaint();
                }
            });
        }
    }

    /**
     * Gets the currently selected primary text color
     */
    public Color getSelectedPrimaryColor() {
        String colorName = (String) primaryColorComboBox.getSelectedItem();
        return colorName != null ? colorMap.get(colorName) : null;
    }

    /**
     * Gets the currently selected secondary text color
     */
    public Color getSelectedSecondaryColor() {
        String colorName = (String) secondaryColorComboBox.getSelectedItem();
        return colorName != null ? colorMap.get(colorName) : null;
    }

    /**
     * Sets the selected primary text color
     */
    public void setSelectedPrimaryColor(String colorName) {
        if (colorMap.containsKey(colorName)) {
            primaryColorComboBox.setSelectedItem(colorName);
        }
    }

    /**
     * Sets the selected secondary text color
     */
    public void setSelectedSecondaryColor(String colorName) {
        if (colorMap.containsKey(colorName)) {
            secondaryColorComboBox.setSelectedItem(colorName);
        }
    }

    /**
     * Adds a property change listener
     */
    public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    /**
     * Adds a property change listener for a specific property
     */
    public void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
    }

    /**
     * Removes a property change listener
     */
    public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }

    /**
     * Removes a property change listener for a specific property
     */
    public void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(propertyName, listener);
    }

    /**
     * Custom renderer for color combo boxes
     */
    private class ColorListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

            if (value instanceof String) {
                String colorName = (String) value;
                Color color = colorMap.get(colorName);

                if (color != null) {
                    // Create a color swatch
                    label.setIcon(new ColorIcon(color, 16, 16));
                    label.setText(colorName);

                    // Set text color based on selection
                    if (isSelected) {
                        label.setForeground(ModernUITheme.TEXT_PRIMARY);
                    } else {
                        // Use a color that contrasts with the background
                        label.setForeground(ModernUITheme.TEXT_PRIMARY);
                    }
                }
            }

            return label;
        }
    }

    /**
     * Icon that displays a color swatch
     */
    private static class ColorIcon implements Icon {
        private final Color color;
        private final int width;
        private final int height;

        public ColorIcon(Color color, int width, int height) {
            this.color = color;
            this.width = width;
            this.height = height;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Draw color swatch
            g2d.setColor(color);
            g2d.fillRoundRect(x, y, width, height, 4, 4);

            // Draw border
            g2d.setColor(new Color(0, 0, 0, 80));
            g2d.drawRoundRect(x, y, width - 1, height - 1, 4, 4);

            g2d.dispose();
        }

        @Override
        public int getIconWidth() {
            return width;
        }

        @Override
        public int getIconHeight() {
            return height;
        }
    }
}
