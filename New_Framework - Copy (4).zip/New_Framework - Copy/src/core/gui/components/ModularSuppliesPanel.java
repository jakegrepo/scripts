package core.gui.components;

import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModularSuppliesPanel extends JPanel {
    private final Map<String, ModularSupplyField> supplyFields = new HashMap<>();
    private final JComboBox<String> foodTypeComboBox;
    private final JSpinner foodQuantitySpinner;
    private final SuppliesConfigurable config;
    private boolean isLoading = false;
    private static final Map<String, String> POTION_MAPPINGS = new HashMap<>();
    private static final String[] FOOD_OPTIONS = {
        "Cooked karambwan",
        "Monkfish",
        "Shark",
        "Lobster",
        "Salmon",
        "Potato with cheese"
    };
    
    static {
        POTION_MAPPINGS.put("Super Attack", "Super attack(4)");
        POTION_MAPPINGS.put("Super Strength", "Super strength(4)");
        POTION_MAPPINGS.put("Super Defence", "Super defence(4)");
        POTION_MAPPINGS.put("Super Combat", "Super combat potion(4)");
        POTION_MAPPINGS.put("Ranging", "Ranging potion(4)");
        POTION_MAPPINGS.put("Prayer", "Prayer potion(4)");
        POTION_MAPPINGS.put("Super Restore", "Super restore(4)");
        POTION_MAPPINGS.put("Stamina", "Stamina potion(4)");
    }

    public ModularSuppliesPanel(SuppliesConfigurable config) {
        super();
        this.config = config;
        this.foodTypeComboBox = new JComboBox<>(FOOD_OPTIONS);
        this.foodQuantitySpinner = new JSpinner(new SpinnerNumberModel(12, 0, 28, 1));
        initializeComponents();
    }

    private void initializeComponents() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(0, 30, 25, 30));
        StyleManager.applyStyle(this);

        // Main container with vertical layout
        JPanel mainContainer = new JPanel();
        mainContainer.setLayout(new BoxLayout(mainContainer, BoxLayout.Y_AXIS));
        mainContainer.setOpaque(false);

        // Potions section
        JPanel potionsSection = new JPanel(new GridBagLayout());
        potionsSection.setOpaque(false);
        GridBagConstraints potionsGbc = new GridBagConstraints();
        potionsGbc.fill = GridBagConstraints.HORIZONTAL;
        potionsGbc.weightx = 1.0;
        potionsGbc.gridwidth = GridBagConstraints.REMAINDER;

        // Create two columns panel
        JPanel columnsPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        columnsPanel.setOpaque(false);

        // Left Column (Combat Potions)
        columnsPanel.add(createColumn("Combat Potions", new String[]{
            "Super Attack",
            "Super Strength",
            "Super Defence",
            "Super Combat",
            "Ranging"
        }));

        // Right Column (Prayer & Special)
        columnsPanel.add(createColumn("Prayer & Special", new String[]{
            "Prayer",
            "Super Restore",
            "Stamina"
        }));

        potionsSection.add(columnsPanel, potionsGbc);

        // Add potions section to main container with proper alignment
        JPanel potionsWrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        potionsWrapper.setOpaque(false);
        potionsWrapper.add(potionsSection);
        mainContainer.add(potionsWrapper);

        // Add spacing between sections
        mainContainer.add(Box.createVerticalStrut(20));

        // Food section
        JPanel foodSection = createFoodSection();
        mainContainer.add(foodSection);

        // Add the main container
        add(mainContainer, BorderLayout.NORTH);

        // Add listeners
        foodTypeComboBox.addActionListener(e -> {
            if (!isLoading) saveSettings();
        });
        foodQuantitySpinner.addChangeListener(e -> {
            if (!isLoading) saveSettings();
        });
    }

    private JPanel createColumn(String title, String[] potions) {
        JPanel column = new JPanel(new GridBagLayout());
        column.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridy = 0;

        // Add header
        addSectionHeader(column, title, gbc);

        // Add potions
        gbc.gridy = 1;
        JPanel potionsPanel = new JPanel(new GridBagLayout());
        potionsPanel.setOpaque(false);
        GridBagConstraints slotGbc = new GridBagConstraints();
        slotGbc.fill = GridBagConstraints.HORIZONTAL;
        slotGbc.gridy = 0;

        for (int i = 0; i < potions.length; i++) {
            String displayName = potions[i];
            String actualItem = POTION_MAPPINGS.get(displayName);

            ModularSupplyField field = new ModularSupplyField();
            field.getItemField().setVisible(false);
            supplyFields.put(displayName, field);

            // Add label
            slotGbc.gridx = 0;
            slotGbc.gridy = i;
            slotGbc.weightx = 0.7;
            slotGbc.insets = new Insets(2, 4, 2, 4);
            JLabel potionLabel = new JLabel(displayName + ":");
            potionLabel.setFont(StyleManager.FIELD_LABEL_FONT);
            potionLabel.setForeground(StyleManager.TEXT_COLOR);
            potionsPanel.add(potionLabel, slotGbc);

            // Add spinner
            JSpinner spinner = field.getQuantitySpinner();
            spinner.setPreferredSize(new Dimension(60, 28));
            slotGbc.gridx = 1;
            slotGbc.weightx = 0.3;
            potionsPanel.add(spinner, slotGbc);

            spinner.addChangeListener(e -> {
                if (!isLoading) saveSettings();
            });
        }

        column.add(potionsPanel, gbc);
        return column;
    }

    private JPanel createFoodSection() {
        JPanel foodSection = new JPanel(new GridBagLayout());
        foodSection.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;

        // Add Food header
        addSectionHeader(foodSection, "Food Settings", gbc);

        // Food settings panel
        JPanel foodSettingsPanel = new JPanel(new GridBagLayout());
        foodSettingsPanel.setOpaque(false);
        GridBagConstraints foodGbc = new GridBagConstraints();
        foodGbc.fill = GridBagConstraints.HORIZONTAL;
        foodGbc.insets = new Insets(2, 4, 2, 4);

        // Food Type field
        foodGbc.gridx = 0;
        foodGbc.gridy = 0;
        foodGbc.weightx = 0.3;
        JLabel foodLabel = new JLabel("Food Type:");
        foodLabel.setFont(StyleManager.FIELD_LABEL_FONT);
        foodLabel.setForeground(StyleManager.TEXT_COLOR);
        foodSettingsPanel.add(foodLabel, foodGbc);

        // Create food type combo box
        foodTypeComboBox.setPreferredSize(new Dimension(150, 28));
        StyleManager.styleComboBox(foodTypeComboBox);
        
        // Create food quantity spinner
        foodQuantitySpinner.setPreferredSize(new Dimension(60, 28));
        StyleManager.styleSpinner(foodQuantitySpinner);

        // Add food type and quantity in a panel
        JPanel foodInputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        foodInputPanel.setOpaque(false);
        foodInputPanel.add(foodTypeComboBox);
        foodInputPanel.add(foodQuantitySpinner);

        foodGbc.gridx = 1;
        foodGbc.weightx = 0.7;
        foodSettingsPanel.add(foodInputPanel, foodGbc);

        // Add food settings panel
        gbc.insets = new Insets(10, 10, 0, 10);
        foodSection.add(foodSettingsPanel, gbc);

        return foodSection;
    }

    private void addSectionHeader(JPanel container, String title, GridBagConstraints gbc) {
        JPanel headerPanel = new JPanel(new BorderLayout(0, 3));
        headerPanel.setOpaque(false);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));

        JLabel headerLabel = new JLabel(title.toUpperCase());
        headerLabel.setFont(StyleManager.SECTION_HEADER_FONT);
        headerLabel.setForeground(StyleManager.ACCENT);
        headerPanel.add(headerLabel, BorderLayout.NORTH);

        JPanel linePanel = new JPanel();
        linePanel.setOpaque(false);
        linePanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.WHITE));
        headerPanel.add(linePanel, BorderLayout.CENTER);

        container.add(headerPanel, gbc);
    }

    public void loadSettings() {
        isLoading = true;
        try {
            // Load potion quantities
            Map<String, Integer> supplies = config.getSupplies();
            for (Map.Entry<String, ModularSupplyField> entry : supplyFields.entrySet()) {
                String potionName = POTION_MAPPINGS.get(entry.getKey());
                int quantity = supplies.getOrDefault(potionName, 0);
                entry.getValue().getQuantitySpinner().setValue(quantity);
            }

            // Load food settings
            List<String> foodNames = config.getFoodNames();
            if (foodNames != null && !foodNames.isEmpty()) {
                foodTypeComboBox.setSelectedItem(foodNames.get(0));
            } else {
                foodTypeComboBox.setSelectedItem(FOOD_OPTIONS[0]);
            }
            foodQuantitySpinner.setValue(config.getTargetFoodCount());
        } finally {
            isLoading = false;
        }
    }

    public void saveSettings() {
        if (isLoading) return;

        // Save potion quantities
        Map<String, Integer> supplies = new HashMap<>();
        for (Map.Entry<String, ModularSupplyField> entry : supplyFields.entrySet()) {
            String potionName = POTION_MAPPINGS.get(entry.getKey());
            int quantity = (int) entry.getValue().getQuantitySpinner().getValue();
            if (quantity > 0) {
                supplies.put(potionName, quantity);
            }
        }
        config.setSupplies(supplies);

        // Save food settings
        List<String> foodList = new ArrayList<>();
        String selectedFood = (String) foodTypeComboBox.getSelectedItem();
        if (selectedFood != null && !selectedFood.isEmpty()) {
            foodList.add(selectedFood);
        }
        config.setFoodNames(foodList);
        config.setTargetFoodCount((int) foodQuantitySpinner.getValue());
    }
} 