package core.gui.components;

import core.gui.style.StyleManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

/**
 * A modern tooltip component with improved styling and positioning.
 * Provides a more visually appealing way to display tooltips.
 */
public class ModernTooltip extends JWindow {
    private final JLabel contentLabel;
    private final Component owner;
    private final int PADDING = 8;
    private final int ARROW_SIZE = 8;
    private final int CORNER_RADIUS = 6;
    
    /**
     * Creates a new modern tooltip for the specified component
     * 
     * @param owner The component that owns this tooltip
     * @param text The tooltip text
     */
    public ModernTooltip(Component owner, String text) {
        super(SwingUtilities.getWindowAncestor(owner) instanceof Frame ? 
              (Frame) SwingUtilities.getWindowAncestor(owner) : 
              new JFrame());
        
        this.owner = owner;
        
        // Create content panel
        JPanel contentPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Draw background
                g2.setColor(new Color(50, 50, 55));
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), CORNER_RADIUS, CORNER_RADIUS));
                
                // Draw arrow
                int[] xPoints = {getWidth() / 2 - ARROW_SIZE / 2, getWidth() / 2, getWidth() / 2 + ARROW_SIZE / 2};
                int[] yPoints = {0, -ARROW_SIZE, 0};
                g2.fillPolygon(xPoints, yPoints, 3);
                
                g2.dispose();
            }
        };
        contentPanel.setOpaque(false);
        contentPanel.setBorder(new EmptyBorder(PADDING, PADDING, PADDING, PADDING));
        
        // Create content label
        contentLabel = new JLabel(text);
        contentLabel.setForeground(StyleManager.FOREGROUND);
        contentLabel.setFont(StyleManager.SMALL_FONT);
        contentPanel.add(contentLabel, BorderLayout.CENTER);
        
        // Set up window
        setBackground(new Color(0, 0, 0, 0));
        setContentPane(contentPanel);
        
        // Add mouse listener to hide tooltip when clicked
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                setVisible(false);
            }
        });
    }
    
    /**
     * Sets the tooltip text
     * 
     * @param text The tooltip text
     */
    public void setText(String text) {
        contentLabel.setText(text);
        pack();
    }
    
    /**
     * Shows the tooltip
     */
    public void showTooltip() {
        // Calculate position
        Point ownerLocation = owner.getLocationOnScreen();
        Dimension ownerSize = owner.getSize();
        Dimension tooltipSize = getPreferredSize();
        
        int x = ownerLocation.x + (ownerSize.width - tooltipSize.width) / 2;
        int y = ownerLocation.y - tooltipSize.height - ARROW_SIZE;
        
        // Ensure tooltip is visible on screen
        Rectangle screenBounds = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        if (x < screenBounds.x) {
            x = screenBounds.x;
        } else if (x + tooltipSize.width > screenBounds.x + screenBounds.width) {
            x = screenBounds.x + screenBounds.width - tooltipSize.width;
        }
        
        if (y < screenBounds.y) {
            // Show below component instead
            y = ownerLocation.y + ownerSize.height + ARROW_SIZE;
        }
        
        // Set location and show
        setLocation(x, y);
        pack();
        setVisible(true);
    }
    
    /**
     * Hides the tooltip
     */
    public void hideTooltip() {
        setVisible(false);
    }
    
    /**
     * Attaches this tooltip to a component
     * 
     * @param component The component to attach to
     */
    public static void attach(JComponent component, String text) {
        ModernTooltip tooltip = new ModernTooltip(component, text);
        
        component.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                tooltip.showTooltip();
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                tooltip.hideTooltip();
            }
        });
    }
}
