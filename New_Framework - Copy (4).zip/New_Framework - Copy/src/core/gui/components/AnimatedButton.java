package core.gui.components;

import core.gui.style.ModernUITheme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

/**
 * A modern button with hover and click animations, gradient background,
 * and rounded corners for a sleek appearance.
 */
public class AnimatedButton extends JButton {
    private boolean isHovered = false;
    private boolean isPressed = false;
    private float animationProgress = 0.0f;
    private final Timer animationTimer;
    private final int animationDuration = ModernUITheme.ANIMATION_DURATION_SHORT;
    private final int animationSteps = 10;
    private final float animationStepSize = 1.0f / animationSteps;
    private final ButtonStyle style;
    
    /**
     * Button style enum for different visual appearances
     */
    public enum ButtonStyle {
        PRIMARY,
        SECONDARY,
        SUCCESS,
        WARNING,
        DANGER,
        GHOST
    }
    
    /**
     * Creates a new animated button with the specified text and primary style
     * 
     * @param text The button text
     */
    public AnimatedButton(String text) {
        this(text, ButtonStyle.PRIMARY);
    }
    
    /**
     * Creates a new animated button with the specified text and style
     * 
     * @param text The button text
     * @param style The button style
     */
    public AnimatedButton(String text, ButtonStyle style) {
        super(text);
        this.style = style;
        
        // Configure button
        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setFont(ModernUITheme.FONT_REGULAR);
        setForeground(ModernUITheme.TEXT_PRIMARY);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Set preferred size
        setPreferredSize(ModernUITheme.BUTTON_SIZE);
        
        // Create animation timer
        animationTimer = new Timer(animationDuration / animationSteps, e -> {
            if (isHovered || isPressed) {
                animationProgress = Math.min(1.0f, animationProgress + animationStepSize);
            } else {
                animationProgress = Math.max(0.0f, animationProgress - animationStepSize);
            }
            
            if ((animationProgress >= 1.0f && (isHovered || isPressed)) || 
                (animationProgress <= 0.0f && !isHovered && !isPressed)) {
                ((Timer) e.getSource()).stop();
            }
            
            repaint();
        });
        
        // Add mouse listeners for animations
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                isHovered = true;
                animationTimer.start();
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                if (!isPressed) {
                    animationTimer.start();
                }
            }
            
            @Override
            public void mousePressed(MouseEvent e) {
                isPressed = true;
                animationTimer.start();
            }
            
            @Override
            public void mouseReleased(MouseEvent e) {
                isPressed = false;
                if (!isHovered) {
                    animationTimer.start();
                }
            }
        });
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int width = getWidth();
        int height = getHeight();
        
        // Get colors based on style
        Color baseColor = getBaseColor();
        Color hoverColor = getHoverColor();
        Color pressedColor = getPressedColor();
        
        // Calculate current color based on animation progress
        Color currentColor;
        if (isPressed) {
            currentColor = blendColors(baseColor, pressedColor, animationProgress);
        } else if (isHovered) {
            currentColor = blendColors(baseColor, hoverColor, animationProgress);
        } else {
            currentColor = blendColors(hoverColor, baseColor, 1.0f - animationProgress);
        }
        
        // Draw button background
        if (style != ButtonStyle.GHOST) {
            // Create gradient paint
            GradientPaint gradient = new GradientPaint(
                0, 0, 
                new Color(currentColor.getRed(), currentColor.getGreen(), currentColor.getBlue(), 255),
                0, height,
                new Color(
                    Math.max(0, currentColor.getRed() - 20),
                    Math.max(0, currentColor.getGreen() - 20),
                    Math.max(0, currentColor.getBlue() - 20),
                    255
                )
            );
            
            g2.setPaint(gradient);
            g2.fill(new RoundRectangle2D.Double(0, 0, width, height, ModernUITheme.BUTTON_RADIUS, ModernUITheme.BUTTON_RADIUS));
        } else {
            // For ghost buttons, only draw border
            g2.setColor(currentColor);
            g2.setStroke(new BasicStroke(1.5f));
            g2.draw(new RoundRectangle2D.Double(1, 1, width - 2, height - 2, ModernUITheme.BUTTON_RADIUS, ModernUITheme.BUTTON_RADIUS));
        }
        
        // Draw text
        FontMetrics fm = g2.getFontMetrics();
        Rectangle stringBounds = fm.getStringBounds(getText(), g2).getBounds();
        
        int textX = (width - stringBounds.width) / 2;
        int textY = (height - stringBounds.height) / 2 + fm.getAscent();
        
        g2.setColor(style == ButtonStyle.GHOST ? currentColor : ModernUITheme.TEXT_PRIMARY);
        g2.drawString(getText(), textX, textY);
        
        g2.dispose();
    }
    
    /**
     * Gets the base color for the button based on its style
     */
    private Color getBaseColor() {
        switch (style) {
            case PRIMARY:
                return ModernUITheme.ACCENT_PRIMARY;
            case SECONDARY:
                return ModernUITheme.ACCENT_SECONDARY;
            case SUCCESS:
                return ModernUITheme.ACCENT_SUCCESS;
            case WARNING:
                return ModernUITheme.ACCENT_WARNING;
            case DANGER:
                return ModernUITheme.ACCENT_DANGER;
            case GHOST:
                return new Color(ModernUITheme.TEXT_PRIMARY.getRed(), 
                               ModernUITheme.TEXT_PRIMARY.getGreen(), 
                               ModernUITheme.TEXT_PRIMARY.getBlue(), 
                               100);
            default:
                return ModernUITheme.ACCENT_PRIMARY;
        }
    }
    
    /**
     * Gets the hover color for the button based on its style
     */
    private Color getHoverColor() {
        Color base = getBaseColor();
        
        // Make hover color lighter
        return new Color(
            Math.min(255, base.getRed() + 20),
            Math.min(255, base.getGreen() + 20),
            Math.min(255, base.getBlue() + 20),
            base.getAlpha()
        );
    }
    
    /**
     * Gets the pressed color for the button based on its style
     */
    private Color getPressedColor() {
        Color base = getBaseColor();
        
        // Make pressed color darker
        return new Color(
            Math.max(0, base.getRed() - 40),
            Math.max(0, base.getGreen() - 40),
            Math.max(0, base.getBlue() - 40),
            base.getAlpha()
        );
    }
    
    /**
     * Blends two colors based on the specified ratio
     */
    private Color blendColors(Color c1, Color c2, float ratio) {
        int r = (int) (c1.getRed() + (c2.getRed() - c1.getRed()) * ratio);
        int g = (int) (c1.getGreen() + (c2.getGreen() - c1.getGreen()) * ratio);
        int b = (int) (c1.getBlue() + (c2.getBlue() - c1.getBlue()) * ratio);
        int a = (int) (c1.getAlpha() + (c2.getAlpha() - c1.getAlpha()) * ratio);
        
        return new Color(r, g, b, a);
    }
}
