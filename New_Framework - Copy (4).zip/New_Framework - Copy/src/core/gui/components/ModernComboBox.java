package core.gui.components;

import core.gui.style.ModernUITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicComboPopup;
import javax.swing.plaf.basic.ComboPopup;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;

/**
 * A modern combo box with rounded corners, custom dropdown arrow,
 * and animated focus effect.
 */
public class ModernComboBox<E> extends JComboBox<E> {
    private boolean focused = false;
    private Timer animationTimer; // Removed final to allow initialization in initialize()
    private float animationProgress = 0.0f;
    private final int animationDuration = ModernUITheme.ANIMATION_DURATION_SHORT;
    private final int animationSteps = 10;
    private final float animationStepSize = 1.0f / animationSteps;

    /**
     * Creates a new modern combo box
     */
    public ModernComboBox() {
        super();
        initialize();
    }

    /**
     * Creates a new modern combo box with the specified items
     *
     * @param items The combo box items
     */
    public ModernComboBox(E[] items) {
        super(items);
        initialize();
    }

    /**
     * Creates a new modern combo box with the specified model
     *
     * @param model The combo box model
     */
    public ModernComboBox(ComboBoxModel<E> model) {
        super(model);
        initialize();
    }

    /**
     * Initializes the combo box
     */
    private void initialize() {
        // Configure combo box
        setOpaque(false);
        setBorder(new EmptyBorder(ModernUITheme.SPACING_SMALL,
                                ModernUITheme.SPACING_MEDIUM,
                                ModernUITheme.SPACING_SMALL,
                                ModernUITheme.SPACING_MEDIUM));
        setFont(ModernUITheme.FONT_REGULAR);
        setForeground(ModernUITheme.TEXT_PRIMARY);
        setBackground(ModernUITheme.BACKGROUND_LIGHT);

        // Set custom UI
        setUI(new ModernComboBoxUI());

        // Create animation timer
        animationTimer = new Timer(animationDuration / animationSteps, e -> {
            if (focused) {
                animationProgress = Math.min(1.0f, animationProgress + animationStepSize);
            } else {
                animationProgress = Math.max(0.0f, animationProgress - animationStepSize);
            }

            if ((animationProgress >= 1.0f && focused) ||
                (animationProgress <= 0.0f && !focused)) {
                ((Timer) e.getSource()).stop();
            }

            repaint();
        });

        // Add focus listener for animation
        addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                focused = true;
                animationTimer.start();
            }

            @Override
            public void focusLost(FocusEvent e) {
                focused = false;
                animationTimer.start();
            }
        });
    }

    /**
     * Custom UI for the modern combo box
     */
    private class ModernComboBoxUI extends BasicComboBoxUI {
        @Override
        protected JButton createArrowButton() {
            return new ArrowButton();
        }

        @Override
        protected ComboPopup createPopup() {
            return new ModernComboPopup(comboBox);
        }

        @Override
        public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) {
            // Don't paint the default background
        }

        @Override
        protected void installDefaults() {
            super.installDefaults();

            // Remove default border and background
            LookAndFeel.uninstallBorder(comboBox);
            comboBox.setBackground(ModernUITheme.BACKGROUND_LIGHT);
        }

        @Override
        public void paint(Graphics g, JComponent c) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = c.getWidth();
            int height = c.getHeight();

            // Draw background
            g2.setColor(ModernUITheme.BACKGROUND_LIGHT);
            g2.fill(new RoundRectangle2D.Double(0, 0, width, height,
                    ModernUITheme.FIELD_RADIUS, ModernUITheme.FIELD_RADIUS));

            // Draw border with animation
            Color borderColor = blendColors(
                    new Color(ModernUITheme.BACKGROUND_LIGHT.getRed() + 20,
                            ModernUITheme.BACKGROUND_LIGHT.getGreen() + 20,
                            ModernUITheme.BACKGROUND_LIGHT.getBlue() + 20),
                    ModernUITheme.ACCENT_PRIMARY,
                    animationProgress
            );

            g2.setColor(borderColor);
            g2.setStroke(new BasicStroke(1.5f));
            g2.draw(new RoundRectangle2D.Double(0.75, 0.75, width - 1.5, height - 1.5,
                    ModernUITheme.FIELD_RADIUS, ModernUITheme.FIELD_RADIUS));

            g2.dispose();

            // Paint the selected item
            paintCurrentValue(g, rectangleForCurrentValue(), hasFocus);
        }

        /**
         * Custom arrow button for the combo box
         */
        private class ArrowButton extends JButton {
            public ArrowButton() {
                setOpaque(false);
                setContentAreaFilled(false);
                setBorderPainted(false);
                setFocusPainted(false);
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(20, 20);
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int width = getWidth();
                int height = getHeight();

                // Draw arrow
                int arrowSize = 8;
                int x = (width - arrowSize) / 2;
                int y = (height - arrowSize / 2) / 2;

                Path2D arrow = new Path2D.Double();
                arrow.moveTo(x, y);
                arrow.lineTo(x + arrowSize, y);
                arrow.lineTo(x + arrowSize / 2, y + arrowSize / 2);
                arrow.closePath();

                g2.setColor(ModernUITheme.TEXT_SECONDARY);
                g2.fill(arrow);

                g2.dispose();
            }
        }

        /**
         * Custom popup for the combo box
         */
        private class ModernComboPopup extends BasicComboPopup {
            public ModernComboPopup(JComboBox<?> combo) {
                super((JComboBox)combo);

                // Style the list
                list.setBackground(ModernUITheme.BACKGROUND_DARK);
                list.setForeground(ModernUITheme.TEXT_PRIMARY);
                list.setSelectionBackground(ModernUITheme.ACCENT_PRIMARY);
                list.setSelectionForeground(ModernUITheme.TEXT_PRIMARY);
                list.setBorder(null);
            }

            @Override
            protected JScrollPane createScroller() {
                JScrollPane scroller = super.createScroller();
                scroller.setBorder(null);
                scroller.getVerticalScrollBar().setUI(new ModernScrollBarUI());
                return scroller;
            }

            @Override
            protected void configurePopup() {
                super.configurePopup();
                setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(ModernUITheme.ACCENT_PRIMARY, 1),
                        BorderFactory.createEmptyBorder(2, 2, 2, 2)
                ));
            }
        }
    }

    /**
     * Custom scroll bar UI for the combo box popup
     */
    private class ModernScrollBarUI extends javax.swing.plaf.basic.BasicScrollBarUI {
        @Override
        protected JButton createDecreaseButton(int orientation) {
            return createZeroButton();
        }

        @Override
        protected JButton createIncreaseButton(int orientation) {
            return createZeroButton();
        }

        private JButton createZeroButton() {
            JButton button = new JButton();
            button.setPreferredSize(new Dimension(0, 0));
            button.setMinimumSize(new Dimension(0, 0));
            button.setMaximumSize(new Dimension(0, 0));
            return button;
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
            if (thumbBounds.isEmpty() || !scrollbar.isEnabled()) {
                return;
            }

            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(ModernUITheme.ACCENT_PRIMARY);
            g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 6, 6);

            g2.dispose();
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(ModernUITheme.BACKGROUND_DARK);
            g2.fillRect(trackBounds.x, trackBounds.y, trackBounds.width, trackBounds.height);
            g2.dispose();
        }
    }

    /**
     * Blends two colors based on the specified ratio
     */
    private Color blendColors(Color c1, Color c2, float ratio) {
        int r = (int) (c1.getRed() + (c2.getRed() - c1.getRed()) * ratio);
        int g = (int) (c1.getGreen() + (c2.getGreen() - c1.getGreen()) * ratio);
        int b = (int) (c1.getBlue() + (c2.getBlue() - c1.getBlue()) * ratio);

        return new Color(r, g, b);
    }
}
