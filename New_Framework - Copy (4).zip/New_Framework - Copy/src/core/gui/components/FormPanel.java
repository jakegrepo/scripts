package core.gui.components;

import core.gui.style.ModernUITheme;
import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;

/**
 * A panel for organizing form fields with consistent layout and styling.
 * Automatically aligns labels and fields for a clean, professional appearance.
 */
public class FormPanel extends JPanel {
    private final GridBagLayout layout;
    private final GridBagConstraints labelConstraints;
    private final GridBagConstraints fieldConstraints;
    private final GridBagConstraints fullWidthConstraints;
    private int currentRow = 0;

    /**
     * Creates a new form panel
     */
    public FormPanel() {
        layout = new GridBagLayout();
        setLayout(layout);
        setBackground(StyleManager.CARD_BG);
        setBorder(null);

        // Initialize constraints for labels
        labelConstraints = new GridBagConstraints();
        labelConstraints.gridx = 0;
        labelConstraints.gridy = 0;
        labelConstraints.anchor = GridBagConstraints.EAST;
        labelConstraints.fill = GridBagConstraints.NONE;
        labelConstraints.insets = new Insets(0, 0, StyleManager.FIELD_SPACING, StyleManager.FIELD_SPACING);

        // Initialize constraints for fields
        fieldConstraints = new GridBagConstraints();
        fieldConstraints.gridx = 1;
        fieldConstraints.gridy = 0;
        fieldConstraints.anchor = GridBagConstraints.WEST;
        fieldConstraints.fill = GridBagConstraints.HORIZONTAL;
        fieldConstraints.weightx = 1.0;
        fieldConstraints.insets = new Insets(0, 0, StyleManager.FIELD_SPACING, 0);

        // Initialize constraints for full-width components
        fullWidthConstraints = new GridBagConstraints();
        fullWidthConstraints.gridx = 0;
        fullWidthConstraints.gridy = 0;
        fullWidthConstraints.gridwidth = 2;
        fullWidthConstraints.anchor = GridBagConstraints.WEST;
        fullWidthConstraints.fill = GridBagConstraints.HORIZONTAL;
        fullWidthConstraints.weightx = 1.0;
        fullWidthConstraints.insets = new Insets(0, 0, StyleManager.FIELD_SPACING, 0);
    }

    /**
     * Adds a field with a label to the form
     *
     * @param labelText The label text
     * @param field The field component
     */
    public void addField(String labelText, JComponent field) {
        // Create label
        JLabel label = new JLabel(labelText);
        label.setFont(StyleManager.FIELD_LABEL_FONT);
        label.setForeground(StyleManager.FOREGROUND);

        // Add label and field
        addField(label, field);
    }

    /**
     * Adds a field with a custom label component to the form
     *
     * @param label The label component
     * @param field The field component
     */
    public void addField(JComponent label, JComponent field) {
        // Update constraints for current row
        labelConstraints.gridy = currentRow;
        fieldConstraints.gridy = currentRow;

        // Add label
        add(label, labelConstraints);

        // Handle toggle switches differently to prevent stretching
        if (field instanceof ModernToggleSwitch) {
            // Create a wrapper panel to prevent stretching
            JPanel wrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            wrapper.setOpaque(false);
            wrapper.add(field);
            add(wrapper, fieldConstraints);
        } else {
            // Add field normally
            add(field, fieldConstraints);
        }

        // Increment row
        currentRow++;
    }

    /**
     * Adds a full-width component to the form
     *
     * @param component The component to add
     */
    public void addFullWidthComponent(JComponent component) {
        // Update constraints for current row
        fullWidthConstraints.gridy = currentRow;

        // Add component
        add(component, fullWidthConstraints);

        // Increment row
        currentRow++;
    }

    /**
     * Adds a section header to the form
     *
     * @param text The header text
     */
    public void addSectionHeader(String text) {
        // Create header label
        JLabel header = new JLabel(text);
        header.setFont(StyleManager.SECTION_HEADER_FONT);
        header.setForeground(StyleManager.FOREGROUND);

        // Add header with top margin
        fullWidthConstraints.gridy = currentRow;
        fullWidthConstraints.insets = new Insets(StyleManager.COMPONENT_SPACING, 0, StyleManager.FIELD_SPACING, 0);
        add(header, fullWidthConstraints);

        // Reset insets for next components
        fullWidthConstraints.insets = new Insets(0, 0, StyleManager.FIELD_SPACING, 0);

        // Add separator
        JSeparator separator = new JSeparator();
        separator.setForeground(StyleManager.BORDER_COLOR);

        currentRow++;
        fullWidthConstraints.gridy = currentRow;
        add(separator, fullWidthConstraints);

        // Increment row
        currentRow++;
    }

    /**
     * Adds vertical spacing to the form
     *
     * @param height The spacing height in pixels
     */
    public void addVerticalSpacing(int height) {
        // Create spacing component
        Component spacer = Box.createVerticalStrut(height);

        // Add spacer
        fullWidthConstraints.gridy = currentRow;
        fullWidthConstraints.insets = new Insets(0, 0, 0, 0);
        add(spacer, fullWidthConstraints);

        // Reset insets for next components
        fullWidthConstraints.insets = new Insets(0, 0, StyleManager.FIELD_SPACING, 0);

        // Increment row
        currentRow++;
    }

    /**
     * Adds a group of related checkboxes to the form
     *
     * @param labelText The group label text
     * @param checkboxes The checkboxes to add
     */
    public void addCheckboxGroup(String labelText, JCheckBox... checkboxes) {
        // Create label
        JLabel label = new JLabel(labelText);
        label.setFont(StyleManager.FIELD_LABEL_FONT);
        label.setForeground(StyleManager.FOREGROUND);

        // Create panel for checkboxes
        JPanel checkboxPanel = new JPanel();
        checkboxPanel.setLayout(new BoxLayout(checkboxPanel, BoxLayout.Y_AXIS));
        checkboxPanel.setBackground(StyleManager.CARD_BG);
        checkboxPanel.setBorder(null);

        // Add checkboxes to panel
        for (JCheckBox checkbox : checkboxes) {
            checkbox.setBackground(StyleManager.CARD_BG);
            checkbox.setFont(StyleManager.REGULAR_FONT);
            checkbox.setForeground(StyleManager.FOREGROUND);
            checkbox.setAlignmentX(Component.LEFT_ALIGNMENT);

            JPanel wrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            wrapper.setBackground(StyleManager.CARD_BG);
            wrapper.setBorder(null);
            wrapper.add(checkbox);

            checkboxPanel.add(wrapper);

            // Add spacing between checkboxes
            if (checkbox != checkboxes[checkboxes.length - 1]) {
                checkboxPanel.add(Box.createVerticalStrut(4));
            }
        }

        // Add label and checkbox panel
        labelConstraints.gridy = currentRow;
        labelConstraints.anchor = GridBagConstraints.NORTHEAST;
        fieldConstraints.gridy = currentRow;

        add(label, labelConstraints);
        add(checkboxPanel, fieldConstraints);

        // Reset anchor for next components
        labelConstraints.anchor = GridBagConstraints.EAST;

        // Increment row
        currentRow++;
    }

    /**
     * Creates a button panel with consistent styling
     *
     * @param buttons The buttons to add
     * @return The button panel
     */
    public static JPanel createButtonPanel(JButton... buttons) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, StyleManager.FIELD_SPACING, 0));
        panel.setBackground(StyleManager.CARD_BG);
        panel.setBorder(null);

        for (JButton button : buttons) {
            panel.add(button);
        }

        return panel;
    }
}
