package core.gui.components;

import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import java.lang.reflect.Method;

/**
 * A modern toast notification that appears and fades out
 * Compatible with Substance look and feel
 */
public class ToastNotification extends JPanel {
    public enum Type {
        INFO, SUCCESS, WARNING, ERROR
    }

    private static final int DISPLAY_TIME = 3000; // 3 seconds
    private static final int FADE_STEP = 10;
    private static final int FADE_TIME = 500; // 0.5 seconds
    private static final int TOAST_HEIGHT = 50;
    private static final int TOAST_WIDTH = 300;
    private static final int TOAST_RADIUS = 10;

    private final JFrame parentFrame;
    private final String message;
    private final Type type;
    private float opacity = 0.9f;
    private Timer fadeTimer;

    /**
     * Creates a new toast notification
     */
    public ToastNotification(JFrame parentFrame, String message, Type type) {
        this.parentFrame = parentFrame;
        this.message = message;
        this.type = type;

        setOpaque(false);
        setSize(TOAST_WIDTH, TOAST_HEIGHT);
        setLayout(new BorderLayout());

        // Position at the bottom of the frame
        positionToast();

        // Add to parent frame's glass pane
        parentFrame.getGlassPane().setVisible(true);
        ((Container) parentFrame.getGlassPane()).setLayout(null);
        ((Container) parentFrame.getGlassPane()).add(this);

        // Start display timer
        Timer displayTimer = new Timer(DISPLAY_TIME, e -> startFadeOut());
        displayTimer.setRepeats(false);
        displayTimer.start();
    }

    private void positionToast() {
        int x = (parentFrame.getWidth() - TOAST_WIDTH) / 2;
        int y = parentFrame.getHeight() - TOAST_HEIGHT - 20;
        setBounds(x, y, TOAST_WIDTH, TOAST_HEIGHT);
    }

    private void startFadeOut() {
        int fadeInterval = FADE_TIME / FADE_STEP;
        fadeTimer = new Timer(fadeInterval, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opacity -= 0.1f;
                if (opacity <= 0) {
                    opacity = 0;
                    fadeTimer.stop();
                    ((Container) parentFrame.getGlassPane()).remove(ToastNotification.this);
                    parentFrame.getGlassPane().repaint();
                }
                repaint();
            }
        });
        fadeTimer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, opacity));

        // Draw background
        Color bgColor = getBackgroundColor();
        g2.setColor(bgColor);
        g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), TOAST_RADIUS, TOAST_RADIUS));

        // Draw icon
        int iconSize = 24;
        int iconX = 15;
        int iconY = (getHeight() - iconSize) / 2;
        drawIcon(g2, iconX, iconY, iconSize);

        // Draw message
        g2.setColor(StyleManager.FOREGROUND);
        g2.setFont(StyleManager.REGULAR_FONT_BOLD);
        FontMetrics fm = g2.getFontMetrics();
        int textY = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
        g2.drawString(message, iconX + iconSize + 15, textY);

        g2.dispose();
    }

    private Color getBackgroundColor() {
        // Check if we're using Substance
        boolean isUsingSubstance = false;
        try {
            Class<?> substanceClass = Class.forName("org.pushingpixels.substance.api.SubstanceCortex");
            Method getCurrentSkinMethod = substanceClass.getMethod("getCurrentSkin");
            isUsingSubstance = getCurrentSkinMethod.invoke(null) != null;
        } catch (Exception e) {
            // Not using Substance or error occurred
            isUsingSubstance = false;
        }

        // Use more translucent colors with Substance
        int alpha = isUsingSubstance ? 200 : 230;

        switch (type) {
            case SUCCESS:
                return new Color(0, 150, 80, alpha);
            case WARNING:
                return new Color(230, 150, 0, alpha);
            case ERROR:
                return new Color(200, 50, 50, alpha);
            case INFO:
            default:
                return new Color(50, 120, 200, alpha);
        }
    }

    private void drawIcon(Graphics2D g2, int x, int y, int size) {
        g2.setColor(Color.WHITE);

        switch (type) {
            case SUCCESS:
                // Checkmark
                g2.setStroke(new BasicStroke(3));
                g2.drawLine(x + 5, y + size/2, x + size/2 - 2, y + size - 8);
                g2.drawLine(x + size/2 - 2, y + size - 8, x + size - 5, y + 8);
                break;
            case WARNING:
                // Exclamation mark
                g2.fillRect(x + size/2 - 2, y + 5, 4, size - 15);
                g2.fillOval(x + size/2 - 2, y + size - 8, 4, 4);
                break;
            case ERROR:
                // X mark
                g2.setStroke(new BasicStroke(3));
                g2.drawLine(x + 5, y + 5, x + size - 5, y + size - 5);
                g2.drawLine(x + size - 5, y + 5, x + 5, y + size - 5);
                break;
            case INFO:
            default:
                // i mark
                g2.fillOval(x + size/2 - 2, y + 5, 4, 4);
                g2.fillRect(x + size/2 - 2, y + 12, 4, size - 17);
                break;
        }
    }

    /**
     * Shows a success toast notification
     */
    public static void showSuccess(JFrame parent, String message) {
        new ToastNotification(parent, message, Type.SUCCESS);
    }

    /**
     * Shows an error toast notification
     */
    public static void showError(JFrame parent, String message) {
        new ToastNotification(parent, message, Type.ERROR);
    }

    /**
     * Shows a warning toast notification
     */
    public static void showWarning(JFrame parent, String message) {
        new ToastNotification(parent, message, Type.WARNING);
    }

    /**
     * Shows an info toast notification
     */
    public static void showInfo(JFrame parent, String message) {
        new ToastNotification(parent, message, Type.INFO);
    }
}
