package core.gui.components;

import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

/**
 * A modern toggle switch component that can be used as an alternative to checkboxes.
 * Provides a more visually appealing way to toggle boolean settings.
 */
public class ToggleSwitch extends JComponent {
    private boolean selected = false;
    private boolean hovered = false;
    private boolean pressed = false;
    
    private final Color TRACK_COLOR = new Color(100, 100, 110);
    private final Color TRACK_SELECTED_COLOR = StyleManager.ACCENT;
    private final Color THUMB_COLOR = new Color(240, 240, 245);
    private final Color THUMB_SHADOW_COLOR = new Color(0, 0, 0, 30);
    
    private final int TRACK_HEIGHT = 14;
    private final int THUMB_SIZE = 20;
    private final int THUMB_MARGIN = 2;
    
    /**
     * Creates a new toggle switch
     */
    public ToggleSwitch() {
        setPreferredSize(new Dimension(40, 24));
        setMinimumSize(new Dimension(40, 24));
        setMaximumSize(new Dimension(40, 24));
        setOpaque(false);
        setFocusable(true);
        
        // Add mouse listeners for interaction
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                setSelected(!selected);
            }
            
            @Override
            public void mousePressed(MouseEvent e) {
                pressed = true;
                repaint();
            }
            
            @Override
            public void mouseReleased(MouseEvent e) {
                pressed = false;
                repaint();
            }
            
            @Override
            public void mouseEntered(MouseEvent e) {
                hovered = true;
                repaint();
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                hovered = false;
                repaint();
            }
        });
    }
    
    /**
     * Sets the selected state of the toggle switch
     * 
     * @param selected The selected state
     */
    public void setSelected(boolean selected) {
        if (this.selected != selected) {
            this.selected = selected;
            repaint();
            firePropertyChange("selected", !selected, selected);
        }
    }
    
    /**
     * Gets the selected state of the toggle switch
     * 
     * @return The selected state
     */
    public boolean isSelected() {
        return selected;
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int width = getWidth();
        int height = getHeight();
        
        // Calculate track bounds
        int trackY = (height - TRACK_HEIGHT) / 2;
        int trackWidth = width - THUMB_MARGIN * 2;
        
        // Calculate thumb position
        int thumbX = selected ? width - THUMB_SIZE - THUMB_MARGIN : THUMB_MARGIN;
        int thumbY = (height - THUMB_SIZE) / 2;
        
        // Draw track
        g2.setColor(selected ? TRACK_SELECTED_COLOR : TRACK_COLOR);
        g2.fill(new RoundRectangle2D.Double(THUMB_MARGIN, trackY, trackWidth, TRACK_HEIGHT, TRACK_HEIGHT, TRACK_HEIGHT));
        
        // Draw thumb shadow
        g2.setColor(THUMB_SHADOW_COLOR);
        g2.fill(new RoundRectangle2D.Double(thumbX + 1, thumbY + 1, THUMB_SIZE, THUMB_SIZE, THUMB_SIZE, THUMB_SIZE));
        
        // Draw thumb
        g2.setColor(THUMB_COLOR);
        g2.fill(new RoundRectangle2D.Double(thumbX, thumbY, THUMB_SIZE, THUMB_SIZE, THUMB_SIZE, THUMB_SIZE));
        
        // Draw hover effect
        if (hovered && !pressed) {
            g2.setColor(new Color(0, 0, 0, 20));
            g2.fill(new RoundRectangle2D.Double(thumbX, thumbY, THUMB_SIZE, THUMB_SIZE, THUMB_SIZE, THUMB_SIZE));
        }
        
        // Draw pressed effect
        if (pressed) {
            g2.setColor(new Color(0, 0, 0, 30));
            g2.fill(new RoundRectangle2D.Double(thumbX, thumbY, THUMB_SIZE, THUMB_SIZE, THUMB_SIZE, THUMB_SIZE));
        }
        
        g2.dispose();
    }
}
