package core.gui.components;

import core.gui.style.ModernUITheme;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/**
 * A modern card component with a glass-like appearance, subtle gradient,
 * and rounded corners for a sleek, contemporary look.
 */
public class GlassCard extends JPanel {
    private final String title;
    private final JPanel contentPanel;
    private final JPanel headerPanel;
    private final JPanel footerPanel;
    private final int cornerRadius;
    private final boolean showHeader;
    private final boolean showFooter;

    /**
     * Creates a new glass card with the specified title
     *
     * @param title The card title
     */
    public GlassCard(String title) {
        this(title, ModernUITheme.CARD_RADIUS, true, false);
    }

    /**
     * Creates a new glass card with the specified title and corner radius
     *
     * @param title The card title
     * @param cornerRadius The corner radius
     */
    public GlassCard(String title, int cornerRadius) {
        this(title, cornerRadius, true, false);
    }

    /**
     * Creates a new glass card with the specified title, corner radius, and header/footer visibility
     *
     * @param title The card title
     * @param cornerRadius The corner radius
     * @param showHeader Whether to show the header
     * @param showFooter Whether to show the footer
     */
    public GlassCard(String title, int cornerRadius, boolean showHeader, boolean showFooter) {
        super(new BorderLayout());
        this.title = title;
        this.cornerRadius = cornerRadius;
        this.showHeader = showHeader;
        this.showFooter = showFooter;

        // Set up panel properties
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(ModernUITheme.SPACING_SMALL,
                                                ModernUITheme.SPACING_SMALL,
                                                ModernUITheme.SPACING_SMALL,
                                                ModernUITheme.SPACING_SMALL));

        // Create header panel
        headerPanel = createHeaderPanel();
        if (showHeader) {
            add(headerPanel, BorderLayout.NORTH);
        }

        // Create content panel
        contentPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                paintContentBackground(g);
            }
        };
        contentPanel.setOpaque(false);
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(
                showHeader ? ModernUITheme.SPACING_MEDIUM : ModernUITheme.SPACING_LARGE,
                ModernUITheme.SPACING_LARGE,
                showFooter ? ModernUITheme.SPACING_MEDIUM : ModernUITheme.SPACING_LARGE,
                ModernUITheme.SPACING_LARGE
        ));
        add(contentPanel, BorderLayout.CENTER);

        // Create footer panel
        footerPanel = createFooterPanel();
        if (showFooter) {
            add(footerPanel, BorderLayout.SOUTH);
        }
    }

    /**
     * Creates the header panel with the title
     */
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                paintHeaderBackground(g);
            }
        };
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(
                ModernUITheme.SPACING_MEDIUM,
                ModernUITheme.SPACING_LARGE,
                ModernUITheme.SPACING_SMALL,
                ModernUITheme.SPACING_LARGE
        ));

        // Add title label
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(ModernUITheme.FONT_TITLE);
        titleLabel.setForeground(ModernUITheme.TEXT_PRIMARY);
        panel.add(titleLabel, BorderLayout.WEST);

        return panel;
    }

    /**
     * Creates the footer panel
     */
    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                paintFooterBackground(g);
            }
        };
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(
                ModernUITheme.SPACING_SMALL,
                ModernUITheme.SPACING_LARGE,
                ModernUITheme.SPACING_MEDIUM,
                ModernUITheme.SPACING_LARGE
        ));

        return panel;
    }

    /**
     * Paints the header background with a subtle gradient
     */
    private void paintHeaderBackground(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        // Create path for top rounded corners
        RoundRectangle2D roundedRect = new RoundRectangle2D.Double(
                0, 0, width, height * 2, cornerRadius, cornerRadius);
        g2.clip(roundedRect);

        // Draw gradient background
        GradientPaint gradient = new GradientPaint(
                0, 0, new Color(ModernUITheme.BACKGROUND_MEDIUM.getRed() + 10,
                              ModernUITheme.BACKGROUND_MEDIUM.getGreen() + 10,
                              ModernUITheme.BACKGROUND_MEDIUM.getBlue() + 10),
                0, height, ModernUITheme.BACKGROUND_MEDIUM);
        g2.setPaint(gradient);
        g2.fillRect(0, 0, width, height);

        // Draw subtle border
        g2.setColor(new Color(255, 255, 255, 30));
        g2.drawLine(0, height - 1, width, height - 1);

        g2.dispose();
    }

    /**
     * Paints the content background
     */
    private void paintContentBackground(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        // Draw background
        g2.setColor(ModernUITheme.BACKGROUND_MEDIUM);
        g2.fillRect(0, 0, width, height);

        g2.dispose();
    }

    /**
     * Paints the footer background with a subtle gradient
     */
    private void paintFooterBackground(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        // Create path for bottom rounded corners
        RoundRectangle2D roundedRect = new RoundRectangle2D.Double(
                0, -height, width, height * 2, cornerRadius, cornerRadius);
        g2.clip(roundedRect);

        // Draw gradient background
        GradientPaint gradient = new GradientPaint(
                0, 0, ModernUITheme.BACKGROUND_MEDIUM,
                0, height, new Color(ModernUITheme.BACKGROUND_MEDIUM.getRed() - 5,
                                   ModernUITheme.BACKGROUND_MEDIUM.getGreen() - 5,
                                   ModernUITheme.BACKGROUND_MEDIUM.getBlue() - 5));
        g2.setPaint(gradient);
        g2.fillRect(0, 0, width, height);

        // Draw subtle border
        g2.setColor(new Color(0, 0, 0, 30));
        g2.drawLine(0, 0, width, 0);

        g2.dispose();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        // Create rounded rectangle for card background
        RoundRectangle2D roundedRect = new RoundRectangle2D.Double(
                0, 0, width - 1, height - 1, cornerRadius, cornerRadius);

        // Draw shadow
        drawShadow(g2, roundedRect);

        // Draw card background
        g2.setColor(ModernUITheme.BACKGROUND_MEDIUM);
        g2.fill(roundedRect);

        // Draw subtle border
        g2.setColor(new Color(255, 255, 255, 30));
        g2.draw(roundedRect);

        g2.dispose();

        super.paintComponent(g);
    }

    /**
     * Draws a shadow around the card
     */
    private void drawShadow(Graphics2D g2, RoundRectangle2D shape) {
        // Save original composite
        Composite originalComposite = g2.getComposite();

        // Draw shadow with decreasing opacity
        for (int i = 0; i < ModernUITheme.SHADOW_SIZE; i++) {
            float opacity = ModernUITheme.SHADOW_OPACITY * (1.0f - (float) i / ModernUITheme.SHADOW_SIZE);
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, opacity));
            g2.setColor(Color.BLACK);
            g2.fill(new RoundRectangle2D.Double(
                    shape.getX() + ModernUITheme.SHADOW_OFFSET - i,
                    shape.getY() + ModernUITheme.SHADOW_OFFSET - i,
                    shape.getWidth() + i * 2,
                    shape.getHeight() + i * 2,
                    shape.getArcWidth(),
                    shape.getArcHeight()
            ));
        }

        // Restore original composite
        g2.setComposite(originalComposite);
    }

    /**
     * Adds a component to the content panel
     */
    public void addContent(Component component) {
        // Make sure the component takes full width but maintains its preferred height
        if (component instanceof JComponent) {
            JComponent jComponent = (JComponent) component;
            jComponent.setAlignmentX(Component.LEFT_ALIGNMENT);

            // Set maximum width to fill the container but keep preferred height
            Dimension prefSize = jComponent.getPreferredSize();
            if (prefSize != null) {
                jComponent.setMaximumSize(new Dimension(Integer.MAX_VALUE, prefSize.height));
            }
        }

        // Add the component
        contentPanel.add(component);

        // Add some spacing after the component
        contentPanel.add(Box.createVerticalStrut(ModernUITheme.SPACING_SMALL));
    }

    /**
     * Adds a component to the content panel with the specified constraints
     */
    public void addContent(Component component, Object constraints) {
        // Make sure the component takes full width but maintains its preferred height
        if (component instanceof JComponent) {
            JComponent jComponent = (JComponent) component;
            jComponent.setAlignmentX(Component.LEFT_ALIGNMENT);

            // Set maximum width to fill the container but keep preferred height
            Dimension prefSize = jComponent.getPreferredSize();
            if (prefSize != null) {
                jComponent.setMaximumSize(new Dimension(Integer.MAX_VALUE, prefSize.height));
            }
        }

        // Add the component
        contentPanel.add(component);

        // Add some spacing after the component
        contentPanel.add(Box.createVerticalStrut(ModernUITheme.SPACING_SMALL));
    }

    /**
     * Sets the content panel layout
     */
    public void setContentLayout(LayoutManager layout) {
        contentPanel.setLayout(layout);
    }

    /**
     * Adds a button to the footer panel
     */
    public void addFooterButton(JButton button) {
        footerPanel.add(button);
    }

    /**
     * Gets the content panel
     */
    public JPanel getContentPanel() {
        return contentPanel;
    }

    /**
     * Gets the header panel
     */
    public JPanel getHeaderPanel() {
        return headerPanel;
    }

    /**
     * Gets the footer panel
     */
    public JPanel getFooterPanel() {
        return footerPanel;
    }
}
