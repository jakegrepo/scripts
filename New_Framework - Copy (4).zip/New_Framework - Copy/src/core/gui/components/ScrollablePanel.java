package core.gui.components;

import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;

/**
 * A panel that can be scrolled with a modern scrollbar appearance.
 * Provides better scrolling experience for content that exceeds the visible area.
 */
public class ScrollablePanel extends JPanel {
    private final JPanel contentPanel;
    private final JScrollPane scrollPane;
    
    /**
     * Creates a new scrollable panel
     */
    public ScrollablePanel() {
        this(new BorderLayout());
    }
    
    /**
     * Creates a new scrollable panel with the specified layout
     * 
     * @param layout The layout to use for the content panel
     */
    public ScrollablePanel(LayoutManager layout) {
        super(new BorderLayout());
        setBackground(StyleManager.PANEL_BG);
        setBorder(null);
        
        // Create content panel
        contentPanel = new JPanel(layout);
        contentPanel.setBackground(StyleManager.PANEL_BG);
        contentPanel.setBorder(null);
        
        // Create scroll pane
        scrollPane = new JScrollPane(contentPanel);
        StyleManager.styleScrollPane(scrollPane);
        scrollPane.setBorder(null);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        // Add scroll pane to this panel
        add(scrollPane, BorderLayout.CENTER);
    }
    
    /**
     * Gets the content panel
     * 
     * @return The content panel
     */
    public JPanel getContentPanel() {
        return contentPanel;
    }
    
    /**
     * Gets the scroll pane
     * 
     * @return The scroll pane
     */
    public JScrollPane getScrollPane() {
        return scrollPane;
    }
    
    /**
     * Adds a component to the content panel
     * 
     * @param component The component to add
     */
    public void addContent(Component component) {
        contentPanel.add(component);
    }
    
    /**
     * Adds a component to the content panel with the specified constraints
     * 
     * @param component The component to add
     * @param constraints The constraints to use
     */
    public void addContent(Component component, Object constraints) {
        contentPanel.add(component, constraints);
    }
    
    /**
     * Sets the layout of the content panel
     * 
     * @param layout The layout to set
     */
    public void setContentLayout(LayoutManager layout) {
        contentPanel.setLayout(layout);
    }
    
    /**
     * Sets the border of the content panel
     * 
     * @param border The border to set
     */
    public void setContentBorder(javax.swing.border.Border border) {
        contentPanel.setBorder(border);
    }
    
    /**
     * Sets the background color of the content panel
     * 
     * @param color The color to set
     */
    public void setContentBackground(Color color) {
        contentPanel.setBackground(color);
    }
    
    /**
     * Scrolls to the top of the panel
     */
    public void scrollToTop() {
        SwingUtilities.invokeLater(() -> {
            JScrollBar scrollBar = scrollPane.getVerticalScrollBar();
            scrollBar.setValue(scrollBar.getMinimum());
        });
    }
    
    /**
     * Scrolls to the bottom of the panel
     */
    public void scrollToBottom() {
        SwingUtilities.invokeLater(() -> {
            JScrollBar scrollBar = scrollPane.getVerticalScrollBar();
            scrollBar.setValue(scrollBar.getMaximum());
        });
    }
}
