package core.gui.components;

import core.gui.style.ModernUITheme;
import core.gui.style.ThemeManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 * A panel that allows users to select and apply different colors for text and background.
 */
public class ColorPickerPanel extends JPanel {
    private final PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);
    private final ColorPickerButton primaryTextColorButton;
    private final ColorPickerButton secondaryTextColorButton;
    private final ColorPickerButton backgroundDarkButton;
    private final ColorPickerButton backgroundLightButton;
    private final ColorPickerButton accentColorButton;

    /**
     * Creates a new color picker panel
     */
    public ColorPickerPanel() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setOpaque(false);

        // Create text colors panel
        JPanel textColorsPanel = new JPanel(new GridLayout(0, 1, 0, 5));
        textColorsPanel.setOpaque(false);
        textColorsPanel.setBorder(BorderFactory.createTitledBorder("Text Colors"));

        // Create primary text color button
        primaryTextColorButton = new ColorPickerButton("Primary Text", ModernUITheme.TEXT_PRIMARY, "primary text");
        primaryTextColorButton.addPropertyChangeListener("selectedColor", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                updateTextColors();
            }
        });
        textColorsPanel.add(primaryTextColorButton);

        // Create secondary text color button
        secondaryTextColorButton = new ColorPickerButton("Secondary Text", ModernUITheme.TEXT_SECONDARY, "secondary text");
        secondaryTextColorButton.addPropertyChangeListener("selectedColor", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                updateTextColors();
            }
        });
        textColorsPanel.add(secondaryTextColorButton);

        // Create background colors panel
        JPanel backgroundColorsPanel = new JPanel(new GridLayout(0, 1, 0, 5));
        backgroundColorsPanel.setOpaque(false);
        backgroundColorsPanel.setBorder(BorderFactory.createTitledBorder("Background Colors"));

        // Create background dark button
        backgroundDarkButton = new ColorPickerButton("Background Dark", ModernUITheme.BACKGROUND_DARK, "background dark");
        backgroundDarkButton.addPropertyChangeListener("selectedColor", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                updateBackgroundColors();
            }
        });
        backgroundColorsPanel.add(backgroundDarkButton);

        // Create background light button
        backgroundLightButton = new ColorPickerButton("Background Light", ModernUITheme.BACKGROUND_LIGHT, "background light");
        backgroundLightButton.addPropertyChangeListener("selectedColor", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                updateBackgroundColors();
            }
        });
        backgroundColorsPanel.add(backgroundLightButton);

        // Create accent color panel
        JPanel accentColorPanel = new JPanel(new GridLayout(0, 1, 0, 5));
        accentColorPanel.setOpaque(false);
        accentColorPanel.setBorder(BorderFactory.createTitledBorder("Accent Color"));

        // Create accent color button
        accentColorButton = new ColorPickerButton("Accent Color", ModernUITheme.ACCENT_PRIMARY, "accent");
        accentColorButton.addPropertyChangeListener("selectedColor", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                updateAccentColor();
            }
        });
        accentColorPanel.add(accentColorButton);

        // Add panels to main panel
        add(textColorsPanel);
        add(Box.createVerticalStrut(10));
        add(backgroundColorsPanel);
        add(Box.createVerticalStrut(10));
        add(accentColorPanel);
    }

    /**
     * Updates all text colors in the application
     */
    private void updateTextColors() {
        Color primaryColor = primaryTextColorButton.getSelectedColor();
        Color secondaryColor = secondaryTextColorButton.getSelectedColor();
        Color disabledColor = new Color(
            (primaryColor.getRed() + secondaryColor.getRed()) / 4,
            (primaryColor.getGreen() + secondaryColor.getGreen()) / 4,
            (primaryColor.getBlue() + secondaryColor.getBlue()) / 4
        );

        // Update text colors in ThemeManager
        ThemeManager.getInstance().updateTextColors(primaryColor, secondaryColor, disabledColor);

        // Force UI update by applying the theme
        SwingUtilities.invokeLater(() -> {
            // Get the window containing this component
            Window window = SwingUtilities.getWindowAncestor(ColorPickerPanel.this);
            if (window != null) {
                // Apply the current theme to this window only
                ModernUITheme.apply(window);
            } else {
                // Just update the theme in the ThemeManager if window not found
                ModernUITheme.apply();
            }

            // Fire property change event
            propertyChangeSupport.firePropertyChange("colorChanged", null, primaryColor);

            // Get the window and repaint it
            Window ancestorWindow = SwingUtilities.getWindowAncestor(ColorPickerPanel.this);
            if (ancestorWindow != null) {
                ancestorWindow.repaint();
            }
        });
    }

    /**
     * Updates all background colors in the application
     */
    private void updateBackgroundColors() {
        Color darkColor = backgroundDarkButton.getSelectedColor();
        Color lightColor = backgroundLightButton.getSelectedColor();

        // Calculate medium and darkest colors
        Color mediumColor = new Color(
            (darkColor.getRed() + lightColor.getRed()) / 2,
            (darkColor.getGreen() + lightColor.getGreen()) / 2,
            (darkColor.getBlue() + lightColor.getBlue()) / 2
        );

        Color darkestColor = new Color(
            Math.max(0, darkColor.getRed() - 20),
            Math.max(0, darkColor.getGreen() - 20),
            Math.max(0, darkColor.getBlue() - 20)
        );

        // Update background colors in ThemeManager
        ThemeManager.getInstance().updateBackgroundColors(darkestColor, darkColor, mediumColor, lightColor);

        // Force UI update by applying the theme
        SwingUtilities.invokeLater(() -> {
            // Get the window containing this component
            Window window = SwingUtilities.getWindowAncestor(ColorPickerPanel.this);
            if (window != null) {
                // Apply the current theme to this window only
                ModernUITheme.apply(window);
            } else {
                // Just update the theme in the ThemeManager if window not found
                ModernUITheme.apply();
            }

            // Fire property change event
            propertyChangeSupport.firePropertyChange("colorChanged", null, darkColor);

            // Get the window and repaint it
            Window ancestorWindow = SwingUtilities.getWindowAncestor(ColorPickerPanel.this);
            if (ancestorWindow != null) {
                ancestorWindow.repaint();
            }
        });
    }

    /**
     * Updates the accent color in the application
     */
    private void updateAccentColor() {
        Color accentColor = accentColorButton.getSelectedColor();

        // Calculate secondary accent color
        Color secondaryAccentColor = new Color(
            Math.max(0, accentColor.getRed() - 40),
            Math.max(0, accentColor.getGreen() - 40),
            Math.max(0, accentColor.getBlue() - 40)
        );

        // Update accent colors in ThemeManager
        ThemeManager.getInstance().updateAccentColors(accentColor, secondaryAccentColor);

        // Force UI update by applying the theme
        SwingUtilities.invokeLater(() -> {
            // Get the window containing this component
            Window window = SwingUtilities.getWindowAncestor(ColorPickerPanel.this);
            if (window != null) {
                // Apply the current theme to this window only
                ModernUITheme.apply(window);
            } else {
                // Just update the theme in the ThemeManager if window not found
                ModernUITheme.apply();
            }

            // Fire property change event
            propertyChangeSupport.firePropertyChange("colorChanged", null, accentColor);

            // Get the window and repaint it
            Window ancestorWindow = SwingUtilities.getWindowAncestor(ColorPickerPanel.this);
            if (ancestorWindow != null) {
                ancestorWindow.repaint();
            }
        });
    }

    /**
     * Resets all colors to the default theme
     */
    public void resetToDefault() {
        // Reset to default theme
        ThemeManager.getInstance().setCurrentTheme("Dark");

        // Update button colors
        primaryTextColorButton.setSelectedColor(ModernUITheme.TEXT_PRIMARY);
        secondaryTextColorButton.setSelectedColor(ModernUITheme.TEXT_SECONDARY);
        backgroundDarkButton.setSelectedColor(ModernUITheme.BACKGROUND_DARK);
        backgroundLightButton.setSelectedColor(ModernUITheme.BACKGROUND_LIGHT);
        accentColorButton.setSelectedColor(ModernUITheme.ACCENT_PRIMARY);
    }

    /**
     * Adds a property change listener
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    /**
     * Adds a property change listener for a specific property
     */
    public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
    }

    /**
     * Removes a property change listener
     */
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }

    /**
     * Removes a property change listener for a specific property
     */
    public void removePropertyChangeListener(String propertyName, PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(propertyName, listener);
    }
}
