package core.gui.components;

import javax.swing.*;
import java.awt.*;

public class Icons {
    // Common action icons
    public static final Icon SAVE = createIcon("save", "Save");
    public static final Icon DELETE = createIcon("delete", "Delete");
    public static final Icon APPLY = createIcon("check", "Apply");
    public static final Icon REFRESH = createIcon("refresh", "Refresh");
    public static final Icon ADD = createIcon("add", "Add");
    public static final Icon EDIT = createIcon("edit", "Edit");
    public static final Icon SETTINGS = createIcon("settings", "Settings");
    public static final Icon PLAY = createIcon("play", "Play");
    public static final Icon PROFILE = createIcon("profile", "Profile");
    public static final Icon LOAD = createIcon("load", "Load");
    public static final Icon LOCATION = createIcon("location", "Location");
    public static final Icon CANCEL = createIcon("cancel", "Cancel");
    public static final Icon LINK = createIcon("link", "Link");
    public static final Icon UNLINK = createIcon("unlink", "Unlink");
    public static final Icon EQUIPMENT = createIcon("equipment", "Equipment");
    public static final Icon INVENTORY = createIcon("inventory", "Inventory");

    private static Icon createIcon(String name, String description) {
        // Create a simple Unicode symbol icon as a fallback
        String symbol = getSymbolForName(name);
        return new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setColor(c.getForeground());
                g2.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
                g2.drawString(symbol, x, y + 16);
                g2.dispose();
            }

            @Override
            public int getIconWidth() {
                return 16;
            }

            @Override
            public int getIconHeight() {
                return 16;
            }
        };
    }

    private static String getSymbolForName(String name) {
        switch (name.toLowerCase()) {
            case "save": return "💾";
            case "delete": return "🗑";
            case "check":
            case "apply": return "✓";
            case "refresh": return "🔄";
            case "add": return "➕";
            case "edit": return "✎";
            case "settings": return "⚙";
            case "play": return "▶";
            case "profile": return "📋";
            case "load": return "📥";
            case "location": return "📍";
            case "cancel": return "✖";
            case "link": return "🔗";
            case "unlink": return "⛓";
            case "equipment": return "🛡";
            case "inventory": return "🎒";
            default: return "•";
        }
    }
}
