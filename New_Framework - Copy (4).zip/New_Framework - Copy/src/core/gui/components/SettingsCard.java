package core.gui.components;

import core.gui.style.StyleManager;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

/**
 * A modern card component for settings with a title, content area, and optional actions.
 * Provides a consistent visual style for grouping related settings.
 */
public class SettingsCard extends JPanel {
    private final JPanel headerPanel;
    private final JPanel contentPanel;
    private final JPanel actionsPanel;
    private final JLabel titleLabel;
    private final JLabel subtitleLabel;

    /**
     * Creates a new settings card with the given title
     *
     * @param title The card title
     */
    public SettingsCard(String title) {
        this(title, null);
    }

    /**
     * Creates a new settings card with the given title and subtitle
     *
     * @param title The card title
     * @param subtitle The card subtitle
     */
    public SettingsCard(String title, String subtitle) {
        super(new BorderLayout(0, 0));
        setBackground(StyleManager.CARD_BG);
        setBorder(StyleManager.CARD_BORDER);

        // Create header panel
        headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(StyleManager.CARD_BG);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(8, 16, 8, 16)
        ));

        // Create title panel
        JPanel titlePanel = new JPanel(new GridBagLayout());
        titlePanel.setBackground(StyleManager.CARD_BG);
        titlePanel.setBorder(null);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // Create title label
        titleLabel = new JLabel(title);
        titleLabel.setFont(StyleManager.HEADER_FONT_SMALL);
        titleLabel.setForeground(StyleManager.FOREGROUND);
        titlePanel.add(titleLabel, gbc);

        // Create subtitle label if provided
        if (subtitle != null && !subtitle.isEmpty()) {
            subtitleLabel = new JLabel(subtitle);
            subtitleLabel.setFont(StyleManager.SMALL_FONT);
            subtitleLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);

            gbc.gridy = 1;
            gbc.insets = new Insets(4, 0, 0, 0);
            titlePanel.add(subtitleLabel, gbc);
        } else {
            subtitleLabel = null;
        }

        // Create actions panel
        actionsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actionsPanel.setBackground(StyleManager.CARD_BG);
        actionsPanel.setBorder(null);

        // Add panels to header
        headerPanel.add(titlePanel, BorderLayout.CENTER);
        headerPanel.add(actionsPanel, BorderLayout.EAST);

        // Create content panel
        contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(StyleManager.CARD_BG);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));

        // Add panels to main panel
        add(headerPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
    }

    /**
     * Sets the card title
     *
     * @param title The card title
     */
    public void setTitle(String title) {
        titleLabel.setText(title);
    }

    /**
     * Sets the card subtitle
     *
     * @param subtitle The card subtitle
     */
    public void setSubtitle(String subtitle) {
        if (subtitleLabel != null) {
            subtitleLabel.setText(subtitle);
        }
    }

    /**
     * Adds an action button to the card header
     *
     * @param button The button to add
     */
    public void addAction(JButton button) {
        actionsPanel.add(button);
    }

    /**
     * Sets the content component
     *
     * @param component The content component
     */
    public void setContent(JComponent component) {
        contentPanel.removeAll();
        contentPanel.add(component);
        revalidate();
        repaint();
    }

    /**
     * Adds a component to the content panel
     *
     * @param component The component to add
     */
    public void addContent(JComponent component) {
        contentPanel.add(component);
        revalidate();
        repaint();
    }

    /**
     * Adds a component to the content panel with the specified constraints
     *
     * @param component The component to add
     * @param constraints The constraints to use
     */
    public void addContent(JComponent component, Object constraints) {
        contentPanel.add(component, constraints);
        revalidate();
        repaint();
    }

    /**
     * Gets the content panel
     *
     * @return The content panel
     */
    public JPanel getContentPanel() {
        return contentPanel;
    }

    /**
     * Sets the content panel border
     *
     * @param border The border to set
     */
    public void setContentBorder(Border border) {
        contentPanel.setBorder(border);
    }

    /**
     * Sets the content panel layout
     *
     * @param layout The layout to set
     */
    public void setContentLayout(LayoutManager layout) {
        contentPanel.setLayout(layout);
    }
}
