package core.gui.components;

import core.gui.style.ModernUITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.geom.RoundRectangle2D;

/**
 * A modern text field with rounded corners, animated focus effect,
 * and optional placeholder text.
 */
public class ModernTextField extends JTextField {
    private String placeholder;
    private boolean focused = false;
    private final Timer animationTimer;
    private float animationProgress = 0.0f;
    private final int animationDuration = ModernUITheme.ANIMATION_DURATION_SHORT;
    private final int animationSteps = 10;
    private final float animationStepSize = 1.0f / animationSteps;
    
    /**
     * Creates a new modern text field
     */
    public ModernTextField() {
        this("");
    }
    
    /**
     * Creates a new modern text field with the specified placeholder text
     * 
     * @param placeholder The placeholder text
     */
    public ModernTextField(String placeholder) {
        super();
        this.placeholder = placeholder;
        
        // Configure text field
        setOpaque(false);
        setBorder(new EmptyBorder(ModernUITheme.SPACING_SMALL, 
                                ModernUITheme.SPACING_MEDIUM, 
                                ModernUITheme.SPACING_SMALL, 
                                ModernUITheme.SPACING_MEDIUM));
        setFont(ModernUITheme.FONT_REGULAR);
        setForeground(ModernUITheme.TEXT_PRIMARY);
        setCaretColor(ModernUITheme.TEXT_PRIMARY);
        setSelectionColor(ModernUITheme.ACCENT_PRIMARY);
        setSelectedTextColor(ModernUITheme.TEXT_PRIMARY);
        
        // Create animation timer
        animationTimer = new Timer(animationDuration / animationSteps, e -> {
            if (focused) {
                animationProgress = Math.min(1.0f, animationProgress + animationStepSize);
            } else {
                animationProgress = Math.max(0.0f, animationProgress - animationStepSize);
            }
            
            if ((animationProgress >= 1.0f && focused) || 
                (animationProgress <= 0.0f && !focused)) {
                ((Timer) e.getSource()).stop();
            }
            
            repaint();
        });
        
        // Add focus listener for animation
        addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                focused = true;
                animationTimer.start();
            }
            
            @Override
            public void focusLost(FocusEvent e) {
                focused = false;
                animationTimer.start();
            }
        });
    }
    
    /**
     * Sets the placeholder text
     * 
     * @param placeholder The placeholder text
     */
    public void setPlaceholder(String placeholder) {
        this.placeholder = placeholder;
        repaint();
    }
    
    /**
     * Gets the placeholder text
     * 
     * @return The placeholder text
     */
    public String getPlaceholder() {
        return placeholder;
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int width = getWidth();
        int height = getHeight();
        
        // Draw background
        g2.setColor(ModernUITheme.BACKGROUND_LIGHT);
        g2.fill(new RoundRectangle2D.Double(0, 0, width, height, 
                ModernUITheme.FIELD_RADIUS, ModernUITheme.FIELD_RADIUS));
        
        // Draw border with animation
        Color borderColor = blendColors(
                new Color(ModernUITheme.BACKGROUND_LIGHT.getRed() + 20, 
                        ModernUITheme.BACKGROUND_LIGHT.getGreen() + 20, 
                        ModernUITheme.BACKGROUND_LIGHT.getBlue() + 20),
                ModernUITheme.ACCENT_PRIMARY,
                animationProgress
        );
        
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(1.5f));
        g2.draw(new RoundRectangle2D.Double(0.75, 0.75, width - 1.5, height - 1.5, 
                ModernUITheme.FIELD_RADIUS, ModernUITheme.FIELD_RADIUS));
        
        g2.dispose();
        
        super.paintComponent(g);
        
        // Draw placeholder text if needed
        if (placeholder != null && !placeholder.isEmpty() && getText().isEmpty() && !focused) {
            Graphics2D g3 = (Graphics2D) g.create();
            g3.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g3.setColor(ModernUITheme.TEXT_DISABLED);
            g3.setFont(getFont());
            
            FontMetrics fm = g3.getFontMetrics();
            int x = getInsets().left;
            int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            
            g3.drawString(placeholder, x, y);
            g3.dispose();
        }
    }
    
    /**
     * Blends two colors based on the specified ratio
     */
    private Color blendColors(Color c1, Color c2, float ratio) {
        int r = (int) (c1.getRed() + (c2.getRed() - c1.getRed()) * ratio);
        int g = (int) (c1.getGreen() + (c2.getGreen() - c1.getGreen()) * ratio);
        int b = (int) (c1.getBlue() + (c2.getBlue() - c1.getBlue()) * ratio);
        
        return new Color(r, g, b);
    }
}
