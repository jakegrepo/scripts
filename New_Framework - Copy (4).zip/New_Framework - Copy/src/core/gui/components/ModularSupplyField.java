package core.gui.components;

import core.gui.style.StyleManager;

import javax.swing.*;

public class ModularSupplyField extends JPanel {
    private final JTextField itemField;
    private final JSpinner quantitySpinner;

    public ModularSupplyField() {
        this.itemField = new JTextField(10);
        StyleManager.styleTextField(itemField);

        SpinnerNumberModel spinnerModel = new SpinnerNumberModel(0, 0, 999999, 1);
        this.quantitySpinner = new JSpinner(spinnerModel);
        StyleManager.styleSpinner(quantitySpinner);
    }

    public JTextField getItemField() {
        return itemField;
    }

    public JSpinner getQuantitySpinner() {
        return quantitySpinner;
    }

    public void setItem(String item) {
        itemField.setText(item);
    }

    public String getItem() {
        return itemField.getText().trim();
    }

    public void setQuantity(int quantity) {
        quantitySpinner.setValue(quantity);
    }

    public int getQuantity() {
        return (int) quantitySpinner.getValue();
    }
} 