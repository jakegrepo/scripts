package core.gui.components;

import core.gui.style.ModernUITheme;
import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A modern sidebar navigation panel that replaces the traditional tabbed pane
 * with a vertical sidebar for better visual organization and space efficiency.
 */
public class SidebarNavigationPanel extends JPanel {
    private final JPanel sidebarPanel;
    private final JPanel contentPanel;
    private final CardLayout cardLayout;
    private final ButtonGroup buttonGroup;
    private final Map<String, JToggleButton> buttons;
    private final List<String> tabNames;
    private final List<Component> tabComponents;
    private String selectedTab;

    /**
     * Creates a new sidebar navigation panel
     */
    public SidebarNavigationPanel() {
        super(new BorderLayout(0, 0));
        setBackground(ModernUITheme.BACKGROUND_DARKEST);
        setBorder(null);

        // Initialize collections
        buttons = new HashMap<>();
        tabNames = new ArrayList<>();
        tabComponents = new ArrayList<>();
        buttonGroup = new ButtonGroup();

        // Create sidebar panel with gradient background
        sidebarPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Paint gradient background using theme colors
                GradientPaint gradient = ModernUITheme.getGradientSidebar();
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                g2d.dispose();
            }
        };
        sidebarPanel.setLayout(new BoxLayout(sidebarPanel, BoxLayout.Y_AXIS));
        sidebarPanel.setOpaque(false);
        sidebarPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1,
                new Color(ModernUITheme.ACCENT_PRIMARY.getRed(),
                         ModernUITheme.ACCENT_PRIMARY.getGreen(),
                         ModernUITheme.ACCENT_PRIMARY.getBlue(), 40)));
        sidebarPanel.setPreferredSize(new Dimension(200, 0));

        // Add a small top padding to the sidebar
        sidebarPanel.add(Box.createVerticalStrut(ModernUITheme.SPACING_SMALL));

        // Create content panel with card layout
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(ModernUITheme.BACKGROUND_DARK);
        contentPanel.setBorder(null);

        // Add panels to main panel
        add(sidebarPanel, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
    }

    /**
     * Adds a tab to the sidebar navigation
     *
     * @param title The tab title
     * @param component The tab component
     */
    public void addTab(String title, Component component) {
        // Create a unique name for the card
        String name = "tab_" + tabNames.size();

        // Add to collections
        tabNames.add(name);
        tabComponents.add(component);

        // Create sidebar button
        JToggleButton button = createSidebarButton(title, name);
        buttons.put(name, button);

        // Add button to sidebar
        sidebarPanel.add(button);

        // Add component to content panel
        contentPanel.add(component, name);

        // Select first tab by default
        if (tabNames.size() == 1) {
            setSelectedTab(name);
        }

        // Add spacing between buttons
        sidebarPanel.add(Box.createVerticalStrut(ModernUITheme.SPACING_TINY));
    }

    /**
     * Creates a sidebar button with modern styling
     */
    private JToggleButton createSidebarButton(String title, String name) {
        // Create a SidebarButton with modern styling
        SidebarButton button = new SidebarButton(title);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));

        // Add to button group
        buttonGroup.add(button);

        // Add action listener
        button.addActionListener(e -> {
            // Deselect all buttons first to avoid multiple selections
            for (Map.Entry<String, JToggleButton> entry : buttons.entrySet()) {
                if (!entry.getKey().equals(name)) {
                    entry.getValue().setSelected(false);
                }
            }
            button.setSelected(true);
            setSelectedTab(name);
        });

        return button;
    }

    /**
     * Sets the selected tab
     *
     * @param name The tab name
     */
    public void setSelectedTab(String name) {
        // Update selected tab
        selectedTab = name;

        // Show selected tab content
        cardLayout.show(contentPanel, name);

        // Reset all buttons first
        for (JToggleButton btn : buttons.values()) {
            btn.setSelected(false);
        }

        // Update button states
        JToggleButton button = buttons.get(name);
        if (button != null) {
            button.setSelected(true);
        }

        // Update styles for all buttons
        updateButtonStyles();
    }

    /**
     * Updates the styles of all buttons based on selection state
     */
    private void updateButtonStyles() {
        // First, reset all buttons to unselected style
        for (Map.Entry<String, JToggleButton> entry : buttons.entrySet()) {
            JToggleButton button = entry.getValue();
            if (!button.isSelected()) {
                // Unselected button style
                button.setContentAreaFilled(false);
                button.setForeground(ModernUITheme.TEXT_SECONDARY);
                button.setFont(ModernUITheme.FONT_REGULAR);
                button.setBorder(BorderFactory.createEmptyBorder(12, 15, 12, 15));
            }
        }

        // Then, apply selected style to the selected button
        JToggleButton selectedButton = buttons.get(selectedTab);
        if (selectedButton != null) {
            // Selected button style
            selectedButton.setContentAreaFilled(true);
            selectedButton.setBackground(new Color(
                    ModernUITheme.ACCENT_PRIMARY.getRed(),
                    ModernUITheme.ACCENT_PRIMARY.getGreen(),
                    ModernUITheme.ACCENT_PRIMARY.getBlue(), 80));
            selectedButton.setForeground(ModernUITheme.TEXT_PRIMARY);
            selectedButton.setFont(ModernUITheme.FONT_REGULAR);
            selectedButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 3, 0, 0, ModernUITheme.ACCENT_PRIMARY),
                BorderFactory.createEmptyBorder(12, 12, 12, 15)
            ));
            selectedButton.setSelected(true);
        }
    }

    /**
     * Gets the selected tab name
     *
     * @return The selected tab name
     */
    public String getSelectedTab() {
        return selectedTab;
    }

    /**
     * Gets the selected tab component
     *
     * @return The selected tab component
     */
    public Component getSelectedComponent() {
        int index = tabNames.indexOf(selectedTab);
        if (index >= 0 && index < tabComponents.size()) {
            return tabComponents.get(index);
        }
        return null;
    }

    /**
     * Gets the number of tabs
     *
     * @return The number of tabs
     */
    public int getTabCount() {
        return tabNames.size();
    }
}
