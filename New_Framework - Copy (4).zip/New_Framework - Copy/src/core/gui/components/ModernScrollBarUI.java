package core.gui.components;

import core.gui.style.ModernUITheme;

import javax.swing.*;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/**
 * A modern scroll bar UI with a sleek design.
 */
public class ModernScrollBarUI extends BasicScrollBarUI {
    private final int THUMB_SIZE = 8;
    
    @Override
    protected JButton createDecreaseButton(int orientation) {
        return createZeroButton();
    }
    
    @Override
    protected JButton createIncreaseButton(int orientation) {
        return createZeroButton();
    }
    
    private JButton createZeroButton() {
        JButton button = new JButton();
        button.setPreferredSize(new Dimension(0, 0));
        button.setMinimumSize(new Dimension(0, 0));
        button.setMaximumSize(new Dimension(0, 0));
        return button;
    }
    
    @Override
    protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Paint track background
        g2.setColor(ModernUITheme.BACKGROUND_MEDIUM);
        g2.fillRect(trackBounds.x, trackBounds.y, trackBounds.width, trackBounds.height);
        
        g2.dispose();
    }
    
    @Override
    protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
        if (thumbBounds.isEmpty() || !scrollbar.isEnabled()) {
            return;
        }
        
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Calculate thumb size and position
        int x = thumbBounds.x;
        int y = thumbBounds.y;
        int width = thumbBounds.width;
        int height = thumbBounds.height;
        
        if (scrollbar.getOrientation() == JScrollBar.VERTICAL) {
            x = thumbBounds.x + (thumbBounds.width - THUMB_SIZE) / 2;
            width = THUMB_SIZE;
        } else {
            y = thumbBounds.y + (thumbBounds.height - THUMB_SIZE) / 2;
            height = THUMB_SIZE;
        }
        
        // Paint thumb
        Color thumbColor = ModernUITheme.ACCENT_PRIMARY;
        if (isDragging) {
            thumbColor = new Color(
                    Math.max(0, thumbColor.getRed() - 20),
                    Math.max(0, thumbColor.getGreen() - 20),
                    Math.max(0, thumbColor.getBlue() - 20)
            );
        } else if (isThumbRollover()) {
            thumbColor = new Color(
                    Math.min(255, thumbColor.getRed() + 20),
                    Math.min(255, thumbColor.getGreen() + 20),
                    Math.min(255, thumbColor.getBlue() + 20)
            );
        }
        
        g2.setColor(thumbColor);
        g2.fill(new RoundRectangle2D.Double(x, y, width, height, 4, 4));
        
        g2.dispose();
    }
    
    @Override
    protected void setThumbBounds(int x, int y, int width, int height) {
        super.setThumbBounds(x, y, width, height);
        scrollbar.repaint();
    }
}
