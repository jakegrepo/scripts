package core.gui;

import core.base.ScarScript;
import core.context.ContextProvider;
import core.context.ScriptContext;
import core.gui.components.Icons;
import core.gui.components.SidebarButton;
import core.gui.style.StyleManager;
import core.state.ScriptState;


import javax.swing.*;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Main GUI frame for script settings.
 * Handles multiple settings tabs and provides consistent styling.
 */
public class ScriptGUI extends ContextProvider {
    private final JFrame frame;
    private final List<AbstractSettingsTab> tabs;
    private final String scriptName;
    private final ScriptContext context;

    // Control buttons
    private JButton startButton;
    private JButton loadProfileButton;
    private JButton saveButton;
    private JButton removeProfileButton;

    // Layout components
    private CardLayout cardLayout;
    private JPanel cardPanel;
    private Map<String, SidebarButton> sidebarButtons;
    private JPanel mainPanel;
    private JPanel sidebar;
    private ButtonGroup sidebarButtonGroup;

    public ScriptGUI(ScriptContext context) {
        super(context);
        this.context = context;
        this.scriptName = context.getScript().getClass().getSimpleName();
        this.tabs = new ArrayList<>();
        this.sidebarButtons = new HashMap<>();
        this.sidebarButtonGroup = new ButtonGroup();
        
        this.frame = new JFrame(scriptName);
        initializeGUI();
    }

    private void initializeGUI() {
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout(0, 0));
        frame.setResizable(true);
        frame.setMinimumSize(StyleManager.MIN_WINDOW_SIZE);

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                handleClose();
            }
        });

        // Create main container
        mainPanel = new JPanel(new BorderLayout(0, 0));
        StyleManager.applyStyle(mainPanel);

        // Create sidebar
        sidebar = createSidebar();
        mainPanel.add(sidebar, BorderLayout.WEST);

        // Create content area with card layout
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        StyleManager.applyStyle(cardPanel);
        cardPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create content wrapper
        JPanel contentWrapper = new JPanel(new BorderLayout());
        StyleManager.applyStyle(contentWrapper);
        contentWrapper.add(cardPanel, BorderLayout.CENTER);

        // Add control panel at bottom
        JPanel controlPanel = createControlPanel();
        contentWrapper.add(controlPanel, BorderLayout.SOUTH);

        mainPanel.add(contentWrapper, BorderLayout.CENTER);
        frame.add(mainPanel);
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(StyleManager.SIDEBAR_BG);
        sidebar.setPreferredSize(new Dimension(200, 0));
        sidebar.setBorder(new MatteBorder(0, 0, 0, 1, StyleManager.BORDER_COLOR));

        // Navigation panel for buttons
        JPanel navPanel = new JPanel();
        navPanel.setLayout(new BoxLayout(navPanel, BoxLayout.Y_AXIS));
        navPanel.setBackground(StyleManager.SIDEBAR_BG);
        navPanel.setBorder(BorderFactory.createEmptyBorder(15, 10, 10, 10));
        
        // Set name for easy retrieval
        navPanel.setName("navPanel");
        
        sidebar.add(navPanel);
        sidebar.add(Box.createVerticalGlue());
        return sidebar;
    }

    public void addSettingsTab(AbstractSettingsTab tab) {
        if (!tabs.contains(tab)) {
            tabs.add(tab);
        }
    }

    public void addPanel(String name, JPanel panel) {
        SwingUtilities.invokeLater(() -> {
            // Skip if panel already exists
            if (sidebarButtons.containsKey(name)) {
                return;
            }

            // Create scroll pane for the panel
            JScrollPane scrollPane = new JScrollPane(panel);
            scrollPane.setBorder(null);
            scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            scrollPane.getVerticalScrollBar().setUnitIncrement(16);
            StyleManager.applyStyle(scrollPane);
            
            // Add to card layout
            cardPanel.add(scrollPane, name);

            // Create and add sidebar button
            SidebarButton btn = new SidebarButton(name);
            btn.addActionListener(e -> {
                cardLayout.show(cardPanel, name);
                btn.setSelected(true);
            });
            btn.setAlignmentX(Component.LEFT_ALIGNMENT);
            
            // Add button to button group
            sidebarButtonGroup.add(btn);
            
            // Find navigation panel and add button
            for (Component comp : sidebar.getComponents()) {
                if (comp instanceof JPanel && "navPanel".equals(comp.getName())) {
                    JPanel navPanel = (JPanel) comp;
                    navPanel.add(btn);
                    navPanel.add(Box.createVerticalStrut(5));
                    break;
                }
            }
            
            // Select first button by default
            if (sidebarButtons.isEmpty()) {
                btn.setSelected(true);
                cardLayout.show(cardPanel, name);
            }
            
            sidebarButtons.put(name, btn);
            sidebar.revalidate();
            sidebar.repaint();
        });
    }

    private JPanel createControlPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
        StyleManager.applyStyle(panel);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(15, 5, 5, 5)
        ));

        // Left-aligned buttons
        JPanel leftButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        leftButtons.setOpaque(false);
        
        startButton = new JButton("Start", Icons.PLAY);

        StyleManager.styleButton(startButton);

        leftButtons.add(startButton);

        // Right-aligned buttons
        JPanel rightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightButtons.setOpaque(false);

        loadProfileButton = new JButton("Load Profile", Icons.PROFILE);
        saveButton = new JButton("Save", Icons.SAVE);
        removeProfileButton = new JButton("Remove Profile", Icons.DELETE);

        StyleManager.styleButton(loadProfileButton);
        StyleManager.styleButton(saveButton);
        StyleManager.styleButton(removeProfileButton);

        rightButtons.add(loadProfileButton);
        rightButtons.add(saveButton);
        rightButtons.add(removeProfileButton);

        // Add button groups with spacing
        panel.add(leftButtons);
        panel.add(Box.createHorizontalGlue());
        panel.add(rightButtons);

        // Add button listeners
        startButton.addActionListener(e -> handleStart());


        return panel;
    }

    /**
     * Gets the script context
     */
    public ScriptContext getContext() {
        return context;
    }

    /**
     * Gets the ScarScript instance
     */
    private ScarScript<?> getScript() {
        return (ScarScript<?>) context.getScript();
    }

    /**
     * Shows the GUI and brings it to front
     */
    public void show() {
        SwingUtilities.invokeLater(() -> {
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            frame.toFront();
            frame.requestFocus();
            
            // Show first panel by default if it exists
            if (!sidebarButtons.isEmpty()) {
                String firstKey = sidebarButtons.keySet().iterator().next();
                cardLayout.show(cardPanel, firstKey);
                sidebarButtons.get(firstKey).setSelected(true);
            }
            
            setState(ScriptState.STOPPED);
            updateControlButtons();
        });
    }

    private void handleStart() {
        saveAllSettings();
        context.data().setGlobal("gui_completed", true);
        getScript().start();
        frame.dispose();
    }

    private void handleStop() {
        getScript().stop();
        updateControlButtons();
    }

    private void handleSave() {
        saveAllSettings();
        debug("Settings saved");
    }

    private void handleReset() {
        if (JOptionPane.showConfirmDialog(frame,
                "Reset all settings to defaults?",
                "Confirm Reset",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            resetAllSettings();
            debug("Settings reset to defaults");
        }
    }

    private void handleClose() {
        saveAllSettings();
        frame.dispose();
    }

    private void updateControlButtons() {
        ScriptState state = getScript().getState();
        debug("Current script state: " + state);
        startButton.setEnabled(state == ScriptState.STOPPED || state == ScriptState.STARTING);
    }
    private void saveAllSettings() {
        for (AbstractSettingsTab tab : tabs) {
            tab.saveSettings();
        }
    }

    private void resetAllSettings() {
        for (AbstractSettingsTab tab : tabs) {
            tab.resetToDefaults();
        }
    }


    /**
     * Checks if the GUI is visible
     */
    public boolean isVisible() {
        return frame.isVisible();
    }

    /**
     * Disposes of the GUI
     */
    public void dispose() {
        frame.setVisible(false);
        frame.dispose();
    }
}
