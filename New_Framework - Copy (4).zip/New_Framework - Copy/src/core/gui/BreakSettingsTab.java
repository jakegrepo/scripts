package core.gui;

import core.base.ScarScript;
import core.context.ScriptContext;
import core.gui.panels.BreakSettingsPanel;
import core.gui.style.StyleManager;

import javax.swing.*;
import java.awt.*;
import java.io.File;

/**
 * Break settings tab for framework-wide break settings
 */
public class BreakSettingsTab extends AbstractSettingsTab {
    private BreakSettingsPanel breakPanel;

    /**
     * Creates a new break settings tab
     */
    public BreakSettingsTab(ScriptContext context) {
        super(context);
        
        // Create panel
        breakPanel = new BreakSettingsPanel(((ScarScript<?>) context.getScript()).getConfig());
        
        // Add panel to main panel
        addSection("Break Settings", breakPanel);
    }

    @Override
    public void createComponents() {
        // No additional components needed
    }

    @Override
    public void saveSettings() {
        debug("Saving break settings");
        // Save panel settings
        breakPanel.saveSettings();
        
        // Save config to file
        ((ScarScript<?>) context.getScript()).getConfig().saveConfig();
    }

    @Override
    public void loadSettings() {
        debug("Loading break settings");
        // Load panel settings
        breakPanel.loadSettings();
    }

    @Override
    public void resetToDefaults() {
        debug("Resetting break settings to defaults");
        // Reset panel to defaults
        breakPanel.loadSettings();
    }

    @Override
    public String getTitle() {
        return "Breaks";
    }

    @Override
    protected File getProfilesDirectory() {
        File dir = new File("ScarFramework/profiles/framework/");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }
}
