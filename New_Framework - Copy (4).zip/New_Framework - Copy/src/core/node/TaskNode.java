package core.node;

import core.context.ContextProvider;
import core.context.ScriptContext;
import core.state.ScriptState;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Base class for all script task nodes.
 * Provides core functionality and easy access to framework services.
 */
public abstract class TaskNode extends ContextProvider {
    private final String name;
    private final int priority;
    private String status;
    private long lastExecutionTime;
    private boolean isEnabled;
    private List<Consumer<String>> statusListeners = new ArrayList<>();

    protected TaskNode(ScriptContext context, String name, int priority) {
        super(context);
        this.name = name;
        this.priority = priority;
        this.status = "Initialized";
        this.lastExecutionTime = 0;
        this.isEnabled = true;
    }

    /**
     * Validates if this node should execute.
     * Must be implemented by concrete nodes.
     */
    public abstract boolean validate();

    /**
     * Executes the node's logic.
     * Must be implemented by concrete nodes.
     * @return Sleep time in milliseconds
     */
    protected abstract int execute();

    /**
     * Called by the TaskNodeManager to run this node.
     * Handles execution tracking and status updates.
     */
    public final int executeNode() {
        try {
            if (!isEnabled) {
                return 1000;
            }

            lastExecutionTime = System.currentTimeMillis();
            debug(String.format("Executing node: %s", getName()));
            
            int sleepTime = execute();
            
            debug(String.format("Node execution complete: %s (Sleep: %dms)", getName(), sleepTime));
            return sleepTime;
            
        } catch (Exception e) {
            error(String.format("Error executing node: %s", getName()), e);
            setState(ScriptState.ERROR);
            return 5000;
        }
    }

    /**
     * Cleanup method called when script is stopping or node is being removed
     */
    public void cleanup() {
        debug("Cleaning up node: " + getName());
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public int getPriority() {
        return priority;
    }

    public String getStatus() {
        return status;
    }

    protected void setStatus(String status) {
        this.status = status;
        // Notify all listeners of the status change
        for (Consumer<String> listener : statusListeners) {
            listener.accept(status);
        }
        debug(String.format("Node status updated - %s: %s", getName(), status));
    }

    public long getLastExecutionTime() {
        return lastExecutionTime;
    }

    public boolean isEnabled() {
        return isEnabled;
    }

    public void setEnabled(boolean enabled) {
        this.isEnabled = enabled;
        log(String.format("Node %s %s", getName(), enabled ? "enabled" : "disabled"));
    }

    /**
     * Time since last execution in milliseconds
     */
    public long getTimeSinceLastExecution() {
        return System.currentTimeMillis() - lastExecutionTime;
    }

    public void addStatusListener(Consumer<String> listener) {
        statusListeners.add(listener);
    }

    public void removeStatusListener(Consumer<String> listener) {
        statusListeners.remove(listener);
    }

    @Override
    public String toString() {
        return String.format("Node[name=%s, priority=%d, status=%s, enabled=%s]",
            name, priority, status, isEnabled);
    }
} 