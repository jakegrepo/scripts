package core.node;

import core.context.ContextProvider;
import core.context.ScriptContext;
import core.state.ScriptState;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Manages the registration and execution of script task nodes.
 */
public class TaskNodeManager extends ContextProvider {
    private final List<TaskNode> nodes;
    private TaskNode activeNode;
    private final Map<String, Long> nodeExecutionTimes;

    public TaskNodeManager(ScriptContext context) {
        super(context);
        this.nodes = new CopyOnWriteArrayList<>();
        this.nodeExecutionTimes = new HashMap<>();
    }

    /**
     * Initializes the node manager
     */
    public void initialize() {
        nodes.clear();
        nodeExecutionTimes.clear();
        activeNode = null;
        log("TaskNodeManager initialized");
    }

    /**
     * Shuts down the node manager
     */
    public void shutdown() {
        nodes.clear();
        nodeExecutionTimes.clear();
        activeNode = null;
        log("TaskNodeManager shut down");
    }

    /**
     * Adds a node to the manager
     */
    public void addNode(TaskNode node) {
        if (node == null) {
            error("Attempted to add null node", new IllegalArgumentException());
            return;
        }

        if (nodes.stream().anyMatch(n -> n.getName().equals(node.getName()))) {
            error("Node with name " + node.getName() + " already exists",
                  new IllegalArgumentException());
            return;
        }

        nodes.add(node);
        sortNodes();
        log("Added node: " + node.getName() + " (Priority: " + node.getPriority() + ")");
    }

    /**
     * Removes a node from the manager
     */
    public void removeNode(String nodeName) {
        nodes.removeIf(node -> node.getName().equals(nodeName));
        log("Removed node: " + nodeName);
    }

    /**
     * Clears all nodes
     */
    public void clearNodes() {
        nodes.clear();
        nodeExecutionTimes.clear();
        activeNode = null;
        log("All nodes cleared");
    }

    /**
     * Executes the highest priority valid node
     * @return Sleep time in milliseconds
     */
    public int execute() {
        if (context.state().getCurrentState() == ScriptState.STOPPED) {
            return 1000;
        }

        // Find lowest priority valid node (lower number = higher priority)
        TaskNode nodeToExecute = null;
        int lowestPriority = Integer.MAX_VALUE;

        for (TaskNode node : nodes) {
            try {
                if (node.validate()) {
                    int priority = node.getPriority();
                    if (priority < lowestPriority) {
                        lowestPriority = priority;
                        nodeToExecute = node;
                    }
                }
            } catch (Exception e) {
                logger.error("Error validating node " + node.getName() + ": " + e.getMessage(), e);
            }
        }

        if (nodeToExecute != null) {
            activeNode = nodeToExecute;
            try {
                int sleepTime = nodeToExecute.execute();
                // Record execution time
                nodeExecutionTimes.put(nodeToExecute.getName(), System.currentTimeMillis());
                return sleepTime;
            } catch (Exception e) {
                logger.error("Error executing node " + nodeToExecute.getName() + ": " + e.getMessage(), e);
                return 1000;
            }
        } else {
            // No valid node found - set activeNode to null
            activeNode = null;
            logger.debug("No valid node found to execute");
            return 1000;
        }
    }

    /**
     * Sorts nodes by priority (highest first)
     */
    private void sortNodes() {
        nodes.sort((n1, n2) -> Integer.compare(n2.getPriority(), n1.getPriority()));
    }

    // Getters
    public List<TaskNode> getNodes() {
        return Collections.unmodifiableList(nodes);
    }

    public TaskNode getActiveNode() {
        return activeNode; // Can be null if no node is active
    }

    /**
     * Checks if there is an active node
     * @return true if there is an active node, false otherwise
     */
    public boolean hasActiveNode() {
        return activeNode != null;
    }

    public Map<String, Long> getNodeExecutionTimes() {
        return Collections.unmodifiableMap(nodeExecutionTimes);
    }

    public int getNodeCount() {
        return nodes.size();
    }

    /**
     * Gets execution statistics for all nodes
     */
    public String getNodeStats() {
        StringBuilder stats = new StringBuilder("Node Statistics:\n");
        for (TaskNode node : nodes) {
            stats.append(String.format("- %s (Priority: %d)\n", node.getName(), node.getPriority()));
            stats.append(String.format("  Status: %s, Enabled: %s\n",
                node.getStatus(), node.isEnabled()));
            stats.append(String.format("  Last Execution: %dms ago\n",
                node.getTimeSinceLastExecution()));

            Long executionTime = nodeExecutionTimes.get(node.getName());
            if (executionTime != null) {
                stats.append(String.format("  Last Runtime: %dms\n", executionTime));
            }
        }
        return stats.toString();
    }
}