package core.data;

import java.util.HashMap;
import java.util.Map;

public class DataManager {
    private final Map<String, Object> globalData;

    public DataManager() {
        this.globalData = new HashMap<>();
    }

    public void setGlobal(String key, Object value) {
        globalData.put(key, value);
    }

    public Object getGlobal(String key) {
        return globalData.get(key);
    }

    public boolean hasGlobal(String key) {
        return globalData.containsKey(key);
    }

    public void removeGlobal(String key) {
        globalData.remove(key);
    }

    public void clearGlobals() {
        globalData.clear();
    }
} 