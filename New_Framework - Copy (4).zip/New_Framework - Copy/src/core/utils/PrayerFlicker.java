package core.utils;

import core.context.ScriptContext;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.prayer.Prayer;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.script.listener.ProjectileListener;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.widgets.WidgetChild;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class PrayerFlicker implements GameTickListener, ProjectileListener {
    private int lastGameTick = -1;
    private static final int RANGED_PROJECTILE_ID = 2642;
    private static final int MAGIC_PROJECTILE_ID = 2640;
    private int gameTick = 0;
    public boolean prayerFlickingRunning = false;
    private final ScriptLogger logger;
    private Thread prayerThread;
    private boolean shouldFlickPrayer = false;
    private Prayer currentPrayer = null;
    private final Map<Projectile, Double> incomingProjectiles = new HashMap<>();
    private final ScriptContext context;

    // Widget info:
    // Protect from Magic: parent=541, child=21
    // Protect from Missiles: parent=541, child=22
    // Protect from Melee: parent=541, child=23

    public PrayerFlicker(ScriptContext context) {
        this.lastGameTick = Client.getGameTick();
        this.logger = context.getLogger();
        this.context = context;
        Client.getInstance().getScriptManager().addListener(this);
    }
    @Override
    public void onTargeted(Projectile projectile, Tile target)
    {
        // 1) Identify the projectile we care about
        if (projectile.getID() == RANGED_PROJECTILE_ID || projectile.getID() == MAGIC_PROJECTILE_ID)
        {
            // 2) Use both start and end cycles for more accurate timing
            int currentCycle = Client.getGameCycle();
            int startCycle = projectile.getStartCycle();
            int endCycle = projectile.getEndCycle();

            // Validate cycles
            if (endCycle <= currentCycle || startCycle >= endCycle)
            {
                return;
            }

            // Calculate total projectile travel time in cycles
            int totalTravelCycles = endCycle - startCycle;
            
            // Calculate remaining cycles from current point
            int remainingCycles = endCycle - currentCycle;

            // Convert to game ticks (30 cycles = 1 game tick)
            double totalTravelTicks = totalTravelCycles / 30.0;
            double remainingTicks = remainingCycles / 30.0;

            // Store in our map with the calculated remaining ticks
            incomingProjectiles.put(projectile, remainingTicks);

            Logger.log(String.format(
                    "New projectile tracked: ID=%d, totalTravelTicks=%.2f, remainingTicks=%.2f, currentTick=%d, startCycle=%d, endCycle=%d",
                    projectile.getID(),
                    totalTravelTicks,
                    remainingTicks,
                    gameTick,
                    startCycle,
                    endCycle
            ));
        }
    }

    @Override
    public void onServerTick()
    {
        gameTick++;

        // Example logic: check if we should flick prayer
        shouldFlickPrayer = isScurriusPresent();

        // Check and turn off prayers if not needed or if banking
        if (!shouldFlickPrayer || Bank.isOpen())
        {
            checkAndTurnOffOverheadPrayers();
        }

        // 3) Decrement projectile timers & log them
        Iterator<Map.Entry<Projectile, Double>> it = incomingProjectiles.entrySet().iterator();
        while (it.hasNext())
        {
            Map.Entry<Projectile, Double> entry = it.next();
            double ticksRemaining = entry.getValue();

            // Subtract 1 because we’re on a new server tick
            ticksRemaining -= 1.0;
            entry.setValue(ticksRemaining);

            Logger.log(String.format(
                    "Projectile %d will impact in: %.2f ticks (currentTick=%d)",
                    entry.getKey().getID(),
                    ticksRemaining,
                    gameTick
            ));

            // Remove if <= 0
            if (ticksRemaining <= 0)
            {
                it.remove();
            }
        }
    }


    private boolean isScurriusPresent() {
        try {
            for (NPC npc : NPCs.all()) {
                if (npc != null && npc.exists() && "Scurrius".equals(npc.getName())) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            Logger.error("Error checking for Scurrius: " + e.getMessage());
            return false;
        }
    }

    public void startPrayerFlick() {
        if (!prayerFlickingRunning) {
            prayerFlickingRunning = true;
            context.getScript().getScriptManager().addListener(this);
            Thread prayerFlickingThread = new Thread(() -> {
                try {
                    while (prayerFlickingRunning) {
                        if (isScurriusPresent() && Skills.getBoostedLevel(Skill.PRAYER) > 0) {
                            handlePrayerFlicking();
                        }
                    }
                } catch (Exception e) {
                    Logger.error("Prayer flicking thread error: " + e.getMessage());
                } finally {
                    prayerFlickingRunning = false;
                }
            });
            prayerFlickingThread.setDaemon(true);
            prayerFlickingThread.start();
        }
    }

    private void handlePrayerFlicking() {
        int currentGameTick = gameTick;
        if (currentGameTick != lastGameTick) {
            lastGameTick = currentGameTick;
            if (Skills.getBoostedLevel(Skill.PRAYER) > 0) {
                Prayer prayerToUse = getCurrentPrayer();
                if (prayerToUse != null) {
                    Logger.log("Game tick: " + currentGameTick + " - Turning ON " + prayerToUse.name());

                    // Toggle prayer on
                    togglePrayerWidget(prayerToUse, true);

                    // Wait until next game tick (like in the example)
                    Sleep.sleepUntil(() -> gameTick != currentGameTick, 600);

                    // Toggle prayer off at the start of next tick
                    togglePrayerWidget(prayerToUse, false);

                    Logger.log("Prayer flick completed. Tick: " + gameTick +
                               ", Prayer Points: " + Skills.getBoostedLevel(Skill.PRAYER));
                }
            }
        }
    }

    public void stop() {
        if (prayerFlickingRunning) {
            context.getScript().getScriptManager().removeListener(this);
            prayerFlickingRunning = false;
            
            // Turn off all protection prayers
            togglePrayerWidget(Prayer.PROTECT_FROM_MELEE, false);
            togglePrayerWidget(Prayer.PROTECT_FROM_MISSILES, false);
            togglePrayerWidget(Prayer.PROTECT_FROM_MAGIC, false);
            
            currentPrayer = null;
            incomingProjectiles.clear();
            Logger.log("Prayer flicker stopped and all protection prayers deactivated");
        }
    }

    private Prayer getCurrentPrayer() {
        // Check for projectiles about to impact in the next tick
        double closestImpact = Double.MAX_VALUE;
        Prayer projectilePrayer = null;

        for (Map.Entry<Projectile, Double> entry : incomingProjectiles.entrySet()) {
            double ticksUntilImpact = entry.getValue();
            
            // If projectile will impact within the next tick (allowing for some margin of error)
            if (ticksUntilImpact <= 1.1 && ticksUntilImpact < closestImpact) {
                closestImpact = ticksUntilImpact;
                if (entry.getKey().getID() == RANGED_PROJECTILE_ID) {
                    projectilePrayer = Prayer.PROTECT_FROM_MISSILES;
                } else if (entry.getKey().getID() == MAGIC_PROJECTILE_ID) {
                    projectilePrayer = Prayer.PROTECT_FROM_MAGIC;
                }
            }
        }

        // If we have a projectile about to hit, use that prayer
        if (projectilePrayer != null) {
            Logger.log(String.format("Switching to %s prayer for impact in %.2f ticks", 
                projectilePrayer.name(), closestImpact));
            return projectilePrayer;
        }

        // Default to protect from melee when no projectiles are about to hit
        return Prayer.PROTECT_FROM_MELEE;
    }

    /**
     * Toggles the prayer by interacting with the widget.
     * We do not check for states, as original code did not.
     * We trust that each call toggles the prayer on/off.
     */
    private void togglePrayerWidget(Prayer prayer, boolean activate) {
        int child = getWidgetChildForPrayer(prayer);
        if (child == -1) {
            logger.error("Invalid widget child for prayer: " + prayer.name());
            return;
        }

        WidgetChild wc = Widgets.get(541, child);
        if (wc == null) {
            logger.error("Widget child not found for prayer: " + prayer.name());
            return;
        }

        String action = activate ? "Activate" : "Deactivate";
        boolean success = wc.interact(action);
        Logger.log("Prayer widget " + action + " " + (success ? "successful" : "failed") +
                    " for " + prayer.name() + " (Widget: 541," + child + ")");
    }

    private int getWidgetChildForPrayer(Prayer prayer) {
        switch (prayer) {
            case PROTECT_FROM_MAGIC:
                return 21;
            case PROTECT_FROM_MISSILES:
                return 22;
            case PROTECT_FROM_MELEE:
                return 23;
            default:
                return -1;
        }
    }

    private int getExpectedOverheadId(Prayer prayer) {
        switch (prayer) {
            case PROTECT_FROM_MELEE:
                return 0;
            case PROTECT_FROM_MISSILES:
                return 1;
            case PROTECT_FROM_MAGIC:
                return 2;
            default:
                return -1;
        }
    }

    private void checkAndTurnOffOverheadPrayers() {
        int playerOverheadId = Players.getLocal().getOverheadIcon();
        if (playerOverheadId != -1) {
            // Turn off the active prayer based on overhead ID
            switch (playerOverheadId) {
                case 0: // Melee
                    togglePrayerWidget(Prayer.PROTECT_FROM_MELEE, false);
                    break;
                case 1: // Ranged
                    togglePrayerWidget(Prayer.PROTECT_FROM_MISSILES, false);
                    break;
                case 2: // Magic
                    togglePrayerWidget(Prayer.PROTECT_FROM_MAGIC, false);
                    break;
            }
            Logger.log("Turned off overhead prayer while away from Scurrius or banking");
        }
    }
}
