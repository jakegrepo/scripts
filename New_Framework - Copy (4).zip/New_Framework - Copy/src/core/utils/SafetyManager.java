package core.utils;

import core.context.ContextProvider;
import core.context.ScriptContext;
import core.state.ScriptState;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

/**
 * Manages script safety features like breaks and anti-ban measures
 */
public class SafetyManager extends ContextProvider {
    private final List<Callable<Boolean>> breakConditions;
    private long lastBreakCheck;
    private long breakStartTime;
    private boolean onBreak;
    private boolean breaksEnabled;
    private int minBreakMinutes;
    private int maxBreakMinutes;
    private int minRunMinutes;
    private int maxRunMinutes;
    
    // Anti-ban settings
    private int mouseMoveProbability;
    private boolean randomizeClicks;
    private boolean humanMouseMovement;
    
    public SafetyManager(ScriptContext context) {
        super(context);
        this.breakConditions = new ArrayList<>();
        this.lastBreakCheck = System.currentTimeMillis();
        this.breakStartTime = 0;
        this.onBreak = false;
        this.breaksEnabled = true;
        
        // Default break settings
        this.minBreakMinutes = 5;
        this.maxBreakMinutes = 15;
        this.minRunMinutes = 45;
        this.maxRunMinutes = 90;
        
        // Default anti-ban settings
        this.mouseMoveProbability = 10;
        this.randomizeClicks = true;
        this.humanMouseMovement = true;
    }
    
    /**
     * Initializes the safety manager
     */
    public void initialize() {
        breakConditions.clear();
        lastBreakCheck = System.currentTimeMillis();
        breakStartTime = 0;
        onBreak = false;
        
        // Add default break conditions
        addBreakCondition(() -> getRuntime() > TimeUnit.MINUTES.toMillis(maxRunMinutes));
        
        debug("SafetyManager initialized");
    }
    
    /**
     * Shuts down the safety manager
     */
    public void shutdown() {
        breakConditions.clear();
        debug("SafetyManager shut down");
    }
    
    /**
     * Performs safety checks
     */
    public void check() {
        if (!breaksEnabled || onBreak) return;
        
        long now = System.currentTimeMillis();
        if (now - lastBreakCheck < TimeUnit.MINUTES.toMillis(1)) return;
        
        lastBreakCheck = now;
        
        try {
            // Check break conditions
            for (Callable<Boolean> condition : breakConditions) {
                if (condition.call()) {
                    startBreak();
                    return;
                }
            }
        } catch (Exception e) {
            error("Error in safety check", e);
        }
    }
    
    /**
     * Starts a break
     */
    public void startBreak() {
        if (!onBreak) {
            onBreak = true;
            breakStartTime = System.currentTimeMillis();
            int breakMinutes = random(minBreakMinutes, maxBreakMinutes);
            log("Taking a break for " + breakMinutes + " minutes");
            debug("Starting break");
        }
    }
    
    /**
     * Checks if the break is over
     */
    public void checkBreak() {
        if (!onBreak) return;
        
        long breakDuration = System.currentTimeMillis() - breakStartTime;
        if (breakDuration >= TimeUnit.MINUTES.toMillis(maxBreakMinutes)) {
            endBreak();
        }
    }
    
    /**
     * Ends the current break
     */
    public void endBreak() {
        if (onBreak) {
            onBreak = false;
            breakStartTime = 0;
            lastBreakCheck = System.currentTimeMillis();
            setState(ScriptState.RUNNING);
            log("Break complete, resuming script");
            debug("Ending break");
        }
    }
    
    /**
     * Adds a custom break condition
     */
    public void addBreakCondition(Callable<Boolean> condition) {
        breakConditions.add(condition);
        debug("Added break condition");
    }
    
    // Getters and setters
    public boolean isBreaksEnabled() { return breaksEnabled; }
    public void setBreaksEnabled(boolean enabled) { this.breaksEnabled = enabled; }
    public boolean isOnBreak() { return onBreak; }
    public int getMinBreakMinutes() { return minBreakMinutes; }
    public void setMinBreakMinutes(int minutes) { this.minBreakMinutes = minutes; }
    public int getMaxBreakMinutes() { return maxBreakMinutes; }
    public void setMaxBreakMinutes(int minutes) { this.maxBreakMinutes = minutes; }
    public int getMinRunMinutes() { return minRunMinutes; }
    public void setMinRunMinutes(int minutes) { this.minRunMinutes = minutes; }
    public int getMaxRunMinutes() { return maxRunMinutes; }
    public void setMaxRunMinutes(int minutes) { this.maxRunMinutes = minutes; }
    
    // Utility methods
    private int random(int min, int max) {
        return min + (int)(Math.random() * ((max - min) + 1));
    }
    
    // Anti-ban related methods
    public int getMouseMoveProbability() {
        return mouseMoveProbability;
    }
    
    public void setMouseMoveProbability(int probability) {
        this.mouseMoveProbability = probability;
        debug("Mouse move probability set to: " + probability + "%");
    }
    
    public boolean isRandomizeClicks() {
        return randomizeClicks;
    }
    
    public void setRandomizeClicks(boolean randomize) {
        this.randomizeClicks = randomize;
        debug("Click randomization " + (randomize ? "enabled" : "disabled"));
    }
    
    public boolean isHumanMouseMovement() {
        return humanMouseMovement;
    }
    
    public void setHumanMouseMovement(boolean enabled) {
        this.humanMouseMovement = enabled;
        debug("Human mouse movement " + (enabled ? "enabled" : "disabled"));
    }
    
    // Break management methods
    public boolean shouldTakeBreak() {
        if (!breaksEnabled || onBreak) {
            return false;
        }
        
        long currentTime = System.currentTimeMillis();
        long runTime = TimeUnit.MILLISECONDS.toMinutes(currentTime - lastBreakCheck);
        
        // Check if we've been running long enough
        if (runTime >= minRunMinutes) {
            // Check custom break conditions
            for (Callable<Boolean> condition : breakConditions) {
                try {
                    if (condition.call()) {
                        return true;
                    }
                } catch (Exception e) {
                    error("Error checking break condition", e);
                }
            }
            
            // Random chance to break after min runtime
            return Math.random() * (maxRunMinutes - minRunMinutes) < (runTime - minRunMinutes);
        }
        
        return false;
    }
    
    public long getBreakDuration() {
        if (!onBreak) {
            return 0;
        }
        return TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis() - breakStartTime);
    }
    
    public boolean shouldEndBreak() {
        if (!onBreak) {
            return false;
        }
        
        long breakDuration = getBreakDuration();
        return breakDuration >= minBreakMinutes && 
               (breakDuration >= maxBreakMinutes || Math.random() < 0.1);
    }
} 