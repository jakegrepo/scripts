package core.utils;

import core.context.ScriptContext;
import org.dreambot.api.Client;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Projectiles;
import org.dreambot.api.methods.prayer.Prayer;
import org.dreambot.api.methods.prayer.Prayers;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.NPC;

class PrayerFlickerExample implements GameTickListener {
    private int lastGameTick = -1;
    private static final int RANGED_PROJECTILE_ID = 2642;
    private static final int MAGIC_PROJECTILE_ID = 2640;
    private Prayer currentPrayer = null;
    private boolean prayerOn = false;
    private volatile boolean isRunning = false;
    private Thread prayerThread;
    private boolean shouldFlickPrayer = false;
    public boolean prayerFlickingRunning = false;
    private int gameTick = 0;
    private final ScriptLogger logger;

    public PrayerFlickerExample (ScriptContext context) {
        this.lastGameTick = Client.getGameTick();
        this.logger = context.getLogger();
        Client.getInstance().getScriptManager().addListener(this);
    }

    @Override
    public void onServerTick() {
        gameTick++;
        shouldFlickPrayer = isScurriusPresent();
    }
    private boolean isScurriusPresent() {
        try {
            NPC[] npcs = NPCs.all().toArray(new NPC[0]);
            if (npcs != null) {
                for (NPC npc : npcs) {
                    if (npc != null && npc.exists() && "Scurrius".equals(npc.getName())) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            Logger.error("Error checking for Scurrius: " + e.getMessage());
            return false;
        }
    }
    public void startPrayerFlick() {
        if (!prayerFlickingRunning) {
            shouldFlickPrayer = true;
            prayerFlickingRunning = true;
            Thread prayerFlickingThread = new Thread(() -> {
                try {
                    while (prayerFlickingRunning) {
                        if (isScurriusPresent() && Skills.getBoostedLevel(Skill.PRAYER) > 0) {
                            handlePrayerFlicking();
                        }
                    }
                } catch (Exception e) {
                    Logger.error("Prayer flicking thread error: " + e.getMessage());
                } finally {
                    prayerFlickingRunning = false;
                    shouldFlickPrayer = false;
                }
            });
            prayerFlickingThread.setDaemon(true);
            prayerFlickingThread.start();
        }
    }
    private void handlePrayerFlicking() {
        int currentGameTick = gameTick;
        if (currentGameTick != lastGameTick) {
            lastGameTick = currentGameTick;
            if (Skills.getBoostedLevel(Skill.PRAYER) > 0) {
                Prayer prayerToUse = getCurrentPrayer();
                if (prayerToUse != null) {
                    Prayers.toggle(true, prayerToUse);
                    Sleep.sleepUntil(() -> gameTick != currentGameTick, 600);
                    Prayers.toggle(false, prayerToUse);
                }
            }
        }
    }
    public void stop() {
        isRunning = false;
        if (prayerThread != null) {
            prayerThread.interrupt();
            prayerThread = null;
        }
        if (currentPrayer != null && Prayers.isActive(currentPrayer)) {
            Prayers.toggle(false, currentPrayer);
        }
        currentPrayer = null;
        prayerOn = false;
    }

    private Prayer getCurrentPrayer() {
        Projectile rangedProjectile = handleProjectile(RANGED_PROJECTILE_ID);
        Projectile magicProjectile = handleProjectile(MAGIC_PROJECTILE_ID);

        if (rangedProjectile != null) {
            return Prayer.PROTECT_FROM_MISSILES;
        } else if (magicProjectile != null) {
            return Prayer.PROTECT_FROM_MAGIC;
        }
        return Prayer.PROTECT_FROM_MELEE;
    }

    private Projectile handleProjectile(int projectileId) {
        Projectile projectile = Projectiles.closest(p -> p.getID() == projectileId);
        if (projectile != null) {
            logger.debug("Handling projectile attack with ID: " + projectileId);
        }
        return projectile;
    }
}