package core.utils;

import java.util.logging.Level;
import java.util.logging.Logger;

public class ScriptLogger {
    private final Logger logger;
    
    public ScriptLogger(String name) {
        this.logger = Logger.getLogger(name);
    }
    
    public void log(String message) {
        logger.log(Level.INFO, message);
    }
    
    public void info(String message) {
        logger.log(Level.INFO, message);
    }
    
    public void debug(String message) {
        logger.log(Level.FINE, message);
    }
    
    public void error(String message) {
        logger.log(Level.SEVERE, message);
    }
    
    public void error(String message, Exception e) {
        logger.log(Level.SEVERE, message, e);
    }
    
    public void warn(String message) {
        logger.log(Level.WARNING, message);
    }
} 