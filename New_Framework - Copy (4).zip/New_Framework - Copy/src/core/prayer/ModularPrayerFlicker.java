package core.prayer;

import core.context.ScriptContext;
import core.utils.ScriptLogger;
import org.dreambot.api.Client;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.prayer.Prayer;
import org.dreambot.api.methods.prayer.Prayers;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.widgets.WidgetChild;

import java.util.ArrayList;
import java.util.List;

public class ModularPrayerFlicker implements GameTickListener {
    private int lastGameTick = -1;
    private int gameTick = 0;
    public boolean prayerFlickingRunning = false;
    private final ScriptLogger logger;
    private final ScriptContext context;
    private final List<Prayer> quickPrayers = new ArrayList<>();
    private static final int QUICK_PRAYER_WIDGET_ID = 160;
    private static final int QUICK_PRAYER_CHILD_ID = 19;
    private static final int PRAYER_TAB_WIDGET_ID = 541;

    public ModularPrayerFlicker(ScriptContext context) {
        this.lastGameTick = Client.getGameTick();
        this.logger = context.getLogger();
        this.context = context;
        Client.getInstance().getScriptManager().addListener(this);
    }

    @Override
    public void onServerTick() {
        gameTick++;

        // Check and turn off prayers if banking
        if (Bank.isOpen()) {
            checkAndTurnOffQuickPrayers();
        }
    }

    public void setupQuickPrayers(List<Prayer> prayers) {
        quickPrayers.clear();
        quickPrayers.addAll(prayers);

        // Open prayer tab if not open
        if (!Prayers.isOpen()) {
            Prayers.openTab();
            Sleep.sleepUntil(() -> Widgets.getWidget(PRAYER_TAB_WIDGET_ID) != null, 2000);
        }

        // Convert List to array for the API call
        Prayer[] prayerArray = prayers.toArray(new Prayer[0]);
        
        // Setup all quick prayers at once
        if (Prayers.setupQuickPrayers(prayerArray)) {
            logger.info("Quick prayers configured: " + prayers);
        } else {
            logger.error("Failed to configure quick prayers");
        }
    }

    public void startPrayerFlick() {
        if (!prayerFlickingRunning) {
            prayerFlickingRunning = true;
            context.getScript().getScriptManager().addListener(this);
            Thread prayerFlickingThread = new Thread(() -> {
                try {
                    while (prayerFlickingRunning) {
                        if (Skills.getBoostedLevel(Skill.PRAYER) > 0) {
                            handlePrayerFlicking();
                        }
                        Sleep.sleep(50); // Small sleep to prevent excessive CPU usage
                    }
                } catch (Exception e) {
                    Logger.error("Prayer flicking thread error: " + e.getMessage());
                } finally {
                    prayerFlickingRunning = false;
                }
            });
            prayerFlickingThread.setDaemon(true);
            prayerFlickingThread.start();
        }
    }

    private void handlePrayerFlicking() {
        int currentGameTick = gameTick;
        if (currentGameTick != lastGameTick) {
            lastGameTick = currentGameTick;
            if (Skills.getBoostedLevel(Skill.PRAYER) > 0) {
                Logger.log("Game tick: " + currentGameTick + " - Flicking quick prayers");

                // Toggle quick prayers on
                toggleQuickPrayers(true);

                // Wait until next game tick
                Sleep.sleepUntil(() -> gameTick != currentGameTick, 600);

                // Toggle quick prayers off at the start of next tick
                toggleQuickPrayers(false);

                Logger.log("Prayer flick completed. Tick: " + gameTick +
                        ", Prayer Points: " + Skills.getBoostedLevel(Skill.PRAYER));
            }
        }
    }

    private void toggleQuickPrayers(boolean activate) {
        WidgetChild quickPrayerWidget = Widgets.get(QUICK_PRAYER_WIDGET_ID, QUICK_PRAYER_CHILD_ID);
        if (quickPrayerWidget != null && quickPrayerWidget.isVisible()) {
            if (activate != Prayers.isQuickPrayerActive()) {
                Prayers.toggleQuickPrayer(activate);
            }
        }
    }

    private void checkAndTurnOffQuickPrayers() {
        if (Prayers.isQuickPrayerActive()) {
            toggleQuickPrayers(false);
            Logger.log("Turned off quick prayers while banking");
        }
    }

    public void stop() {
        if (prayerFlickingRunning) {
            context.getScript().getScriptManager().removeListener(this);
            prayerFlickingRunning = false;
            
            // Turn off quick prayers
            toggleQuickPrayers(false);
            
            quickPrayers.clear();
            Logger.log("Prayer flicker stopped and quick prayers deactivated");
        }
    }

    public List<Prayer> getConfiguredQuickPrayers() {
        return new ArrayList<>(quickPrayers);
    }
}
