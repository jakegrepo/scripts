package core.context;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import core.config.ScriptConfig;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * Manages script configurations
 */
public class ConfigManager extends ContextProvider {
    private final Map<String, ScriptConfig> configs;
    private final Gson gson;
    
    public ConfigManager(ScriptContext context) {
        super(context);
        this.configs = new HashMap<>();
        this.gson = new GsonBuilder()
            .setPrettyPrinting()
            .excludeFieldsWithoutExposeAnnotation()
            .serializeNulls()
            .create();
    }
    
    /**
     * Gets a config by key
     */
    @SuppressWarnings("unchecked")
    public <T extends ScriptConfig> T getConfig(String key) {
        return (T) configs.get(key);
    }
    
    /**
     * Sets a config
     */
    public void setConfig(String key, ScriptConfig config) {
        configs.put(key, config);
        debug("Set config: " + key);
    }
    
    /**
     * Removes a config
     */
    public void removeConfig(String key) {
        configs.remove(key);
        debug("Removed config: " + key);
    }
    
    /**
     * Clears all configs
     */
    public void clearConfigs() {
        configs.clear();
        debug("Cleared all configs");
    }
    
    /**
     * Saves all configs to disk
     */
    public void saveConfigs() {
        try {
            for (Map.Entry<String, ScriptConfig> entry : configs.entrySet()) {
                String configPath = getConfigPath(entry.getKey());
                String json = gson.toJson(entry.getValue());
                Files.write(Paths.get(configPath), json.getBytes(StandardCharsets.UTF_8));
                debug("Saved config: " + entry.getKey());
            }
        } catch (Exception e) {
            error("Error saving configs", e);
        }
    }
    
    private String getConfigPath(String configKey) {
        return "ScarFramework/configs/" + configKey + ".json";
    }
    
    /**
     * Loads all configs from disk
     */
    public void loadConfigs() {
        configs.forEach((key, config) -> {
            try {
                config.loadConfig();
                debug("Loaded config: " + key);
            } catch (Exception e) {
                error("Error loading config: " + key, e);
            }
        });
    }
} 