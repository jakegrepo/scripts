package core.context;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages global script data storage
 */
public class DataManager extends ContextProvider {
    private final Map<String, Object> globalData;
    private final Map<String, Map<String, Object>> nodeData;
    
    public DataManager(ScriptContext context) {
        super(context);
        this.globalData = new ConcurrentHashMap<>();
        this.nodeData = new ConcurrentHashMap<>();
    }
    
    /**
     * Sets a global data value
     */
    public void setGlobal(String key, Object value) {
        globalData.put(key, value);
        debug("Set global data: " + key + " = " + value);
    }
    
    /**
     * Gets a global data value
     */
    @SuppressWarnings("unchecked")
    public <T> T getGlobal(String key, T defaultValue) {
        return (T) globalData.getOrDefault(key, defaultValue);
    }
    
    /**
     * Sets node-specific data
     */
    public void setNodeData(String nodeName, String key, Object value) {
        nodeData.computeIfAbsent(nodeName, k -> new ConcurrentHashMap<>())
                .put(key, value);
        debug("Set node data: " + nodeName + "." + key + " = " + value);
    }
    
    /**
     * Gets node-specific data
     */
    @SuppressWarnings("unchecked")
    public <T> T getNodeData(String nodeName, String key, T defaultValue) {
        Map<String, Object> data = nodeData.get(nodeName);
        if (data == null) return defaultValue;
        return (T) data.getOrDefault(key, defaultValue);
    }
    
    /**
     * Clears all data for a node
     */
    public void clearNodeData(String nodeName) {
        nodeData.remove(nodeName);
        debug("Cleared data for node: " + nodeName);
    }
    
    /**
     * Clears all global data
     */
    public void clearGlobalData() {
        globalData.clear();
        debug("Cleared all global data");
    }
    
    /**
     * Clears all data
     */
    public void clearAllData() {
        globalData.clear();
        nodeData.clear();
        debug("Cleared all data");
    }
    
    /**
     * Gets a snapshot of global data
     */
    public Map<String, Object> getGlobalDataSnapshot() {
        return new HashMap<>(globalData);
    }
    
    /**
     * Gets a snapshot of node data
     */
    public Map<String, Map<String, Object>> getNodeDataSnapshot() {
        Map<String, Map<String, Object>> snapshot = new HashMap<>();
        nodeData.forEach((node, data) -> snapshot.put(node, new HashMap<>(data)));
        return snapshot;
    }
} 