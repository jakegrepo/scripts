package core.context;

import core.debug.DebugManager;
import core.node.TaskNodeManager;
import core.paint.debug.DebugOverlayManager;
import core.state.ScriptState;
import core.state.StateManager;
import core.utils.SafetyManager;
import core.utils.ScriptLogger;
import events.EventManager;
import events.ListenerManager;
import org.dreambot.api.script.AbstractScript;

/**
 * Main context class that holds all framework services
 */
public class ScriptContext {
    private final AbstractScript script;
    protected ScriptLogger logger;
    private final ConfigManager config;
    private final DataManager data;
    private final StateManager stateManager;
    private final EventManager eventManager;
    private final ListenerManager listenerManager;
    private final TaskNodeManager taskManager;
    private final SafetyManager safetyManager;
    private final DebugManager debugManager;
    private final DebugOverlayManager debugOverlayManager;
    private final long startTime;
    private boolean isInTestMode = false;

    public ScriptContext(AbstractScript script) {
        this.script = script;
        initializeLogger(script.getClass().getSimpleName());

        this.config = new ConfigManager(this);
        this.data = new DataManager(this);
        this.stateManager = new StateManager(this);
        this.eventManager = new EventManager(this);
        this.listenerManager = new ListenerManager(this);
        this.taskManager = new TaskNodeManager(this);
        this.safetyManager = new SafetyManager(this);
        this.debugManager = new DebugManager(this);
        this.debugOverlayManager = new DebugOverlayManager(this);
        this.startTime = System.currentTimeMillis();
    }

    /**
     * Initialize all framework services
     */
    public void initialize() {
        if (logger == null) {
            initializeLogger(script.getClass().getSimpleName());
        }
        try {
            // Start all listeners
            listenerManager.startAll();

            // Enable event processing
            eventManager.setProcessingEvents(true);

            logger.info("Framework services initialized");
        } catch (Exception e) {
            logger.error("Error initializing framework services", e);
            setState(ScriptState.ERROR);
        }
    }

    /**
     * Shutdown all framework services
     */
    public void shutdown() {
        try {
            // Stop all listeners
            listenerManager.stopAll();

            // Disable event processing
            eventManager.setProcessingEvents(false);

            // Save configs
            config.saveConfigs();

            logger.info("Framework services shutdown");
        } catch (Exception e) {
            logger.error("Error shutting down framework services", e);
        }
    }

    public ConfigManager config() {
        return config;
    }

    public DataManager data() {
        return data;
    }

    public StateManager state() {
        return stateManager;
    }

    public EventManager events() {
        return eventManager;
    }

    public ListenerManager listeners() {
        return listenerManager;
    }

    public TaskNodeManager tasks() {
        return taskManager;
    }

    public SafetyManager safety() {
        return safetyManager;
    }

    public void setState(ScriptState state) {
        stateManager.setState(state);
    }

    public ScriptState getState() {
        return stateManager.getCurrentState();
    }

    public long getRuntime() {
        return System.currentTimeMillis() - startTime;
    }

    public TaskNodeManager getTaskManager() {
        return tasks();
    }

    public EventManager getEventManager() {
        return events();
    }

    public StateManager getStateManager() {
        return state();
    }

    public ListenerManager getListenerManager() {
        return listeners();
    }

    public SafetyManager getSafetyManager() {
        return safety();
    }

    public AbstractScript getScript() {
        return script;
    }

    public void initializeLogger(String name) {
        if (logger == null) {
            logger = new ScriptLogger(name);
        }
    }

    public ScriptLogger getLogger() {
        if (logger == null) {
            initializeLogger(script.getClass().getSimpleName());
        }
        return logger;
    }

    public DebugManager getDebugManager() {
        return debugManager;
    }

    public DebugOverlayManager getDebugOverlayManager() {
        return debugOverlayManager;
    }

    public boolean isInTestMode() {
        return isInTestMode;
    }

    public void setTestMode(boolean testMode) {
        this.isInTestMode = testMode;
    }
}