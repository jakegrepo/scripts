package core.context;

import core.node.TaskNode;
import core.node.TaskNodeManager;
import core.state.ScriptState;
import core.state.StateManager;
import core.utils.ScriptLogger;
import events.EventType;
import events.ListenerManager;
import events.ScriptEvent;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Base class providing simplified access to ScriptContext services.
 * Extend this class to get easy access to all framework functionality.
 */
public abstract class ContextProvider {
    protected ScriptContext context;

    // Common services as protected fields for direct access
    protected ScriptLogger logger;
    protected ConfigManager config;
    protected DataManager data;
    protected StateManager stateManager;
    protected TaskNodeManager taskManager;
    private Map<String, EventType> methodToEventTypeMap;
    protected ListenerManager listenerManager;

    /**
     * Default constructor for use in deserialization
     * This skips the context validation check
     */
    protected ContextProvider() {
        // Skip context validation for deserialization
    }

    /**
     * Constructor for deserialization with a flag
     * @param forDeserialization Flag to indicate this is for deserialization only
     */
    protected ContextProvider(boolean forDeserialization) {
        // Skip context validation for deserialization
    }

    protected ContextProvider(ScriptContext context) {
        if (context == null) {
            throw new IllegalArgumentException("Context cannot be null");
        }
        this.context = context;
        initializeLogger();

        // Initialize common service references
        this.logger = context.getLogger();
        if (this.logger == null) {
            System.err.println("Warning: Logger not initialized in context");
        }

        this.config = context.config();
        this.data = context.data();
        this.stateManager = context.state();
        this.taskManager = context.getTaskManager();
        this.methodToEventTypeMap = new HashMap<>();
        this.listenerManager = context.listeners();
        registerEventHandlers();
    }

    private void initializeLogger() {
        if (context.getLogger() == null) {
            context.initializeLogger(getClass().getSimpleName());
        }
    }

    /**
     * Gets the script context
     */
    public ScriptContext getContext() {
        return context;
    }

    /**
     * Initialize the mapping of method name suffixes to event types
     */
    private Map<String, EventType> initializeEventTypeMap() {
        Map<String, EventType> map = new HashMap<>();
        for (EventType type : EventType.values()) {
            map.put(type.name().toLowerCase(), type);
        }
        return map;
    }

    /**
     * Automatically register all event handlers in this class
     */
    private void registerEventHandlers() {
        Arrays.stream(getClass().getDeclaredMethods())
            .forEach(this::registerEventHandler);
    }

    private void registerEventHandler(Method method) {
        String methodName = method.getName().toLowerCase();
        EventType eventType = methodToEventTypeMap.get(methodName);

        if (eventType == null || method.getParameterCount() != 1 ||
            !ScriptEvent.class.isAssignableFrom(method.getParameterTypes()[0])) {
            return; // Skip methods that don't match the convention
        }

        method.setAccessible(true);

        context.getEventManager().addEventListener(eventType, event -> {
            try {
                method.invoke(this, event);
            } catch (Exception e) {
                error("Error in event handler: " + method.getName(), e);
            }
        });

        debug("Registered event handler: " + method.getName() + " for " + eventType);
    }

    // Simplified helper methods
    protected void setState(ScriptState state) {
        context.setState(state);
    }

    protected ScriptState getState() {
        return stateManager.getCurrentState();
    }

    protected void log(String message) {
        logger.log(message);
    }

    protected void debug(String message) {
        logger.debug(message);
    }

    protected void error(String message, Exception e) {
        logger.error(message, e);
    }

    public void setGlobalData(String key, Object value) {
        data.setGlobal(key, value);
    }

    public <T> T getGlobalData(String key, T defaultValue) {
        return data.getGlobal(key, defaultValue);
    }

    protected long getRuntime() {
        return context.getRuntime();
    }

    public void addNode(TaskNode node) {
        taskManager.addNode(node);
    }

    public void clearNodes() {
        taskManager.clearNodes();
    }

    public int getNodeCount() {
        return taskManager.getNodeCount();
    }
}
