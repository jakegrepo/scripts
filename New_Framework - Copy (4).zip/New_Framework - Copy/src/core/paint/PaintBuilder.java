package core.paint;

import core.context.ContextProvider;
import core.context.ScriptContext;
import core.node.TaskNode;
import org.dreambot.api.methods.skills.Skill;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * Builder for creating script paint displays
 */
public class PaintBuilder extends ContextProvider {
    private static final Rectangle DEFAULT_BOUNDS = new Rectangle(5, 5, 200, 200);
    private static final Color DEFAULT_BG_COLOR = new Color(0, 0, 0, 160);
    private static final Color DEFAULT_BORDER_COLOR = new Color(255, 255, 255, 160);
    private static final int BORDER_RADIUS = 10;
    
    // Row styling constants
    private static final int ROW_ICON_SIZE = 16;
    private static final int ROW_ICON_PADDING = 4;
    
    private final List<PaintRow> rows;
    private Font font;
    private Color backgroundColor;
    private Color textColor;
    private Color borderColor;
    private Rectangle bounds;
    private int padding;
    private boolean showTitle;
    private String title;
    private XPTracker xpTracker;
    
    public PaintBuilder(ScriptContext context) {
        super(context);
        this.title = "";
        this.font = new Font("SansSerif", Font.BOLD, 12);
        this.backgroundColor = DEFAULT_BG_COLOR;
        this.borderColor = DEFAULT_BORDER_COLOR;
        this.textColor = Color.WHITE;
        this.bounds = DEFAULT_BOUNDS;
        this.padding = 5;
        this.showTitle = true;
        this.rows = new ArrayList<>();
        this.xpTracker = new XPTracker(context);
    }
    
    /**
     * Sets the paint title
     */
    public PaintBuilder setTitle(String title) {
        this.title = title;
        return this;
    }
    
    /**
     * Sets whether to show the title
     */
    public PaintBuilder setShowTitle(boolean show) {
        this.showTitle = show;
        return this;
    }
    
    /**
     * Sets the padding between elements
     */
    public PaintBuilder setPadding(int padding) {
        this.padding = padding;
        return this;
    }
    
    /**
     * Sets the font
     */
    public PaintBuilder setFont(Font font) {
        this.font = font;
        return this;
    }
    
    /**
     * Sets the background color
     */
    public PaintBuilder setBackgroundColor(Color color) {
        this.backgroundColor = color;
        return this;
    }
    
    /**
     * Sets the text color
     */
    public PaintBuilder setTextColor(Color color) {
        this.textColor = color;
        return this;
    }
    
    /**
     * Adds a static row
     */
    public PaintBuilder addRow(String label, Object value) {
        rows.add(new StaticPaintRow(label, value));
        return this;
    }
    
    /**
     * Adds a dynamic row
     */
    public PaintBuilder addRow(String label, Supplier<?> valueSupplier) {
        rows.add(new DynamicPaintRow(label, valueSupplier));
        return this;
    }
    
    /**
     * Adds a styled row with an icon
     */
    public PaintBuilder addStyledRow(String label, Supplier<?> valueSupplier, RowIcon icon) {
        rows.add(new StyledPaintRow(label, valueSupplier, icon));
        return this;
    }
    
    /**
     * Adds a styled row with an icon
     */
    public PaintBuilder addStyledRow(String label, Object value, RowIcon icon) {
        rows.add(new StyledPaintRow(label, () -> value, icon));
        return this;
    }
    
    /**
     * Adds a runtime row with a clock icon
     */
    public PaintBuilder addRuntime() {
        return addStyledRow("Runtime", () -> formatTime(getRuntime()), RowIcon.CLOCK);
    }
    
    /**
     * Adds a state row that includes the active node with a status icon
     */
    public PaintBuilder addState() {
        return addStyledRow("State", () -> {
            String state = context.getState().toString();
            TaskNode activeNode = context.tasks().getActiveNode();
            String nodeName = activeNode != null ? activeNode.getName() : "";
            return state + (nodeName.isEmpty() ? "" : " - " + nodeName);
        }, RowIcon.STATUS);
    }
    
    /**
     * Adds a per-hour calculation row with a speed icon
     */
    public PaintBuilder addPerHour(String label, Supplier<Number> valueSupplier) {
        return addStyledRow(label + "/hr", () -> {
            Number value = valueSupplier.get();
            if (value == null) return 0;
            double perHour = (value.doubleValue() * 3600000.0) / getRuntime();
            return formatNumber(Math.round(perHour));
        }, RowIcon.SPEED);
    }
    
    /**
     * Adds a formatted number row
     */
    public PaintBuilder addFormattedRow(String label, Supplier<Number> valueSupplier) {
        return addRow(label, () -> formatNumber(valueSupplier.get()));
    }
    
    /**
     * Adds a formatted number row with an icon
     */
    public PaintBuilder addFormattedRow(String label, Supplier<Number> valueSupplier, RowIcon icon) {
        return addStyledRow(label, () -> formatNumber(valueSupplier.get()), icon);
    }
    
    /**
     * Adds a row for tracking XP for a specific skill
     */
    public PaintBuilder addXpTracker(Skill skill) {
        return addXpTracker(skill.name(), skill);
    }
    
    /**
     * Adds a row for tracking XP for a specific skill with a custom label
     */
    public PaintBuilder addXpTracker(String label, Skill skill) {
        if (xpTracker == null) {
            xpTracker = new XPTracker(context);
        }
        xpTracker.initializeSkill(skill);
        rows.add(new StyledPaintRow(label, () -> xpTracker.getFormattedXpInfo(skill), RowIcon.XP));
        return this;
    }
    
    /**
     * Adds a row for tracking XP for multiple skills combined
     */
    public PaintBuilder addCombinedXpTracker(String label, Skill... skills) {
        if (xpTracker == null) {
            xpTracker = new XPTracker(context);
        }
        for (Skill skill : skills) {
            xpTracker.initializeSkill(skill);
        }
        rows.add(new StyledPaintRow(label, () -> xpTracker.getFormattedTotalXpInfo(skills), RowIcon.XP));
        return this;
    }
    
    /**
     * Adds a row for time to next level for a specific skill
     */
    public PaintBuilder addTimeToLevel(Skill skill) {
        return addTimeToLevel(skill.name() + " TTL", skill);
    }
    
    /**
     * Adds a row for time to next level for a specific skill with a custom label
     */
    public PaintBuilder addTimeToLevel(String label, Skill skill) {
        if (xpTracker == null) {
            xpTracker = new XPTracker(context);
        }
        xpTracker.initializeSkill(skill);
        rows.add(new StyledPaintRow(label, () -> xpTracker.getFormattedTimeToNextLevel(skill), RowIcon.TIMER));
        return this;
    }
    
    /**
     * Adds rows for all combat skills that are actively being trained
     */
    public PaintBuilder addCombatXpTracker() {
        if (xpTracker == null) {
            xpTracker = new XPTracker(context);
        }
        
        // Initialize all combat skills
        xpTracker.initializeSkill(Skill.ATTACK);
        xpTracker.initializeSkill(Skill.STRENGTH);
        xpTracker.initializeSkill(Skill.DEFENCE);
        xpTracker.initializeSkill(Skill.RANGED);
        xpTracker.initializeSkill(Skill.MAGIC);
        xpTracker.initializeSkill(Skill.HITPOINTS);
        xpTracker.initializeSkill(Skill.PRAYER);
        
        // Add a dynamic row that updates based on active skills
        rows.add(new DynamicPaintRow("Combat XP", () -> {
            // Get all active combat skills
            Set<Skill> activeSkills = xpTracker.getActiveSkills().stream()
                .filter(skill -> skill == Skill.ATTACK || skill == Skill.STRENGTH || 
                       skill == Skill.DEFENCE || skill == Skill.RANGED || 
                       skill == Skill.MAGIC || skill == Skill.HITPOINTS || 
                       skill == Skill.PRAYER)
                .collect(Collectors.toSet());
            
            if (activeSkills.isEmpty()) {
                return "No active skills";
            }
            
            return xpTracker.getFormattedTotalXpInfo(activeSkills);
        }));
        
        // Add time to level rows for active skills
        rows.add(new DynamicPaintRow("TTL", () -> {
            // Get all active combat skills
            Set<Skill> activeSkills = xpTracker.getActiveSkills().stream()
                .filter(skill -> skill == Skill.ATTACK || skill == Skill.STRENGTH || 
                       skill == Skill.DEFENCE || skill == Skill.RANGED || 
                       skill == Skill.MAGIC || skill == Skill.HITPOINTS || 
                       skill == Skill.PRAYER)
                .collect(Collectors.toSet());
            
            if (activeSkills.isEmpty()) {
                return "No active skills";
            }
            
            // Get the skill with the shortest time to level
            return activeSkills.stream()
                .min(Comparator.comparing(skill -> {
                    long time = xpTracker.getTimeToNextLevel(skill);
                    return time <= 0 ? Long.MAX_VALUE : time;
                }))
                .map(skill -> skill.name() + ": " + xpTracker.getFormattedTimeToNextLevel(skill))
                .orElse("Unknown");
        }));
        
        return this;
    }
    
    /**
     * Adds a profit tracker row with a coin icon
     */
    public PaintBuilder addProfitTracker(String label, Supplier<Number> valueSupplier) {
        return addStyledRow(label, () -> {
            Number value = valueSupplier.get();
            if (value == null) return "0";
            long profit = value.longValue();
            String formattedProfit = formatNumber(profit);
            
            // Calculate profit per hour
            long runtime = getRuntime();
            if (runtime <= 0) return formattedProfit;
            
            long profitPerHour = (long) ((profit * 3600000.0) / runtime);
            return formattedProfit + " (" + formatNumber(profitPerHour) + "/hr)";
        }, RowIcon.COINS);
    }
    
    /**
     * Gets the XP tracker instance
     */
    public XPTracker getXpTracker() {
        return xpTracker;
    }
    
    /**
     * Sets a custom XP tracker instance
     */
    public PaintBuilder setXpTracker(XPTracker xpTracker) {
        this.xpTracker = xpTracker;
        return this;
    }
    
    /**
     * Updates the XP tracker
     */
    public void updateXpTracker() {
        if (xpTracker != null) {
            xpTracker.update();
        }
    }
    
    /**
     * Builds the paint with standardized dimensions and styling
     */
    public ScriptPaint build() {
        return new ScriptPaint(this);
    }
    
    // Getters for ScriptPaint
    public Rectangle getBounds() { return bounds; }
    public Color getBorderColor() { return borderColor; }
    public Font getFont() { return font; }
    public Color getBackgroundColor() { return backgroundColor; }
    public Color getTextColor() { return textColor; }
    public int getPadding() { return padding; }
    public boolean isShowTitle() { return showTitle; }
    public String getTitle() { return title; }
    public List<PaintRow> getRows() { return rows; }
    
    // Helper methods
    private String formatTime(long ms) {
        long s = ms / 1000;
        long m = s / 60;
        long h = m / 60;
        s %= 60;
        m %= 60;
        return String.format("%02d:%02d:%02d", h, m, s);
    }
    
    // Format numbers with k/m suffixes
    private String formatNumber(Number number) {
        if (number == null) return "0";
        
        long value = number.longValue();
        if (value < 1000) {
            return String.valueOf(value);
        } else if (value < 1000000) {
            return String.format("%.1fk", value / 1000.0).replace(".0k", "k");
        } else {
            return String.format("%.2fm", value / 1000000.0).replace(".00m", "m");
        }
    }
    
    // Paint row implementations
    public interface PaintRow {
        String getLabel();
        Object getValue();
        default RowIcon getIcon() { return null; }
        default boolean hasIcon() { return getIcon() != null; }
    }
    
    public static class StaticPaintRow implements PaintRow {
        private final String label;
        private final Object value;
        
        public StaticPaintRow(String label, Object value) {
            this.label = label;
            this.value = value;
        }
        
        @Override public String getLabel() { return label; }
        @Override public Object getValue() { return value; }
    }
    
    public static class DynamicPaintRow implements PaintRow {
        private final String label;
        private final Supplier<?> valueSupplier;
        
        public DynamicPaintRow(String label, Supplier<?> valueSupplier) {
            this.label = label;
            this.valueSupplier = valueSupplier;
        }
        
        @Override public String getLabel() { return label; }
        @Override public Object getValue() { return valueSupplier.get(); }
    }
    
    public static class StyledPaintRow implements PaintRow {
        private final String label;
        private final Supplier<?> valueSupplier;
        private final RowIcon icon;
        
        public StyledPaintRow(String label, Supplier<?> valueSupplier, RowIcon icon) {
            this.label = label;
            this.valueSupplier = valueSupplier;
            this.icon = icon;
        }
        
        @Override public String getLabel() { return label; }
        @Override public Object getValue() { return valueSupplier.get(); }
        @Override public RowIcon getIcon() { return icon; }
    }
    
    /**
     * Enum of icons that can be used in rows
     */
    public enum RowIcon {
        CLOCK(new Color(114, 137, 218), "\u23F0"),     // Clock emoji
        XP(new Color(87, 242, 135), "\u2B06"),         // Up arrow emoji
        COINS(new Color(255, 215, 0), "\u26C1"),       // Gold coin emoji
        TIMER(new Color(255, 165, 0), "\u23F3"),       // Hourglass emoji
        STATUS(new Color(114, 137, 218), "\u2699"),    // Gear emoji
        SPEED(new Color(255, 99, 71), "\u26A1"),       // Lightning bolt emoji
        LOCATION(new Color(135, 206, 250), "\u26F2"),  // Anchor emoji
        COMBAT(new Color(255, 99, 71), "\u2694"),      // Crossed swords emoji
        ITEM(new Color(210, 180, 140), "\u2696"),      // Scales emoji
        QUEST(new Color(255, 215, 0), "\u2605");       // Star emoji
        
        private final Color color;
        private final String symbol;
        
        RowIcon(Color color, String symbol) {
            this.color = color;
            this.symbol = symbol;
        }
        
        public Color getColor() {
            return color;
        }
        
        public String getSymbol() {
            return symbol;
        }
    }
}