package core.paint;

import core.context.ContextProvider;
import core.paint.debug.BaseDebugOverlay;
import core.paint.debug.DebugOverlay;
import core.paint.debug.DebugOverlayAdapter;
import org.dreambot.api.Client;
import org.dreambot.api.methods.widget.Widget;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.wrappers.widgets.WidgetChild;

import java.awt.*;
import java.awt.geom.Rectangle2D;

/**
 * Handles the rendering of script paint information.
 */
public class ScriptPaint extends ContextProvider {
    // Modern Professional Color Palette
    private static final Color BACKGROUND = new Color(25, 30, 40, 230);  // Dark blue-gray background
    private static final Color HEADER_BG = new Color(35, 40, 55, 240);   // Slightly lighter header
    private static final Color ACCENT_COLOR = new Color(88, 101, 242);   // Discord-like blue accent
    private static final Color ACCENT_COLOR_SECONDARY = new Color(114, 137, 218, 180); // Secondary accent
    private static final Color TEXT_PRIMARY = new Color(245, 245, 250);  // Almost white text
    private static final Color TEXT_SECONDARY = new Color(185, 190, 205); // Light gray text
    private static final Color VALUE_HIGHLIGHT = new Color(87, 242, 135); // Bright green for values
    private static final Color VALUE_NEGATIVE = new Color(255, 99, 99);  // Red for negative values
    private static final Color SEPARATOR = new Color(255, 255, 255, 30); // Very subtle separator
    private static final Color ROW_HIGHLIGHT = new Color(255, 255, 255, 15); // Subtle row highlight
    private static final Color USERNAME_BLUR_OVERLAY = new Color(20, 25, 35, 200); // Username privacy

    // Panel design constants
    private static final int PANEL_RADIUS = 15;      // Rounded corner radius
    private static final int HEADER_HEIGHT = 40;     // Header section height
    private static final int ROW_HEIGHT = 24;        // Height of each data row
    private static final int CONTENT_PADDING = 15;   // Padding inside content area
    private static final int HEADER_PADDING = 15;    // Padding inside header
    
    private final PaintBuilder builder;

    // Modern fonts
    private final Font HEADER_FONT = new Font("SansSerif", Font.BOLD, 15);
    private final Font CONTENT_FONT = new Font("SansSerif", Font.PLAIN, 12);
    private final Font VALUE_FONT = new Font("SansSerif", Font.BOLD, 12);
    private final Font SMALL_FONT = new Font("SansSerif", Font.PLAIN, 10);

    private boolean visible;
    private BaseDebugOverlay debugOverlay;
    
    // For animation effects
    private long lastUpdateTime = System.currentTimeMillis();
    private float pulseEffect = 0f;
    private boolean pulseDirection = true;

    public ScriptPaint(PaintBuilder builder) {
        super(builder.getContext());
        this.builder = builder;
        this.visible = true;
    }

    public void setDebugOverlay(BaseDebugOverlay overlay) {
        this.debugOverlay = overlay;
    }

    public void setDebugOverlay(DebugOverlay overlay) {
        this.debugOverlay = new DebugOverlayAdapter(overlay);
    }

    public void render(Graphics2D g) {
        if (!visible || !Client.isLoggedIn()) return;

        Widget chatWidget = Widgets.getWidget(162);
        if (chatWidget == null) return;

        WidgetChild chatBox = chatWidget.getChild(0);
        if (chatBox == null) return;

        setupGraphics(g);
        updateAnimationEffects();

        // Render debug overlay first
        if (debugOverlay != null) {
            debugOverlay.render(g);
        }

        // Main paint rendering
        int x = chatBox.getX();
        int y = chatBox.getY() - 5; // Slight offset to position above chat
        int width = chatBox.getWidth();
        int height = chatBox.getHeight() - 20; // Slightly shorter than chat

        drawMainPanel(g, x, y, width, height);
        drawHeader(g, x, y, width);
        drawContent(g, x, y + HEADER_HEIGHT, width, height - HEADER_HEIGHT);
        
        // Apply username blur effect
        blurUsernameArea(g, chatBox);
    }
    
    /**
     * Updates animation effects for the paint
     */
    private void updateAnimationEffects() {
        long currentTime = System.currentTimeMillis();
        long deltaTime = currentTime - lastUpdateTime;
        lastUpdateTime = currentTime;
        
        // Update pulse effect (0.0 to 1.0 and back)
        float pulseSpeed = 0.001f;
        if (pulseDirection) {
            pulseEffect += pulseSpeed * deltaTime;
            if (pulseEffect >= 1.0f) {
                pulseEffect = 1.0f;
                pulseDirection = false;
            }
        } else {
            pulseEffect -= pulseSpeed * deltaTime;
            if (pulseEffect <= 0.0f) {
                pulseEffect = 0.0f;
                pulseDirection = true;
            }
        }
    }
    
    /**
     * Applies a blur effect over the username area in the chatbox
     */
    private void blurUsernameArea(Graphics2D g, WidgetChild chatBox) {
        int x = chatBox.getX() + 10;
        int y = chatBox.getY();
        int width = 90; // Estimated width of username area
        int totalHeight = chatBox.getHeight();
        
        // Only apply blur to the bottom 30% of the chatbox where usernames typically appear
        int blurStartY = y + (int)(totalHeight * 0.65); // Start at 70% down the chatbox
        int height = (int)(totalHeight * 0.2); // Cover only the bottom 30%
        
        // Save the original composite
        Composite originalComposite = g.getComposite();
        
        // Create a semi-transparent overlay for the username area
        g.setColor(USERNAME_BLUR_OVERLAY);
        
        // Create a rounded rectangle for a softer look
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.fillRoundRect(x, blurStartY, width, height, 10, 10);
        
        // Add a subtle pattern for a more sophisticated blur effect
        g.setStroke(new BasicStroke(1.0f));
        for (int i = 0; i < height; i += 3) {
            g.setColor(new Color(255, 255, 255, 5));
            g.drawLine(x, blurStartY + i, x + width, blurStartY + i);
        }
        
        // Add a small "Privacy" label
        g.setFont(SMALL_FONT);
        g.setColor(new Color(255, 255, 255, 120));
        g.drawString("v1.2", x + 5, blurStartY + 12);
        
        // Restore the original composite
        g.setComposite(originalComposite);
    }

    private void setupGraphics(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
    }

    private void drawMainPanel(Graphics2D g, int x, int y, int width, int height) {
        // Drop shadow effect (subtle)
        g.setColor(new Color(0, 0, 0, 50));
        g.fillRoundRect(x + 3, y + 3, width, height, PANEL_RADIUS, PANEL_RADIUS);
        
        // Base panel background with gradient
        GradientPaint gradient = new GradientPaint(
            x, y, BACKGROUND, 
            x, y + height, new Color(BACKGROUND.getRed() - 10, BACKGROUND.getGreen() - 10, BACKGROUND.getBlue() - 10, BACKGROUND.getAlpha())
        );
        g.setPaint(gradient);
        g.fillRoundRect(x, y, width, height, PANEL_RADIUS, PANEL_RADIUS);

        // Accent border at the top
        g.setColor(ACCENT_COLOR);
        g.fillRect(x + 2, y + 2, width - 4, 3);
        
        // Subtle glow effect on the accent (pulsing)
        float alpha = 0.3f + (0.2f * pulseEffect);
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
        g.setColor(new Color(ACCENT_COLOR.getRed(), ACCENT_COLOR.getGreen(), ACCENT_COLOR.getBlue(), 60));
        g.fillRect(x + 2, y + 5, width - 4, 5);
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f));

        // Soft outline for a cleaner boundary
        g.setColor(new Color(0, 0, 0, 100));
        g.setStroke(new BasicStroke(1.0f));
        g.drawRoundRect(x, y, width, height, PANEL_RADIUS, PANEL_RADIUS);
    }

    private void drawHeader(Graphics2D g, int x, int y, int width) {
        // Header background with gradient
        GradientPaint headerGradient = new GradientPaint(
            x, y, HEADER_BG,
            x + width, y, new Color(HEADER_BG.getRed() + 5, HEADER_BG.getGreen() + 5, HEADER_BG.getBlue() + 10, HEADER_BG.getAlpha())
        );
        g.setPaint(headerGradient);
        g.fillRoundRect(x + 1, y + 3, width - 2, HEADER_HEIGHT, PANEL_RADIUS - 2, PANEL_RADIUS - 2);

        // Script title with icon-like element
        String title = builder.getTitle();
        g.setFont(HEADER_FONT);
        
        // Draw a small icon/badge before the title
        int iconSize = 18;
        int iconX = x + HEADER_PADDING;
        int iconY = y + (HEADER_HEIGHT / 2) - (iconSize / 2) + 2;
        
        // Icon background
        g.setColor(ACCENT_COLOR);
        g.fillRoundRect(iconX, iconY, iconSize, iconSize, 5, 5);
        
        // Icon detail (simple S letter or custom icon)
        g.setColor(TEXT_PRIMARY);
        g.setFont(new Font("SansSerif", Font.BOLD, 12));
        FontMetrics fm = g.getFontMetrics();
        String iconText = title.substring(0, 1).toUpperCase(); // First letter of title
        Rectangle2D textBounds = fm.getStringBounds(iconText, g);
        g.drawString(iconText, 
                     iconX + (iconSize - (int)textBounds.getWidth()) / 2, 
                     iconY + (iconSize + (int)textBounds.getHeight()) / 2 - 2);
        
        // Draw title text
        g.setFont(HEADER_FONT);
        g.setColor(TEXT_PRIMARY);
        int titleX = iconX + iconSize + 8;
        int titleY = y + (HEADER_HEIGHT / 2) + 6;
        g.drawString(title, titleX, titleY);
        
        // Draw runtime with a clock icon
        String runtime = formatTime(getRuntime());
        g.setFont(CONTENT_FONT);
        g.setColor(TEXT_SECONDARY);
        
        // Draw clock icon
        int clockSize = 12;
        int clockX = x + width - HEADER_PADDING - fm.stringWidth(runtime) - clockSize - 5;
        int clockY = titleY - 10;
        
        // Clock circle
        g.setColor(ACCENT_COLOR_SECONDARY);
        g.fillOval(clockX, clockY, clockSize, clockSize);
        
        // Clock hands
        g.setColor(TEXT_PRIMARY);
        g.setStroke(new BasicStroke(1.0f));
        g.drawLine(clockX + clockSize/2, clockY + clockSize/2, 
                  clockX + clockSize/2, clockY + clockSize/2 - clockSize/3);
        g.drawLine(clockX + clockSize/2, clockY + clockSize/2, 
                  clockX + clockSize/2 + clockSize/3, clockY + clockSize/2);
        
        // Draw runtime text
        g.setColor(TEXT_SECONDARY);
        g.drawString(runtime, clockX + clockSize + 5, titleY);

        // Separator under header
        drawSeparator(g, x + CONTENT_PADDING, y + HEADER_HEIGHT - 1, width - (CONTENT_PADDING * 2));
    }

    private void drawContent(Graphics2D g, int x, int y, int width, int height) {
        int currentY = y + CONTENT_PADDING;
        int leftColumnX = x + CONTENT_PADDING;
        int rightColumnX = x + width/2 + 5;
        int maxRowsPerColumn = (height - CONTENT_PADDING) / ROW_HEIGHT;
        
        // Update XP tracker if available
        if (builder.getXpTracker() != null) {
            builder.getXpTracker().update();
        }
        
        g.setFont(CONTENT_FONT);

        int rowCount = 0;
        for (PaintBuilder.PaintRow row : builder.getRows()) {
            // Break if we've exceeded the available space
            if (rowCount >= maxRowsPerColumn * 2) break;
            
            // Determine which column to draw in
            boolean isRightColumn = rowCount >= maxRowsPerColumn;
            int drawX = isRightColumn ? rightColumnX : leftColumnX;
            int adjustedY = isRightColumn ? 
                            y + CONTENT_PADDING + ((rowCount - maxRowsPerColumn) * ROW_HEIGHT) : 
                            currentY;
            
            // Draw row background with subtle animation effect
            if (rowCount % 2 == 0) {
                // Calculate a subtle pulse effect for the row highlight
                float rowPulse = 0.7f + (0.3f * pulseEffect);
                Color highlightColor = new Color(
                    ROW_HIGHLIGHT.getRed(),
                    ROW_HIGHLIGHT.getGreen(),
                    ROW_HIGHLIGHT.getBlue(),
                    (int)(ROW_HIGHLIGHT.getAlpha() * rowPulse)
                );
                
                g.setColor(highlightColor);
                int rowWidth = isRightColumn ? (width/2 - CONTENT_PADDING - 5) : (width/2 - CONTENT_PADDING);
                g.fillRoundRect(drawX - 5, adjustedY - 15, rowWidth, ROW_HEIGHT, 6, 6);
                
                // Add a subtle gradient effect
                GradientPaint rowGradient = new GradientPaint(
                    drawX - 5, adjustedY - 15, 
                    new Color(255, 255, 255, 5),
                    drawX - 5 + rowWidth, adjustedY - 15,
                    new Color(255, 255, 255, 15)
                );
                g.setPaint(rowGradient);
                g.fillRoundRect(drawX - 5, adjustedY - 15, rowWidth, ROW_HEIGHT, 6, 6);
                
                // Reset paint to solid color
                g.setPaint(null);
            }

            // Draw row with icon if available
            if (row.hasIcon()) {
                drawStyledRow(g, row, drawX, adjustedY);
            } else {
                // Draw standard row
                drawStandardRow(g, row, drawX, adjustedY);
            }
            
            // Only increment currentY if we're still in the left column
            if (!isRightColumn) {
                currentY += ROW_HEIGHT;
            }
            
            rowCount++;
        }
    }

    /**
     * Draws a standard row without an icon
     */
    private void drawStandardRow(Graphics2D g, PaintBuilder.PaintRow row, int x, int y) {
        // Draw label
        g.setColor(TEXT_SECONDARY);
        String label = row.getLabel() + ":";
        g.drawString(label, x, y);

        // Draw value
        g.setFont(VALUE_FONT);
        String value = String.valueOf(row.getValue());
        int valueX = x + g.getFontMetrics().stringWidth(label + " ");
        
        // Determine value color based on content
        if (isNumeric(value)) {
            // Check if it's a negative value (starts with - or has red/loss keywords)
            if (value.startsWith("-") || value.toLowerCase().contains("loss") || value.toLowerCase().contains("red")) {
                g.setColor(VALUE_NEGATIVE);
            } else {
                g.setColor(VALUE_HIGHLIGHT);
            }
        } else {
            g.setColor(TEXT_PRIMARY);
        }
        
        g.drawString(value, valueX, y);

        // Reset font for next iteration
        g.setFont(CONTENT_FONT);
    }

    /**
     * Draws a styled row with an icon
     */
    private void drawStyledRow(Graphics2D g, PaintBuilder.PaintRow row, int x, int y) {
        PaintBuilder.RowIcon icon = row.getIcon();
        int iconSize = 16;
        int iconY = y - 12;
        
        // Draw icon background with subtle glow effect
        Color iconColor = icon.getColor();
        g.setColor(iconColor);
        g.fillRoundRect(x - 2, iconY, iconSize, iconSize, 4, 4);
        
        // Add subtle glow around icon
        Color glowColor = new Color(iconColor.getRed(), iconColor.getGreen(), iconColor.getBlue(), 40);
        g.setColor(glowColor);
        g.fillRoundRect(x - 4, iconY - 2, iconSize + 4, iconSize + 4, 6, 6);
        
        // Draw icon symbol
        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.BOLD, 12));
        FontMetrics iconFm = g.getFontMetrics();
        Rectangle2D iconBounds = iconFm.getStringBounds(icon.getSymbol(), g);
        g.drawString(icon.getSymbol(), 
                    x - 2 + (iconSize - (int)iconBounds.getWidth()) / 2, 
                    iconY + (iconSize + (int)iconBounds.getHeight()) / 2 - 2);
        
        // Draw label with indent for icon
        g.setColor(TEXT_SECONDARY);
        g.setFont(CONTENT_FONT);
        String label = row.getLabel() + ":";
        g.drawString(label, x + iconSize + 4, y);
        
        // Draw value
        g.setFont(VALUE_FONT);
        String value = String.valueOf(row.getValue());
        int valueX = x + iconSize + 4 + g.getFontMetrics().stringWidth(label + " ");
        
        // Parse value for special formatting
        if (value.contains("(")) {
            // Handle values with rate information: "1.2k (45.6k/hr)"
            String[] parts = value.split("\\(");
            if (parts.length == 2) {
                String mainValue = parts[0].trim();
                String rateValue = "(" + parts[1].trim();
                
                // Draw main value with subtle shadow for better readability
                g.setColor(new Color(0, 0, 0, 60));
                g.drawString(mainValue, valueX + 1, y + 1);
                
                g.setColor(VALUE_HIGHLIGHT);
                g.drawString(mainValue, valueX, y);
                
                // Draw rate value
                int rateX = valueX + g.getFontMetrics().stringWidth(mainValue + " ");
                g.setColor(TEXT_SECONDARY);
                g.drawString(rateValue, rateX, y);
            } else {
                drawValueWithColor(g, value, valueX, y);
            }
        } else {
            drawValueWithColor(g, value, valueX, y);
        }
        
        // Reset font for next iteration
        g.setFont(CONTENT_FONT);
    }

    /**
     * Draws a value with appropriate color based on content
     */
    private void drawValueWithColor(Graphics2D g, String value, int x, int y) {
        // Determine value color based on content
        Color valueColor;
        if (isNumeric(value)) {
            // Check if it's a negative value (starts with - or has red/loss keywords)
            if (value.startsWith("-") || value.toLowerCase().contains("loss") || value.toLowerCase().contains("red")) {
                valueColor = VALUE_NEGATIVE;
            } else {
                valueColor = VALUE_HIGHLIGHT;
            }
        } else {
            valueColor = TEXT_PRIMARY;
        }
        
        // Draw subtle shadow for better readability
        g.setColor(new Color(0, 0, 0, 60));
        g.drawString(value, x + 1, y + 1);
        
        // Draw the actual value
        g.setColor(valueColor);
        g.drawString(value, x, y);
    }

    private void drawSeparator(Graphics2D g, int x, int y, int width) {
        // Gradient separator for a more polished look
        GradientPaint separatorGradient = new GradientPaint(
            x, y, new Color(SEPARATOR.getRed(), SEPARATOR.getGreen(), SEPARATOR.getBlue(), 0),
            x + width/2, y, SEPARATOR,
            true
        );
        g.setPaint(separatorGradient);
        g.fillRect(x, y, width, 1);
    }

    private boolean isNumeric(String str) {
        if (str == null) return false;
        str = str.replaceAll("[,kmKM]", "").trim();
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private String formatTime(long ms) {
        long s = ms / 1000;
        long m = s / 60;
        long h = m / 60;
        s %= 60;
        m %= 60;
        return String.format("%02d:%02d:%02d", h, m, s);
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public BaseDebugOverlay getDebugOverlay() {
        return debugOverlay;
    }
}
