package core.paint.debug;

import core.context.ContextProvider;
import core.context.ScriptContext;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.wrappers.graphics.GraphicsObject;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;

import java.awt.*;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

public abstract class BaseDebugOverlay extends ContextProvider {
    protected boolean enabled = true;
    protected boolean visualsEnabled = false;

    // Core collections for tracking
    protected final Set<HighlightedTile> highlightedTiles = new CopyOnWriteArraySet<>();
    protected final Set<HighlightedProjectile> highlightedProjectiles = new CopyOnWriteArraySet<>();
    protected final Map<Integer, Long> graphicSpawnTimes = new ConcurrentHashMap<>();
    protected final Map<Integer, Long> gameObjectSpawnTimes = new ConcurrentHashMap<>();
    protected final Set<Tile> occupiedTiles = new CopyOnWriteArraySet<>();

    // Default colors that can be overridden
    protected static final Color TEXT_COLOR = new Color(255, 255, 255);
    protected static final Color DANGER_TILE_COLOR = new Color(255, 0, 0, 100);
    protected static final Color BORDER_TILE_COLOR = new Color(0, 255, 0, 100);
    protected static final Color BACKGROUND_TILE_COLOR = new Color(50, 50, 50, 47);

    public BaseDebugOverlay(ScriptContext context) {
        super(context);
    }

    // Core functionality methods
    public void toggle() {
        visualsEnabled = !visualsEnabled;
        log("Debug overlay visuals " + (visualsEnabled ? "enabled" : "disabled"));
    }

    public boolean isEnabled() {
        return enabled;
    }

    public boolean areVisualsEnabled() {
        return visualsEnabled;
    }

    // Base highlighting methods
    public void highlightNPCTileArea(NPC npc, Color highlightColor, String label) {
        if (npc == null || !npc.exists()) return;
        Area npcArea = npc.getArea();
        addTileHighlight(HighlightedTile.builder()
                .area(npcArea)
                .color(highlightColor)
                .label(label)
                .build());
        addTileHighlight(HighlightedTile.builder()
                .area(npcArea)
                .color(BORDER_TILE_COLOR)
                .isBorder(true)
                .build());
    }

    public void highlightTile(Tile tile, Color color, String label) {
        addTileHighlight(HighlightedTile.builder()
                .tile(tile)
                .color(color)
                .label(label)
                .build());
    }

    public void highlightArea(Area area, Color color, String label) {
        addTileHighlight(HighlightedTile.builder()
                .area(area)
                .color(color)
                .label(label)
                .build());
    }

    public void highlightProjectile(Projectile projectile, Tile startTile, Tile endTile, Color pathColor, Color endTileColor) {
        if (projectile == null) return;
        addProjectileHighlight(HighlightedProjectile.builder()
                .projectile(projectile)
                .startTile(startTile)
                .endTile(endTile)
                .pathColor(pathColor)
                .endTileColor(endTileColor)
                .build());
    }

    // Graphics object tracking
    public void recordGraphicSpawn(int graphicHash) {
        graphicSpawnTimes.putIfAbsent(graphicHash, System.currentTimeMillis());
    }

    public long getGraphicElapsedTime(int graphicHash) {
        Long spawnTime = graphicSpawnTimes.get(graphicHash);
        return spawnTime != null ? System.currentTimeMillis() - spawnTime : 0;
    }

    public void removeGraphicSpawn(int graphicHash) {
        graphicSpawnTimes.remove(graphicHash);
    }

    // GameObject tracking methods
    public void recordGameObjectSpawn(int objectHash) {
        gameObjectSpawnTimes.putIfAbsent(objectHash, System.currentTimeMillis());
    }

    public long getGameObjectElapsedTime(int objectHash) {
        Long spawnTime = gameObjectSpawnTimes.get(objectHash);
        return spawnTime != null ? System.currentTimeMillis() - spawnTime : 0;
    }

    public void removeGameObjectSpawn(int objectHash) {
        gameObjectSpawnTimes.remove(objectHash);
    }

    protected void cleanupExpiredGraphics(long expiryTime) {
        Set<Integer> expiredGraphics = new HashSet<>();
        graphicSpawnTimes.forEach((hash, time) -> {
            if (getGraphicElapsedTime(hash) > expiryTime) {
                expiredGraphics.add(hash);
            }
        });
        expiredGraphics.forEach(this::removeGraphicSpawn);
    }

    protected void cleanupExpiredGameObjects(long expiryTime) {
        Set<Integer> expiredObjects = new HashSet<>();
        gameObjectSpawnTimes.forEach((hash, time) -> {
            if (getGameObjectElapsedTime(hash) > expiryTime) {
                expiredObjects.add(hash);
            }
        });
        expiredObjects.forEach(this::removeGameObjectSpawn);
    }

    // Utility methods
    public void clearTileHighlights() {
        highlightedTiles.clear();
    }

    public void clearProjectileHighlights() {
        highlightedProjectiles.clear();
    }

    // Additional utility methods
    protected int getTilePriority(Color color) {
        if (color.equals(BACKGROUND_TILE_COLOR)) return 0;
        if (color.equals(BORDER_TILE_COLOR)) return 1;
        return 2;
    }

    protected void log(String message) {
        context.getLogger().debug("[Debug Overlay] " + message);
    }

    protected void trackGraphicsObjectWithDuration(GraphicsObject obj, int graphicsId, Color color, String label, long duration) {
        if (obj != null && obj.getID() == graphicsId) {
            Tile graphicTile = obj.getTile();
            if (graphicTile != null) {
                int hash = obj.hashCode();
                recordGraphicSpawn(hash);
                long elapsedTime = getGraphicElapsedTime(hash);
                
                if (elapsedTime <= duration) {
                    highlightedTiles.add(HighlightedTile.builder()
                            .tile(graphicTile)
                            .color(color)
                            .label(label != null ? label + " " + (elapsedTime / 1000.0) + "s" : null)
                            .build());
                    occupiedTiles.add(graphicTile);
                } else {
                    removeGraphicSpawn(hash);
                }
            }
        }
    }

    protected void trackProjectileWithPath(Projectile projectile, Color pathColor, Color endTileColor) {
        if (projectile == null || !projectile.exists()) return;

        Tile startTile = new Tile(projectile.getOriginX(), projectile.getOriginY(), projectile.getZ());
        Tile endTile = new Tile(projectile.getX(), projectile.getY(), projectile.getZ());

        if (startTile != null && endTile != null) {
            highlightProjectile(projectile, startTile, endTile, pathColor, endTileColor);
        }
    }

    protected void highlightNPCWithBorder(NPC npc, Color fillColor, Color borderColor, String label) {
        if (npc == null || !npc.exists()) return;

        Area npcArea = npc.getArea();
        // Highlight the area itself
        addTileHighlight(HighlightedTile.builder()
                .area(npcArea)
                .color(fillColor)
                .label(label)
                .build());

        // Highlight the border with custom color
        addTileHighlight(HighlightedTile.builder()
                .area(npcArea)
                .color(borderColor)
                .isBorder(true)
                .build());
    }

    protected void highlightTileRange(Tile centerTile, int range, Color color) {
        if (centerTile == null) return;

        for (int x = -range; x <= range; x++) {
            for (int y = -range; y <= range; y++) {
                Tile tile = centerTile.translate(x, y);
                if (tile != null && !occupiedTiles.contains(tile)) {
                    highlightTile(tile, color, null);
                }
            }
        }
    }

    protected void highlightPath(java.util.List<Tile> path, Color pathColor, String label) {
        if (path == null || path.isEmpty()) return;

        for (int i = 0; i < path.size(); i++) {
            Tile tile = path.get(i);
            String tileLabel = label != null ? label + " " + (i + 1) : null;
            highlightTile(tile, pathColor, tileLabel);
        }
    }

    public void highlightAreaBorder(Area area, Color borderColor) {
        if (area == null) return;
        addTileHighlight(HighlightedTile.builder()
                .area(area)
                .color(borderColor)
                .isBorder(true)
                .build());
    }

    public void highlightAreaWithLabel(Area area, Color fillColor, String label) {
        if (area == null) return;
        addTileHighlight(HighlightedTile.builder()
                .area(area)
                .color(fillColor)
                .label(label)
                .build());
    }

    protected boolean isWithinRange(Tile tile1, Tile tile2, int range) {
        return tile1 != null && tile2 != null && tile1.distance(tile2) <= range;
    }

    protected Set<Tile> getTilesWithColor(Color color) {
        return highlightedTiles.stream()
                .filter(ht -> ht.getColor().equals(color))
                .filter(ht -> ht.tile != null)
                .map(ht -> ht.tile)
                .collect(java.util.stream.Collectors.toSet());
    }

    protected Set<Tile> getTilesWithColors(Set<Color> colors) {
        return highlightedTiles.stream()
                .filter(ht -> colors.contains(ht.getColor()))
                .filter(ht -> ht.tile != null)
                .map(ht -> ht.tile)
                .collect(java.util.stream.Collectors.toSet());
    }

    protected void clearTilesWithColor(Color color) {
        highlightedTiles.removeIf(ht -> ht.getColor().equals(color));
    }

    protected void clearTilesInArea(Area area) {
        highlightedTiles.removeIf(ht -> ht.tile != null && area.contains(ht.tile));
    }

    protected boolean hasTileWithColor(Tile tile, Color color) {
        return highlightedTiles.stream()
                .anyMatch(ht -> ht.tile != null && ht.tile.equals(tile) && ht.getColor().equals(color));
    }

    // Abstract methods that must be implemented by specific overlays
    public abstract void updateAllTiles();
    public abstract void updateGameObjectHighlights();
    public abstract void updateGraphicsHighlights();
    public abstract void render(Graphics2D g);
    public abstract Set<Tile> getDangerTiles();
    public abstract Set<Tile> getBorderTiles();
    public abstract boolean isDangerTile(Tile tile);
    public abstract long getTimeToImpactForTile(Tile tile, long totalFlightTime);

    // Protected helper methods for subclasses
    protected void addTileHighlight(HighlightedTile tileHighlight) {
        if (tileHighlight.isBorder && tileHighlight.area != null) {
            Set<Tile> borderTiles = computeBorderTiles(tileHighlight.area);
            for (Tile borderTile : borderTiles) {
                highlightedTiles.add(HighlightedTile.builder()
                        .tile(borderTile)
                        .color(BORDER_TILE_COLOR)
                        .isBorder(false)
                        .build());
            }
        } else {
            highlightedTiles.add(tileHighlight);
        }
    }

    protected void addProjectileHighlight(HighlightedProjectile projectileHighlight) {
        highlightedProjectiles.add(projectileHighlight);
    }

    protected Set<Tile> computeBorderTiles(Area area) {
        Set<Tile> borderTiles = new HashSet<>();
        Tile[] areaTiles = area.getTiles();
        if (areaTiles.length == 0) return borderTiles;

        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;

        for (Tile t : areaTiles) {
            minX = Math.min(minX, t.getX());
            maxX = Math.max(maxX, t.getX());
            minY = Math.min(minY, t.getY());
            maxY = Math.max(maxY, t.getY());
        }

        for (int x = minX - 1; x <= maxX + 1; x++) {
            for (int y = minY - 1; y <= maxY + 1; y++) {
                Tile borderTile = new Tile(x, y, areaTiles[0].getZ());
                if (!area.contains(borderTile)) {
                    boolean isAdjacent = false;
                    for (Tile areaTile : areaTiles) {
                        if ((areaTile.getX() == x && Math.abs(areaTile.getY() - y) <= 1)
                                || (areaTile.getY() == y && Math.abs(areaTile.getX() - x) <= 1)) {
                            isAdjacent = true;
                            break;
                        }
                    }
                    if (isAdjacent) {
                        borderTiles.add(borderTile);
                    }
                }
            }
        }
        return borderTiles;
    }

    protected void trackGraphicsObject(GraphicsObject obj, int graphicsId, Color color, String label) {
        if (obj != null && obj.getID() == graphicsId) {
            Tile graphicTile = obj.getTile();
            if (graphicTile != null) {
                int hash = obj.hashCode();
                recordGraphicSpawn(hash);
                long elapsedTime = getGraphicElapsedTime(hash);
                
                highlightedTiles.add(HighlightedTile.builder()
                        .tile(graphicTile)
                        .color(color)
                        .label(label != null ? label + " " + (elapsedTime / 1000.0) + "s" : null)
                        .build());
                occupiedTiles.add(graphicTile);
            }
        }
    }

    protected void trackGameObject(GameObject obj, int objectId, Color color, String label) {
        if (obj != null && obj.getID() == objectId) {
            Tile objectTile = obj.getTile();
            if (objectTile != null) {
                int hash = obj.hashCode();
                recordGameObjectSpawn(hash);
                long elapsedTime = getGameObjectElapsedTime(hash);
                
                highlightedTiles.add(HighlightedTile.builder()
                        .tile(objectTile)
                        .color(color)
                        .label(label != null ? label + " " + (elapsedTime / 1000.0) + "s" : null)
                        .build());
                occupiedTiles.add(objectTile);
            }
        }
    }

    protected void trackGameObjectWithDuration(GameObject obj, int objectId, Color color, String label, long duration) {
        if (obj != null && obj.getID() == objectId) {
            Tile objectTile = obj.getTile();
            if (objectTile != null) {
                int hash = obj.hashCode();
                recordGameObjectSpawn(hash);
                long elapsedTime = getGameObjectElapsedTime(hash);
                
                if (elapsedTime <= duration) {
                    highlightedTiles.add(HighlightedTile.builder()
                            .tile(objectTile)
                            .color(color)
                            .label(label != null ? label + " " + (elapsedTime / 1000.0) + "s" : null)
                            .build());
                    occupiedTiles.add(objectTile);
                } else {
                    removeGameObjectSpawn(hash);
                }
            }
        }
    }

    protected void trackGameObjectArea(GameObject obj, int objectId, Color fillColor, Color borderColor, String label) {
        if (obj != null && obj.getID() == objectId) {
            Rectangle boundingBox = obj.getBoundingBox();
            if (boundingBox != null) {
                int hash = obj.hashCode();
                recordGameObjectSpawn(hash);
                long elapsedTime = getGameObjectElapsedTime(hash);
                
                // Convert Rectangle to Area using tile coordinates
                Tile baseTile = obj.getTile();
                if (baseTile != null) {
                    int width = (int) Math.ceil(boundingBox.getWidth() / 32.0);  // Convert pixels to tiles
                    int height = (int) Math.ceil(boundingBox.getHeight() / 32.0);
                    Area objectArea = new Area(
                        baseTile.getX(),
                        baseTile.getY(),
                        baseTile.getX() + width - 1,
                        baseTile.getY() + height - 1,
                        baseTile.getZ()
                    );
                    
                    // Add area highlight with fill color
                    highlightedTiles.add(HighlightedTile.builder()
                            .area(objectArea)
                            .color(fillColor)
                            .label(label != null ? label + " " + (elapsedTime / 1000.0) + "s" : null)
                            .build());
                    
                    // Add border highlight
                    highlightedTiles.add(HighlightedTile.builder()
                            .area(objectArea)
                            .color(borderColor)
                            .isBorder(true)
                            .build());
                    
                    // Mark tiles as occupied
                    for (int x = 0; x < width; x++) {
                        for (int y = 0; y < height; y++) {
                            occupiedTiles.add(baseTile.translate(x, y));
                        }
                    }
                }
            }
        }
    }

    protected void trackGameObjectAreaWithDuration(GameObject obj, int objectId, Color fillColor, Color borderColor, String label, long duration) {
        if (obj != null && obj.getID() == objectId) {
            Rectangle boundingBox = obj.getBoundingBox();
            if (boundingBox != null) {
                int hash = obj.hashCode();
                recordGameObjectSpawn(hash);
                long elapsedTime = getGameObjectElapsedTime(hash);
                
                if (elapsedTime <= duration) {
                    // Convert Rectangle to Area using tile coordinates
                    Tile baseTile = obj.getTile();
                    if (baseTile != null) {
                        int width = (int) Math.ceil(boundingBox.getWidth() / 32.0);  // Convert pixels to tiles
                        int height = (int) Math.ceil(boundingBox.getHeight() / 32.0);
                        Area objectArea = new Area(
                            baseTile.getX(),
                            baseTile.getY(),
                            baseTile.getX() + width - 1,
                            baseTile.getY() + height - 1,
                            baseTile.getZ()
                        );
                        
                        // Add area highlight with fill color
                        highlightedTiles.add(HighlightedTile.builder()
                                .area(objectArea)
                                .color(fillColor)
                                .label(label != null ? label + " " + (elapsedTime / 1000.0) + "s" : null)
                                .build());
                        
                        // Add border highlight
                        highlightedTiles.add(HighlightedTile.builder()
                                .area(objectArea)
                                .color(borderColor)
                                .isBorder(true)
                                .build());
                        
                        // Mark tiles as occupied
                        for (int x = 0; x < width; x++) {
                            for (int y = 0; y < height; y++) {
                                occupiedTiles.add(baseTile.translate(x, y));
                            }
                        }
                    }
                } else {
                    removeGameObjectSpawn(hash);
                }
            }
        }
    }

    // Inner class for highlighted tiles
    protected static class HighlightedTile {
        protected final Area area;
        protected final Tile tile;
        protected final Color color;
        protected final String label;
        protected final boolean isBorder;

        private HighlightedTile(Area area, Tile tile, Color color, String label, boolean isBorder) {
            this.area = area;
            this.tile = tile;
            this.color = color;
            this.label = label;
            this.isBorder = isBorder;
        }

        public Color getColor() {
            return color;
        }

        public void render(Graphics2D g, ScriptContext context) {
            if (tile != null) {
                renderTile(g, tile, color, label);
            } else if (area != null && !isBorder) {
                // Render the entire area (non-border areas)
                for (Tile areaTile : area.getTiles()) {
                    renderTile(g, areaTile, color, label);
                }
            }
        }

        private static void renderTile(Graphics2D g, Tile tileToRender, Color color, String label) {
            Polygon poly = tileToRender.getPolygon();
            if (poly == null) return;

            g.setColor(color);
            g.fillPolygon(poly);

            if (!color.equals(BACKGROUND_TILE_COLOR)) {
                g.setColor(Color.BLACK);
                g.drawPolygon(poly);
            }

            if (label != null) {
                Point center = new Point(
                        (poly.xpoints[0] + poly.xpoints[2]) / 2,
                        (poly.ypoints[0] + poly.ypoints[2]) / 2
                );
                g.setColor(TEXT_COLOR);
                g.drawString(label, center.x, center.y);
            }
        }

        public static Builder builder() {
            return new Builder();
        }

        static class Builder {
            private Area area;
            private Tile tile;
            private Color color;
            private String label;
            private boolean isBorder;

            public Builder area(Area area) {
                this.area = area;
                return this;
            }

            public Builder tile(Tile tile) {
                this.tile = tile;
                return this;
            }

            public Builder color(Color color) {
                this.color = color;
                return this;
            }

            public Builder label(String label) {
                this.label = label;
                return this;
            }

            public Builder isBorder(boolean isBorder) {
                this.isBorder = isBorder;
                return this;
            }

            public HighlightedTile build() {
                return new HighlightedTile(area, tile, color, label, isBorder);
            }
        }
    }

    // Inner class for highlighted projectiles
    protected static class HighlightedProjectile {
        private final Projectile projectile;
        private final Tile startTile;
        private final Tile endTile;
        private final Color pathColor;
        private final Color endTileColor;

        private HighlightedProjectile(Projectile projectile, Tile startTile, Tile endTile, Color pathColor, Color endTileColor) {
            this.projectile = projectile;
            this.startTile = startTile;
            this.endTile = endTile;
            this.pathColor = pathColor;
            this.endTileColor = endTileColor;
        }

        public boolean isValid() {
            return projectile != null && projectile.exists();
        }

        public void render(Graphics2D g, ScriptContext context) {
            if (!isValid()) return;

            Polygon startPoly = startTile.getPolygon();
            Polygon endPoly = endTile.getPolygon();
            if (startPoly == null || endPoly == null) return;

            Point start = new Point(
                    (startPoly.xpoints[0] + startPoly.xpoints[2]) / 2,
                    (startPoly.ypoints[0] + startPoly.ypoints[2]) / 2
            );
            Point end = new Point(
                    (endPoly.xpoints[0] + endPoly.xpoints[2]) / 2,
                    (endPoly.ypoints[0] + endPoly.ypoints[2]) / 2
            );

            // Draw path line
            g.setColor(pathColor);
            g.drawLine(start.x, start.y, end.x, end.y);

            // Highlight the end tile
            g.setColor(endTileColor);
            g.fillPolygon(endPoly);
            g.setColor(Color.BLACK);
            g.drawPolygon(endPoly);

            // Draw timer
            int totalCycles = projectile.getEndCycle() - projectile.getStartCycle();
            int currentCycle = org.dreambot.api.Client.getGameCycle() - projectile.getStartCycle();
            double progress = (double) currentCycle / totalCycles;
            double timeLeft = (1.0 - progress) * (totalCycles * 0.6 / 100.0);
            String timer = String.format("%.1fs", timeLeft);

            g.setColor(TEXT_COLOR);
            g.drawString(timer, end.x, end.y);
        }

        public static Builder builder() {
            return new Builder();
        }

        static class Builder {
            private Projectile projectile;
            private Tile startTile;
            private Tile endTile;
            private Color pathColor = new Color(255, 255, 0, 100);
            private Color endTileColor = new Color(255, 165, 0, 100);

            public Builder projectile(Projectile projectile) {
                this.projectile = projectile;
                return this;
            }

            public Builder startTile(Tile startTile) {
                this.startTile = startTile;
                return this;
            }

            public Builder endTile(Tile endTile) {
                this.endTile = endTile;
                return this;
            }

            public Builder pathColor(Color pathColor) {
                this.pathColor = pathColor;
                return this;
            }

            public Builder endTileColor(Color endTileColor) {
                this.endTileColor = endTileColor;
                return this;
            }

            public HighlightedProjectile build() {
                return new HighlightedProjectile(projectile, startTile, endTile, pathColor, endTileColor);
            }
        }
    }
} 