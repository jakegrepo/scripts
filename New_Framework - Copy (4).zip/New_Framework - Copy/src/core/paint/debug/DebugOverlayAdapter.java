package core.paint.debug;

import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.wrappers.interactive.NPC;

import java.awt.*;
import java.util.Set;

/**
 * Adapter class that allows the old DebugOverlay to be used with the new BaseDebugOverlay system.
 * This maintains backward compatibility for scripts using the old system while allowing new scripts
 * to use the more modular BaseDebugOverlay.
 */
public class DebugOverlayAdapter extends BaseDebugOverlay {
    private final DebugOverlay legacyOverlay;

    public DebugOverlayAdapter(DebugOverlay legacyOverlay) {
        super(legacyOverlay.getContext());
        this.legacyOverlay = legacyOverlay;
    }

    @Override
    public void updateAllTiles() {
        legacyOverlay.updateAllTiles();
    }

    @Override
    public void updateGameObjectHighlights() {
    }

    @Override
    public void updateGraphicsHighlights() {
        legacyOverlay.updateGraphicsHighlights();
    }

    @Override
    public void render(Graphics2D g) {
        legacyOverlay.render(g);
    }

    @Override
    public Set<Tile> getDangerTiles() {
        return legacyOverlay.getDangerTiles();
    }

    @Override
    public Set<Tile> getBorderTiles() {
        return legacyOverlay.getBorderTiles();
    }

    @Override
    public boolean isDangerTile(Tile tile) {
        return legacyOverlay.isDangerTile(tile);
    }

    @Override
    public long getTimeToImpactForTile(Tile tile, long totalFlightTime) {
        return legacyOverlay.getTimeToImpactForTile(tile, totalFlightTime);
    }

    @Override
    public void toggle() {
        legacyOverlay.toggle();
    }

    @Override
    public boolean isEnabled() {
        return legacyOverlay.isEnabled();
    }

    @Override
    public boolean areVisualsEnabled() {
        return legacyOverlay.areVisualsEnabled();
    }

    @Override
    public void highlightNPCTileArea(NPC npc, Color highlightColor, String label) {
        legacyOverlay.highlightNPCTileArea(npc, highlightColor, label);
    }

    @Override
    public void highlightTile(Tile tile, Color color, String label) {
        legacyOverlay.highlightTile(tile, color, label);
    }

    @Override
    public void highlightArea(Area area, Color color, String label) {
        legacyOverlay.highlightArea(area, color, label);
    }

    @Override
    public void clearTileHighlights() {
        legacyOverlay.clearTileHighlights();
    }

    @Override
    public void clearProjectileHighlights() {
        legacyOverlay.clearProjectileHighlights();
    }
} 