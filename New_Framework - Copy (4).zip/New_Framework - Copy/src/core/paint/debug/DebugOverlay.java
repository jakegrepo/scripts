package core.paint.debug;

import core.context.ContextProvider;
import core.context.ScriptContext;
import core.utils.ScriptLogger;
import org.dreambot.api.Client;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.NPC;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * A debug overlay that renders highlighted tiles and projectiles,
 * storing them so that getBorderTiles() and getDangerTiles() work as intended.
 */
public class DebugOverlay extends ContextProvider {
    private boolean enabled = true;
    private boolean visualsEnabled = false;

    // Highlighted tiles and projectiles
    private final Set<HighlightedTile> highlightedTiles = new CopyOnWriteArraySet<>();
    private final Set<HighlightedProjectile> highlightedProjectiles = new CopyOnWriteArraySet<>();

    // Record spawn times for graphics
    private final Map<Integer, Long> graphicSpawnTimes = new ConcurrentHashMap<>();

    // Default colors
    private static final Color TEXT_COLOR = new Color(255, 255, 255);
    private static final Color SCURRIUS_COLOR = new Color(255, 165, 0, 100); // Orange
    private static final Color DANGER_TILE_COLOR = new Color(255, 0, 0, 100); // Red
    private static final Color BORDER_TILE_COLOR = new Color(0, 255, 0, 100); // Green
    private static final Color BACKGROUND_TILE_COLOR = new Color(50, 50, 50, 47); // Dark grey with transparency

    // Track occupied tiles to prevent overlap
    private final Set<Tile> occupiedTiles = new CopyOnWriteArraySet<>();

    private final ScriptLogger logger;

    public DebugOverlay(ScriptContext context) {
        super(context);
        this.logger = context.getLogger();
    }

    public void toggle() {
        visualsEnabled = !visualsEnabled;
        logger.debug("Debug overlay visuals " + (visualsEnabled ? "enabled" : "disabled"));
    }

    public boolean isEnabled() {
        return enabled;
    }

    public boolean areVisualsEnabled() {
        return visualsEnabled;
    }

    /**
     * Highlight a 3x3 area around an NPC and its border.
     */
    public void highlightNPCTileArea(NPC npc, Color highlightColor, String label) {
        if (npc == null || !npc.exists()) {
            return;
        }

        Area npcArea = npc.getArea();
        // Highlight the area itself
        addTileHighlight(HighlightedTile.builder()
                .area(npcArea)
                .color(highlightColor)
                .label(label)
                .build());

        // Highlight the border
        addTileHighlight(HighlightedTile.builder()
                .area(npcArea)
                .color(BORDER_TILE_COLOR)
                .isBorder(true)
                .build());
    }

    /**
     * Highlight a single tile.
     */
    public void highlightTile(Tile tile, Color color, String label) {
        addTileHighlight(HighlightedTile.builder()
                .tile(tile)
                .color(color)
                .label(label)
                .build());
    }

    /**
     * Highlight an area.
     */
    public void highlightArea(Area area, Color color, String label) {
        addTileHighlight(HighlightedTile.builder()
                .area(area)
                .color(color)
                .label(label)
                .build());
    }

    /**
     * Highlight a projectile.
     */
    public void highlightProjectile(Projectile projectile, Tile startTile, Tile endTile, Color pathColor, Color endTileColor) {
        if (projectile == null) {
            return;
        }

        addProjectileHighlight(HighlightedProjectile.builder()
                .projectile(projectile)
                .startTile(startTile)
                .endTile(endTile)
                .pathColor(pathColor)
                .endTileColor(endTileColor)
                .build());
    }

    /**
     * Clears all highlighted tiles.
     */
    public void clearTileHighlights() {
        highlightedTiles.clear();
    }

    /**
     * Clears all highlighted projectiles.
     */
    public void clearProjectileHighlights() {
        highlightedProjectiles.clear();
    }

    /**
     * Records the spawn time of a specific graphic.
     */
    public void recordGraphicSpawn(int graphicHash) {
        graphicSpawnTimes.putIfAbsent(graphicHash, System.currentTimeMillis());
    }

    public long getGraphicElapsedTime(int graphicHash) {
        Long spawnTime = graphicSpawnTimes.get(graphicHash);
        if (spawnTime == null) return 0;
        return System.currentTimeMillis() - spawnTime;
    }

    public void removeGraphicSpawn(int graphicHash) {
        graphicSpawnTimes.remove(graphicHash);
    }

    public void render(Graphics2D g) {
        // Always update tracking regardless of visual state
        updateAllTiles();
        updateScurriusHighlight();
        updateGraphicsHighlights();

        // Don't render anything if visuals are disabled
        if (!visualsEnabled) {
            return;
        }

        // Sort highlights by color to ensure proper layering
        new ArrayList<>(highlightedTiles).stream()
                .sorted((t1, t2) -> {
                    int priority1 = getTilePriority(t1.getColor());
                    int priority2 = getTilePriority(t2.getColor());
                    return Integer.compare(priority1, priority2);
                })
                .forEach(tile -> tile.render(g, context));

        // Render projectiles
        new ArrayList<>(highlightedProjectiles).forEach(p -> p.render(g, context));

        // Clean up expired graphics
        cleanupExpiredGraphics();
    }

    private void addTileHighlight(HighlightedTile tileHighlight) {
        // If this is a border highlight with an area, compute border tiles now
        if (tileHighlight.isBorder && tileHighlight.area != null) {
            // Compute border tiles and add them individually
            Set<Tile> borderTiles = computeBorderTiles(tileHighlight.area);
            for (Tile borderTile : borderTiles) {
                // Each border tile is added as its own HighlightedTile
                highlightedTiles.add(HighlightedTile.builder()
                        .tile(borderTile)
                        .color(BORDER_TILE_COLOR)
                        .isBorder(false) // The tile itself is not an "area border," it's an actual tile now
                        .build());
            }
        } else {
            highlightedTiles.add(tileHighlight);
        }
    }

    private Set<Tile> computeBorderTiles(Area area) {
        Set<Tile> borderTiles = new HashSet<>();
        Tile[] areaTiles = area.getTiles();

        if (areaTiles.length == 0) return borderTiles;

        // Calculate the area bounds
        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;

        for (Tile t : areaTiles) {
            minX = Math.min(minX, t.getX());
            maxX = Math.max(maxX, t.getX());
            minY = Math.min(minY, t.getY());
            maxY = Math.max(maxY, t.getY());
        }

        // Compute border tiles
        for (int x = minX - 1; x <= maxX + 1; x++) {
            for (int y = minY - 1; y <= maxY + 1; y++) {
                Tile borderTile = new Tile(x, y, areaTiles[0].getZ());
                if (!area.contains(borderTile)) {
                    boolean isAdjacent = false;
                    for (Tile areaTile : areaTiles) {
                        // Only consider a tile adjacent if it is orthogonally adjacent,
                        // meaning it shares either the same X or the same Y coordinate.
                        if ((areaTile.getX() == x && Math.abs(areaTile.getY() - y) <= 1)
                                || (areaTile.getY() == y && Math.abs(areaTile.getX() - x) <= 1)) {
                            isAdjacent = true;
                            break;
                        }
                    }

                    if (isAdjacent) {
                        borderTiles.add(borderTile);
                    }
                }
            }
        }
        return borderTiles;
    }

    private void addProjectileHighlight(HighlightedProjectile projectileHighlight) {
        highlightedProjectiles.add(projectileHighlight);
    }

    private int getTilePriority(Color color) {
        if (color.equals(BACKGROUND_TILE_COLOR)) return 0;
        if (color.equals(BORDER_TILE_COLOR)) return 1; // Border color
        if (color.equals(SCURRIUS_COLOR)) return 2;
        if (color.equals(DANGER_TILE_COLOR)) return 3;
        return 4;
    }

    private void cleanupExpiredGraphics() {
        Set<Integer> expiredGraphics = new HashSet<>();
        graphicSpawnTimes.forEach((hash, time) -> {
            if (getGraphicElapsedTime(hash) > 3000) {
                expiredGraphics.add(hash);
            }
        });
        expiredGraphics.forEach(this::removeGraphicSpawn);
    }

    public void updateAllTiles() {
        try {
            clearTileHighlights();
            occupiedTiles.clear();

            Tile playerTile = Players.getLocal().getTile();
            if (playerTile == null) return;

            log("Updating room tiles around player at: " + playerTile);

            int range = 10;
            for (int x = -range; x <= range; x++) {
                for (int y = -range; y <= range; y++) {
                    Tile tile = playerTile.translate(x, y);
                    if (tile != null && !occupiedTiles.contains(tile)) {
                        highlightTile(tile, BACKGROUND_TILE_COLOR, null);
                    }
                }
            }
            logger.debug("Updated all tiles in debug overlay");
        } catch (Exception e) {
            logger.error("Error updating tiles in debug overlay: " + e.getMessage());
        }
    }

    public void updateScurriusHighlight() {
        try {
            NPC scurrius = NPCs.closest(npc ->
                    npc != null &&
                            npc.exists() &&
                            npc.getName() != null &&
                            npc.getName().equals("Scurrius"));

            if (scurrius != null) {
                log("Found Scurrius at: " + scurrius.getTile() + " with true tile: " + scurrius.getTrueTile());
                highlightNPCTileArea(scurrius, SCURRIUS_COLOR, "");
            }
            logger.debug("Updated Scurrius highlight");
        } catch (Exception e) {
            logger.error("Error updating Scurrius highlight: " + e.getMessage());
        }
    }

    public void updateGraphicsHighlights() {
        try {
            final int FALLING_ROCKS_GRAPHICS_ID = 2644;

            // Remove expired graphics first
            cleanupExpiredGraphics();

            // Track and highlight new graphics
            Client.getGraphicsObjects().stream()
                    .filter(obj -> obj != null && obj.getID() == FALLING_ROCKS_GRAPHICS_ID)
                    .forEach(obj -> {
                        Tile graphicTile = obj.getTile();
                        if (graphicTile != null) {
                            int hash = obj.hashCode();
                            recordGraphicSpawn(hash);
                            long elapsedTime = getGraphicElapsedTime(hash);

                            HighlightedTile highlight = HighlightedTile.builder()
                                    .tile(graphicTile)
                                    .color(DANGER_TILE_COLOR)
                                    .label("Danger " + (elapsedTime / 1000.0) + "s")
                                    .build();
                            
                            highlightedTiles.add(highlight);
                            occupiedTiles.add(graphicTile);
                        }
                    });
        } catch (Exception e) {
            logger.error("Error updating graphics highlights: " + e.getMessage());
        }
    }

    /**
     * Gets the current set of border tiles.
     */
    public Set<Tile> getBorderTiles() {
        Set<Tile> borderTiles = new HashSet<>();
        for (HighlightedTile ht : new ArrayList<>(highlightedTiles)) {
            if (ht.getColor().equals(BORDER_TILE_COLOR) && ht.tile != null) {
                borderTiles.add(ht.tile);
            }
        }
        return borderTiles;
    }

    /**
     * Gets the current set of danger tiles.
     */
    public Set<Tile> getDangerTiles() {
        Set<Tile> dangerTiles = new HashSet<>();
        for (HighlightedTile ht : new ArrayList<>(highlightedTiles)) {
            if (ht.getColor().equals(DANGER_TILE_COLOR) && ht.tile != null) {
                dangerTiles.add(ht.tile);
            }
        }
        return dangerTiles;
    }

    public boolean isDangerTile(Tile tile) {
        return Client.getGraphicsObjects().stream()
                .filter(obj -> obj != null && obj.getID() == 2644)
                .map(obj -> obj.getTile())
                .anyMatch(dangerTile -> dangerTile.equals(tile));
    }

    // HighlightedTile class
    private static class HighlightedTile {
        private final Area area;
        private final Tile tile;
        private final Color color;
        private final String label;
        private final boolean isBorder;

        private HighlightedTile(Area area, Tile tile, Color color, String label, boolean isBorder) {
            this.area = area;
            this.tile = tile;
            this.color = color;
            this.label = label;
            this.isBorder = isBorder;
        }

        public String getLabel() {
            return label;
        }

        public Color getColor() {
            return color;
        }

        public void render(Graphics2D g, ScriptContext context) {
            if (tile != null) {
                renderTile(g, tile, color, label);
            } else if (area != null && !isBorder) {
                // Render the entire area (non-border areas)
                for (Tile areaTile : area.getTiles()) {
                    renderTile(g, areaTile, color, label);
                }
            }
        }

        private static void renderTile(Graphics2D g, Tile tileToRender, Color color, String label) {
            Polygon poly = tileToRender.getPolygon();
            if (poly == null) {
                return;
            }

            g.setColor(color);
            g.fillPolygon(poly);

            if (!color.equals(BACKGROUND_TILE_COLOR)) {
                g.setColor(Color.BLACK);
                g.drawPolygon(poly);
            }

            if (label != null) {
                Point center = new Point(
                        (poly.xpoints[0] + poly.xpoints[2]) / 2,
                        (poly.ypoints[0] + poly.ypoints[2]) / 2
                );
                g.setColor(TEXT_COLOR);
                g.drawString(label, center.x, center.y);
            }
        }

        public static Builder builder() {
            return new Builder();
        }

        static class Builder {
            private Area area;
            private Tile tile;
            private Color color;
            private String label;
            private boolean isBorder;

            public Builder area(Area area) {
                this.area = area;
                return this;
            }

            public Builder tile(Tile tile) {
                this.tile = tile;
                return this;
            }

            public Builder color(Color color) {
                this.color = color;
                return this;
            }

            public Builder label(String label) {
                this.label = label;
                return this;
            }

            public Builder isBorder(boolean isBorder) {
                this.isBorder = isBorder;
                return this;
            }

            public HighlightedTile build() {
                return new HighlightedTile(area, tile, color, label, isBorder);
            }
        }
    }
    public long getTimeToImpactForTile(Tile tile, long totalFlightTime) {
        // Check if this tile has a falling rock graphic
        return Client.getGraphicsObjects().stream()
                .filter(obj -> obj != null && obj.getID() == 2644 && obj.getTile().equals(tile))
                .findFirst()
                .map(obj -> {
                    int hash = obj.hashCode();
                    long elapsedTime = getGraphicElapsedTime(hash);
                    long timeLeft = totalFlightTime - elapsedTime;
                    return timeLeft < 0 ? 0 : timeLeft;
                }).orElse(Long.MAX_VALUE);
    }

    // HighlightedProjectile class
    private static class HighlightedProjectile {
        private final Projectile projectile;
        private final Tile startTile;
        private final Tile endTile;
        private final Color pathColor;
        private final Color endTileColor;

        private HighlightedProjectile(Projectile projectile, Tile startTile, Tile endTile, Color pathColor, Color endTileColor) {
            this.projectile = projectile;
            this.startTile = startTile;
            this.endTile = endTile;
            this.pathColor = pathColor;
            this.endTileColor = endTileColor;
        }

        public boolean isValid() {
            return projectile != null && projectile.exists();
        }

        public void render(Graphics2D g, ScriptContext context) {
            if (!isValid()) return;

            Polygon startPoly = startTile.getPolygon();
            Polygon endPoly = endTile.getPolygon();
            if (startPoly == null || endPoly == null) return;

            Point start = new Point(
                    (startPoly.xpoints[0] + startPoly.xpoints[2]) / 2,
                    (startPoly.ypoints[0] + startPoly.ypoints[2]) / 2
            );
            Point end = new Point(
                    (endPoly.xpoints[0] + endPoly.xpoints[2]) / 2,
                    (endPoly.ypoints[0] + endPoly.ypoints[2]) / 2
            );

            // Draw path line
            g.setColor(pathColor);
            g.drawLine(start.x, start.y, end.x, end.y);

            // Highlight the end tile
            g.setColor(endTileColor);
            g.fillPolygon(endPoly);
            g.setColor(Color.BLACK);
            g.drawPolygon(endPoly);

            // Optionally draw a timer
            int totalCycles = projectile.getEndCycle() - projectile.getStartCycle();
            int currentCycle = Client.getGameCycle() - projectile.getStartCycle();
            double progress = (double) currentCycle / totalCycles;
            double timeLeft = (1.0 - progress) * (totalCycles * 0.6 / 100.0);
            String timer = String.format("%.1fs", timeLeft);

            g.setColor(TEXT_COLOR);
            g.drawString(timer, end.x, end.y);
        }

        public static Builder builder() {
            return new Builder();
        }

        static class Builder {
            private Projectile projectile;
            private Tile startTile;
            private Tile endTile;
            private Color pathColor = new Color(255, 255, 0, 100);
            private Color endTileColor = new Color(255, 165, 0, 100);

            public Builder projectile(Projectile projectile) {
                this.projectile = projectile;
                return this;
            }

            public Builder startTile(Tile startTile) {
                this.startTile = startTile;
                return this;
            }

            public Builder endTile(Tile endTile) {
                this.endTile = endTile;
                return this;
            }

            public Builder pathColor(Color pathColor) {
                this.pathColor = pathColor;
                return this;
            }

            public Builder endTileColor(Color endTileColor) {
                this.endTileColor = endTileColor;
                return this;
            }

            public HighlightedProjectile build() {
                return new HighlightedProjectile(projectile, startTile, endTile, pathColor, endTileColor);
            }
        }
    }
}
