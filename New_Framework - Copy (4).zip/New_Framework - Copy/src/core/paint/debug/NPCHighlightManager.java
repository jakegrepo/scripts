package core.paint.debug;

import core.context.ContextProvider;
import core.context.ScriptContext;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.wrappers.interactive.NPC;

import java.awt.*;
import java.util.List;
import java.util.*;

public class NPCHighlightManager extends ContextProvider {
    private final Map<NPC, HighlightedNPC> highlightedNpcs = new HashMap<>();
    private final Set<String> npcNames = new HashSet<>();
    private final Set<Integer> npcIds = new HashSet<>();
    private final Map<String, Color> npcHighlights = Collections.synchronizedMap(new HashMap<>());

    // Default colors and styles
    private Color defaultHighlightColor = new Color(255, 0, 0, 100);
    private Color defaultFillColor = new Color(255, 0, 0, 50);
    private boolean drawNames = true;
    private boolean drawTiles = true;
    private boolean drawOutline = true;
    private float borderWidth = 2.0f;

    public NPCHighlightManager(ScriptContext context) {
        super(context);
    }

    public void addNpcToHighlight(String name) {
        npcNames.add(name);
        rebuildHighlights();
    }

    public void addNpcToHighlight(int id) {
        npcIds.add(id);
        rebuildHighlights();
    }

    public void removeNpcHighlight(String name) {
        npcNames.remove(name);
        rebuildHighlights();
    }

    public void removeNpcHighlight(int id) {
        npcIds.remove(id);
        rebuildHighlights();
    }

    public void rebuildHighlights() {
        highlightedNpcs.clear();

        log("Rebuilding highlights. Looking for NPCs with names: " + npcNames + " or IDs: " + npcIds);

        for (NPC npc : NPCs.all()) {
            if (shouldHighlight(npc)) {
                log("Found NPC to highlight: " + npc.getName() + " (ID: " + npc.getID() + ")");
                highlightedNpcs.put(npc, createHighlightedNPC(npc));
            }
        }

        log("Total NPCs highlighted: " + highlightedNpcs.size());
    }

    private boolean shouldHighlight(NPC npc) {
        if (npc == null || !npc.exists()) return false;

        String name = npc.getName();
        return (name != null && npcNames.contains(name)) || npcIds.contains(npc.getID());
    }

    private HighlightedNPC createHighlightedNPC(NPC npc) {
        Color highlightColor = npc.getName().equals("Scurrius") ? 
            new Color(255, 165, 0, 100) : defaultHighlightColor;
        Color fillColor = npc.getName().equals("Scurrius") ? 
            new Color(255, 165, 0, 50) : defaultFillColor;
        
        return HighlightedNPC.builder()
                .npc(npc)
                .highlightColor(highlightColor)
                .fillColor(fillColor)
                .drawName(drawNames)
                .drawTile(drawTiles)
                .drawOutline(drawOutline)
                .borderWidth(borderWidth)
                .build();
    }

    public void render(Graphics2D g) {
        synchronized(npcHighlights) {
            for (Map.Entry<String, Color> entry : npcHighlights.entrySet()) {
                String npcName = entry.getKey();
                Color color = entry.getValue();
                
                List<NPC> npcs = NPCs.all(npc -> npc != null && npc.getName() != null && npc.getName().equals(npcName));
                for (NPC npc : npcs) {
                    if (npc != null && npc.exists()) {
                        Polygon poly = npc.getTile().getPolygon();
                        if (poly != null) {
                            g.setColor(color);
                            g.draw(poly);
                            g.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 50));
                            g.fill(poly);
                        }
                    }
                }
            }
        }
    }

    public void clearHighlights() {
        synchronized(npcHighlights) {
            npcHighlights.clear();
        }
    }

    public void setHighlightColor(Color color) {
        this.defaultHighlightColor = color;
    }

    public void setEnabled(boolean enabled) {
        this.drawNames = enabled;
        this.drawTiles = enabled;
        this.drawOutline = enabled;
    }

    private static class HighlightedNPC {
        private final NPC npc;
        private final int npcSize;
        private final Color highlightColor;
        private final Color fillColor;
        private final boolean drawName;
        private final boolean drawTile;
        private final boolean drawOutline;
        private final float borderWidth;

        private HighlightedNPC(Builder builder) {
            this.npc = builder.npc;
            this.npcSize = npc.getSize(); // The expected tile footprint
            this.highlightColor = builder.highlightColor;
            this.fillColor = builder.fillColor;
            this.drawName = builder.drawName;
            this.drawTile = builder.drawTile;
            this.drawOutline = builder.drawOutline;
            this.borderWidth = builder.borderWidth;
        }

        public void render(Graphics2D g) {
            if (!npc.exists()) return;

            // Debug: print NPC size
            // Remove or comment out after verifying
            System.out.println("Rendering NPC: " + npc.getName() + ", size: " + npcSize);

            Stroke originalStroke = g.getStroke();

            if (drawTile && npc.getTile() != null) {
                Tile baseTile = npc.getTile();
                // Centering around NPC base tile
                // If npcSize is odd: half = npcSize/2, we go from -half to half.
                // If npcSize is even (rare), adjust accordingly.
                int half = npcSize / 2;

                for (int dx = -half; dx <= half; dx++) {
                    for (int dy = -half; dy <= half; dy++) {
                        Tile tile = baseTile.translate(dx, dy);
                        Polygon poly = tile != null ? tile.getPolygon() : null;
                        if (poly != null) {
                            g.setColor(fillColor);
                            g.fillPolygon(poly);

                            g.setColor(highlightColor);
                            g.setStroke(new BasicStroke(borderWidth));
                            g.drawPolygon(poly);
                        }
                    }
                }
            }

            if (drawOutline) {
                // Attempt to draw model outline if available
                if (npc.getArea() != null && npc.getArea().getPolygonArea() != null) {
                    Polygon modelOutline = npc.getArea().getPolygonArea();
                    if (modelOutline != null) {
                        g.setColor(highlightColor);
                        g.setStroke(new BasicStroke(borderWidth));
                        g.drawPolygon(modelOutline);
                    }
                }
            }

            if (drawName) {
                // Attempt to draw the name in the center of the NPC
                // Using the "true tile" and adjusting for size
                Tile centerTile = npc.getTrueTile();
                if (centerTile != null && centerTile.getPolygon() != null) {
                    Rectangle tileBounds = centerTile.getPolygon().getBounds();
                    String name = npc.getName();
                    if (name != null) {
                        g.setColor(Color.WHITE);
                        g.drawString(name, (int) tileBounds.getCenterX(), (int) tileBounds.getCenterY());
                    }
                }
            }

            g.setStroke(originalStroke);
        }

        public static Builder builder() {
            return new Builder();
        }

        static class Builder {
            private NPC npc;
            private Color highlightColor = Color.RED;
            private Color fillColor = new Color(255, 0, 0, 50);
            private boolean drawName = true;
            private boolean drawTile = true;
            private boolean drawOutline = true;
            private float borderWidth = 2.0f;

            public Builder npc(NPC npc) {
                this.npc = npc;
                return this;
            }

            public Builder highlightColor(Color color) {
                this.highlightColor = color;
                return this;
            }

            public Builder fillColor(Color color) {
                this.fillColor = color;
                return this;
            }

            public Builder drawName(boolean draw) {
                this.drawName = draw;
                return this;
            }

            public Builder drawTile(boolean draw) {
                this.drawTile = draw;
                return this;
            }

            public Builder drawOutline(boolean draw) {
                this.drawOutline = draw;
                return this;
            }

            public Builder borderWidth(float width) {
                this.borderWidth = width;
                return this;
            }

            public HighlightedNPC build() {
                return new HighlightedNPC(this);
            }
        }
    }
}
