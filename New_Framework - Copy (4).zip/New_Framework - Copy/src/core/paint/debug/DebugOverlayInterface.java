package core.paint.debug;

import java.awt.Graphics2D;

/**
 * Interface for debug overlays
 */
public interface DebugOverlayInterface {
    /**
     * Renders the overlay
     * @param g Graphics2D object
     */
    void render(Graphics2D g);
    
    /**
     * Gets the name of the overlay
     * @return Overlay name
     */
    String getName();
    
    /**
     * Checks if the overlay is enabled
     * @return True if enabled
     */
    boolean isEnabled();
    
    /**
     * Sets whether the overlay is enabled
     * @param enabled True to enable
     */
    void setEnabled(boolean enabled);
}
