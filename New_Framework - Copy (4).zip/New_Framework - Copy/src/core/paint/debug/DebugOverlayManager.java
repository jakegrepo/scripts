package core.paint.debug;

import core.context.ContextProvider;
import core.context.ScriptContext;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Manages debug overlays
 */
public class DebugOverlayManager extends ContextProvider {
    private final List<DebugOverlayInterface> overlays;
    private boolean enabled = true;
    
    public DebugOverlayManager(ScriptContext context) {
        super(context);
        this.overlays = new ArrayList<>();
    }
    
    /**
     * Registers a debug overlay
     * @param overlay The overlay to register
     */
    public void registerOverlay(DebugOverlayInterface overlay) {
        if (overlay != null && !overlays.contains(overlay)) {
            overlays.add(overlay);
            debug("Registered overlay: " + overlay.getName());
        }
    }
    
    /**
     * Unregisters a debug overlay
     * @param overlay The overlay to unregister
     */
    public void unregisterOverlay(DebugOverlayInterface overlay) {
        if (overlay != null && overlays.contains(overlay)) {
            overlays.remove(overlay);
            debug("Unregistered overlay: " + overlay.getName());
        }
    }
    
    /**
     * Renders all enabled overlays
     * @param g Graphics2D object
     */
    public void render(Graphics2D g) {
        if (!enabled) {
            return;
        }
        
        for (DebugOverlayInterface overlay : overlays) {
            if (overlay.isEnabled()) {
                overlay.render(g);
            }
        }
    }
    
    /**
     * Enables or disables all overlays
     * @param enabled True to enable
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    /**
     * Checks if overlays are enabled
     * @return True if enabled
     */
    public boolean isEnabled() {
        return enabled;
    }
    
    /**
     * Gets all registered overlays
     * @return List of overlays
     */
    public List<DebugOverlayInterface> getOverlays() {
        return new ArrayList<>(overlays);
    }
}
