package core.paint;

import core.context.ContextProvider;
import core.context.ScriptContext;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.SkillTracker;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Tracks XP gains and calculates XP/hour rates
 */
public class XPTracker extends ContextProvider {

    private final Map<Skill, Long> lastXpGainTimeMap = new EnumMap<>(Skill.class);
    private final Set<Skill> trackedSkills = EnumSet.noneOf(Skill.class);
    
    // Minimum XP gain to consider a skill active
    private static final long MIN_XP_GAIN = 100;
    private static final long XP_TIMEOUT = TimeUnit.MINUTES.toMillis(15); // 15 minutes timeout for XP gains
    
    private final long startTime;

    /**
     * Creates a new XP tracker
     * @param context The script context
     */
    public XPTracker(ScriptContext context) {
        super(context);
        this.startTime = System.currentTimeMillis();
        // Initialize the SkillTracker
        SkillTracker.start();
    }

    /**
     * Initializes tracking for all skills
     */
    public void initializeAllSkills() {
        for (Skill skill : Skill.values()) {
            initializeSkill(skill);
        }
    }

    /**
     * Initializes tracking for a specific skill
     * @param skill The skill to initialize
     */
    public void initializeSkill(Skill skill) {
        trackedSkills.add(skill);
        SkillTracker.start(skill);
        lastXpGainTimeMap.put(skill, System.currentTimeMillis());
    }

    /**
     * Updates XP tracking data
     */
    public void update() {
        for (Skill skill : trackedSkills) {
            long gained = getXpGained(skill);
            if (gained > MIN_XP_GAIN) {
                lastXpGainTimeMap.put(skill, System.currentTimeMillis());
            }
        }
    }

    /**
     * Gets the XP gained for a skill
     * @param skill The skill to check
     * @return The XP gained
     */
    public long getXpGained(Skill skill) {
        return SkillTracker.getGainedExperience(skill);
    }

    /**
     * Gets the total XP gained for multiple skills
     * @param skills The skills to check
     * @return The total XP gained
     */
    public long getTotalXpGained(Skill... skills) {
        long total = 0;
        for (Skill skill : skills) {
            total += getXpGained(skill);
        }
        return total;
    }

    /**
     * Gets the XP per hour for a skill
     * @param skill The skill to check
     * @return The XP per hour
     */
    public long getXpPerHour(Skill skill) {
        return SkillTracker.getGainedExperiencePerHour(skill);
    }

    /**
     * Gets the total XP per hour for multiple skills
     * @param skills The skills to check
     * @return The total XP per hour
     */
    public long getTotalXpPerHour(Skill... skills) {
        long total = 0;
        for (Skill skill : skills) {
            total += getXpPerHour(skill);
        }
        return total;
    }

    /**
     * Checks if a skill is actively being trained
     * @param skill The skill to check
     * @return True if the skill is active
     */
    public boolean isSkillActive(Skill skill) {
        if (!trackedSkills.contains(skill)) {
            return false;
        }
        
        long lastXpGainTime = lastXpGainTimeMap.getOrDefault(skill, 0L);
        long timeSinceLastXpGain = System.currentTimeMillis() - lastXpGainTime;
        
        return getXpGained(skill) > MIN_XP_GAIN && timeSinceLastXpGain < XP_TIMEOUT;
    }

    /**
     * Gets the time to next level for a skill at the current XP rate
     * @param skill The skill to check
     * @return The time to next level in milliseconds, or -1 if unknown
     */
    public long getTimeToNextLevel(Skill skill) {
        return SkillTracker.getTimeToLevel(skill);
    }

    /**
     * Gets a formatted string with the time to next level
     * @param skill The skill to check
     * @return A formatted string with the time to next level
     */
    public String getFormattedTimeToNextLevel(Skill skill) {
        long timeToLevel = getTimeToNextLevel(skill);
        if (timeToLevel <= 0) {
            return "Unknown";
        }
        
        long hours = TimeUnit.MILLISECONDS.toHours(timeToLevel);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(timeToLevel) % 60;
        
        if (hours > 0) {
            return hours + "h " + minutes + "m";
        } else {
            return minutes + "m";
        }
    }

    /**
     * Gets a formatted string with XP gained and XP/hr
     * @param skill The skill to check
     * @return A formatted string with XP information
     */
    public String getFormattedXpInfo(Skill skill) {
        long gained = getXpGained(skill);
        long perHour = getXpPerHour(skill);
        
        return formatNumber(gained) + " (" + formatNumber(perHour) + "/hr)";
    }
    
    /**
     * Gets a formatted string with total XP gained and XP/hr for multiple skills
     * @param skills The skills to check
     * @return A formatted string with combined XP information
     */
    public String getFormattedTotalXpInfo(Set<Skill> skills) {
        return getFormattedTotalXpInfo(skills.toArray(new Skill[0]));
    }

    /**
     * Gets a formatted string with total XP gained and XP/hr for multiple skills
     * @param skills The skills to check
     * @return A formatted string with combined XP information
     */
    public String getFormattedTotalXpInfo(Skill... skills) {
        long totalGained = getTotalXpGained(skills);
        long totalPerHour = getTotalXpPerHour(skills);
        
        return formatNumber(totalGained) + " (" + formatNumber(totalPerHour) + "/hr)";
    }
    
    /**
     * Gets all skills that are currently active
     * @return A set of active skills
     */
    public Set<Skill> getActiveSkills() {
        return Arrays.stream(Skill.values())
                .filter(this::isSkillActive)
                .collect(Collectors.toSet());
    }
    
    /**
     * Formats a number with k/m suffixes for readability
     * @param number The number to format
     * @return A formatted string
     */
    private String formatNumber(long number) {
        if (number < 1000) {
            return String.valueOf(number);
        } else if (number < 1000000) {
            return String.format("%.1fk", number / 1000.0);
        } else {
            return String.format("%.2fm", number / 1000000.0);
        }
    }
}