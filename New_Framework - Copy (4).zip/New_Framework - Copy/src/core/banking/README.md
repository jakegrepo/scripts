# Restock System Integration Guide

This guide explains how to integrate the framework's restock system into your script's banking nodes.

## Overview

The restock system allows scripts to automatically restock items when they fall below a certain threshold. The system uses the Grand Exchange to buy items when needed.

## Key Components

1. **RestockConfig**: Stores configuration for items to restock, thresholds, and quantities.
2. **RestockGrandExchangeManager**: Manages the Grand Exchange operations for restocking.
3. **RestockGrandExchangeNode**: Node that handles the restocking process.

## Integration Steps

### 1. Add the RestockGrandExchangeNode to your script

In your script's initialization method, add the RestockGrandExchangeNode:

```java
// Create RestockGrandExchangeManager and add RestockGrandExchangeNode
RestockGrandExchangeManager geManager = new RestockGrandExchangeManager(getContext(), config);
addNode(new RestockGrandExchangeNode("RestockGE", 10, config, geManager));
```

### 2. Integrate with your Banking Node

There are two ways to integrate with your banking node:

#### Option 1: Extend RestockBankingTemplate

The simplest approach is to extend the `RestockBankingTemplate` class:

```java
public class MyScriptBankingNode extends RestockBankingTemplate<MyScriptConfig> {
    
    public MyScriptBankingNode(MyScriptConfig config) {
        super("Banking", 3, config);
    }
    
    @Override
    public boolean validate() {
        // Your validation logic
        return needsBanking();
    }
    
    @Override
    protected int performBankingOperations() {
        // Your banking operations
        // Deposit items
        Bank.depositAllExcept(item -> isEssentialItem(item.getName()));
        Sleep.sleepUntil(() -> Inventory.onlyContains(item -> isEssentialItem(item.getName())), 3000);
        
        // Withdraw items
        if (shouldWithdrawItems()) {
            // Withdraw logic
        }
        
        return 0; // Success
    }
    
    // Your helper methods
}
```

#### Option 2: Manual Integration

If you can't extend the template, add the restock check to your existing banking node:

```java
// Inside your banking node's onExecute method
if (Bank.isOpen()) {
    // Your banking operations
    
    // Check if restock is needed
    if (config.getRestockConfig().isEnabled()) {
        // Get the RestockGrandExchangeNode from the script
        RestockGrandExchangeNode restockNode = getContext().tasks().getNodes().stream()
            .filter(node -> node instanceof RestockGrandExchangeNode)
            .map(node -> (RestockGrandExchangeNode) node)
            .findFirst().orElse(null);
        
        if (restockNode != null) {
            // Force a restock check
            restockNode.forceRestockCheck();
            Logger.info("Triggered restock check during banking");
            
            // If restock is needed, let the RestockGrandExchangeNode handle it
            if (!restockNode.isFinished()) {
                // Close the bank to let the restock node take over
                Bank.close();
                Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
                return 0;
            }
        }
    }
    
    // Continue with your banking operations
}
```

## Configuring Items to Restock

Items to restock are configured through the RestockConfig in the GUI. The user can add items, set thresholds, and specify quantities.

## Testing

To test the restock system:

1. Enable restock in the GUI
2. Add items to restock with appropriate thresholds
3. Reduce the quantity of those items below the threshold
4. Run your script and observe the banking node triggering the restock process

## Troubleshooting

- If restock is not triggering, check if the RestockConfig is enabled
- Verify that items are properly added to the restock list
- Check that thresholds are set appropriately
- Ensure the RestockGrandExchangeNode is added to your script with a high priority
