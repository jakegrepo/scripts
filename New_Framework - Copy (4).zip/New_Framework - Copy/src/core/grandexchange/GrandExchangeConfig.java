package core.grandexchange;

import java.util.List;
import java.util.Map;

public interface GrandExchangeConfig {
    boolean isUsingGrandExchange();
    void setUseGrandExchange(boolean useGrandExchange);
    
    List<String> getFoodNames();
    void setFoodNames(List<String> foodNames);
    
    int getTargetFoodCount();
    void setTargetFoodCount(int targetFoodCount);
    
    int getSuppliesMultiplier();
    void setSuppliesMultiplier(int suppliesMultiplier);
    
    Map<String, Integer> getSupplies();
    void setSupplies(Map<String, Integer> supplies);
    
    Map<String, String> getEquipment();
    void setEquipment(Map<String, String> equipment);
    
    String getTeleportMethod();
    void setTeleportMethod(String teleportMethod);
    
    boolean isAlchemyEnabled();
    void setAlchemyEnabled(boolean alchemyEnabled);
} 