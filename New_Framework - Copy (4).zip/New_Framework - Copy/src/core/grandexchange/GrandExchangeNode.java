package core.grandexchange;

import core.base.SimpleNode;
import core.config.ScriptConfig;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.bank.BankLocation;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.grandexchange.GrandExchangeItem;
import org.dreambot.api.methods.grandexchange.LivePrices;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.walking.web.node.impl.items.RequiredItem;
import org.dreambot.api.methods.walking.web.node.impl.teleports.TeleportWebNode;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GrandExchangeNode<T extends ScriptConfig & GrandExchangeConfig> extends SimpleNode<T> {
    public static final Area GRAND_EXCHANGE_AREA = new Area(3143, 3507, 3186, 3471);
    private static final Tile GE_CENTER = GRAND_EXCHANGE_AREA.getCenter();
    public boolean completed = false;
    public boolean forceExecute = false;
    public final List<ItemToBuy> itemsToBuy = new ArrayList<>();
    private final Map<String, Integer> customItems = new HashMap<>();
    private final Map<Integer, String> slotToItemMap = new HashMap<>(); // Track which item is in which GE slot

    public enum State {
        CHECK_TELEPORTS,
        WALK_TO_BANK,
        WITHDRAW_TELEPORT,
        WALK_TO_GE,
        OPEN_BANK_CHECK_COUNTS,
        PREPARE_PURCHASE_LIST,
        BUY_ITEMS,
        COLLECT_AND_CHECK,
        FINISH_TASK,
        PREPARING, 
        IDLE
    }

    public State currentState = State.IDLE;

    public GrandExchangeNode(String name, int priority, T config) {
        super(name, priority, config);
    }

    protected T getConfig() {
        return config;
    }

    // Easy-to-use methods for adding items
    public void addItem(String itemName, int quantity) {
        customItems.put(itemName, quantity);
    }

    public void addItems(Map<String, Integer> items) {
        customItems.putAll(items);
    }

    public void clearCustomItems() {
        customItems.clear();
    }

    public void setForceExecute(boolean force) {
        this.forceExecute = force;
    }

    @Override
    public boolean validate() {
        if (completed) {
            return false;  // Exit node when completed
        }
        
        if (forceExecute) {
            return true;
        }
        
        return config.isUsingGrandExchange();
    }

    public void reset() {
        completed = false;
        itemsToBuy.clear();
        slotToItemMap.clear();
        currentState = State.IDLE;
        forceExecute = false;
        Logger.log("GE Node reset - Ready for next run");
    }

    private boolean hasRequiredItems(List<RequiredItem> items) {
        for (RequiredItem item : items) {
            if (Bank.count(item.getName()) < item.getCount()) {
                return false;
            }
        }
        return true;
    }

    private boolean isTabTeleport(List<RequiredItem> items) {
        return items.size() == 1 && items.get(0).getName().toLowerCase().contains("teleport");
    }

    @Override
    protected int onExecute() {
        try {
            if (completed) {
                return 0;
            }

            if (currentState == State.IDLE) {
                if (!GRAND_EXCHANGE_AREA.contains(getLocalPlayer())) {
                    Logger.log("[GE Node] Not at GE, checking for teleports...");
                    currentState = State.CHECK_TELEPORTS;
                } else {
                    currentState = State.OPEN_BANK_CHECK_COUNTS;
                }
            }

            switch (currentState) {
                case CHECK_TELEPORTS:
                    if (!Bank.isOpen()) {
                        BankLocation nearestBank = Bank.getClosestBankLocation();
                        if (nearestBank != null && !nearestBank.getArea(8).contains(getLocalPlayer())) {
                            Logger.log("[GE Node] Walking to nearest bank: " + Bank.getClosestBankLocation());
                            Walking.walk(nearestBank.getArea(0).getTile());
                            Sleep.sleepUntil(() -> nearestBank.getArea(8).contains(getLocalPlayer()), 5000);
                            return 600;
                        }
                        Logger.log("[GE Node] Opening bank...");
                        Bank.open();
                        Sleep.sleepUntil(Bank::isOpen, 5000);
                        return 600;
                    }

                    // Find the best teleport option
                    List<TeleportWebNode> teleportNodes = TeleportWebNode.getTeleportNodes();
                    TeleportWebNode bestTeleport = null;
                    double bestDistance = Double.MAX_VALUE;
                    List<RequiredItem> bestRequiredItems = null;
                    boolean foundTab = false;

                    for (TeleportWebNode teleportNode : teleportNodes) {
                        double distanceToGE = teleportNode.getTile().distance(GE_CENTER);
                        List<RequiredItem> requiredItems = teleportNode.getRequiredItems();
                        
                        if (!requiredItems.isEmpty() && hasRequiredItems(requiredItems)) {
                            boolean isTab = isTabTeleport(requiredItems);
                            
                            // If we haven't found a tab yet, or this is a tab and closer, or we have no teleport yet
                            if ((!foundTab && isTab) || 
                                (isTab && foundTab && distanceToGE < bestDistance) ||
                                (bestTeleport == null) ||
                                (!foundTab && !isTab && distanceToGE < bestDistance)) {
                                
                                bestDistance = distanceToGE;
                                bestTeleport = teleportNode;
                                bestRequiredItems = requiredItems;
                                foundTab = isTab;
                            }
                        }
                    }

                    // If we found a good teleport option, withdraw the items
                    if (bestTeleport != null && bestRequiredItems != null) {
                        Logger.log("[GE Node] Selected best teleport with distance " + bestDistance + " tiles to GE");
                        Logger.log("[GE Node] Withdrawing required items: " + bestRequiredItems.stream()
                                .map(item -> item.getName() + " (x" + item.getCount() + ")")
                                .collect(Collectors.joining(", ")));
                        
                        for (RequiredItem item : bestRequiredItems) {
                            Logger.log("[GE Node] Withdrawing: " + item.getName() + " x" + item.getCount());
                            Bank.withdraw(item.getName(), item.getCount());
                            Sleep.sleepUntil(() -> Inventory.count(item.getName()) >= item.getCount(), 3000);
                        }
                        
                        Bank.close();
                        Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
                        currentState = State.WALK_TO_GE;
                        return 600;
                    } else {
                        Logger.log("[GE Node] No suitable teleports found, proceeding with normal walking");
                        Bank.close();
                        currentState = State.WALK_TO_GE;
                    }
                    break;

                case WALK_TO_GE:
                    if (!GRAND_EXCHANGE_AREA.contains(getLocalPlayer())) {
                        Logger.log("[GE Node] Walking to GE...");
                        Walking.walk(BankLocation.GRAND_EXCHANGE);
                        Sleep.sleepUntil(() -> GRAND_EXCHANGE_AREA.contains(getLocalPlayer()), 5000);
                        return 600;
                    } else {
                        Logger.log("[GE Node] Arrived at GE");
                        currentState = State.OPEN_BANK_CHECK_COUNTS;
                    }
                    break;

                case OPEN_BANK_CHECK_COUNTS:
                    if (!Bank.isOpen()) {
                        Bank.open();
                        Sleep.sleepUntil(Bank::isOpen, 3000);
                        return 600;
                    }
                    checkAndPreparePurchaseList();
                    currentState = State.PREPARE_PURCHASE_LIST;
                    return 600;

                case PREPARE_PURCHASE_LIST:
                    if (itemsToBuy.isEmpty()) {
                        currentState = State.FINISH_TASK;
                    } else {
                        currentState = State.BUY_ITEMS;
                    }
                    return 600;

                case BUY_ITEMS:
                    if (buyItems()) {
                        currentState = State.COLLECT_AND_CHECK;
                    }
                    return 600;

                case COLLECT_AND_CHECK:
                    if (collectAndVerifyItems()) {
                        currentState = State.FINISH_TASK;
                    }
                    return 600;

                case FINISH_TASK:
                    if (GrandExchange.isOpen()) {
                        GrandExchange.close();
                        Sleep.sleepUntil(() -> !GrandExchange.isOpen(), 3000);
                        return 600;
                    }
                    completed = true;
                    forceExecute = false;
                    return 0;

                default:
                    currentState = State.IDLE;
                    return 600;
            }

            return 600;
        } catch (Exception e) {
            Logger.log("[GE Node] Error during execution: " + e.getMessage());
            reset();  // Reset state on error
            throw e;  // Rethrow to let SimpleNode handle it
        }
    }

    protected void checkAndPreparePurchaseList() {
        itemsToBuy.clear();
        T config = getConfig();
        
        // Check equipment from config
        Map<String, String> equipment = config.getEquipment();
        if (equipment != null) {
            for (Map.Entry<?, ?> entry : equipment.entrySet()) {
                String itemName = String.valueOf(entry.getValue());
                if (itemName != null && !itemName.isEmpty() && !itemName.equals("None") && !hasItem(itemName)) {
                    addItemToBuy(itemName, 1);
                }
            }
        }

        // Check supplies from config
        Map<String, Integer> supplies = config.getSupplies();
        if (supplies != null) {
            int multiplier = config.getSuppliesMultiplier();
            for (Map.Entry<?, ?> entry : supplies.entrySet()) {
                String itemName = String.valueOf(entry.getKey());
                int requiredForOneTrip = ((Number) entry.getValue()).intValue();
                int totalCount = Bank.count(itemName) + Inventory.count(itemName);
                
                if (totalCount < requiredForOneTrip) {
                    int amountToBuy = (requiredForOneTrip * multiplier) - totalCount;
                    if (amountToBuy > 0) {
                        addItemToBuy(itemName, amountToBuy);
                    }
                }
            }
        }

        // Check food
        if (!config.getFoodNames().isEmpty()) {
            String foodName = (String) config.getFoodNames().get(0);
            int requiredForOneTrip = config.getTargetFoodCount();
            int totalFood = Bank.count(foodName) + Inventory.count(foodName);
            
            if (totalFood < requiredForOneTrip) {
                int amountToBuy = (requiredForOneTrip * config.getSuppliesMultiplier()) - totalFood;
                if (amountToBuy > 0) {
                    addItemToBuy(foodName, amountToBuy);
                }
            }
        }

        // Check custom items
        for (Map.Entry<?, ?> entry : customItems.entrySet()) {
            String itemName = String.valueOf(entry.getKey());
            int quantity = ((Number) entry.getValue()).intValue();
            checkAndAddItem(itemName, quantity);
        }

        // If nothing to buy, complete immediately
        if (itemsToBuy.isEmpty()) {
            Logger.log("No items need to be purchased");
            completed = true;
        } else {
            Logger.log("Items to buy: " + itemsToBuy.size());
        }

        if (Bank.isOpen()) {
            Bank.close();
            Sleep.sleep(600);
        }
    }

    private void checkAndAddItem(String itemName, int requiredAmount) {
        int currentAmount = Bank.count(itemName) + Inventory.count(itemName);
        if (currentAmount < requiredAmount) {
            addItemToBuy(itemName, requiredAmount - currentAmount);
        }
    }

    public void addItemToBuy(String itemName, int quantity) {
        Logger.log("Adding to buy list: " + itemName + " x" + quantity);
        itemsToBuy.add(new ItemToBuy(itemName, quantity));
    }

    protected boolean buyItems() {
        if (!GrandExchange.isOpen()) {
            if (Bank.isOpen()) {
                Bank.close();
                Sleep.sleep(600);
                return false;
            }
            GrandExchange.open();
            Sleep.sleepUntil(GrandExchange::isOpen, 5000, 600);
            return false;
        }

        // First, update our tracking of existing offers
        updateOfferTracking();

        // Check if there are any active offers that need to be collected first
        if (GrandExchange.isReadyToCollect()) {
            Logger.log("Items ready to collect, moving to collection phase...");
            currentState = State.COLLECT_AND_CHECK;
            return false;
        }

        // Check if we have any items left to buy
        boolean allItemsPurchased = true;
        boolean allOrdersPlaced = true;
        
        for (ItemToBuy item : itemsToBuy) {
            if (!item.isPurchased()) {
                allItemsPurchased = false;
                
                if (!item.isOrderPlaced()) {
                    allOrdersPlaced = false;
                    break;
                }
            }
        }
        
        // If all items are already purchased, return true
        if (allItemsPurchased) {
            return true;
        }
        
        // If all orders are placed but not yet purchased, wait for them to complete
        if (allOrdersPlaced) {
            Logger.log("All buy orders have been placed, waiting for completion...");
            if (GrandExchange.getUsedSlots() > 0) {
                Sleep.sleepUntil(GrandExchange::isReadyToCollect, 3000);
                if (GrandExchange.isReadyToCollect()) {
                    currentState = State.COLLECT_AND_CHECK;
                }
            } else {
                // If no slots are used but orders were placed, move to collection phase
                currentState = State.COLLECT_AND_CHECK;
            }
            return false;
        }
        
        // Count available GE slots
        int availableSlots = 8 - GrandExchange.getUsedSlots();
        int itemsPlaced = 0;
        
        // Place buy orders for items that don't have orders yet
        for (ItemToBuy item : itemsToBuy) {
            if (!item.isPurchased() && !item.isOrderPlaced() && itemsPlaced < availableSlots) {
                int price = LivePrices.get(item.getName());
                if (price > 0) {
                    Logger.log("Buying " + item.getQuantity() + "x " + item.getName() + " at " + (price * 1.6) + " each");
                    int slot = GrandExchange.getFirstOpenSlot();
                    if (slot != -1 && GrandExchange.buyItem(item.getName(), item.getQuantity(), (int) (price * 1.6))) {
                        item.setOrderPlaced(true);
                        item.setSlot(slot);
                        slotToItemMap.put(slot, item.getName());
                        itemsPlaced++;
                        Sleep.sleep(600); // Small delay between placing orders
                    }
                }
            }
        }
        
        // If we placed any orders, wait a moment for them to process
        if (itemsPlaced > 0) {
            Logger.log("Placed " + itemsPlaced + " buy orders, waiting for processing...");
            Sleep.sleep(1000);
            return false;
        }

        return false; // Continue processing until all items are purchased
    }

    /**
     * Updates our tracking of GE offers by checking the GrandExchangeItems
     */
    private void updateOfferTracking() {
        GrandExchangeItem[] geItems = GrandExchange.getItems();
        
        if (geItems != null) {
            // First, check if any of our tracked items are complete
            for (ItemToBuy item : itemsToBuy) {
                if (item.isOrderPlaced() && !item.isPurchased() && item.getSlot() >= 0 && item.getSlot() < geItems.length) {
                    GrandExchangeItem geItem = geItems[item.getSlot()];
                    
                    // If the slot is empty or has a different item, our tracking might be off
                    if (geItem == null || !geItem.getName().equalsIgnoreCase(item.getName())) {
                        // Check if the item is in our inventory or bank now
                        if (hasItem(item.getName())) {
                            Logger.log("Item " + item.getName() + " was purchased and is now in our possession");
                            item.setPurchased(true);
                        } else {
                            // Reset the order status if the slot is empty but we don't have the item
                            Logger.log("Slot " + item.getSlot() + " is empty but we don't have " + item.getName() + ", resetting order status");
                            item.setOrderPlaced(false);
                            item.setSlot(-1);
                            slotToItemMap.remove(item.getSlot());
                        }
                    } 
                    // If the item is in the slot and is ready to collect
                    else if (geItem.isReadyToCollect()) {
                        Logger.log("Item " + item.getName() + " in slot " + item.getSlot() + " is ready to collect");
                    }
                }
            }
            
            // Now check all GE slots to make sure our tracking is accurate
            for (int i = 0; i < geItems.length; i++) {
                GrandExchangeItem geItem = geItems[i];
                if (geItem != null && geItem.getName() != null && !geItem.getName().isEmpty()) {
                    String itemName = geItem.getName();
                    
                    // Update our slot tracking
                    slotToItemMap.put(i, itemName);
                    
                    // Find the corresponding ItemToBuy
                    for (ItemToBuy item : itemsToBuy) {
                        if (item.getName().equalsIgnoreCase(itemName) && !item.isPurchased()) {
                            // Update the slot if it's not already set
                            if (item.getSlot() == -1) {
                                item.setSlot(i);
                                item.setOrderPlaced(true);
                                Logger.log("Updated tracking: " + itemName + " is in slot " + i);
                            }
                        }
                    }
                } else {
                    // Slot is empty, remove from our tracking
                    slotToItemMap.remove(i);
                }
            }
        }
    }

    protected boolean collectAndVerifyItems() {
        try {
            if (!GrandExchange.isOpen()) {
                GrandExchange.open();
                Sleep.sleepUntil(GrandExchange::isOpen, 3000);
                return false;
            }

            // Update our tracking of existing offers
            updateOfferTracking();

            // Check if there are any active offers that aren't ready to collect
            boolean anyOffersActive = false;
            GrandExchangeItem[] geItems = GrandExchange.getItems();
            
            if (geItems != null) {
                for (GrandExchangeItem geItem : geItems) {
                    if (geItem != null && geItem.getName() != null && !geItem.getName().isEmpty() && !geItem.isReadyToCollect()) {
                        anyOffersActive = true;
                        Logger.log("Offer for " + geItem.getName() + " is still active, waiting...");
                        break;
                    }
                }
            }

            // Collect items if ready
            if (GrandExchange.isReadyToCollect()) {
                Logger.log("Collecting completed offers...");
                GrandExchange.collect();
                Sleep.sleep(1000);
                
                // After collecting, update our item status
                for (ItemToBuy item : itemsToBuy) {
                    if (!item.isPurchased() && item.isOrderPlaced()) {
                        if (hasItem(item.getName())) {
                            Logger.log("Successfully purchased: " + item.getName());
                            item.setPurchased(true);
                        }
                    }
                }
            }

            // Check if we still have items to collect
            if (GrandExchange.isReadyToCollect()) {
                Logger.log("Items still ready to collect, waiting...");
                return false;
            }

            // If we have active offers, wait for them to complete
            if (anyOffersActive) {
                Logger.log("Waiting for active offers to complete...");
                return false;
            }

            // Check if we have any unpurchased items with no active offers
            boolean needToPlaceMoreOrders = false;
            for (ItemToBuy item : itemsToBuy) {
                if (!item.isPurchased()) {
                    if (!item.isOrderPlaced()) {
                        needToPlaceMoreOrders = true;
                        Logger.log("Item " + item.getName() + " still needs to be purchased");
                    } else {
                        // Check if the order is still in the GE
                        boolean foundInGE = false;
                        if (geItems != null) {
                            for (GrandExchangeItem geItem : geItems) {
                                if (geItem != null && geItem.getName() != null &&
                                    geItem.getName().equalsIgnoreCase(item.getName())) {
                                    foundInGE = true;
                                    break;
                                }
                            }
                        }
                        
                        if (!foundInGE) {
                            // Order is not in GE anymore, but we don't have the item
                            if (!hasItem(item.getName())) {
                                item.setOrderPlaced(false);
                                item.setSlot(-1);
                                needToPlaceMoreOrders = true;
                                Logger.log("Order for " + item.getName() + " is no longer in GE but item not found, will try again");
                            } else {
                                // We have the item but didn't mark it as purchased
                                item.setPurchased(true);
                                Logger.log("Item " + item.getName() + " was found in inventory/bank/equipment");
                            }
                        }
                    }
                }
            }

            // If we need to place more orders, go back to buying
            if (needToPlaceMoreOrders) {
                Logger.log("Need to place more buy orders, returning to BUY_ITEMS state");
                currentState = State.BUY_ITEMS;
                return false;
            }

            // Check if all items are purchased
            boolean allItemsPurchased = itemsToBuy.stream().allMatch(ItemToBuy::isPurchased);
            
            if (allItemsPurchased) {
                Logger.log("All items have been successfully purchased and collected");
                completed = true;
                currentState = State.FINISH_TASK;
                forceExecute = false;
                notifyComplete();
                return true;
            } else {
                // If we still have items to buy but no active offers, go back to buying
                currentState = State.BUY_ITEMS;
                return false;
            }

        } catch (Exception e) {
            Logger.log("[GE Node] Error during collection: " + e.getMessage());
            return false;
        }
    }

    protected boolean hasItem(String itemName) {
        return itemName != null && !itemName.isEmpty() && (
               Bank.contains(itemName) || 
               Inventory.contains(itemName) || 
               Equipment.contains(itemName));
    }

    // Method to notify completion - can be overridden by specific implementations
    protected void notifyComplete() {
        try {
            if (!completed) {
                Logger.log("GE operations completed");
                completed = true;
                forceExecute = false;
                currentState = State.FINISH_TASK;
            }
        } catch (Exception e) {
            Logger.log("[GE Node] Error in notifyComplete: " + e.getMessage());
        }
    }

    protected static class ItemToBuy {
        private final String name;
        private final int quantity;
        private boolean purchased;
        private boolean orderPlaced;
        private int slot = -1; // Track which GE slot this item is in

        public ItemToBuy(String name, int quantity) {
            this.name = name;
            this.quantity = quantity;
            this.purchased = false;
            this.orderPlaced = false;
        }

        public String getName() {
            return name;
        }

        public int getQuantity() {
            return quantity;
        }

        public boolean isPurchased() {
            return purchased;
        }

        public void setPurchased(boolean purchased) {
            this.purchased = purchased;
        }
        
        public boolean isOrderPlaced() {
            return orderPlaced;
        }
        
        public void setOrderPlaced(boolean orderPlaced) {
            this.orderPlaced = orderPlaced;
        }
        
        public int getSlot() {
            return slot;
        }
        
        public void setSlot(int slot) {
            this.slot = slot;
        }
    }
}