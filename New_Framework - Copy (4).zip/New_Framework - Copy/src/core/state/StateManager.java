package core.state;

import core.context.ContextProvider;
import core.context.ScriptContext;

/**
 * Manages script state transitions and provides state-related utilities.
 */
public class StateManager extends ContextProvider {
    private ScriptState currentState;

    public StateManager(ScriptContext context) {
        super(context);
        this.currentState = ScriptState.STOPPED;
    }

    /**
     * Initializes the state manager.
     */
    public void initialize() {
        setState(ScriptState.INITIALIZING);
        log("StateManager initialized");
    }

    /**
     * Handles state transitions.
     */
    public void onStateChange(ScriptState newState) {
        if (newState != currentState) {
            log("State changing from " + currentState + " to " + newState);
            currentState = newState;
            handleStateSpecificLogic(newState);
        }
    }

    /**
     * Handles logic specific to certain states.
     */
    private void handleStateSpecificLogic(ScriptState state) {
        switch (state) {
            case RUNNING:
                log("Script is now running");
                break;
            case STOPPING:
                log("Script is stopping");
                break;
            case STOPPED:
                log("Script has stopped");
                break;
            case ERROR:
                log("Script encountered an error");
                break;
            default:
                break;
        }
    }

    /**
     * Gets the current script state.
     */
    public ScriptState getCurrentState() {
        return currentState;
    }

    /**
     * Sets the current script state.
     */
    public void setState(ScriptState state) {
        onStateChange(state);
    }

    /**
     * Checks if the script is currently runnable.
     */
    public boolean isRunnable() {
        return currentState.isRunnable();
    }

    /**
     * Checks if the script is currently non-runnable.
     */
    public boolean isNonRunnable() {
        return currentState.isNonRunnable();
    }
} 