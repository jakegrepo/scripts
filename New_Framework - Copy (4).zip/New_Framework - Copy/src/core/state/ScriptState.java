package core.state;

/**
 * Enum representing the various states a script can be in.
 */
public enum ScriptState {
    STARTING,
    INITIALIZING,
    RUNNING,
    STOPPING,
    STOPPED,
    ERROR, MULING;

    /**
     * Checks if the script is in a state where it can execute nodes.
     */
    public boolean isRunnable() {
        return this == RUNNING || this == STARTING;
    }

    /**
     * Checks if the script is in a state where it should not execute nodes.
     */
    public boolean isNonRunnable() {
        return this == STOPPING || this == STOPPED || this == ERROR;
    }
} 