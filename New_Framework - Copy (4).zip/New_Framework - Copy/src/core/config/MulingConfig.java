package core.config;

import com.google.gson.annotations.Expose;
import core.context.ScriptContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * Framework-level muling configuration
 * Used by all scripts that need muling functionality
 */
public class MulingConfig {
    // Muling Configuration
    @Expose private boolean enabled = false;
    @Expose private String muleUsername = "";
    @Expose private int muleWorld = 301; // Default world
    @Expose private String meetingSpot = "Grand Exchange"; // Default spot
    @Expose private int port = 61616; // Default port
    @Expose private List<String> itemsToMule = new ArrayList<>(); // Items to mule
    @Expose private int triggerValue = 150; // Trigger muling when inventory value exceeds 1M GP
    @Expose private int coinsToKeep = 1000000; // Default 1M coins to keep
    @Expose private Map<String, Integer> itemThresholds = new HashMap<>();

    /**
     * Default constructor
     */
    public MulingConfig() {
        // Initialize with default items
        itemsToMule.add("Aldarium");
        itemsToMule.add("Chugging barrel (dismantled)");
        itemThresholds.put("Aldarium", 150);
        itemThresholds.put("Chugging barrel (dismantled)", 1);
    }

    /**
     * Copy constructor
     */
    public MulingConfig(MulingConfig other) {
        if (other != null) {
            this.enabled = other.enabled;
            this.muleUsername = other.muleUsername;
            this.muleWorld = other.muleWorld;
            this.meetingSpot = other.meetingSpot;
            this.port = other.port;
            this.itemsToMule = new ArrayList<>(other.itemsToMule);
            this.triggerValue = other.triggerValue;
            this.coinsToKeep = other.coinsToKeep;
            this.itemThresholds = new HashMap<>(other.itemThresholds);
        }
    }

    // Getters and setters

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getMuleUsername() {
        return muleUsername;
    }

    public void setMuleUsername(String muleUsername) {
        this.muleUsername = muleUsername;
    }

    public int getMuleWorld() {
        return muleWorld;
    }

    public void setMuleWorld(int muleWorld) {
        this.muleWorld = muleWorld;
    }

    public String getMeetingSpot() {
        return meetingSpot;
    }

    public void setMeetingSpot(String meetingSpot) {
        this.meetingSpot = meetingSpot;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public List<String> getItemsToMule() {
        return itemsToMule;
    }

    public void setItemsToMule(List<String> itemsToMule) {
        this.itemsToMule = itemsToMule;
    }

    public int getTriggerValue() {
        return triggerValue;
    }

    public void setTriggerValue(int triggerValue) {
        this.triggerValue = triggerValue;
    }

    public int getCoinsToKeep() {
        return coinsToKeep;
    }

    public void setCoinsToKeep(int coinsToKeep) {
        this.coinsToKeep = coinsToKeep;
    }

    public Map<String, Integer> getItemThresholds() {
        return itemThresholds;
    }

    public void setItemThresholds(Map<String, Integer> thresholds) {
        this.itemThresholds = thresholds;
    }

}
