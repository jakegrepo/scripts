package core.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import core.context.ContextProvider;
import core.context.ScriptContext;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.JsonElement;
import com.google.gson.annotations.Expose;
import com.google.gson.reflect.TypeToken;

/**
 * Base configuration class that handles saving/loading of script settings
 */
public abstract class ScriptConfig extends ContextProvider {
    private static final String CONFIG_DIR = "ScarFramework/configs/";
    private static final String PROFILES_DIR = "ScarFramework/profiles/";
    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .excludeFieldsWithoutExposeAnnotation()
            .serializeNulls()
            .disableJdkUnsafe() // Prevent access to inaccessible fields
            .addSerializationExclusionStrategy(new ExclusionStrategy() {
                @Override
                public boolean shouldSkipField(FieldAttributes f) {
                    // Skip Thread fields and other problematic types
                    return f.getDeclaringClass() == Thread.class ||
                           f.getDeclaringClass().getName().startsWith("java.lang.Thread") ||
                           f.getDeclaringClass().getName().startsWith("java.util.concurrent");
                }

                @Override
                public boolean shouldSkipClass(Class<?> clazz) {
                    // Skip Thread class and other problematic types
                    return clazz == Thread.class ||
                           clazz.getName().startsWith("java.lang.Thread") ||
                           clazz.getName().startsWith("java.util.concurrent");
                }
            })
            .create();

    private final String scriptName;
    private final Map<String, Object> customData;
    private boolean initialized;
    private String currentProfile = "Default";
    private boolean dirty = false;

    // Framework-level configurations
    @Expose private MulingConfig mulingConfig = new MulingConfig();
    @Expose private BreakConfig breakConfig = new BreakConfig();
    @Expose private AntiBanConfig antiBanConfig = new AntiBanConfig();
    @Expose private RestockConfig restockConfig = new RestockConfig();

    /**
     * Constructor for deserialization
     * This constructor is specifically for use by Gson deserialization.
     */
    protected ScriptConfig(boolean forDeserialization) {
        // Skip the context check in ContextProvider
        // Initialize with default values
        this.scriptName = "unknown";
        this.customData = new HashMap<>();
        this.initialized = false;
    }

    /**
     * No-args constructor for Gson deserialization
     */
    protected ScriptConfig() {
        // Use the deserialization constructor
        this(true);
    }

    protected ScriptConfig(ScriptContext context, String scriptName) {
        super(context);
        this.scriptName = scriptName;
        this.customData = new HashMap<>();
        this.initialized = false;

        // Ensure config directory exists
        createConfigDirectory();
    }

    /**
     * Initialize configuration with default values
     */
    public void initialize() {
        if (initialized) {
            debug("Config already initialized");
            return;
        }

        try {
            log("Initializing config for " + scriptName);
            setDefaults();
            loadConfig();
            initialized = true;

        } catch (Exception e) {
            error("Error initializing config", e);
            initialized = false;
        }
    }

    /**
     * Set default configuration values
     * Override in concrete config classes
     */
    protected abstract void setDefaults();

    /**
     * Save configuration to file
     */
    public void saveConfig() {
        try {
            // Create a structured data object for serialization
            Map<String, Object> configData = new HashMap<>();

            // Add framework configs
            configData.put("mulingConfig", mulingConfig);
            configData.put("breakConfig", breakConfig);
            configData.put("antiBanConfig", antiBanConfig);

            // Add custom data (filtered to remove problematic objects)
            Map<String, Object> filteredData = new HashMap<>();
            for (Map.Entry<String, Object> entry : customData.entrySet()) {
                Object value = entry.getValue();
                // Skip Thread objects and other problematic types
                if (value != null && !(value instanceof Thread) &&
                    !value.getClass().getName().startsWith("java.lang.Thread") &&
                    !value.getClass().getName().startsWith("java.util.concurrent")) {
                    filteredData.put(entry.getKey(), value);
                }
            }
            configData.put("customData", filteredData);

            // Add metadata
            configData.put("scriptName", scriptName);
            configData.put("currentProfile", currentProfile);

            // Save to config file
            String json = GSON.toJson(configData);
            Path configPath = getConfigPath();

            Files.write(configPath, json.getBytes(StandardCharsets.UTF_8));
            debug("Config saved to: " + configPath);

            // Mark config as clean
            markClean();

        } catch (Exception e) {
            error("Error saving config", e);
            throw new RuntimeException("Failed to save config: " + e.getMessage(), e);
        }
    }

    /**
     * Load configuration from file
     */
    @SuppressWarnings("unchecked")
    public void loadConfig() {
        try {
            Path configPath = getConfigPath();

            if (Files.exists(configPath)) {
                String json = new String(Files.readAllBytes(configPath), StandardCharsets.UTF_8);

                try {
                    // Load as a structured data object
                    Map<String, Object> configData = GSON.fromJson(json, new TypeToken<Map<String, Object>>(){}.getType());

                    // Load framework configs if available
                    if (configData.containsKey("mulingConfig")) {
                        JsonElement mulingElement = ((JsonElement)configData.get("mulingConfig"));
                        MulingConfig loadedMulingConfig = GSON.fromJson(mulingElement, MulingConfig.class);
                        this.mulingConfig = loadedMulingConfig;
                    }

                    if (configData.containsKey("breakConfig")) {
                        JsonElement breakElement = ((JsonElement)configData.get("breakConfig"));
                        BreakConfig loadedBreakConfig = GSON.fromJson(breakElement, BreakConfig.class);
                        this.breakConfig = loadedBreakConfig;
                    }

                    if (configData.containsKey("antiBanConfig")) {
                        JsonElement antiBanElement = ((JsonElement)configData.get("antiBanConfig"));
                        AntiBanConfig loadedAntiBanConfig = GSON.fromJson(antiBanElement, AntiBanConfig.class);
                        this.antiBanConfig = loadedAntiBanConfig;
                    }

                    // Load custom data if available
                    if (configData.containsKey("customData")) {
                        JsonElement customDataElement = ((JsonElement)configData.get("customData"));
                        Map<String, Object> loadedCustomData = GSON.fromJson(customDataElement, new TypeToken<Map<String, Object>>(){}.getType());
                        this.customData.clear();
                        this.customData.putAll(loadedCustomData);
                    }

                    // Load metadata if available
                    if (configData.containsKey("currentProfile")) {
                        this.currentProfile = ((JsonElement)configData.get("currentProfile")).getAsString();
                    }

                    debug("Config loaded from: " + configPath);
                } catch (Exception e) {
                    error("Error loading config", e);
                    throw new RuntimeException("Failed to load config: " + e.getMessage(), e);
                }
            } else {
                debug("Config file not found: " + configPath);
            }
        } catch (Exception e) {
            error("Error loading config", e);
            throw new RuntimeException("Failed to load config: " + e.getMessage(), e);
        }
    }

    /**
     * Store custom data in config
     */
    public void setCustomData(String key, Object value) {
        customData.put(key, value);
    }

    /**
     * Retrieve custom data from config
     */
    @SuppressWarnings("unchecked")
    public <T> T getCustomData(String key, T defaultValue) {
        return (T) customData.getOrDefault(key, defaultValue);
    }

    /**
     * Get config file path
     */
    private Path getConfigPath() {
        return Paths.get(CONFIG_DIR, scriptName + ".json");
    }

    /**
     * Ensure config directory exists
     */
    private void createConfigDirectory() {
        try {
            Files.createDirectories(Paths.get(CONFIG_DIR));
        } catch (IOException e) {
            error("Error creating config directory", e);
        }
    }

    /**
     * Copy values from loaded config
     */
    private void copyValues(ScriptConfig loaded) {
        if (loaded != null) {
            // Clear and copy only if loaded.customData is not null
            if (loaded.customData != null) {
                this.customData.clear();
                this.customData.putAll(loaded.customData);
            }

            // Copy specific config values
            copyConfigValues(loaded);
        }
    }

    /**
     * Copy specific configuration values
     * Override in concrete config classes
     */
    protected void copyConfigValues(ScriptConfig loaded) {
        // Copy framework-level configurations
        if (loaded.mulingConfig != null) {
            this.mulingConfig = new MulingConfig(loaded.mulingConfig);
        }

        if (loaded.breakConfig != null) {
            this.breakConfig = new BreakConfig(loaded.breakConfig);
        }

        if (loaded.antiBanConfig != null) {
            this.antiBanConfig = new AntiBanConfig(loaded.antiBanConfig);
        }

        if (loaded.restockConfig != null) {
            this.restockConfig = new RestockConfig(loaded.restockConfig);
        }
    }

    /**
     * Reset config to defaults
     */
    public void reset() {
        customData.clear();
        setDefaults();
        log("Config reset to defaults");
    }

    /**
     * Save configuration to a profile file
     * @param profileName The profile name
     */
    public void saveProfile(String profileName) {
        if (profileName == null || profileName.isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }

        try {
            // Create profiles directory if it doesn't exist
            Path profilesDir = Paths.get(PROFILES_DIR, scriptName);
            Files.createDirectories(profilesDir);

            // Create a structured data object for serialization
            Map<String, Object> profileData = new HashMap<>();

            // Add framework configs
            profileData.put("mulingConfig", mulingConfig);
            profileData.put("breakConfig", breakConfig);
            profileData.put("antiBanConfig", antiBanConfig);
            profileData.put("restockConfig", restockConfig);

            // Add custom data (filtered to remove problematic objects)
            Map<String, Object> filteredData = new HashMap<>();
            for (Map.Entry<String, Object> entry : customData.entrySet()) {
                Object value = entry.getValue();
                // Skip Thread objects and other problematic types
                if (value != null && !(value instanceof Thread) &&
                    !value.getClass().getName().startsWith("java.lang.Thread") &&
                    !value.getClass().getName().startsWith("java.util.concurrent")) {
                    filteredData.put(entry.getKey(), value);
                }
            }
            profileData.put("customData", filteredData);

            // Add metadata
            profileData.put("scriptName", scriptName);
            profileData.put("currentProfile", profileName);

            // Save to profile file
            Path profilePath = profilesDir.resolve(profileName + ".json");
            String json = GSON.toJson(profileData);
            Files.write(profilePath, json.getBytes(StandardCharsets.UTF_8));

            this.currentProfile = profileName;
            debug("Profile saved: " + profileName);

            // Mark config as clean
            markClean();
        } catch (Exception e) {
            error("Error saving profile: " + profileName, e);
            throw new RuntimeException("Failed to save profile: " + e.getMessage(), e);
        }
    }

    /**
     * Load configuration from a profile file
     * @param profileName The profile name
     */
    public void loadProfile(String profileName) {
        if (profileName == null || profileName.isEmpty()) {
            throw new IllegalArgumentException("Profile name cannot be empty");
        }

        if (profileName.equals("Default")) {
            setDefaults();
            this.currentProfile = "Default";
            return;
        }

        try {
            // Load from profile file
            Path profilePath = Paths.get(PROFILES_DIR, scriptName, profileName + ".json");

            if (Files.exists(profilePath)) {
                String json = new String(Files.readAllBytes(profilePath), StandardCharsets.UTF_8);

                try {
                    // Load as a structured data object
                    Map<String, Object> profileData = GSON.fromJson(json, new TypeToken<Map<String, Object>>(){}.getType());

                    // Load framework configs if available
                    if (profileData.containsKey("mulingConfig")) {
                        // Convert the object to JSON string and then parse it to the correct type
                        String configJson = GSON.toJson(profileData.get("mulingConfig"));
                        MulingConfig loadedMulingConfig = GSON.fromJson(configJson, MulingConfig.class);
                        this.mulingConfig = loadedMulingConfig;
                    }

                    if (profileData.containsKey("breakConfig")) {
                        // Convert the object to JSON string and then parse it to the correct type
                        String configJson = GSON.toJson(profileData.get("breakConfig"));
                        BreakConfig loadedBreakConfig = GSON.fromJson(configJson, BreakConfig.class);
                        this.breakConfig = loadedBreakConfig;
                    }

                    if (profileData.containsKey("antiBanConfig")) {
                        // Convert the object to JSON string and then parse it to the correct type
                        String configJson = GSON.toJson(profileData.get("antiBanConfig"));
                        AntiBanConfig loadedAntiBanConfig = GSON.fromJson(configJson, AntiBanConfig.class);
                        this.antiBanConfig = loadedAntiBanConfig;
                    }

                    if (profileData.containsKey("restockConfig")) {
                        // Convert the object to JSON string and then parse it to the correct type
                        String configJson = GSON.toJson(profileData.get("restockConfig"));
                        RestockConfig loadedRestockConfig = GSON.fromJson(configJson, RestockConfig.class);
                        this.restockConfig = loadedRestockConfig;
                    }

                    // Load custom data if available
                    if (profileData.containsKey("customData")) {
                        // Convert the object to JSON string and then parse it to the correct type
                        String customDataJson = GSON.toJson(profileData.get("customData"));
                        Map<String, Object> loadedCustomData = GSON.fromJson(customDataJson, new TypeToken<Map<String, Object>>(){}.getType());
                        this.customData.clear();
                        this.customData.putAll(loadedCustomData);
                    }

                    this.currentProfile = profileName;
                    debug("Profile loaded: " + profileName);
                } catch (Exception e) {
                    error("Error loading profile: " + profileName, e);
                    throw new RuntimeException("Failed to load profile: " + e.getMessage(), e);
                }
            } else {
                debug("Profile not found: " + profileName);
                throw new RuntimeException("Profile not found: " + profileName);
            }
        } catch (Exception e) {
            error("Error loading profile: " + profileName, e);
            throw new RuntimeException("Failed to load profile: " + e.getMessage(), e);
        }
    }

    /**
     * Remove a profile
     * @param profileName The profile name
     */
    public void removeProfile(String profileName) {
        if (profileName == null || profileName.isEmpty() || profileName.equals("Default")) {
            throw new IllegalArgumentException("Cannot remove default or empty profile");
        }

        try {
            Path profilePath = Paths.get(PROFILES_DIR, scriptName, profileName + ".json");

            if (Files.exists(profilePath)) {
                Files.delete(profilePath);
                debug("Profile removed: " + profileName);

                // If current profile was removed, reset to default
                if (profileName.equals(currentProfile)) {
                    setDefaults();
                    this.currentProfile = "Default";
                }
            } else {
                debug("Profile not found: " + profileName);
            }
        } catch (Exception e) {
            error("Error removing profile: " + profileName, e);
        }
    }

    /**
     * Get a list of available profiles
     * @return List of profile names
     */
    public List<String> getAvailableProfiles() {
        List<String> profiles = new ArrayList<>();

        try {
            Path profilesDir = Paths.get(PROFILES_DIR, scriptName);

            if (Files.exists(profilesDir)) {
                profiles = Files.list(profilesDir)
                        .filter(path -> path.toString().endsWith(".json"))
                        .map(path -> path.getFileName().toString().replace(".json", ""))
                        .collect(Collectors.toList());
            }
        } catch (Exception e) {
            error("Error listing profiles", e);
        }

        return profiles;
    }

    /**
     * Get the current profile name
     * @return Current profile name
     */
    public String getCurrentProfile() {
        return currentProfile;
    }

    /**
     * Get the muling configuration
     * @return Muling configuration
     */
    public MulingConfig getMulingConfig() {
        return mulingConfig;
    }

    /**
     * Set the muling configuration
     * @param mulingConfig Muling configuration
     */
    public void setMulingConfig(MulingConfig mulingConfig) {
        if (mulingConfig != null) {
            this.mulingConfig = mulingConfig;
            markDirty();
        }
    }

    /**
     * Get the break configuration
     * @return Break configuration
     */
    public BreakConfig getBreakConfig() {
        return breakConfig;
    }

    /**
     * Set the break configuration
     * @param breakConfig Break configuration
     */
    public void setBreakConfig(BreakConfig breakConfig) {
        if (breakConfig != null) {
            this.breakConfig = breakConfig;
            markDirty();
        }
    }

    /**
     * Get the anti-ban configuration
     * @return Anti-ban configuration
     */
    public AntiBanConfig getAntiBanConfig() {
        return antiBanConfig;
    }

    /**
     * Set the anti-ban configuration
     * @param antiBanConfig Anti-ban configuration
     */
    public void setAntiBanConfig(AntiBanConfig antiBanConfig) {
        if (antiBanConfig != null) {
            this.antiBanConfig = antiBanConfig;
            markDirty();
        }
    }

    /**
     * Get the restock configuration
     * @return Restock configuration
     */
    public RestockConfig getRestockConfig() {
        return restockConfig;
    }

    /**
     * Set the restock configuration
     * @param restockConfig Restock configuration
     */
    public void setRestockConfig(RestockConfig restockConfig) {
        if (restockConfig != null) {
            this.restockConfig.merge(restockConfig);
        }
    }

    /**
     * Check if config is initialized
     */
    public boolean isInitialized() {
        return initialized;
    }

    /**
     * Mark the config as dirty (needs to be saved)
     */
    public void markDirty() {
        this.dirty = true;
        debug("Config marked as dirty");
    }

    /**
     * Check if the config is dirty (needs to be saved)
     */
    public boolean isDirty() {
        return this.dirty;
    }

    /**
     * Mark the config as clean (no longer needs to be saved)
     */
    public void markClean() {
        this.dirty = false;
        debug("Config marked as clean");
    }

    @Override
    public String toString() {
        return String.format("Config[script=%s, initialized=%s]",
                scriptName, initialized);
    }
}