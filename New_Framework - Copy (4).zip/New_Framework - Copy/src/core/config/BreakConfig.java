package core.config;

import com.google.gson.annotations.Expose;

/**
 * Configuration for break settings
 */
public class BreakConfig {
    // Break settings
    @Expose private boolean enabled = true;
    @Expose private int breakFrequency = 60; // minutes
    @Expose private int breakDuration = 5; // minutes
    @Expose private boolean randomizeBreaks = true;
    @Expose private int breakRandomization = 10; // ±minutes
    @Expose private boolean logoutDuringBreaks = true;
    @Expose private boolean screenBreaks = false;
    @Expose private String breakType = "Random"; // Random, Fixed, Progressive
    
    /**
     * Default constructor
     */
    public BreakConfig() {
        // Default values already set
    }
    
    /**
     * Copy constructor
     */
    public BreakConfig(BreakConfig other) {
        if (other != null) {
            this.enabled = other.enabled;
            this.breakFrequency = other.breakFrequency;
            this.breakDuration = other.breakDuration;
            this.randomizeBreaks = other.randomizeBreaks;
            this.breakRandomization = other.breakRandomization;
            this.logoutDuringBreaks = other.logoutDuringBreaks;
            this.screenBreaks = other.screenBreaks;
            this.breakType = other.breakType;
        }
    }
    
    // Getters and setters
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    public int getBreakFrequency() {
        return breakFrequency;
    }
    
    public void setBreakFrequency(int breakFrequency) {
        this.breakFrequency = breakFrequency;
    }
    
    public int getBreakDuration() {
        return breakDuration;
    }
    
    public void setBreakDuration(int breakDuration) {
        this.breakDuration = breakDuration;
    }
    
    public boolean isRandomizeBreaks() {
        return randomizeBreaks;
    }
    
    public void setRandomizeBreaks(boolean randomizeBreaks) {
        this.randomizeBreaks = randomizeBreaks;
    }
    
    public int getBreakRandomization() {
        return breakRandomization;
    }
    
    public void setBreakRandomization(int breakRandomization) {
        this.breakRandomization = breakRandomization;
    }
    
    public boolean isLogoutDuringBreaks() {
        return logoutDuringBreaks;
    }
    
    public void setLogoutDuringBreaks(boolean logoutDuringBreaks) {
        this.logoutDuringBreaks = logoutDuringBreaks;
    }
    
    public boolean isScreenBreaks() {
        return screenBreaks;
    }
    
    public void setScreenBreaks(boolean screenBreaks) {
        this.screenBreaks = screenBreaks;
    }
    
    public String getBreakType() {
        return breakType;
    }
    
    public void setBreakType(String breakType) {
        this.breakType = breakType;
    }
}
