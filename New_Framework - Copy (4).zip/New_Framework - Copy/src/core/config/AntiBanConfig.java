package core.config;

import com.google.gson.annotations.Expose;

/**
 * Configuration for anti-ban settings
 */
public class AntiBanConfig {
    // Anti-ban settings
    @Expose private boolean enabled = true;
    @Expose private int intensity = 5; // 1-10
    @Expose private boolean randomMouseMovements = true;
    @Expose private boolean randomCameraMovements = true;
    @Expose private boolean randomTabChecks = true;
    @Expose private boolean examineObjects = false;
    @Expose private boolean hoverNPCs = false;
    @Expose private boolean hoverPlayers = false;
    @Expose private boolean afkBreaks = true;
    @Expose private int afkFrequency = 15; // minutes
    @Expose private int afkDuration = 30; // seconds
    
    /**
     * Default constructor
     */
    public AntiBanConfig() {
        // Default values already set
    }
    
    /**
     * Copy constructor
     */
    public AntiBanConfig(AntiBanConfig other) {
        if (other != null) {
            this.enabled = other.enabled;
            this.intensity = other.intensity;
            this.randomMouseMovements = other.randomMouseMovements;
            this.randomCameraMovements = other.randomCameraMovements;
            this.randomTabChecks = other.randomTabChecks;
            this.examineObjects = other.examineObjects;
            this.hoverNPCs = other.hoverNPCs;
            this.hoverPlayers = other.hoverPlayers;
            this.afkBreaks = other.afkBreaks;
            this.afkFrequency = other.afkFrequency;
            this.afkDuration = other.afkDuration;
        }
    }
    
    // Getters and setters
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    public int getIntensity() {
        return intensity;
    }
    
    public void setIntensity(int intensity) {
        this.intensity = intensity;
    }
    
    public boolean isRandomMouseMovements() {
        return randomMouseMovements;
    }
    
    public void setRandomMouseMovements(boolean randomMouseMovements) {
        this.randomMouseMovements = randomMouseMovements;
    }
    
    public boolean isRandomCameraMovements() {
        return randomCameraMovements;
    }
    
    public void setRandomCameraMovements(boolean randomCameraMovements) {
        this.randomCameraMovements = randomCameraMovements;
    }
    
    public boolean isRandomTabChecks() {
        return randomTabChecks;
    }
    
    public void setRandomTabChecks(boolean randomTabChecks) {
        this.randomTabChecks = randomTabChecks;
    }
    
    public boolean isExamineObjects() {
        return examineObjects;
    }
    
    public void setExamineObjects(boolean examineObjects) {
        this.examineObjects = examineObjects;
    }
    
    public boolean isHoverNPCs() {
        return hoverNPCs;
    }
    
    public void setHoverNPCs(boolean hoverNPCs) {
        this.hoverNPCs = hoverNPCs;
    }
    
    public boolean isHoverPlayers() {
        return hoverPlayers;
    }
    
    public void setHoverPlayers(boolean hoverPlayers) {
        this.hoverPlayers = hoverPlayers;
    }
    
    public boolean isAfkBreaks() {
        return afkBreaks;
    }
    
    public void setAfkBreaks(boolean afkBreaks) {
        this.afkBreaks = afkBreaks;
    }
    
    public int getAfkFrequency() {
        return afkFrequency;
    }
    
    public void setAfkFrequency(int afkFrequency) {
        this.afkFrequency = afkFrequency;
    }
    
    public int getAfkDuration() {
        return afkDuration;
    }
    
    public void setAfkDuration(int afkDuration) {
        this.afkDuration = afkDuration;
    }
}
