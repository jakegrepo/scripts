package core.debug;

import core.paint.debug.DebugOverlay;

import java.awt.*;

/**
 * Adapter class that bridges between DebugManager and DebugOverlay systems.
 * This allows scripts to use the new DebugManager while maintaining compatibility
 * with the existing paint system that expects a DebugOverlay.
 */
public class DebugOverlayAdapter extends DebugOverlay {
    private final DebugManager debugManager;

    public DebugOverlayAdapter(DebugManager debugManager) {
        super(debugManager.getContext());
        this.debugManager = debugManager;
    }

    @Override
    public void render(Graphics2D g) {
        if (debugManager != null) {
            debugManager.render(g);
        }
    }

    @Override
    public void clearTileHighlights() {
        if (debugManager != null) {
            debugManager.clearTileHighlights();
        }
    }

    @Override
    public void clearProjectileHighlights() {
        // No-op as DebugManager doesn't handle projectiles
    }

    @Override
    public void toggle() {
        if (debugManager != null) {
            debugManager.setEnabled(!debugManager.isEnabled());
        }
    }

    @Override
    public boolean isEnabled() {
        return debugManager != null && debugManager.isEnabled();
    }

    @Override
    public void updateAllTiles() {
        // No-op as DebugManager handles this differently
    }

    @Override
    public void updateScurriusHighlight() {
        // No-op as this is Scurrius specific
    }

    @Override
    public void updateGraphicsHighlights() {
        // No-op as DebugManager doesn't handle graphics
    }
} 