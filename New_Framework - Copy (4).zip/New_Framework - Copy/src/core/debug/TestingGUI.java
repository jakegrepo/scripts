package core.debug;

import core.context.ScriptContext;
import core.gui.style.StyleManager;
import core.node.TaskNode;
import core.state.ScriptState;
import org.dreambot.api.methods.container.impl.bank.Bank;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class TestingGUI extends JFrame {
    private final ScriptContext context;
    private final DefaultListModel<TaskNode> nodeListModel;
    private final JList<TaskNode> nodeList;
    private TaskNode activeTestNode;
    private boolean isTestingActive = false;
    private boolean isInTestMode = false;
    private boolean forceExecute = false;
    private JLabel statusLabel;
    private JTextArea nodeInfoArea;
    private JCheckBox forceExecuteCheckbox;
    private JPanel statusPanel;
    private JLabel currentStatusLabel;
    private JTextArea statusHistory;
    private List<String> statusList = new ArrayList<>();
    private static final int MAX_STATUS_HISTORY = 10;

    public TestingGUI(ScriptContext context) {
        this.context = context;
        this.setTitle("Node Tester");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Initialize components
        nodeListModel = new DefaultListModel<>();
        nodeList = new JList<>(nodeListModel);
        nodeList.setCellRenderer(new NodeListCellRenderer());
        nodeList.setBackground(StyleManager.FIELD_BG);
        nodeList.setForeground(StyleManager.FOREGROUND);
        nodeList.setSelectionBackground(StyleManager.ACCENT);
        nodeList.setSelectionForeground(StyleManager.FOREGROUND);
        nodeList.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        // Add selection listener to show node info
        nodeList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                TaskNode selectedNode = nodeList.getSelectedValue();
                if (selectedNode != null) {
                    updateNodeInfo(selectedNode);
                }
            }
        });
        
        // Create main layout with dark theme
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(StyleManager.BACKGROUND);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Create header panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(StyleManager.BACKGROUND);
        
        // Add title label
        JLabel titleLabel = new JLabel("Node Tester");
        titleLabel.setFont(StyleManager.HEADER_FONT);
        titleLabel.setForeground(StyleManager.ACCENT);
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Create content panel with split pane
        JSplitPane contentSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        contentSplit.setBackground(StyleManager.BACKGROUND);
        contentSplit.setBorder(null);
        contentSplit.setDividerLocation(300);
        
        // Left side: Node list and info
        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setBackground(StyleManager.BACKGROUND);
        
        // Create node list panel with title
        JPanel nodeListPanel = new JPanel(new BorderLayout(5, 5));
        nodeListPanel.setBackground(StyleManager.BACKGROUND);
        
        JLabel nodesLabel = new JLabel("Available Nodes");
        nodesLabel.setFont(StyleManager.SECTION_HEADER_FONT);
        nodesLabel.setForeground(StyleManager.ACCENT);
        nodeListPanel.add(nodesLabel, BorderLayout.NORTH);
        
        // Style the node list scroll pane
        JScrollPane nodeScrollPane = new JScrollPane(nodeList);
        nodeScrollPane.setBackground(StyleManager.BACKGROUND);
        nodeScrollPane.getViewport().setBackground(StyleManager.FIELD_BG);
        nodeScrollPane.setBorder(BorderFactory.createLineBorder(StyleManager.BORDER_COLOR));
        nodeListPanel.add(nodeScrollPane, BorderLayout.CENTER);
        
        // Add node info area
        nodeInfoArea = new JTextArea(5, 40);
        nodeInfoArea.setEditable(false);
        nodeInfoArea.setBackground(StyleManager.FIELD_BG);
        nodeInfoArea.setForeground(StyleManager.FOREGROUND);
        nodeInfoArea.setFont(StyleManager.REGULAR_FONT);
        nodeInfoArea.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        JScrollPane infoScrollPane = new JScrollPane(nodeInfoArea);
        infoScrollPane.setBackground(StyleManager.BACKGROUND);
        infoScrollPane.setBorder(BorderFactory.createLineBorder(StyleManager.BORDER_COLOR));
        
        leftPanel.add(nodeListPanel, BorderLayout.CENTER);
        leftPanel.add(infoScrollPane, BorderLayout.SOUTH);
        
        // Right side: Status panel
        createStatusPanel();
        
        contentSplit.setLeftComponent(leftPanel);
        contentSplit.setRightComponent(statusPanel);
        
        mainPanel.add(contentSplit, BorderLayout.CENTER);
        
        // Create control panel
        JPanel controlPanel = createControlPanel();
        mainPanel.add(controlPanel, BorderLayout.SOUTH);
        
        // Setup frame
        this.add(mainPanel);
        this.setSize(800, 600);
        this.setLocationRelativeTo(null);
        
        // Initial node load
        refreshNodes();
    }

    private JPanel createControlPanel() {
        // Create control panel with gradient background
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                int w = getWidth();
                int h = getHeight();
                GradientPaint gp = new GradientPaint(0, 0, StyleManager.PANEL_BG, 
                    0, h, StyleManager.BACKGROUND);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
                g2d.dispose();
            }
        };
        controlPanel.setOpaque(false);
        
        // Add force execute checkbox with custom styling
        forceExecuteCheckbox = new JCheckBox("Force Execute (Bypass Validation)");
        forceExecuteCheckbox.setFont(StyleManager.REGULAR_FONT);
        forceExecuteCheckbox.setForeground(StyleManager.FOREGROUND);
        forceExecuteCheckbox.setBackground(StyleManager.PANEL_BG);
        forceExecuteCheckbox.addActionListener(e -> forceExecute = forceExecuteCheckbox.isSelected());
        
        // Create and style buttons
        JButton setupButton = createStyledButton("Setup Test");
        JButton startButton = createStyledButton("Start Testing");
        JButton stopButton = createStyledButton("Stop Testing");
        JButton refreshButton = createStyledButton("Refresh Nodes");
        
        // Add action listeners
        setupButton.addActionListener(e -> setupNodeTest());
        startButton.addActionListener(e -> startTesting());
        stopButton.addActionListener(e -> stopTesting());
        refreshButton.addActionListener(e -> refreshNodes());
        
        // Add components to control panel
        controlPanel.add(forceExecuteCheckbox);
        controlPanel.add(setupButton);
        controlPanel.add(startButton);
        controlPanel.add(stopButton);
        controlPanel.add(refreshButton);
        
        return controlPanel;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(StyleManager.REGULAR_FONT);
        button.setBackground(StyleManager.BUTTON_BG);
        button.setForeground(StyleManager.FOREGROUND);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        
        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(StyleManager.BUTTON_HOVER);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(StyleManager.BUTTON_BG);
            }
        });
        
        return button;
    }

    private void updateNodeInfo(TaskNode node) {
        StringBuilder info = new StringBuilder();
        info.append("Node: ").append(node.getClass().getSimpleName()).append("\n");
        info.append("Priority: ").append(node.getPriority()).append("\n");
        info.append("Current Status: ").append(node.getStatus()).append("\n");
        info.append("\nValidation Requirements:\n");
        
        // Add specific node requirements
        if (node.getClass().getSimpleName().equals("SupplyCheckNode")) {
            info.append("- Bank must be open\n");
            info.append("- Must not be in instance\n");
        } else if (node.getClass().getSimpleName().equals("BankingNode")) {
            info.append("- Bank must be accessible\n");
            info.append("- Must not be in combat\n");
        }
        // Add more node-specific requirements as needed
        
        nodeInfoArea.setText(info.toString());
    }

    private void setupNodeTest() {
        TaskNode selectedNode = nodeList.getSelectedValue();
        if (selectedNode == null) {
            JOptionPane.showMessageDialog(this, "Please select a node to setup");
            return;
        }

        updateStatus("Setting up test for " + selectedNode.getClass().getSimpleName());
        
        // Perform node-specific setup
        String nodeName = selectedNode.getClass().getSimpleName();
        switch (nodeName) {
            case "SupplyCheckNode":
                // Open bank if not open
                if (!Bank.isOpen()) {
                    updateStatus("Opening bank...");
                    Bank.open();
                }
                break;
            case "BankingNode":
                // Similar setup for banking node
                break;
            // Add more cases for other nodes
            default:
                updateStatus("No specific setup needed for " + nodeName);
                break;
        }
    }

    private void updateStatus(String status) {
        SwingUtilities.invokeLater(() -> {
            // Only update the current status label for framework messages
            currentStatusLabel.setText(status);
            
            // Log to script logger
            context.getLogger().info("Node Tester: " + status);
        });
    }

    private void startTesting() {
        TaskNode selectedNode = nodeList.getSelectedValue();
        if (selectedNode == null) {
            JOptionPane.showMessageDialog(this, "Please select a node to test");
            return;
        }

        updateStatus("Starting test for " + selectedNode.getClass().getSimpleName() + 
            (forceExecute ? " (Force Execute Mode)" : ""));

        // Save current script state
        ScriptState previousState = context.state().getCurrentState();
        
        // Enter test mode without actually starting the script
        isInTestMode = true;
        isTestingActive = true;
        
        // Add status listener to the node
        selectedNode.addStatusListener(this::updateNodeStatus);
        
        // Temporarily set state to RUNNING just for this node
        context.state().setState(ScriptState.RUNNING);
        activeTestNode = selectedNode;
        
        new Thread(() -> {
            try {
                updateStatus("Test mode started for: " + selectedNode.getClass().getSimpleName());
                
                while (isTestingActive) {
                    if (forceExecute || activeTestNode.validate()) {
                        updateStatus("Node " + (forceExecute ? "force executing" : "validated") + ", executing...");
                        int sleepTime = activeTestNode.executeNode();
                        Thread.sleep(Math.max(600, sleepTime));
                    } else {
                        updateStatus("Node validation failed, waiting... (Enable Force Execute to bypass)");
                        Thread.sleep(600);
                    }
                }
            } catch (Exception e) {
                String errorMsg = "Error in test mode: " + e.getMessage();
                context.getLogger().error(errorMsg);
                updateStatus("Error: " + e.getMessage());
                e.printStackTrace();
            } finally {
                // Remove status listener
                selectedNode.removeStatusListener(this::updateNodeStatus);
                
                // Restore previous state when done
                if (!isInTestMode) {
                    context.state().setState(previousState);
                }
            }
        }, "NodeTesterThread").start();
    }

    private void updateNodeStatus(String status) {
        SwingUtilities.invokeLater(() -> {
            // Add to history with timestamp
            String timestamp = String.format("[%tT] ", new java.util.Date());
            String logEntry = timestamp + status;
            
            // Add to list and update display
            statusList.add(0, logEntry);
            while (statusList.size() > MAX_STATUS_HISTORY) {
                statusList.remove(statusList.size() - 1);
            }
            
            // Update history display
            StringBuilder history = new StringBuilder();
            for (String s : statusList) {
                history.append(s).append("\n");
            }
            statusHistory.setText(history.toString());
            
            // Update current status label
            currentStatusLabel.setText(status);
            
            // Update icon based on status content
            JLabel iconLabel = (JLabel) ((JPanel)currentStatusLabel.getParent()).getComponent(0);
            String statusLower = status.toLowerCase();
            if (statusLower.contains("error")) {
                iconLabel.setText("\u274C");  // X mark Unicode
                iconLabel.setForeground(StyleManager.ERROR);
            } else if (statusLower.contains("success")) {
                iconLabel.setText("\u2705");  // Check mark Unicode
                iconLabel.setForeground(StyleManager.SUCCESS);
            } else if (statusLower.contains("waiting")) {
                iconLabel.setText("\u23F3");  // Hourglass Unicode
                iconLabel.setForeground(StyleManager.WARNING);
            } else {
                iconLabel.setText("\u26A1");  // Lightning bolt Unicode
                iconLabel.setForeground(StyleManager.ACCENT);
            }
            
            // Log to script logger
            context.getLogger().info("Node Status: " + status);
            
            // Auto-scroll to top
            statusHistory.setCaretPosition(0);
        });
    }

    private void stopTesting() {
        isTestingActive = false;
        isInTestMode = false;
        
        if (activeTestNode != null) {
            updateStatus("Stopping test for " + activeTestNode.getClass().getSimpleName());
            context.getLogger().info("Stopping test mode for node: " + activeTestNode.getClass().getSimpleName());
            activeTestNode.cleanup();
            activeTestNode = null;
        }
        
        // Restore script to STOPPED state if it wasn't already running
        if (context.state().getCurrentState() != ScriptState.RUNNING) {
            context.state().setState(ScriptState.STOPPED);
        }
        
        updateStatus("Ready");
    }

    private void refreshNodes() {
        nodeListModel.clear();
        List<TaskNode> nodes = context.tasks().getNodes();
        nodes.forEach(nodeListModel::addElement);
        updateStatus("Nodes refreshed - " + nodes.size() + " nodes available");
    }

    private void createStatusPanel() {
        statusPanel = new JPanel(new BorderLayout(5, 5));
        statusPanel.setBackground(StyleManager.BACKGROUND);
        statusPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Current status with icon
        JPanel currentStatusPanel = new JPanel(new BorderLayout(10, 0));
        currentStatusPanel.setBackground(StyleManager.PANEL_BG);
        currentStatusPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(StyleManager.BORDER_COLOR),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        // Status icon (can be updated based on status type)
        JLabel statusIcon = new JLabel("\u26A1");  // Lightning bolt Unicode
        statusIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));
        statusIcon.setForeground(StyleManager.ACCENT);
        currentStatusPanel.add(statusIcon, BorderLayout.WEST);

        // Current status label
        currentStatusLabel = new JLabel("Ready");
        currentStatusLabel.setFont(StyleManager.HEADER_FONT);
        currentStatusLabel.setForeground(StyleManager.FOREGROUND);
        currentStatusPanel.add(currentStatusLabel, BorderLayout.CENTER);

        // Status history
        JPanel historyPanel = new JPanel(new BorderLayout(5, 5));
        historyPanel.setBackground(StyleManager.BACKGROUND);
        
        JLabel historyLabel = new JLabel("Status History");
        historyLabel.setFont(StyleManager.SECTION_HEADER_FONT);
        historyLabel.setForeground(StyleManager.ACCENT);
        historyPanel.add(historyLabel, BorderLayout.NORTH);

        statusHistory = new JTextArea();
        statusHistory.setEditable(false);
        statusHistory.setBackground(StyleManager.FIELD_BG);
        statusHistory.setForeground(StyleManager.FOREGROUND);
        statusHistory.setFont(StyleManager.REGULAR_FONT);
        statusHistory.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        statusHistory.setLineWrap(true);
        statusHistory.setWrapStyleWord(true);

        JScrollPane historyScroll = new JScrollPane(statusHistory);
        historyScroll.setBackground(StyleManager.BACKGROUND);
        historyScroll.setBorder(BorderFactory.createLineBorder(StyleManager.BORDER_COLOR));
        historyPanel.add(historyScroll, BorderLayout.CENTER);

        // Add to status panel
        statusPanel.add(currentStatusPanel, BorderLayout.NORTH);
        statusPanel.add(historyPanel, BorderLayout.CENTER);
    }

    private static class NodeListCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, 
                                                    int index, boolean isSelected, 
                                                    boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof TaskNode) {
                TaskNode node = (TaskNode) value;
                setText(String.format("%s (Priority: %d)", 
                    node.getClass().getSimpleName(), 
                    node.getPriority()));
                setFont(StyleManager.REGULAR_FONT);
                
                if (!isSelected) {
                    setBackground(StyleManager.FIELD_BG);
                    setForeground(StyleManager.FOREGROUND);
                }
            }
            return this;
        }
    }
}