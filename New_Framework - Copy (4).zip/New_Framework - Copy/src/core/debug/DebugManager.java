package core.debug;

import core.context.ScriptContext;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.map.Tile;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class DebugManager {
    private final Map<String, String> debugInfo;
    private final Map<Tile, TileHighlight> highlightedTiles;
    private final Map<Area, AreaHighlight> highlightedAreas;
    private final Map<String, NPCHighlight> highlightedNPCs;
    private final ScriptContext context;
    private boolean enabled;

    public DebugManager(ScriptContext context) {
        this.context = context;
        this.debugInfo = new ConcurrentHashMap<>();
        this.highlightedTiles = new ConcurrentHashMap<>();
        this.highlightedAreas = new ConcurrentHashMap<>();
        this.highlightedNPCs = new ConcurrentHashMap<>();
        this.enabled = false;
    }

    public ScriptContext getContext() {
        return context;
    }

    public void render(Graphics2D g) {
        if (!enabled) return;
        
        // Render debug info
        int y = 40;
        for (Map.Entry<String, String> entry : debugInfo.entrySet()) {
            g.drawString(entry.getKey() + ": " + entry.getValue(), 10, y);
            y += 15;
        }

        // Render tile highlights
        for (Map.Entry<Tile, TileHighlight> entry : highlightedTiles.entrySet()) {
            Tile tile = entry.getKey();
            TileHighlight highlight = entry.getValue();
            // Draw tile highlight (implementation depends on your tile rendering logic)
            // This is a placeholder for the actual rendering code
        }

        // Render area highlights
        for (Map.Entry<Area, AreaHighlight> entry : highlightedAreas.entrySet()) {
            Area area = entry.getKey();
            AreaHighlight highlight = entry.getValue();
            if (area != null && highlight != null) {
                g.setColor(highlight.getColor());
                // Draw area highlight logic here
                if (highlight.getLabel() != null) {
                    g.drawString(highlight.getLabel(), area.getCenter().getX(), area.getCenter().getY());
                }
            }
        }
    }

    public void clearTileHighlights() {
        highlightedTiles.clear();
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void addDebugInfo(String key, String value) {
        debugInfo.put(key, value);
    }

    public void removeDebugInfo(String key) {
        debugInfo.remove(key);
    }

    public void clearDebugInfo() {
        debugInfo.clear();
    }

    public Map<String, String> getDebugInfo() {
        return new HashMap<>(debugInfo);
    }

    public void highlightTile(Tile tile, Color color, String label) {
        highlightedTiles.put(tile, new TileHighlight(color, label));
    }

    public void removeHighlight(Tile tile) {
        highlightedTiles.remove(tile);
    }

    public void clearHighlights() {
        highlightedTiles.clear();
    }

    public Map<Tile, TileHighlight> getHighlightedTiles() {
        return new HashMap<>(highlightedTiles);
    }

    public void highlightArea(Area area, Color color, String label) {
        if (area != null) {
            highlightedAreas.put(area, new AreaHighlight(color, label));
        }
    }

    public void clearNPCHighlights() {
        highlightedNPCs.clear();
    }

    public void addNPCHighlight(String npcName, Color color) {
        highlightedNPCs.put(npcName, new NPCHighlight(color));
    }

    public static class TileHighlight {
        private final Color color;
        private final String label;

        public TileHighlight(Color color, String label) {
            this.color = color;
            this.label = label;
        }

        public Color getColor() {
            return color;
        }

        public String getLabel() {
            return label;
        }
    }

    // Inner class for Area highlights
    private static class AreaHighlight {
        private final Color color;
        private final String label;

        public AreaHighlight(Color color, String label) {
            this.color = color;
            this.label = label;
        }

        public Color getColor() {
            return color;
        }

        public String getLabel() {
            return label;
        }
    }

    // Inner class for NPC highlights
    private static class NPCHighlight {
        private final Color color;

        public NPCHighlight(Color color) {
            this.color = color;
        }

        public Color getColor() {
            return color;
        }
    }
} 