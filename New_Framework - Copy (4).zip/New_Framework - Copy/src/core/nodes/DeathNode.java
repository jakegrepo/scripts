package core.nodes;

import core.base.SimpleNode;
import core.config.ScriptConfig;
import org.dreambot.api.methods.container.impl.Inventory;
import org.dreambot.api.methods.container.impl.bank.Bank;
import org.dreambot.api.methods.container.impl.bank.BankLocation;
import org.dreambot.api.methods.container.impl.equipment.Equipment;
import org.dreambot.api.methods.container.impl.equipment.EquipmentSlot;
import org.dreambot.api.methods.dialogues.Dialogues;
import org.dreambot.api.methods.interactive.GameObjects;
import org.dreambot.api.methods.interactive.NPCs;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Area;
import org.dreambot.api.methods.walking.impl.Walking;
import org.dreambot.api.methods.widget.Widgets;
import org.dreambot.api.utilities.Logger;
import org.dreambot.api.utilities.Sleep;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;
import org.dreambot.api.wrappers.widgets.WidgetChild;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DeathNode<T extends ScriptConfig> extends SimpleNode<T> {
    private static final String DEATHS_DOMAIN = "Death's Domain";
    private static final int DEATH_HANDLER_PRIORITY = 0; // Highest priority possible
    private boolean handlingDeath = false;
    private boolean needToBank = false;
    private boolean hasMoreItemsToCollect = false;
    private static final Pattern CHARGE_PATTERN = Pattern.compile("\\((\\d+)\\)$");
    private static final Area LUMBRIDGE_BANK_AREA = BankLocation.LUMBRIDGE.getArea(10);
    private static final Area FEROX_ENCLAVE_AREA = new Area(3126, 3636, 3143, 3617);
    public static final Area FEROX_ENCLAVE = new Area(3125, 3640, 3158, 3617);

    private enum DeathState {
        CHECK_DEATH,
        WALK_TO_DEATHS_DOMAIN,
        ENTER_DEATHS_DOMAIN,
        HANDLE_DIALOGUE,
        COLLECT_ITEMS,
        LEAVE_DEATHS_OFFICE,
        WALK_TO_BANK,
        DEPOSIT_ITEMS,
        RETURN_TO_DEATHS_DOMAIN,
        TELEPORT_TO_FEROX,
        FINISHED
    }

    private DeathState currentState = DeathState.CHECK_DEATH;

    public DeathNode(T config) {
        super("Death Handler", DEATH_HANDLER_PRIORITY, config); // Priority 0 for highest priority
    }

    @Override
    public boolean validate() {
        // Check for death widget with "Grave info" action OR if we're in Death's Office interface
        WidgetChild deathWidget = Widgets.getWidgetChild(548, 39);
        WidgetChild retrievalWidget = Widgets.getWidgetChild(669, 1, 1);

        if (FEROX_ENCLAVE.contains(Players.getLocal())){
            return false;
        }
        // Check for initial death widget with Grave info
        if (deathWidget != null && deathWidget.isVisible()) {
            String[] actions = deathWidget.getActions();
            if (actions != null && actions.length > 0 && "Grave info".equals(actions[0])) {
                Logger.log("Found death widget with Grave info - activating death handler");
                handlingDeath = true;
                currentState = DeathState.CHECK_DEATH;
                return true;
            }
        }

        // Check if we're in Death's Office interface
        if (retrievalWidget != null && retrievalWidget.isVisible()) {
            Logger.log("In Death's Office interface - continuing death handling");
            handlingDeath = true;
            return true;
        }

        // Continue handling if we're in the process
        if (handlingDeath) {
            // Check if we're in dialogue with Death
            if (Dialogues.inDialogue()) {
                return true;
            }
            
            // Check if we're still in Death's office needing to use the portal
            if (currentState == DeathState.LEAVE_DEATHS_OFFICE) {
                if (NPCs.closest("Death") != null) {
                    Logger.log("Still in Death's office, need to leave");
                    return true;
                }
            }
            
            // Check if we need to go to bank
            if (currentState == DeathState.WALK_TO_BANK || 
                currentState == DeathState.DEPOSIT_ITEMS || 
                currentState == DeathState.RETURN_TO_DEATHS_DOMAIN ||
                currentState == DeathState.TELEPORT_TO_FEROX) {
                return true;
            }
            
            // Only reset if we're not in Death's office and not in any death-related state
            if (NPCs.closest("Death") == null && !Dialogues.inDialogue() && retrievalWidget == null && 
                currentState == DeathState.FINISHED) {
                Logger.log("Death handling complete - resetting state");
                handlingDeath = false;
                currentState = DeathState.CHECK_DEATH;
            }
        }

        return handlingDeath;
    }

    @Override
    protected int onExecute() {
        try {
            Logger.log("Death handler state: " + currentState);
            
            // First handle any active dialogues
            if (Dialogues.inDialogue()) {
                if (Dialogues.canContinue()) {
                    Dialogues.spaceToContinue();
                    return 600;
                }
                
                String[] options = Dialogues.getOptions();
                if (options != null) {
                    for (String option : options) {
                        if (option.contains("Yes, have you got anything for me?") || 
                            option.contains("Can I collect the items") || 
                            option.contains("Bring my items here now") ||
                            option.contains("Pay Death's fee.")) {
                            Dialogues.chooseOption(option);
                            return 600;
                        }
                    }
                }
                return 600;
            }

            // Then handle the collection interface if it's open
            WidgetChild retrievalWidget = Widgets.getWidgetChild(669, 1, 1);
            if (retrievalWidget != null && retrievalWidget.isVisible()) {
                String widgetText = retrievalWidget.getText();
                Logger.log("Collection interface text: " + widgetText);

                // First try to collect items if we haven't yet
                if (!widgetText.contains("(0/120)")) {
                    WidgetChild takeAllButton = Widgets.getWidgetChild(669, 10);
                    if (takeAllButton != null && takeAllButton.isVisible()) {
                        // Check if inventory is full
                        if (Inventory.isFull()) {
                            // If inventory is full, we need to bank
                            Logger.log("Inventory full, need to bank before collecting more items");
                            needToBank = true;
                            hasMoreItemsToCollect = true;
                            
                            // Close the interface to leave Death's office
                            WidgetChild closeButton = Widgets.getWidgetChild(669, 1, 11);
                            if (closeButton != null && closeButton.interact("Close")) {
                                Logger.log("Closing interface to proceed to banking");
                                Sleep.sleepUntil(() -> Widgets.getWidgetChild(669, 1) == null, 2000);
                                currentState = DeathState.LEAVE_DEATHS_OFFICE;
                                return 600;
                            }
                        } else {
                            // If inventory has space, collect items
                            Logger.log("Clicking Take-All button");
                            if (takeAllButton.interact("Take-All")) {
                                Sleep.sleepUntil(() -> {
                                    WidgetChild checkWidget = Widgets.getWidgetChild(669, 1, 1);
                                    return checkWidget != null && checkWidget.getText().contains("(0/120)");
                                }, 3000);
                            }
                        }
                        return 600;
                    }
                }
                // Only close interface after confirming items are collected
                else {
                    Logger.log("All items collected, closing interface");
                    WidgetChild closeButton = Widgets.getWidgetChild(669, 1, 11);
                    if (closeButton != null && closeButton.interact("Close")) {
                        Sleep.sleepUntil(() -> Widgets.getWidgetChild(669, 1) == null, 2000);
                        if (needToBank && hasMoreItemsToCollect) {
                            // If we've already banked once and returned, we're done collecting
                            hasMoreItemsToCollect = false;
                            currentState = DeathState.LEAVE_DEATHS_OFFICE;
                        } else if (needToBank) {
                            // If we've collected all items after banking, proceed to teleport
                            currentState = DeathState.LEAVE_DEATHS_OFFICE;
                        } else {
                            // Normal flow - leave Death's office
                            currentState = DeathState.LEAVE_DEATHS_OFFICE;
                        }
                    }
                    return 600;
                }
            }

            // Handle leaving Death's office
            if (currentState == DeathState.LEAVE_DEATHS_OFFICE) {
                GameObject portal = GameObjects.closest("Portal");
                if (portal != null && portal.interact("Use")) {
                    Logger.log("Using portal to leave Death's Office");
                    Sleep.sleepUntil(() -> NPCs.closest("Death") == null, 5000);
                    
                    if (needToBank) {
                        if (hasMoreItemsToCollect) {
                            // If we need to bank and have more items to collect, go to bank
                            Logger.log("Need to bank and collect more items - walking to bank");
                            currentState = DeathState.WALK_TO_BANK;
                        } else {
                            // If we've collected all items and need to bank, go to bank
                            Logger.log("Need to bank after collecting all items - walking to bank");
                            currentState = DeathState.WALK_TO_BANK;
                        }
                    } else {
                        // Normal flow - we're done
                        Logger.log("All items collected - teleporting to Ferox");
                        currentState = DeathState.TELEPORT_TO_FEROX;
                    }
                    return 1000;
                }
                return 600;
            }

            // Handle walking to bank
            if (currentState == DeathState.WALK_TO_BANK) {
                if (!(BankLocation.LUMBRIDGE.distance(Players.getLocal().getTile()) <= 4)) {
                    Logger.log("Walking to Lumbridge bank");
                    Walking.walk(BankLocation.LUMBRIDGE);
                    return 1000;
                } else {
                    Logger.log("Reached Lumbridge bank");
                    currentState = DeathState.DEPOSIT_ITEMS;
                    return 600;
                }
            }

            // Handle depositing items at bank
            if (currentState == DeathState.DEPOSIT_ITEMS) {
                if (!Bank.isOpen()) {
                    Logger.log("Opening bank");
                    if (Bank.open()) {
                        Sleep.sleepUntil(Bank::isOpen, 3000);
                        Bank.depositAllItems();
                    }
                    return 600;
                }
                
                Logger.log("Depositing all items");
                if (Bank.depositAllItems()) {
                    Sleep.sleepUntil(Inventory::isEmpty, 3000);
                    
                    if (hasMoreItemsToCollect) {
                        // If we have more items to collect, close bank and return to Death
                        Logger.log("Need to return to Death's Domain to collect more items");
                        Bank.close();
                        Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
                        currentState = DeathState.RETURN_TO_DEATHS_DOMAIN;
                    } else {
                        // If we're done collecting, withdraw Ring of Dueling
                        Logger.log("Withdrawing Ring of Dueling");
                        if (withdrawRingOfDueling()) {
                            Bank.close();
                            Sleep.sleepUntil(() -> !Bank.isOpen(), 3000);
                            currentState = DeathState.TELEPORT_TO_FEROX;
                        }
                    }
                }
                return 600;
            }

            // Handle returning to Death's Domain
            if (currentState == DeathState.RETURN_TO_DEATHS_DOMAIN) {
                GameObject deathsDomain = GameObjects.closest(DEATHS_DOMAIN);
                if (deathsDomain != null) {
                    if (!deathsDomain.canReach()) {
                        Walking.walk(deathsDomain);
                        return 1000;
                    }
                    if (deathsDomain.interact("Enter")) {
                        Logger.log("Entering Death's Domain to collect more items");
                        Sleep.sleepUntil(() -> Dialogues.inDialogue(), 5000);
                        currentState = DeathState.HANDLE_DIALOGUE;
                        return 1000;
                    }
                } else {
                    // If we can't find Death's Domain, walk to its location
                    Logger.log("Walking to Death's Domain location");
                    Walking.walk(3121, 3358); // Approximate location of Death's Domain
                    return 1000;
                }
                return 600;
            }

            // Handle teleporting to Ferox Enclave
            if (currentState == DeathState.TELEPORT_TO_FEROX) {
                if (teleportToFeroxEnclave()) {
                    Logger.log("Successfully teleported to Ferox Enclave");
                    currentState = DeathState.FINISHED;
                    return 1000;
                } else {
                    Logger.log("Failed to teleport to Ferox Enclave, trying again");
                    return 1000;
                }
            }

            // Handle entering Death's office if needed
            if (currentState == DeathState.CHECK_DEATH) {
                GameObject deathsDomain = GameObjects.closest(DEATHS_DOMAIN);
                if (deathsDomain != null) {
                    if (!deathsDomain.canReach()) {
                        Walking.walk(deathsDomain);
                        return 1000;
                    }
                    if (deathsDomain.interact("Enter")) {
                        Logger.log("Entering Death's Domain");
                        Sleep.sleepUntil(() -> Dialogues.inDialogue(), 5000);
                        currentState = DeathState.HANDLE_DIALOGUE;
                        return 1000;
                    }
                }
                return 600;
            }

            return 600;

        } catch (Exception e) {
            Logger.log("Error in death handler: " + e.getMessage());
            handlingDeath = false;
            currentState = DeathState.CHECK_DEATH;
            return 0;
        }
    }

    /**
     * Attempts to withdraw a charged Ring of Dueling from the bank
     * @return true if a ring was withdrawn, false otherwise
     */
    private boolean withdrawRingOfDueling() {
        // Try to withdraw any charged Ring of Dueling
        Item ringOfDueling = Bank.get(item -> {
            if (item != null && item.getName().startsWith("Ring of dueling(")) {
                // Extract the charge number using regex
                Matcher matcher = CHARGE_PATTERN.matcher(item.getName());
                if (matcher.find()) {
                    try {
                        int charge = Integer.parseInt(matcher.group(1));
                        return charge > 0;
                    } catch (NumberFormatException e) {
                        return false;
                    }
                }
            }
            return false;
        });
        
        if (ringOfDueling != null) {
            Logger.log("Found Ring of Dueling: " + ringOfDueling.getName());
            if (Bank.withdraw(ringOfDueling.getName(), 1)) {
                Sleep.sleepUntil(() -> Inventory.contains(ringOfDueling.getName()), 3000);
                return true;
            }
        } else {
            Logger.log("No charged Ring of Dueling found in bank");
        }
        
        return false;
    }
    
    /**
     * Attempts to teleport to Ferox Enclave using a Ring of Dueling
     * @return true if teleport was successful, false otherwise
     */
    private boolean teleportToFeroxEnclave() {
        // Check both equipment and inventory for any charge level
        Item ring = findDuelingRing();
        
        if (ring == null) {
            Logger.log("No Ring of Dueling found for Ferox teleport");
            return false;
        }
        
        // Log the exact name of the ring for debugging
        Logger.log("Using Ring of Dueling to teleport to Ferox Enclave: " + ring.getName());
        
        // Try direct "Ferox Enclave" action first (some rings have this)
        if (ring.interact("Ferox Enclave")) {
            Logger.log("Using direct 'Ferox Enclave' action");
            
            // Wait for teleport to complete
            if (Sleep.sleepUntil(() -> FEROX_ENCLAVE.contains(Players.getLocal()), 8000)) {
                Logger.log("Successfully teleported to Ferox Enclave (direct action)");
                return true;
            } else {
                Logger.log("Direct teleport action failed - trying rub method");
            }
        }
        
        // If direct action failed or isn't available, try rubbing the ring
        if (ring.interact("Rub")) {
            Logger.log("Rubbing Ring of Dueling");
            
            // Wait for dialogue to appear
            if (Sleep.sleepUntil(Dialogues::inDialogue, 3000)) {
                // Find the Ferox Enclave option
                String[] options = Dialogues.getOptions();
                if (options != null) {
                    int feroxOptionIndex = -1;
                    for (int i = 0; i < options.length; i++) {
                        if (options[i] != null && options[i].contains("Ferox Enclave")) {
                            feroxOptionIndex = i;
                            break;
                        }
                    }
                    
                    if (feroxOptionIndex != -1) {
                        Logger.log("Selecting option " + feroxOptionIndex + " for Ferox Enclave");
                        if (Dialogues.chooseOption(feroxOptionIndex)) {
                            // Wait for teleport to complete
                            if (Sleep.sleepUntil(() -> FEROX_ENCLAVE.contains(Players.getLocal()), 8000)) {
                                Logger.log("Successfully teleported to Ferox Enclave");
                                return true;
                            } else {
                                Logger.log("Teleport initiated but didn't reach Ferox Enclave in time");
                                return false;
                            }
                        } else {
                            Logger.log("Failed to select Ferox Enclave option");
                            return false;
                        }
                    } else {
                        Logger.log("Ferox Enclave option not found in dialogue");
                        return false;
                    }
                } else {
                    Logger.log("No dialogue options found after rubbing Ring of Dueling");
                    return false;
                }
            } else {
                Logger.log("Teleport interface did not appear after rubbing Ring of Dueling");
                return false;
            }
        }
        
        Logger.log("Failed to activate Ring of Dueling teleport");
        return false;
    }
    
    /**
     * Finds a charged Ring of Dueling in equipment or inventory
     * @return The ring if found, null otherwise
     */
    private Item findDuelingRing() {
        // Check equipment first
        Item equippedRing = Equipment.getItemInSlot(EquipmentSlot.RING);
        if (equippedRing != null && equippedRing.getName().contains("Ring of dueling")) {
            // Check if it has charges
            Matcher matcher = CHARGE_PATTERN.matcher(equippedRing.getName());
            if (matcher.find()) {
                try {
                    int charges = Integer.parseInt(matcher.group(1));
                    if (charges > 0) return equippedRing;
                } catch (NumberFormatException e) {
                    // If we can't parse charges, assume it's valid
                    return equippedRing;
                }
            } else {
                // If no charge pattern, assume it's valid
                return equippedRing;
            }
        }
        
        // Check inventory
        return Inventory.get(item -> {
            if (item != null && item.getName().contains("Ring of dueling")) {
                // Check if it has charges
                Matcher matcher = CHARGE_PATTERN.matcher(item.getName());
                if (matcher.find()) {
                    try {
                        int charges = Integer.parseInt(matcher.group(1));
                        return charges > 0;
                    } catch (NumberFormatException e) {
                        // If we can't parse charges, assume it's valid
                        return true;
                    }
                } else {
                    // If no charge pattern, assume it's valid
                    return true;
                }
            }
            return false;
        });
    }

    public boolean isHandlingDeath() {
        return handlingDeath;
    }

    public void reset() {
        handlingDeath = false;
        needToBank = false;
        hasMoreItemsToCollect = false;
        currentState = DeathState.CHECK_DEATH;
    }
}