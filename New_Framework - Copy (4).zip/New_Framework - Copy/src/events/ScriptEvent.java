package events;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Base class for all script events
 */
public abstract class ScriptEvent {
    private final LocalDateTime timestamp;
    private final String source;
    private boolean handled;
    private final Map<String, Object> attributes;

    protected ScriptEvent(String source) {
        this.timestamp = LocalDateTime.now();
        this.source = source;
        this.handled = false;
        this.attributes = new HashMap<>();
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getSource() {
        return source;
    }

    public boolean isHandled() {
        return handled;
    }

    public void setHandled(boolean handled) {
        this.handled = handled;
    }

    public void addAttribute(String key, Object value) {
        attributes.put(key, value);
    }

    public Object getAttribute(String key) {
        return attributes.get(key);
    }

    /**
     * Gets the type of this event
     */
    public abstract EventType getType();

    @Override
    public String toString() {
        return String.format("Event[type=%s, source=%s, time=%s]",
            getType(), source, timestamp);
    }

    public abstract boolean hasAttribute(String key);

    public abstract Map<String, Object> getAttributes();
}

