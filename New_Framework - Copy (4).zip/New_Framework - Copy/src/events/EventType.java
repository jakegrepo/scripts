package events;

/**
 * Defines all possible event types in the framework
 */
public enum EventType {
    // Script lifecycle events
    SCRIPT_STARTED,
    SCRIPT_STOPPED,
    SCRIPT_PAUSED,
    SCRIPT_RESUMED,
    
    // Node events
    NODE_STARTED,
    NODE_COMPLETED,
    NODE_FAILED,
    
    // Inventory events
    INVENTORY_FULL,
    INVENTORY_EMPTY,
    ITEM_GAINED,
    ITEM_LOST,
    
    // Player events
    LEVEL_GAINED,
    EXPERIENCE_GAINED,
    PLAYER_IDLE,
    PLAYER_MOVING,
    PLAYER_ANIMATION,
    
    // Combat events
    COMBAT_STARTED,
    COMBAT_ENDED,
    HEALTH_LOW,
    
    // Game events
    GAME_TICK,
    GAME_MESSAGE,
    GAME_STATE_CHANGED,
    
    // World events
    OBJECT_SPAWN,
    NPC_SPAWN,
    NPC_ANIMATION,
    GROUND_ITEM_SPAWN,
    PROJECTILE_CREATED,
    
    // Chat events
    PLAYER_MESSAGE,
    PRIVATE_MESSAGE,
    
    // Custom events
    CUSTOM, GRAPHICS_OBJECT_SPAWNED;
    
    public boolean isScriptEvent() {
        return this == SCRIPT_STARTED || this == SCRIPT_STOPPED || 
               this == SCRIPT_PAUSED || this == SCRIPT_RESUMED;
    }
    
    public boolean isNodeEvent() {
        return this == NODE_STARTED || this == NODE_COMPLETED || 
               this == NODE_FAILED;
    }
    
    public boolean isInventoryEvent() {
        return this == INVENTORY_FULL || this == INVENTORY_EMPTY || 
               this == ITEM_GAINED || this == ITEM_LOST;
    }
    
    public boolean isPlayerEvent() {
        return this == LEVEL_GAINED || this == EXPERIENCE_GAINED || 
               this == PLAYER_IDLE || this == PLAYER_MOVING || 
               this == PLAYER_ANIMATION;
    }
    
    public boolean isCombatEvent() {
        return this == COMBAT_STARTED || this == COMBAT_ENDED || 
               this == HEALTH_LOW;
    }
}
