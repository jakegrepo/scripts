package events;

import java.util.HashMap;
import java.util.Map;

/**
 * Factory class for creating ScriptEvents with proper attributes
 */
public class EventFactory {
    
    /**
     * Creates a basic ScriptEvent with the given type and source
     */
    public static ScriptEvent createEvent(EventType type, String source) {
        return new BasicScriptEvent(type, source);
    }
    
    /**
     * Creates an inventory-related event with item details
     */
    public static ScriptEvent createInventoryEvent(EventType type, String source, int itemId, int quantity, String itemName) {
        ScriptEvent event = createEvent(type, source);
        event.addAttribute("itemId", itemId);
        event.addAttribute("quantity", quantity);
        event.addAttribute("name", itemName);
        return event;
    }
    
    /**
     * Creates a player-related event
     */
    public static ScriptEvent createPlayerEvent(EventType type, String source, String playerName) {
        ScriptEvent event = createEvent(type, source);
        event.addAttribute("playerName", playerName);
        return event;
    }
    
    /**
     * Creates a combat-related event
     */
    public static ScriptEvent createCombatEvent(EventType type, String source, String target, int targetHealth) {
        ScriptEvent event = createEvent(type, source);
        event.addAttribute("target", target);
        event.addAttribute("targetHealth", targetHealth);
        return event;
    }
    
    /**
     * Basic implementation of ScriptEvent
     */
    private static class BasicScriptEvent extends ScriptEvent {
        private final EventType type;
        private final Map<String, Object> attributes;
        
        private BasicScriptEvent(EventType type, String source) {
            super(source);
            this.type = type;
            this.attributes = new HashMap<>();
        }
        
        @Override
        public EventType getType() {
            return type;
        }
        
        @Override
        public void addAttribute(String key, Object value) {
            attributes.put(key, value);
        }
        
        @Override
        public Object getAttribute(String key) {
            return attributes.get(key);
        }
        
        @Override
        public boolean hasAttribute(String key) {
            return attributes.containsKey(key);
        }
        
        @Override
        public Map<String, Object> getAttributes() {
            return new HashMap<>(attributes);
        }
    }
} 