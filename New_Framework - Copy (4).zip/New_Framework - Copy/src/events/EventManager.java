package events;

import core.context.ContextProvider;
import core.context.ScriptContext;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Manages script events and event listeners
 */
public class EventManager extends ContextProvider {
    private final Map<EventType, List<EventListener>> listeners;
    private final Queue<ScriptEvent> eventQueue;
    private final int maxQueueSize;
    private boolean processingEvents;

    public EventManager(ScriptContext context) {
        super(context);
        this.listeners = new ConcurrentHashMap<>();
        this.eventQueue = new LinkedList<>();
        this.maxQueueSize = 1000;
        this.processingEvents = true;
    }

    /**
     * Add an event listener
     */
    public void addEventListener(EventType type, EventListener listener) {
        listeners.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>()).add(listener);
        debug("Added listener for " + type);
    }

    /**
     * Remove an event listener
     */
    public void removeEventListener(EventType type, EventListener listener) {
        if (listeners.containsKey(type)) {
            listeners.get(type).remove(listener);
            debug("Removed listener for " + type);
        }
    }

    /**
     * Fire an event
     */
    public void fireEvent(ScriptEvent event) {
        if (!processingEvents) return;

        try {
            debug("Firing event: " + event);
            
            // Add to queue
            synchronized (eventQueue) {
                eventQueue.offer(event);
                while (eventQueue.size() > maxQueueSize) {
                    eventQueue.poll();
                }
            }
            
            // Process event
            processEvent(event);
            
        } catch (Exception e) {
            error("Error firing event", e);
        }
    }

    /**
     * Process a single event
     */
    private void processEvent(ScriptEvent event) {
        List<EventListener> typeListeners = listeners.get(event.getType());
        if (typeListeners != null) {
            for (EventListener listener : typeListeners) {
                try {
                    if (!event.isHandled()) {
                        listener.onEvent(event);
                    }
                } catch (Exception e) {
                    error("Error in event listener", e);
                }
            }
        }
    }

    /**
     * Enable/disable event processing
     */
    public void setProcessingEvents(boolean enabled) {
        this.processingEvents = enabled;
        debug("Event processing " + (enabled ? "enabled" : "disabled"));
    }

    /**
     * Clear all listeners
     */
    public void clearListeners() {
        listeners.clear();
        debug("All event listeners cleared");
    }

    /**
     * Get recent events
     */
    public List<ScriptEvent> getRecentEvents() {
        synchronized (eventQueue) {
            return new ArrayList<>(eventQueue);
        }
    }
} 