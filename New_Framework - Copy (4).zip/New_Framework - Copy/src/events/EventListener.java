package events;

/**
 * Interface for event listeners
 */
@FunctionalInterface
public interface EventListener {
    void onEvent(ScriptEvent event);
} 