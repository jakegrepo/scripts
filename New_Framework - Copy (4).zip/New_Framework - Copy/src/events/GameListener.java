package events;

import org.dreambot.api.methods.skills.Skill;

/**
 * Base interface for all game event listeners
 */
public interface GameListener {
    void experienceGained(Skill skill, double gained, double total);

    void levelGained(Skill skill, int gained, int total);

    /**
     * Starts the listener
     */
    void start();
    
    /**
     * Stops the listener
     */
    void stop();
    
    /**
     * Checks if the listener is running
     */
    default boolean isRunning() {
        return false;
    }
} 