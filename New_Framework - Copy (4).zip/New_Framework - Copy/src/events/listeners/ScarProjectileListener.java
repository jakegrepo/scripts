package events.listeners;

import core.context.ScriptContext;
import events.EventFactory;
import events.EventType;
import events.ScriptEvent;
import org.dreambot.api.data.GameState;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.script.listener.ProjectileListener;
import org.dreambot.api.wrappers.graphics.Projectile;


/**
 * Listens for projectile events using DreamBot's API
 */
public class ScarProjectileListener extends AbstractGameListener implements ProjectileListener {

    public ScarProjectileListener(ScriptContext context) {
        super(context);
    }

    @Override
    public void onGameStateChanged(GameState oldState, GameState newState) {

    }

    @Override
    public void onTargeted(Projectile projectile, Tile target) {
        if (!isRunning) return;

        // Log the projectile directly for debugging
        context.getLogger().info(String.format(
            "[PROJECTILE DETECTED] ID: %d, Target: %s, Speed: %d, Height: %d, Z: %d",
            projectile.getID(),
            target.toString(),
            projectile.getStartCycle(),
            (int)projectile.getHeight(),
            (int)projectile.getZ()
        ));

        ScriptEvent scarEvent = EventFactory.createEvent(EventType.PROJECTILE_CREATED, "ProjectileListener");
        scarEvent.addAttribute("projectileId", projectile.getID());
        scarEvent.addAttribute("projectile", projectile);
        scarEvent.addAttribute("target", target);
        scarEvent.addAttribute("targetX", target.getX());
        scarEvent.addAttribute("targetY", target.getY());

        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onMoved(Projectile projectile, Tile from, Tile to) {
        if (!isRunning) return;

        // Log the projectile movement directly for debugging
        context.getLogger().info(String.format(
            "[PROJECTILE MOVED] ID: %d, From: %s, To: %s, Speed: %d, Height: %d, Z: %d",
            projectile.getID(),
            from.toString(),
            to.toString(),
            projectile.getStartCycle(),
            (int)projectile.getHeight(),
            (int)projectile.getZ()
        ));

        ScriptEvent scarEvent = EventFactory.createEvent(EventType.PROJECTILE_CREATED, "ProjectileListener");
        scarEvent.addAttribute("projectileId", projectile.getID());
        scarEvent.addAttribute("projectile", projectile);
        scarEvent.addAttribute("fromTile", from);
        scarEvent.addAttribute("toTile", to);
        scarEvent.addAttribute("fromX", from.getX());
        scarEvent.addAttribute("fromY", from.getY());
        scarEvent.addAttribute("toX", to.getX());
        scarEvent.addAttribute("toY", to.getY());

        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void start() {
        if (!isRunning) {
            isRunning = true;
            context.getScript().getScriptManager().addListener(this);
            debug("ProjectileListener started");
        }
    }

    @Override
    public void stop() {
        if (isRunning) {
            isRunning = false;
            context.getScript().getScriptManager().removeListener(this);
            debug("ProjectileListener stopped");
        }
    }
}