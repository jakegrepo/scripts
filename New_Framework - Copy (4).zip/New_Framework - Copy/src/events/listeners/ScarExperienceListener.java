package events.listeners;

import core.context.ContextProvider;
import core.context.ScriptContext;
import events.EventFactory;
import events.EventType;
import events.ScriptEvent;
import events.GameListener;
import org.dreambot.api.script.listener.ExperienceListener;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.skills.Skills;

/**
 * Listens for experience and level gain events using DreamBot's API
 */
public class ScarExperienceListener extends ContextProvider implements GameListener, ExperienceListener {
    private boolean isRunning;
    
    public ScarExperienceListener(ScriptContext context) {
        super(context);
    }
    
    @Override
    public void experienceGained(Skill skill, double gained, double total) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.EXPERIENCE_GAINED, "ExperienceListener");
        scarEvent.addAttribute("skill", skill.getName());
        scarEvent.addAttribute("gained", gained);
        scarEvent.addAttribute("total", total);
        scarEvent.addAttribute("level", Skills.getRealLevel(skill));
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void levelGained(Skill skill, int gained, int total) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.LEVEL_GAINED, "ExperienceListener");
        scarEvent.addAttribute("skill", skill.getName());
        scarEvent.addAttribute("levelsGained", gained);
        scarEvent.addAttribute("newLevel", total);
        scarEvent.addAttribute("virtualLevel", Skills.getBoostedLevel(skill));
        
        context.getEventManager().fireEvent(scarEvent);
        
        // Log level up message
        log(String.format("Congratulations! %s level up! New level: %d", 
            skill.getName(), total));
    }
    
    @Override
    public void start() {
        if (!isRunning) {
            isRunning = true;
            context.getScript().getScriptManager().addListener(this);
            debug("ExperienceListener started");
        }
    }
    
    @Override
    public void stop() {
        if (isRunning) {
            isRunning = false;
            context.getScript().getScriptManager().removeListener(this);
            debug("ExperienceListener stopped");
        }
    }
    
    @Override
    public boolean isRunning() {
        return isRunning;
    }
} 