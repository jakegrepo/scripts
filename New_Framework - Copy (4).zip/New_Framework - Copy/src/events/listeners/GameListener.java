package events.listeners;

import core.context.ContextProvider;

/**
 * Base interface for all game listeners
 */
public interface GameListener {
    void start();
    void stop();
} 