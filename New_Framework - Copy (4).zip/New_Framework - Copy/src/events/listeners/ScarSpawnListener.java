package events.listeners;

import core.context.ScriptContext;
import events.EventFactory;
import events.EventType;
import events.ScriptEvent;
import org.dreambot.api.data.GameState;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.script.listener.SpawnListener;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.items.GroundItem;
import org.dreambot.api.wrappers.interactive.GameObject;

/**
 * Listens for spawn events using DreamBot's API
 */
public class ScarSpawnListener extends AbstractGameListener implements SpawnListener {
    
    public ScarSpawnListener(ScriptContext context) {
        super(context);
    }

    @Override
    public void onGameStateChanged(GameState oldState, GameState newState) {

    }

    @Override
    public void onMoved(Projectile projectile, Tile from, Tile to) {

    }

    @Override
    public void onObjectSpawn(GameObject object) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.OBJECT_SPAWN, "SpawnListener");
        scarEvent.addAttribute("object", object);
        scarEvent.addAttribute("id", object.getID());
        scarEvent.addAttribute("location", object.getTile());
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void onNpcSpawn(NPC npc) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.NPC_SPAWN, "SpawnListener");
        scarEvent.addAttribute("npc", npc);
        scarEvent.addAttribute("id", npc.getID());
        scarEvent.addAttribute("location", npc.getTile());
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void onGroundItemSpawn(GroundItem item) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.GROUND_ITEM_SPAWN, "SpawnListener");
        scarEvent.addAttribute("item", item);
        scarEvent.addAttribute("id", item.getID());
        scarEvent.addAttribute("amount", item.getAmount());
        scarEvent.addAttribute("location", item.getTile());
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void start() {
        if (!isRunning) {
            isRunning = true;
            context.getScript().getScriptManager().addListener(this);
            debug("SpawnListener started");
        }
    }
    
    @Override
    public void stop() {
        if (isRunning) {
            isRunning = false;
            context.getScript().getScriptManager().removeListener(this);
            debug("SpawnListener stopped");
        }
    }
} 