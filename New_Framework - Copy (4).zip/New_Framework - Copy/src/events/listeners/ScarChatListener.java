package events.listeners;

import core.context.ScriptContext;
import events.EventFactory;
import events.EventType;
import events.ScriptEvent;
import org.dreambot.api.data.GameState;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.script.listener.ChatListener;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.widgets.message.Message;

/**
 * Listens for chat messages using DreamBot's API
 */
public class ScarChatListener extends AbstractGameListener implements ChatListener {
    
    public ScarChatListener(ScriptContext context) {
        super(context);
    }
    
    @Override
    public void onGameMessage(Message message) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.GAME_MESSAGE, "ChatListener");
        scarEvent.addAttribute("message", message.getMessage());
        scarEvent.addAttribute("type", "game");
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void onPlayerMessage(Message message) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.PLAYER_MESSAGE, "ChatListener");
        scarEvent.addAttribute("message", message.getMessage());
        scarEvent.addAttribute("sender", message.getUsername());
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void onPrivateInMessage(Message message) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.PRIVATE_MESSAGE, "ChatListener");
        scarEvent.addAttribute("message", message.getMessage());
        scarEvent.addAttribute("sender", message.getUsername());
        scarEvent.addAttribute("type", "received");
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onGameStateChanged(GameState oldState, GameState newState) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.GAME_STATE_CHANGED, "ChatListener");
        scarEvent.addAttribute("oldState", oldState);
        scarEvent.addAttribute("newState", newState);
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onMoved(Projectile projectile, Tile from, Tile to) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.PROJECTILE_CREATED, "ChatListener");
        scarEvent.addAttribute("projectile", projectile);
        scarEvent.addAttribute("from", from);
        scarEvent.addAttribute("to", to);
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onObjectSpawn(GameObject object) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.OBJECT_SPAWN, "ChatListener");
        scarEvent.addAttribute("object", object);
        scarEvent.addAttribute("id", object.getID());
        scarEvent.addAttribute("location", object.getTile());
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void start() {
        if (!isRunning) {
            isRunning = true;
            context.getScript().getScriptManager().addListener(this);
            debug("ChatListener started");
        }
    }
    
    @Override
    public void stop() {
        if (isRunning) {
            isRunning = false;
            context.getScript().getScriptManager().removeListener(this);
            debug("ChatListener stopped");
        }
    }
} 