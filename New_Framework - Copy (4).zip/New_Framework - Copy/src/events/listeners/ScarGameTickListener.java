package events.listeners;

import core.context.ScriptContext;
import events.EventFactory;
import events.EventType;
import events.ScriptEvent;
import org.dreambot.api.data.GameState;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.GameObject;

/**
 * Listens for game tick events using DreamBot's API
 */
public class ScarGameTickListener extends AbstractGameListener implements GameTickListener {
    private long lastTick;
    
    public ScarGameTickListener(ScriptContext context) {
        super(context);
        this.lastTick = System.currentTimeMillis();
    }
    
    @Override
    public void onServerTick() {
        if (!isRunning) return;
        
        long currentTime = System.currentTimeMillis();
        long tickDelta = currentTime - lastTick;
        lastTick = currentTime;
        
        // Create our framework event
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.GAME_TICK, "GameTickListener");
        scarEvent.addAttribute("tickDelta", tickDelta);
        
        // Fire event through our system
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onGameStateChanged(GameState oldState, GameState newState) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.GAME_STATE_CHANGED, "GameTickListener");
        scarEvent.addAttribute("oldState", oldState);
        scarEvent.addAttribute("newState", newState);
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onMoved(Projectile projectile, Tile from, Tile to) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.PROJECTILE_CREATED, "GameTickListener");
        scarEvent.addAttribute("projectile", projectile);
        scarEvent.addAttribute("from", from);
        scarEvent.addAttribute("to", to);
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onObjectSpawn(GameObject object) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.OBJECT_SPAWN, "GameTickListener");
        scarEvent.addAttribute("object", object);
        scarEvent.addAttribute("id", object.getID());
        scarEvent.addAttribute("location", object.getTile());
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void start() {
        if (!isRunning) {
            isRunning = true;
            context.getScript().getScriptManager().addListener(this);
            debug("GameTickListener started");
        }
    }
    
    @Override
    public void stop() {
        if (isRunning) {
            isRunning = false;
            context.getScript().getScriptManager().removeListener(this);
            debug("GameTickListener stopped");
        }
    }
} 