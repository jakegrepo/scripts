package events.listeners;

import core.context.ContextProvider;
import core.context.ScriptContext;
import events.GameListener;
import org.dreambot.api.data.GameState;
import org.dreambot.api.methods.skills.Skill;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;

/**
 * Abstract base class for game listeners that provides default implementations
 */
public abstract class AbstractGameListener extends ContextProvider implements GameListener {
    protected boolean isRunning;
    
    protected AbstractGameListener(ScriptContext context) {
        super(context);
        this.isRunning = false;
    }
    
    @Override
    public boolean isRunning() {
        return isRunning;
    }

    @Override
    public void experienceGained(Skill skill, double gained, double total) {
        // Default empty implementation
    }

    @Override
    public void levelGained(Skill skill, int gained, int total) {
        // Default empty implementation
    }

    public abstract void onGameStateChanged(GameState oldState, GameState newState);

    public void onMoved(Projectile projectile, Tile from, Tile to) {
        // Default empty implementation
    }

    public void onObjectSpawn(GameObject object) {
        // Default empty implementation
    }
    
    public abstract void start();
    
    public abstract void stop();

    public void onContainerItemAdded(Item item, int containerId) {
        // Default empty implementation
    }

    public void onContainerItemRemoved(Item item, int containerId) {
        // Default empty implementation
    }
}