package events.listeners;

import core.context.ScriptContext;
import events.EventFactory;
import events.EventType;
import events.ScriptEvent;
import org.dreambot.api.data.GameState;
import org.dreambot.api.methods.interactive.GraphicsObjects;
import org.dreambot.api.script.listener.GameTickListener;
import org.dreambot.api.wrappers.graphics.GraphicsObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Listens for graphic object events by polling on game ticks
 */
public class ScarGraphicObjectListener extends AbstractGameListener implements GameTickListener {

    private List<Integer> lastGraphicsObjectIds = new ArrayList<>();

    public ScarGraphicObjectListener(ScriptContext context) {
        super(context);
    }

    @Override
    public void onGameStateChanged(GameState oldState, GameState newState) {
        // Not needed for this listener
    }

    @Override
    public void onGameTick() {
        if (!isRunning) return;

        try {
            // Get current graphics objects
            List<GraphicsObject> currentGraphicsObjects = GraphicsObjects.all();

            // Log all graphics objects every tick for debugging
            if (!currentGraphicsObjects.isEmpty()) {
                context.getLogger().info("[DEBUG] Found " + currentGraphicsObjects.size() + " graphics objects");
                for (GraphicsObject obj : currentGraphicsObjects) {
                    context.getLogger().info(String.format(
                        "[GRAPHICS OBJECT] ID: %d, Tile: %s, Height: %d",
                        obj.getID(),
                        obj.getTile().toString(),
                        obj.getHeight()
                    ));
                }
            }

            List<Integer> currentIds = new ArrayList<>();

            // Check for new graphics objects
            for (GraphicsObject graphicsObject : currentGraphicsObjects) {
                int id = graphicsObject.getID();
                currentIds.add(id);

                // If this is a new graphics object, fire an event
                if (!lastGraphicsObjectIds.contains(id)) {
                    ScriptEvent scarEvent = EventFactory.createEvent(EventType.GRAPHICS_OBJECT_SPAWNED, "GraphicsObjectListener");
                    scarEvent.addAttribute("graphicsObjectId", id);
                    scarEvent.addAttribute("graphicsObject", graphicsObject);
                    scarEvent.addAttribute("tile", graphicsObject.getTile());
                    scarEvent.addAttribute("tileX", graphicsObject.getTile().getX());
                    scarEvent.addAttribute("tileY", graphicsObject.getTile().getY());

                    context.getEventManager().fireEvent(scarEvent);
                    context.getLogger().info(String.format(
                        "[GRAPHICS OBJECT DETECTED] ID: %d, Tile: %s, Height: %d",
                        id,
                        graphicsObject.getTile().toString(),
                        graphicsObject.getHeight()
                    ));
                }
            }

            // Update last graphics object IDs
            lastGraphicsObjectIds = currentIds;
        } catch (Exception e) {
            context.getLogger().error("Error in GraphicsObjectListener: " + e.getMessage());
        }
    }

    @Override
    public void start() {
        if (!isRunning) {
            isRunning = true;
            context.getScript().getScriptManager().addListener(this);
            debug("GraphicsObjectListener started");
        }
    }

    @Override
    public void stop() {
        if (isRunning) {
            isRunning = false;
            context.getScript().getScriptManager().removeListener(this);
            debug("GraphicsObjectListener stopped");
            lastGraphicsObjectIds.clear();
        }
    }
}
