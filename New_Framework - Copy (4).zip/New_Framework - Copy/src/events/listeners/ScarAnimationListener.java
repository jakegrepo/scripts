package events.listeners;

import core.context.ScriptContext;
import events.EventFactory;
import events.EventType;
import events.ScriptEvent;
import org.dreambot.api.data.GameState;
import org.dreambot.api.methods.interactive.Players;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.script.listener.AnimationListener;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.interactive.NPC;
import org.dreambot.api.wrappers.interactive.Player;

/**
 * Listens for animation events using DreamBot's API
 */
public class ScarAnimationListener extends AbstractGameListener implements AnimationListener {
    
    public ScarAnimationListener(ScriptContext context) {
        super(context);
    }
    
    protected Player getLocalPlayer() {
        return Players.getLocal();
    }
    
    @Override
    public void onPlayerAnimation(Player player, int animation, int delay) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.PLAYER_ANIMATION, "AnimationListener");
        scarEvent.addAttribute("player", player);
        scarEvent.addAttribute("animation", animation);
        scarEvent.addAttribute("delay", delay);
        scarEvent.addAttribute("isLocal", player.equals(getLocalPlayer()));
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void onNpcAnimation(NPC npc, int animation, int delay) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.NPC_ANIMATION, "AnimationListener");
        scarEvent.addAttribute("npc", npc);
        scarEvent.addAttribute("animation", animation);
        scarEvent.addAttribute("delay", delay);
        scarEvent.addAttribute("id", npc.getID());
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onGameStateChanged(GameState oldState, GameState newState) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.GAME_STATE_CHANGED, "AnimationListener");
        scarEvent.addAttribute("oldState", oldState);
        scarEvent.addAttribute("newState", newState);
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onMoved(Projectile projectile, Tile from, Tile to) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.PROJECTILE_CREATED, "AnimationListener");
        scarEvent.addAttribute("projectile", projectile);
        scarEvent.addAttribute("from", from);
        scarEvent.addAttribute("to", to);
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onObjectSpawn(GameObject object) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.OBJECT_SPAWN, "AnimationListener");
        scarEvent.addAttribute("object", object);
        scarEvent.addAttribute("id", object.getID());
        scarEvent.addAttribute("location", object.getTile());
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void start() {
        if (!isRunning) {
            isRunning = true;
            context.getScript().getScriptManager().addListener(this);
            debug("AnimationListener started");
        }
    }
    
    @Override
    public void stop() {
        if (isRunning) {
            isRunning = false;
            context.getScript().getScriptManager().removeListener(this);
            debug("AnimationListener stopped");
        }
    }
} 