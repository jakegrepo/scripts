package events.listeners;

import core.context.ScriptContext;
import events.EventFactory;
import events.EventType;
import events.ScriptEvent;
import org.dreambot.api.data.GameState;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.script.listener.LoginListener;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.GameObject;

/**
 * Listens for login events using DreamBot's API
 */
public class ScarLoginListener extends AbstractGameListener implements LoginListener {
    
    public ScarLoginListener(ScriptContext context) {
        super(context);
    }
    
    @Override
    public void onGameStateChanged(GameState oldState, GameState newState) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.GAME_STATE_CHANGED, "LoginListener");
        scarEvent.addAttribute("oldState", oldState);
        scarEvent.addAttribute("newState", newState);
        
        if (newState == GameState.LOGGED_IN) {
            scarEvent.addAttribute("event", "login");
        } else if (oldState == GameState.LOGGED_IN) {
            scarEvent.addAttribute("event", "logout");
        }
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void onLoginResponseChange(String response, String username, String password) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.GAME_MESSAGE, "LoginListener");
        scarEvent.addAttribute("message", response);
        scarEvent.addAttribute("username", username);
        scarEvent.addAttribute("type", "login");
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onLoginResponse(int i) {
        // Implementation not needed for this listener
    }

    @Override
    public void onLoginStageChange(int stage) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.GAME_STATE_CHANGED, "LoginListener");
        scarEvent.addAttribute("loginStage", stage);
        scarEvent.addAttribute("event", "loginStage");
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void onLoadingStateChange(int state) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.GAME_STATE_CHANGED, "LoginListener");
        scarEvent.addAttribute("loadingState", state);
        scarEvent.addAttribute("event", "loadingState");
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onMoved(Projectile projectile, Tile from, Tile to) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.PROJECTILE_CREATED, "LoginListener");
        scarEvent.addAttribute("projectile", projectile);
        scarEvent.addAttribute("from", from);
        scarEvent.addAttribute("to", to);
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onObjectSpawn(GameObject object) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.OBJECT_SPAWN, "LoginListener");
        scarEvent.addAttribute("object", object);
        scarEvent.addAttribute("id", object.getID());
        scarEvent.addAttribute("location", object.getTile());
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void start() {
        if (!isRunning) {
            isRunning = true;
            context.getScript().getScriptManager().addListener(this);
            debug("LoginListener started");
        }
    }
    
    @Override
    public void stop() {
        if (isRunning) {
            isRunning = false;
            context.getScript().getScriptManager().removeListener(this);
            debug("LoginListener stopped");
        }
    }
} 