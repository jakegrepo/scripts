package events.listeners;

import core.context.ScriptContext;
import events.EventFactory;
import events.EventType;
import events.ScriptEvent;
import org.dreambot.api.data.GameState;
import org.dreambot.api.methods.map.Tile;
import org.dreambot.api.script.listener.ItemContainerListener;
import org.dreambot.api.wrappers.graphics.Projectile;
import org.dreambot.api.wrappers.interactive.GameObject;
import org.dreambot.api.wrappers.items.Item;

/**
 * Listens for inventory events using DreamBot's API
 */
public class ScarInventoryListener extends AbstractGameListener implements ItemContainerListener {
    
    public ScarInventoryListener(ScriptContext context) {
        super(context);
    }
    
    @Override
    public void onInventoryItemAdded(Item item) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.ITEM_GAINED, "InventoryListener");
        scarEvent.addAttribute("item", item);
        scarEvent.addAttribute("itemId", item.getID());
        scarEvent.addAttribute("quantity", item.getAmount());
        scarEvent.addAttribute("name", item.getName());
        scarEvent.addAttribute("containerId", 93); // 93 is inventory container ID
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void onInventoryItemRemoved(Item item) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.ITEM_LOST, "InventoryListener");
        scarEvent.addAttribute("item", item);
        scarEvent.addAttribute("itemId", item.getID());
        scarEvent.addAttribute("quantity", item.getAmount());
        scarEvent.addAttribute("name", item.getName());
        scarEvent.addAttribute("containerId", 93);
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onGameStateChanged(GameState oldState, GameState newState) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.GAME_STATE_CHANGED, "InventoryListener");
        scarEvent.addAttribute("oldState", oldState);
        scarEvent.addAttribute("newState", newState);
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onMoved(Projectile projectile, Tile from, Tile to) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.PROJECTILE_CREATED, "InventoryListener");
        scarEvent.addAttribute("projectile", projectile);
        scarEvent.addAttribute("from", from);
        scarEvent.addAttribute("to", to);
        
        context.getEventManager().fireEvent(scarEvent);
    }

    @Override
    public void onObjectSpawn(GameObject object) {
        if (!isRunning) return;
        
        ScriptEvent scarEvent = EventFactory.createEvent(EventType.OBJECT_SPAWN, "InventoryListener");
        scarEvent.addAttribute("object", object);
        scarEvent.addAttribute("id", object.getID());
        scarEvent.addAttribute("location", object.getTile());
        
        context.getEventManager().fireEvent(scarEvent);
    }
    
    @Override
    public void start() {
        if (!isRunning) {
            isRunning = true;
            context.getScript().getScriptManager().addListener(this);
            debug("InventoryListener started");
        }
    }
    
    @Override
    public void stop() {
        if (isRunning) {
            isRunning = false;
            context.getScript().getScriptManager().removeListener(this);
            debug("InventoryListener stopped");
        }
    }
} 