package events;

import core.context.ContextProvider;
import core.context.ScriptContext;
import events.listeners.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Manages game listeners and provides easy access
 */
public class ListenerManager extends ContextProvider {
    private final Map<Class<? extends GameListener>, GameListener> listeners;

    /**
     * No-args constructor for Gson deserialization
     */
    public ListenerManager() {
        super();
        this.listeners = new HashMap<>();
    }

    public ListenerManager(ScriptContext context) {
        super(context);
        this.listeners = new HashMap<>();
        initializeListeners();
    }

    private void initializeListeners() {
        addListener(new ScarProjectileListener(context));
        addListener(new ScarGameTickListener(context));
        addListener(new ScarInventoryListener(context));
        addListener(new ScarChatListener(context));
        addListener(new ScarAnimationListener(context));
        addListener(new ScarSpawnListener(context));
        addListener(new ScarExperienceListener(context));
        addListener(new ScarLoginListener(context));
    }

    private void addListener(GameListener listener) {
        listeners.put(listener.getClass(), listener);
        debug("Registered listener: " + listener.getClass().getSimpleName());
    }

    public <T extends GameListener> T getListener(Class<T> listenerClass) {
        return (T) listeners.get(listenerClass);
    }

    public void startAll() {
        for (GameListener listener : listeners.values()) {
            try {
                listener.start();
            } catch (Exception e) {
                error("Error starting listener: " + listener.getClass().getSimpleName(), e);
            }
        }
        debug("All listeners started");
    }

    public void stopAll() {
        for (GameListener listener : listeners.values()) {
            try {
                listener.stop();
            } catch (Exception e) {
                error("Error stopping listener: " + listener.getClass().getSimpleName(), e);
            }
        }
        debug("All listeners stopped");
    }

    public void startListener(Class<? extends GameListener> listenerClass) {
        GameListener listener = listeners.get(listenerClass);
        if (listener == null) {
            error("Listener not found: " + listenerClass.getSimpleName(), new IllegalArgumentException());
            return;
        }

        try {
            listener.start();
            debug("Started listener: " + listenerClass.getSimpleName());
        } catch (Exception e) {
            error("Error starting listener: " + listenerClass.getSimpleName(), e);
        }
    }

    public void stopListener(Class<? extends GameListener> listenerClass) {
        GameListener listener = listeners.get(listenerClass);
        if (listener == null) {
            error("Listener not found: " + listenerClass.getSimpleName(), new IllegalArgumentException());
            return;
        }

        try {
            listener.stop();
            debug("Stopped listener: " + listenerClass.getSimpleName());
        } catch (Exception e) {
            error("Error stopping listener: " + listenerClass.getSimpleName(), e);
        }
    }
}