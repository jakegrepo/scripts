# Script Settings Generator for ScarFramework
# This script creates settings for a script with appropriate getters/setters and UI elements

# Clear the console
Clear-Host

Write-Host "===== ScarFramework Script Settings Generator =====" -ForegroundColor Cyan
Write-Host "This tool will create settings for your script with appropriate getters/setters and UI elements." -ForegroundColor Cyan
Write-Host ""

# Get script information
$scriptName = Read-Host "Script Name (e.g., Miner)"
$scriptNameNoSpaces = $scriptName -replace '\s+', ''
$scriptNameUpper = $scriptNameNoSpaces.Substring(0, 1).ToUpper() + $scriptNameNoSpaces.Substring(1)
$scriptNameLower = $scriptNameNoSpaces.ToLower()

# Validate input
if ([string]::IsNullOrWhiteSpace($scriptName)) {
    Write-Host "Script name cannot be empty. Exiting..." -ForegroundColor Red
    exit
}

# Check if script exists
$scriptDir = "src\scripts\$scriptNameUpper"
if (-not (Test-Path -Path $scriptDir)) {
    Write-Host "Script directory does not exist: $scriptDir" -ForegroundColor Red
    Write-Host "Please create the script first using CreateNewScript.ps1" -ForegroundColor Red
    exit
}

# Define field types
$fieldTypes = @(
    "String (Text Field)",
    "Integer (Number Field)",
    "Boolean (Checkbox)",
    "ComboBox (Dropdown)",
    "List<String> (List of Strings)",
    "Map<String, Integer> (Key-Value Pairs)"
)

# Initialize arrays to store settings
$script:settingNames = @()
$script:settingTypes = @()
$script:settingDescriptions = @()
$script:settingDefaultValues = @()
$script:settingOptions = @()

# Function to add a setting
function Add-Setting {
    Write-Host ""
    Write-Host "Adding a new setting:" -ForegroundColor Yellow
    
    # Get setting name
    $settingName = Read-Host "Setting Name (e.g., targetOre)"
    if ([string]::IsNullOrWhiteSpace($settingName)) {
        Write-Host "Setting name cannot be empty. Skipping..." -ForegroundColor Red
        return $false
    }
    
    # Format setting name to camelCase
    $settingName = $settingName.Substring(0, 1).ToLower() + $settingName.Substring(1)
    
    # Get setting description
    $settingDescription = Read-Host "Setting Description (e.g., The type of ore to mine)"
    
    # Display field type options
    Write-Host "Field Types:" -ForegroundColor Yellow
    for ($i = 0; $i -lt $fieldTypes.Count; $i++) {
        Write-Host "  $($i+1). $($fieldTypes[$i])"
    }
    
    # Get field type
    $typeIndex = Read-Host "Select Field Type (1-$($fieldTypes.Count))"
    if (-not ($typeIndex -match '^\d+$') -or [int]$typeIndex -lt 1 -or [int]$typeIndex -gt $fieldTypes.Count) {
        Write-Host "Invalid field type. Skipping..." -ForegroundColor Red
        return $false
    }
    
    $fieldType = $fieldTypes[[int]$typeIndex - 1]
    $settingType = ""
    $defaultValue = ""
    $options = ""
    
    # Handle different field types
    switch ($fieldType) {
        "String (Text Field)" {
            $settingType = "String"
            $defaultValue = Read-Host "Default Value (leave empty for none)"
            if ([string]::IsNullOrWhiteSpace($defaultValue)) {
                $defaultValue = '""'
            } else {
                $defaultValue = "`"$defaultValue`""
            }
        }
        "Integer (Number Field)" {
            $settingType = "int"
            $defaultValue = Read-Host "Default Value (leave empty for 0)"
            if ([string]::IsNullOrWhiteSpace($defaultValue)) {
                $defaultValue = "0"
            }
        }
        "Boolean (Checkbox)" {
            $settingType = "boolean"
            $defaultValue = Read-Host "Default Value (true/false, leave empty for false)"
            if ([string]::IsNullOrWhiteSpace($defaultValue) -or $defaultValue -ne "true") {
                $defaultValue = "false"
            }
        }
        "ComboBox (Dropdown)" {
            $settingType = "String"
            $defaultValue = Read-Host "Default Value (leave empty for first option)"
            $options = Read-Host "Options (comma-separated, e.g., Copper,Tin,Iron)"
            if ([string]::IsNullOrWhiteSpace($options)) {
                Write-Host "Options cannot be empty for ComboBox. Skipping..." -ForegroundColor Red
                return $false
            }
            if ([string]::IsNullOrWhiteSpace($defaultValue)) {
                $defaultValue = "`"$($options.Split(',')[0].Trim())`""
            } else {
                $defaultValue = "`"$defaultValue`""
            }
        }
        "List<String> (List of Strings)" {
            $settingType = "List<String>"
            $options = Read-Host "Default Items (comma-separated, leave empty for empty list)"
            $defaultValue = "new ArrayList<>()"
        }
        "Map<String, Integer> (Key-Value Pairs)" {
            $settingType = "Map<String, Integer>"
            $options = Read-Host "Default Key-Value Pairs (key:value,key:value, leave empty for empty map)"
            $defaultValue = "new HashMap<>()"
            if (-not [string]::IsNullOrWhiteSpace($options)) {
                $defaultValue = @"
new HashMap<String, Integer>() {{
                $($options.Split(',') | ForEach-Object { $kv = $_.Split(':'); "put(`"$($kv[0].Trim())`", $($kv[1].Trim()))" } | Join-String -Separator '; ')
            }}
"@
            }
        }
    }
    
    # Add setting to arrays
    $script:settingNames += $settingName
    $script:settingTypes += $settingType
    $script:settingDescriptions += $settingDescription
    $script:settingDefaultValues += $defaultValue
    $script:settingOptions += $options
    
    Write-Host "Setting added: $settingName ($settingType)" -ForegroundColor Green
    return $true
}

# Main loop to add settings
$addMore = $true
$settingsAdded = 0
while ($addMore) {
    $result = Add-Setting
    if ($result) {
        $settingsAdded++
    }
    
    # Debug output
    Write-Host "Current settings count: $($script:settingNames.Count)" -ForegroundColor Yellow
    
    $response = Read-Host "Add another setting? (y/n)"
    $addMore = $response -eq "y"
}

# Debug output
Write-Host "Settings to be added: $($script:settingNames.Count)" -ForegroundColor Yellow

# If no settings were added, exit
if ($script:settingNames.Count -eq 0) {
    Write-Host "No settings were added. Exiting..." -ForegroundColor Red
    exit
}

Write-Host ""
Write-Host "Settings to be added:" -ForegroundColor Yellow
for ($i = 0; $i -lt $script:settingNames.Count; $i++) {
    Write-Host "  $($i+1). $($script:settingNames[$i]) ($($script:settingTypes[$i])): $($script:settingDescriptions[$i])"
}

$confirm = Read-Host "Proceed with adding these settings? (y/n)"
if ($confirm -ne "y") {
    Write-Host "Operation cancelled. Exiting..." -ForegroundColor Red
    exit
}

# Function to replace content in a file
function Replace-FileContent {
    param (
        [string]$filePath,
        [string]$oldText,
        [string]$newText
    )
    
    try {
        $content = Get-Content -Path $filePath -Raw
        $content = $content.Replace($oldText, $newText)
        
        # Use ASCII encoding to avoid BOM character
        [System.IO.File]::WriteAllText($filePath, $content, [System.Text.Encoding]::ASCII)
        
        # Add a small delay to ensure file is released
        Start-Sleep -Milliseconds 100
        return $true
    }
    catch {
        Write-Host "Error replacing content in $filePath" -ForegroundColor Red
        return $false
    }
}

# Update the config file
$configFile = "$scriptDir\config\${scriptNameUpper}Config.java"
if (-not (Test-Path -Path $configFile)) {
    Write-Host "Config file does not exist: $configFile" -ForegroundColor Red
    exit
}

# Generate field declarations
$fieldDeclarations = ""
for ($i = 0; $i -lt $script:settingNames.Count; $i++) {
    $fieldDeclarations += "    @Expose private $($script:settingTypes[$i]) $($script:settingNames[$i]) = $($script:settingDefaultValues[$i]);`n"
}

# Generate getters and setters
$gettersSetters = ""
for ($i = 0; $i -lt $script:settingNames.Count; $i++) {
    $name = $script:settingNames[$i]
    $type = $script:settingTypes[$i]
    $capitalizedName = $name.Substring(0, 1).ToUpper() + $name.Substring(1)
    
    # Getter
    if ($type -eq "boolean") {
        $gettersSetters += @"

    /**
     * Checks if $name is enabled
     * @return $name value
     */
    public boolean is$capitalizedName() {
        return $name;
    }
"@
    } else {
        $gettersSetters += @"

    /**
     * Gets the $name
     * @return $name value
     */
    public $type get$capitalizedName() {
        return $name;
    }
"@
    }
    
    # Setter
    $gettersSetters += @"

    /**
     * Sets the $name
     * @param $name New value
     */
    public void set$capitalizedName($type $name) {
        this.$name = $name;
        dirty = true;
    }
"@
}

# Read the config file content
$content = Get-Content -Path $configFile -Raw

# Add imports if needed
$importsToAdd = ""
if ($script:settingTypes -contains "List<String>") {
    $importsToAdd += "import java.util.ArrayList;`nimport java.util.Arrays;`nimport java.util.List;`n"
}
if ($script:settingTypes -contains "Map<String, Integer>") {
    $importsToAdd += "import java.util.HashMap;`nimport java.util.Map;`n"
}

# Add imports
if ($importsToAdd -ne "") {
    $importInsertPoint = $content.IndexOf("import")
    if ($importInsertPoint -ge 0) {
        $importEndPoint = $content.IndexOf(";`n", $importInsertPoint)
        $importEndPoint = $content.IndexOf("`n", $importEndPoint + 2)
        $content = $content.Insert($importEndPoint + 1, $importsToAdd)
    }
}

# Find the settings section
$settingsPoint = $content.IndexOf("    // Settings")
if ($settingsPoint -ge 0) {
    $settingsEndPoint = $content.IndexOf("`n`n", $settingsPoint)
    $content = $content.Insert($settingsEndPoint, "`n$fieldDeclarations")
}

# Add getters and setters
$constructorEndPoint = $content.IndexOf("    /**`n     * Default constructor with default values (for Gson deserialization)")
if ($constructorEndPoint -ge 0) {
    $content = $content.Insert($constructorEndPoint, "$gettersSetters`n")
}

# Write the updated content back to the file
[System.IO.File]::WriteAllText($configFile, $content, [System.Text.Encoding]::ASCII)
Write-Host "Updated config file with new settings" -ForegroundColor Green

# Now update the settings tab file
$settingsTabFile = "$scriptDir\gui\${scriptNameUpper}SettingsTab.java"
if (-not (Test-Path -Path $settingsTabFile)) {
    Write-Host "Settings tab file does not exist: $settingsTabFile" -ForegroundColor Red
    exit
}

# Generate UI components
$uiDeclarations = ""
$uiInitializations = ""
$uiSetValues = ""
$uiGetValues = ""

for ($i = 0; $i -lt $script:settingNames.Count; $i++) {
    $name = $script:settingNames[$i]
    $type = $script:settingTypes[$i]
    $description = $script:settingDescriptions[$i]
    $options = $script:settingOptions[$i]
    $capitalizedName = $name.Substring(0, 1).ToUpper() + $name.Substring(1)
    
    switch ($type) {
        "String" {
            if ($options -ne "") {
                # ComboBox
                $uiDeclarations += "    private JComboBox<String> $($name)ComboBox;`n"
                $uiInitializations += @"
        // $($description)
        JLabel $($name)Label = new JLabel("$($description):");
        $($name)ComboBox = new JComboBox<>(new String[] {"Option1", "Option2"});
        $($name)ComboBox.setSelectedItem(config.get$($capitalizedName)());
        panel.add($($name)Label);
        panel.add($($name)ComboBox);
        
"@
                $uiSetValues += "        $($name)ComboBox.setSelectedItem(config.get$($capitalizedName)());`n"
                $uiGetValues += "        config.set$($capitalizedName)((String) $($name)ComboBox.getSelectedItem());`n"
            } else {
                # Text field
                $uiDeclarations += "    private JTextField $($name)Field;`n"
                $uiInitializations += @"
        // $($description)
        JLabel $($name)Label = new JLabel("$($description):");
        $($name)Field = new JTextField(config.get$($capitalizedName)(), 20);
        panel.add($($name)Label);
        panel.add($($name)Field);
        
"@
                $uiSetValues += "        $($name)Field.setText(config.get$($capitalizedName)());`n"
                $uiGetValues += "        config.set$($capitalizedName)($($name)Field.getText());`n"
            }
        }
        "int" {
            $uiDeclarations += "    private JSpinner $($name)Spinner;`n"
            $uiInitializations += @"
        // $($description)
        JLabel $($name)Label = new JLabel("$($description):");
        $($name)Spinner = new JSpinner(new SpinnerNumberModel(config.get$($capitalizedName)(), 0, 10000, 1));
        panel.add($($name)Label);
        panel.add($($name)Spinner);
        
"@
            $uiSetValues += "        $($name)Spinner.setValue(config.get$($capitalizedName)());`n"
            $uiGetValues += "        config.set$($capitalizedName)((int) $($name)Spinner.getValue());`n"
        }
        "boolean" {
            $uiDeclarations += "    private JCheckBox $($name)CheckBox;`n"
            $uiInitializations += @"
        // $($description)
        $($name)CheckBox = new JCheckBox("$($description)", config.is$($capitalizedName)());
        panel.add($($name)CheckBox);
        panel.add(new JLabel("")); // Empty label for grid alignment
        
"@
            $uiSetValues += "        $($name)CheckBox.setSelected(config.is$($capitalizedName)());`n"
            $uiGetValues += "        config.set$($capitalizedName)($($name)CheckBox.isSelected());`n"
        }
        "List<String>" {
            $uiDeclarations += "    private JList<String> $($name)List;`n"
            $uiDeclarations += "    private DefaultListModel<String> $($name)Model;`n"
            $uiInitializations += @"
        // $($description)
        JLabel $($name)Label = new JLabel("$($description):");
        $($name)Model = new DefaultListModel<>();
        for (String item : config.get$($capitalizedName)()) {
            $($name)Model.addElement(item);
        }
        $($name)List = new JList<>($($name)Model);
        JScrollPane $($name)ScrollPane = new JScrollPane($($name)List);
        $($name)ScrollPane.setPreferredSize(new Dimension(200, 100));
        
        JPanel $($name)ButtonPanel = new JPanel();
        JButton $($name)AddButton = new JButton("Add");
        JButton $($name)RemoveButton = new JButton("Remove");
        $($name)ButtonPanel.add($($name)AddButton);
        $($name)ButtonPanel.add($($name)RemoveButton);
        
        $($name)AddButton.addActionListener(e -> {
            String newItem = JOptionPane.showInputDialog("Enter new item:");
            if (newItem != null && !newItem.trim().isEmpty()) {
                $($name)Model.addElement(newItem.trim());
            }
        });
        
        $($name)RemoveButton.addActionListener(e -> {
            int selectedIndex = $($name)List.getSelectedIndex();
            if (selectedIndex != -1) {
                $($name)Model.remove(selectedIndex);
            }
        });
        
        panel.add($($name)Label);
        panel.add($($name)ScrollPane);
        panel.add(new JLabel("")); // Empty label for grid alignment
        panel.add($($name)ButtonPanel);
        
"@
            $uiSetValues += @"
        $($name)Model.clear();
        for (String item : config.get$($capitalizedName)()) {
            $($name)Model.addElement(item);
        }
"@
            $uiGetValues += @"
        List<String> $($name)Items = new ArrayList<>();
        for (int i = 0; i < $($name)Model.getSize(); i++) {
            $($name)Items.add($($name)Model.getElementAt(i));
        }
        config.set$($capitalizedName)($($name)Items);
"@
        }
        "Map<String, Integer>" {
            $uiDeclarations += "    private JTable $($name)Table;`n"
            $uiDeclarations += "    private DefaultTableModel $($name)Model;`n"
            $uiInitializations += @"
        // $($description)
        JLabel $($name)Label = new JLabel("$($description):");
        $($name)Model = new DefaultTableModel(new Object[]{"Key", "Value"}, 0);
        for (Map.Entry<String, Integer> entry : config.get$($capitalizedName)().entrySet()) {
            $($name)Model.addRow(new Object[]{entry.getKey(), entry.getValue()});
        }
        $($name)Table = new JTable($($name)Model);
        JScrollPane $($name)ScrollPane = new JScrollPane($($name)Table);
        $($name)ScrollPane.setPreferredSize(new Dimension(200, 100));
        
        JPanel $($name)ButtonPanel = new JPanel();
        JButton $($name)AddButton = new JButton("Add");
        JButton $($name)RemoveButton = new JButton("Remove");
        $($name)ButtonPanel.add($($name)AddButton);
        $($name)ButtonPanel.add($($name)RemoveButton);
        
        $($name)AddButton.addActionListener(e -> {
            String key = JOptionPane.showInputDialog("Enter key:");
            if (key != null && !key.trim().isEmpty()) {
                String valueStr = JOptionPane.showInputDialog("Enter value:");
                try {
                    int value = Integer.parseInt(valueStr);
                    $($name)Model.addRow(new Object[]{key.trim(), value});
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Value must be an integer");
                }
            }
        });
        
        $($name)RemoveButton.addActionListener(e -> {
            int selectedRow = $($name)Table.getSelectedRow();
            if (selectedRow != -1) {
                $($name)Model.removeRow(selectedRow);
            }
        });
        
        panel.add($($name)Label);
        panel.add($($name)ScrollPane);
        panel.add(new JLabel("")); // Empty label for grid alignment
        panel.add($($name)ButtonPanel);
        
"@
            $uiSetValues += @"
        $($name)Model.setRowCount(0);
        for (Map.Entry<String, Integer> entry : config.get$($capitalizedName)().entrySet()) {
            $($name)Model.addRow(new Object[]{entry.getKey(), entry.getValue()});
        }
"@
            $uiGetValues += @"
        Map<String, Integer> $($name)Map = new HashMap<>();
        for (int i = 0; i < $($name)Model.getRowCount(); i++) {
            String key = (String) $($name)Model.getValueAt(i, 0);
            Integer value = (Integer) $($name)Model.getValueAt(i, 1);
            $($name)Map.put(key, value);
        }
        config.set$($capitalizedName)($($name)Map);
"@
        }
    }
}

# Read the settings tab file content
$tabContent = Get-Content -Path $settingsTabFile -Raw

# Add imports if needed
$tabImportsToAdd = ""
if ($script:settingTypes -contains "String" -and $script:settingOptions -contains "") {
    $tabImportsToAdd += "import javax.swing.JTextField;`n"
}
if ($script:settingTypes -contains "String" -and $script:settingOptions -ne "") {
    $tabImportsToAdd += "import javax.swing.JComboBox;`n"
}
if ($script:settingTypes -contains "int") {
    $tabImportsToAdd += "import javax.swing.JSpinner;`nimport javax.swing.SpinnerNumberModel;`n"
}
if ($script:settingTypes -contains "boolean") {
    $tabImportsToAdd += "import javax.swing.JCheckBox;`n"
}
if ($script:settingTypes -contains "List<String>") {
    $tabImportsToAdd += "import javax.swing.JList;`nimport javax.swing.JScrollPane;`nimport javax.swing.DefaultListModel;`nimport javax.swing.JOptionPane;`nimport java.awt.Dimension;`nimport java.util.ArrayList;`n"
}
if ($script:settingTypes -contains "Map<String, Integer>") {
    $tabImportsToAdd += "import javax.swing.JTable;`nimport javax.swing.JScrollPane;`nimport javax.swing.table.DefaultTableModel;`nimport javax.swing.JOptionPane;`nimport java.awt.Dimension;`nimport java.util.HashMap;`nimport java.util.Map;`n"
}

# Add imports
if ($tabImportsToAdd -ne "") {
    $tabImportInsertPoint = $tabContent.IndexOf("import")
    if ($tabImportInsertPoint -ge 0) {
        $tabImportEndPoint = $tabContent.IndexOf(";`n", $tabImportInsertPoint)
        $tabImportEndPoint = $tabContent.IndexOf("`n", $tabImportEndPoint + 2)
        $tabContent = $tabContent.Insert($tabImportEndPoint + 1, $tabImportsToAdd)
    }
}

# Find the MinerGeneralPanel class
$generalPanelClass = $tabContent.IndexOf("class ${scriptNameUpper}GeneralPanel extends JPanel")
if ($generalPanelClass -ge 0) {
    # Add UI declarations
    $generalPanelOpenBrace = $tabContent.IndexOf("{", $generalPanelClass)
    $tabContent = $tabContent.Insert($generalPanelOpenBrace + 1, "`n$uiDeclarations")
    
    # Add UI initializations
    $generalPanelConstructor = $tabContent.IndexOf("public ${scriptNameUpper}GeneralPanel(${scriptNameUpper}Config config)", $generalPanelClass)
    if ($generalPanelConstructor -ge 0) {
        $constructorOpenBrace = $tabContent.IndexOf("{", $generalPanelConstructor)
        $constructorCloseBrace = $tabContent.IndexOf("}", $constructorOpenBrace)
        $tabContent = $tabContent.Insert($constructorCloseBrace, $uiInitializations)
    }
    
    # Add UI set values
    $setValuesMethod = $tabContent.IndexOf("public void setValues()", $generalPanelClass)
    if ($setValuesMethod -ge 0) {
        $setValuesOpenBrace = $tabContent.IndexOf("{", $setValuesMethod)
        $setValuesCloseBrace = $tabContent.IndexOf("}", $setValuesOpenBrace)
        $tabContent = $tabContent.Insert($setValuesCloseBrace, $uiSetValues)
    }
    
    # Add UI get values
    $getValuesMethod = $tabContent.IndexOf("public void getValues()", $generalPanelClass)
    if ($getValuesMethod -ge 0) {
        $getValuesOpenBrace = $tabContent.IndexOf("{", $getValuesMethod)
        $getValuesCloseBrace = $tabContent.IndexOf("}", $getValuesOpenBrace)
        $tabContent = $tabContent.Insert($getValuesCloseBrace, $uiGetValues)
    }
}

# Write the updated content back to the file
[System.IO.File]::WriteAllText($settingsTabFile, $tabContent, [System.Text.Encoding]::ASCII)
Write-Host "Updated settings tab file with new UI components" -ForegroundColor Green

Write-Host ""
Write-Host "===== Script Settings Generation Complete =====" -ForegroundColor Green
Write-Host "Added $($script:settingNames.Count) settings to your script." -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "1. Build the project with 'mvn clean package'" -ForegroundColor Cyan
Write-Host "2. Test your script to make sure the settings work correctly" -ForegroundColor Cyan
Write-Host "3. Use the settings in your script logic" -ForegroundColor Cyan
Write-Host ""
Write-Host "Happy scripting!" -ForegroundColor Cyan
