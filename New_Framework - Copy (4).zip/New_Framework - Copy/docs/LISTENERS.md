# ScarFramework Listeners Guide

## Overview
Listeners provide an easy way to monitor game events. They automatically convert DreamBot events into our framework's event system.

## Available Listeners

### 1. Game Tick Listener
Monitors game ticks (600ms intervals)
```java
private final GameTickListener tickListener = getListener(GameTickListener.class);

private void gameTick(ScriptEvent event) {
    long tickDelta = (long) event.getAttribute("tickDelta");
    // Handle tick
}
```

### 2. Projectile Listener
Tracks projectiles in game
```java
private void projectileCreated(ScriptEvent event) {
    int projectileId = (int) event.getAttribute("projectileId");
    int sourceX = (int) event.getAttribute("sourceX");
    int sourceY = (int) event.getAttribute("sourceY");
}
```

### 3. Inventory Listener
Monitors inventory changes
```java
private void itemGained(ScriptEvent event) {
    int itemId = (int) event.getAttribute("itemId");
    int quantity = (int) event.getAttribute("quantity");
    String name = (String) event.getAttribute("name");
}
```

### 4. Chat Message Listener
Tracks various chat messages
```java
// Game messages
private void gameMessage(ScriptEvent event) {
    String message = (String) event.getAttribute("message");
}

// Player messages
private void playerMessage(ScriptEvent event) {
    String sender = (String) event.getAttribute("sender");
    String message = (String) event.getAttribute("message");
}
```

### 5. Animation Listener
Monitors player and NPC animations
```java
private void playerAnimation(ScriptEvent event) {
    Player player = (Player) event.getAttribute("player");
    int animation = (int) event.getAttribute("animation");
    boolean isLocal = (boolean) event.getAttribute("isLocal");
}

private void npcAnimation(ScriptEvent event) {
    NPC npc = (NPC) event.getAttribute("npc");
    int animation = (int) event.getAttribute("animation");
}
```

### 6. Spawn Listener
Detects entity spawns
```java
private void objectSpawn(ScriptEvent event) {
    GameObject object = (GameObject) event.getAttribute("object");
    int id = (int) event.getAttribute("id");
}

private void npcSpawn(ScriptEvent event) {
    NPC npc = (NPC) event.getAttribute("npc");
    Tile location = (Tile) event.getAttribute("location");
}
```

### 7. Experience Listener
Tracks experience and level gains
```java
private void experienceGained(ScriptEvent event) {
    String skill = (String) event.getAttribute("skill");
    double gained = (double) event.getAttribute("gained");
    double total = (double) event.getAttribute("total");
}

private void levelGained(ScriptEvent event) {
    String skill = (String) event.getAttribute("skill");
    int newLevel = (int) event.getAttribute("newLevel");
    int virtualLevel = (int) event.getAttribute("virtualLevel");
}
```

### 8. Login Listener
Monitors login state changes
```java
private void gameStateChanged(ScriptEvent event) {
    GameState oldState = (GameState) event.getAttribute("oldState");
    GameState newState = (GameState) event.getAttribute("newState");
    String eventType = (String) event.getAttribute("event"); // "login" or "logout"
}
```

## Using Listeners in Your Script

### Basic Setup
```java
public class MyNode extends SimpleNode<MyConfig> {
    private ExperienceListener expListener;
    private InventoryListener invListener;
    
    @Override
    public void onStart() {
        // Get listeners
        expListener = getListener(ExperienceListener.class);
        invListener = getListener(InventoryListener.class);
        
        // Start listeners
        expListener.start();
        invListener.start();
    }
    
    @Override
    public void onStop() {
        // Stop listeners
        expListener.stop();
        invListener.stop();
    }
}
```

### Event Handling
Events are automatically routed to methods matching their names:
```java
public class WoodcuttingNode extends SimpleNode<WoodcuttingConfig> {
    
    // Automatically called when inventory is full
    private void inventoryFull(ScriptEvent event) {
        setState(ScriptState.BANKING);
    }
    
    // Automatically called on level up
    private void levelGained(ScriptEvent event) {
        String skill = (String) event.getAttribute("skill");
        int level = (int) event.getAttribute("newLevel");
        
        if (skill.equals("Woodcutting") && level >= 45) {
            config.setTreeType("Maple");
        }
    }
}
```

## Best Practices

### DO:
✅ Start listeners in onStart() and stop them in onStop()
✅ Handle events efficiently - they run on the game thread
✅ Check event attributes before using them
✅ Use type casting safely
✅ Log important events

### DON'T:
❌ Leave listeners running when not needed
❌ Perform long operations in event handlers
❌ Ignore error handling
❌ Start the same listener multiple times

## Advanced Usage

### Combining Listeners
```java
public class CombatNode extends SimpleNode<CombatConfig> {
    private AnimationListener animListener;
    private ProjectileListener projListener;
    private ExperienceListener expListener;
    
    @Override
    public void onStart() {
        // Setup multiple listeners
        animListener = getListener(AnimationListener.class);
        projListener = getListener(ProjectileListener.class);
        expListener = getListener(ExperienceListener.class);
        
        // Start all
        listenerManager.startAll();
    }
    
    private void npcAnimation(ScriptEvent event) {
        NPC npc = (NPC) event.getAttribute("npc");
        int animation = (int) event.getAttribute("animation");
        
        if (animation == ATTACK_ANIMATION) {
            handleIncomingAttack(npc);
        }
    }
    
    private void experienceGained(ScriptEvent event) {
        String skill = (String) event.getAttribute("skill");
        if (skill.equals("Hitpoints")) {
            updateDamageTaken();
        }
    }
}
```

### Custom Event Chaining
```java
public class FishingNode extends SimpleNode<FishingConfig> {
    private void inventoryFull(ScriptEvent event) {
        // Chain events
        getEventManager().fireSimpleEvent(EventType.CUSTOM, "StartBanking");
        setState(ScriptState.BANKING);
    }
    
    private void levelGained(ScriptEvent event) {
        String skill = (String) event.getAttribute("skill");
        int level = (int) event.getAttribute("newLevel");
        
        if (skill.equals("Fishing")) {
            // Fire custom event for fishing method change
            ScriptEvent methodChange = EventFactory.createEvent(
                EventType.CUSTOM, 
                "FishingNode"
            );
            methodChange.addAttribute("newMethod", getBestMethod(level));
            getEventManager().fireEvent(methodChange);
        }
    }
}
```

Remember: Listeners are powerful tools that help you create more responsive and robust scripts. Use them wisely! 