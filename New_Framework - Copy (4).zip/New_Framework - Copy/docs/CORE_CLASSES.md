# ScarFramework Core Classes - Simple Guide

## What's This Framework About?
ScarFramework makes writing DreamBot scripts easier and cleaner. Instead of writing lots of repetitive code, you get simple, powerful tools to build your scripts.

## The Three Main Parts

### 1. ScriptContext (The Brain)
Think of this as the main control center. It keeps track of everything your script needs:
- Current state (running, paused, etc.)
- Configuration settings
- Logging system
- Node management
- And more!

### 2. ContextProvider (The Helper)
This makes accessing ScriptContext super easy. Instead of writing long lines of code, you get simple commands like:
```java
// Old way (complicated):
framework.getContext().logger().info("Cutting tree");
framework.getContext().setState(ScriptState.WOODCUTTING);

// New way (simple):
log("Cutting tree");
setState(ScriptState.WOODCUTTING);
```

### 3. ScarScript (Your Starting Point)
This is where you'll start building your script. It gives you everything you need right away:
- Easy setup
- GUI handling
- Node management
- Error handling

## Real Examples

### Creating a Simple Script
```java
public class MyWoodcutter extends ScarScript<WoodcutterConfig> {
    @Override
    protected void onScriptStart() {
        // These methods come from ContextProvider - nice and simple!
        log("Starting woodcutting script");
        
        // Add what your script should do
        addNode(new ChopTreesNode(config));
        addNode(new BankLogsNode(config));
        
        // Ready to go!
        setState(ScriptState.RUNNING);
    }
}
```

### Creating a Node (A Task Your Script Does)
```java
public class ChopTreesNode extends TaskNode {
    @Override
    public void execute() {
        // Easy logging
        log("Looking for trees...");
        
        // Simple inventory check
        if (getInventory().isFull()) {
            log("Inventory full, heading to bank");
            setState(ScriptState.BANKING);
        }
    }
}
```

## Why This Is Better

### 1. Less Writing, More Doing
- No more long, complicated lines of code
- Built-in tools for common tasks
- Focus on what your script does, not how it does it

### 2. Keeps Things Organized
- Everything has its place
- Easy to find what you need
- Simple to add new features

### 3. Handles the Hard Stuff
- Error handling built in
- GUI system ready to use
- State management taken care of

## Quick Tips

### DO:
✅ Use the simple helper methods (`log`, `setState`, etc.)
✅ Let the framework handle complex tasks
✅ Keep your code clean and focused

### DON'T:
❌ Bypass the framework's tools
❌ Write complicated access code
❌ Worry about the internal workings

## State System

### ScriptState (The States)
This enum defines all possible states your script can be in:
- STARTING
- INITIALIZING
- RUNNING
- PAUSED
- STOPPING
- STOPPED
- ERROR

```java
// Easy state checking
if (getState().isRunnable()) {
    log("Script can run!");
}
```

### StateManager (The Controller)
Handles all state changes and makes sure everything happens in order.

```java
// Simple state changes
setState(ScriptState.RUNNING);

// Easy state checking
if (stateManager.isRunnable()) {
    // Do script stuff
}
```

## Paint System

### PaintBuilder (The Designer)
Makes creating nice-looking paints super easy:

```java
paint = new PaintBuilder(getContext())
    .setTitle("My Cool Script")
    .addRuntime()
    .addState()
    .addRow("Trees Cut", () -> treeCount)
    .addPerHour("Trees", () -> treeCount)
    .build();
```

### ScriptPaint (The Artist)
Takes care of actually drawing your paint on screen:

```java
@Override
public void onPaint(Graphics2D g) {
    paint.render(g);
}
```

## Node System

### SimpleNode (The Template)
Makes creating nodes easy with built-in features:

```java
public class WoodcuttingNode extends SimpleNode<WoodcuttingConfig> {
    @Override
    protected int executeNode() {
        log("Chopping trees...");
        // Your node logic here
        return 600;
    }
}
```

### TaskNode (The Worker)
Base class for all script tasks with core functionality:
- Status tracking
- Error handling
- Execution timing
- Debug logging

### TaskNodeManager (The Supervisor)
Manages all your script's nodes:
- Handles node execution
- Tracks node statistics
- Manages priorities
- Error recovery

```java
// Adding nodes is simple
addNode(new WoodcuttingNode(config));
addNode(new BankingNode(config));
```

## Configuration System

### ScriptConfig (The Settings)
Handles all your script's settings:
- Automatic saving/loading
- JSON serialization
- Default values
- Easy access

```java
public class WoodcuttingConfig extends ScriptConfig {
    private String treeType = "Oak";
    
    @Override
    protected void setDefaults() {
        treeType = "Oak";
    }
}
```

## Quick Tips for All Systems

### DO:
✅ Use SimpleNode for new nodes
✅ Let PaintBuilder create your paints
✅ Use the state system for script flow
✅ Extend ScriptConfig for settings

### DON'T:
❌ Create custom paint systems
❌ Manage states manually
❌ Skip the node system
❌ Store settings outside configs

## Common Patterns

### 1. Setting Up a Script
```java
public class MyScript extends ScarScript<MyConfig> {
    @Override
    protected void onScriptStart() {
        // Setup paint
        paint = new PaintBuilder(getContext())
            .setTitle("My Script")
            .addRuntime()
            .build();
            
        // Add nodes
        addNode(new MyTaskNode(config));
        
        // Start script
        setState(ScriptState.RUNNING);
    }
}
```

### 2. Creating a Node
```java
public class MyTaskNode extends SimpleNode<MyConfig> {
    public MyTaskNode(MyConfig config) {
        super("MyTask", 1, config);
    }
    
    @Override
    protected int executeNode() {
        status("Doing my task...");
        // Your logic here
        return 600;
    }
}
```

### 3. Managing Configuration
```java
public class MyConfig extends ScriptConfig {
    private String option = "default";
    
    @Override
    protected void setDefaults() {
        option = "default";
    }
    
    @Override
    protected void copyConfigValues(ScriptConfig loaded) {
        if (loaded instanceof MyConfig) {
            this.option = ((MyConfig) loaded).option;
        }
    }
}
```

## GUI System

### Overview
The GUI system provides a professional, easy-to-use interface for script settings. It's designed to be:
- Easy to extend
- Consistent in style
- Config-aware
- User-friendly

### Main Components

#### 1. ScriptGUI (The Window)
The main window that holds all settings tabs and controls:
```java
public class MyScript extends ScarScript<MyConfig> {
    @Override
    protected void onScriptStart() {
        // GUI is automatically created
        gui.addTab(new MySettingsTab(getContext(), config));
        gui.show();
    }
}
```

Features:
- Multiple settings tabs
- Start/Stop/Pause controls
- Auto-saving settings
- Clean modern look

#### 2. AbstractSettingsTab (The Tab Template)
Base class for creating script-specific settings tabs:
```java
public class MySettingsTab extends AbstractSettingsTab {
    public MySettingsTab(ScriptContext context, MyConfig config) {
        super(context, "My Settings");
        
        // Easy section creation
        SettingsPanel mainSection = new SettingsPanel();
        addSection("Main Settings", mainSection);
    }
}
```

Features:
- Section management
- Automatic layout
- Settings persistence
- Consistent styling

#### 3. Config-Bound Components
Special components that automatically sync with your config:

##### ConfigTextField
```java
// Automatically binds to config
ConfigTextField locationField = new ConfigTextField(
    15,
    config::getLocation,    // Gets value from config
    config::setLocation     // Saves value to config
);
```

##### ConfigComboBox
```java
// Dropdown with automatic config binding
ConfigComboBox<String> treeSelect = new ConfigComboBox<>(
    new String[]{"Oak", "Willow", "Yew"},
    config::getTreeType,    // Gets selected type
    config::setTreeType     // Saves selection
);
```

### Creating a Settings Tab

1. **Create Your Tab Class**
```java
public class MyScriptTab extends AbstractSettingsTab {
    private ConfigTextField nameField;
    private ConfigComboBox<String> optionBox;
    
    public MyScriptTab(ScriptContext context, MyConfig config) {
        super(context, "My Script");
        initializeComponents();
        setupLayout();
    }
}
```

2. **Add Components**
```java
private void initializeComponents() {
    // Create a settings section
    SettingsPanel section = new SettingsPanel();
    
    // Add labeled components
    section.addComponent(
        createLabeledComponent("Name:", nameField),
        0, 0, 2, 1
    );
    
    // Add to main panel
    addSection("Main Settings", section);
}
```

3. **Handle Settings**
```java
@Override
public void saveSettings() {
    nameField.saveValue();
    optionBox.saveValue();
}

@Override
public void loadSettings() {
    nameField.loadValue();
    optionBox.loadValue();
}
```

### Best Practices

#### DO:
✅ Use config-bound components when possible
✅ Organize settings into logical sections
✅ Provide clear labels and tooltips
✅ Override save/load methods
✅ Use consistent spacing

#### DON'T:
❌ Create raw Swing components
❌ Skip the AbstractSettingsTab
❌ Forget to save settings
❌ Overcrowd your tabs

### Tips & Tricks

1. **Section Organization**
```java
// Create logical groupings
addSection("General Settings", generalPanel);
addSection("Advanced Options", advancedPanel);
```

2. **Component Layout**
```java
// Use the built-in layout helpers
panel.addComponent(component, x, y, width, height);
```

3. **Tooltips**
```java
// Add helpful tooltips
myComponent.setToolTipText("Explains what this does");
```

4. **Validation**
```java
// Add input validation
numberField.addActionListener(e -> {
    try {
        int value = Integer.parseInt(numberField.getText());
        if (value < 0) throw new Exception();
    } catch (Exception ex) {
        numberField.setText("0");
    }
});
```

### Common Patterns

1. **Settings Group**
```java
private JPanel createSettingsGroup(String title) {
    SettingsPanel panel = new SettingsPanel();
    panel.setBorder(BorderFactory.createTitledBorder(title));
    return panel;
}
```

2. **Quick Components**
```java
private ConfigTextField addTextField(String label, String defaultValue) {
    ConfigTextField field = new ConfigTextField(
        15,
        () -> config.getValue(label, defaultValue),
        value -> config.setValue(label, value)
    );
    addLabeledComponent(label, field);
    return field;
}
```

Remember: The GUI system is designed to make your script look professional and be easy to use. Take advantage of the built-in components and layouts!

## What's Next?
We're still building:
- GUI System
- Safety Features
- Utility Classes
- Profile Management

Remember: The framework is designed to make scripting easier - use its features to save time and write better scripts!

## Utils Package

### SafetyManager & Anti-Ban System

The SafetyManager provides comprehensive safety features and anti-ban measures that can be customized through the GUI.

#### Built-in Safety Features

1. **Break System**
```java
// Automatically handles breaks
safetyManager.setBreakTimes(5, 15);  // 5-15 minute breaks
safetyManager.setRunTimes(45, 90);   // 45-90 minute runtime
```

2. **Mouse Movement**
```java
// Configurable mouse behavior
safetyManager.setMouseMoveProbability(10);  // 10% chance every 30 seconds
safetyManager.setHumanMouseMovement(true);  // Natural movement patterns
```

3. **Click Patterns**
```java
// Randomize click locations
safetyManager.setRandomizeClicks(true);
```

#### Safety Settings GUI

The SafetySettingsTab is automatically included in every script's GUI:

1. **Break Settings**
   - Enable/disable breaks
   - Minimum/maximum break duration
   - Minimum/maximum runtime
   - Break scheduling

2. **Anti-Ban Settings**
   - Mouse movement frequency
   - Click pattern randomization
   - Human-like mouse movement

Example configuration:
```java
public class MyScript extends ScarScript<MyConfig> {
    @Override
    protected void onScriptStart() {
        // Safety settings are automatically loaded from GUI
        if (getSafetyManager().isBreaksEnabled()) {
            log("Breaks enabled: " + 
                getSafetyManager().getMinBreakMinutes() + "-" + 
                getSafetyManager().getMaxBreakMinutes() + " minutes");
        }
    }
}
```

### ScriptLogger

Advanced logging system with file output and debug capabilities.

#### Features

1. **Log Levels**
```java
logger.info("Normal operation");
logger.debug("Detailed information");
logger.error("Something went wrong", exception);
```

2. **File Logging**
- Automatic log file creation
- Timestamp prefixes
- Script name identification
- Stack traces for errors

3. **Debug Mode**
```java
logger.setDebugEnabled(true);  // Enable detailed logging
```

4. **Log Queue**
```java
// Access recent logs
for (LogEntry entry : logger.getRecentLogs()) {
    System.out.println(entry.getMessage());
}
```

### Best Practices

#### Safety & Anti-Ban

1. **Break Configuration**
```java
// DO: Use variable break times
safetyManager.setBreakTimes(
    random(5, 10),    // Min break
    random(15, 20)    // Max break
);

// DON'T: Use fixed times
safetyManager.setBreakTimes(10, 10);  // Too predictable
```

2. **Mouse Movement**
```java
// DO: Enable human-like movement
safetyManager.setHumanMouseMovement(true);

// DON'T: Use direct movements
mouse.moveDirectly(point);  // Too robotic
```

#### Logging

1. **Debug Information**
```java
// DO: Use appropriate log levels
logger.debug("Detailed state: " + state);
logger.info("Important event occurred");
logger.error("Critical issue", exception);

// DON'T: Use system.out
System.out.println("Debug info");  // Won't be saved to log file
```

2. **Error Handling**
```java
try {
    // Script operation
} catch (Exception e) {
    logger.error("Operation failed", e);  // Logs stack trace
    setState(ScriptState.ERROR);
}
```

### Integration Example

```java
public class MyScript extends ScarScript<MyConfig> {
    @Override
    protected void onScriptStart() {
        // Logger setup
        getLogger().setDebugEnabled(true);
        
        // Safety setup is handled by GUI
        getSafetyManager().check();  // Regular safety checks
        
        if (getSafetyManager().isOnBreak()) {
            getLogger().info("Taking a break");
        }
        
        // Normal script operation
    }
}
```

### Tips & Tricks

1. **Custom Safety Checks**
```java
// Add script-specific safety measures
if (getSafetyManager().isBreaksEnabled()) {
    addCustomBreakCondition(() -> 
        inventory.isFull() || 
        skills.getFatigue() > 90
    );
}
```

2. **Advanced Logging**
```java
// Create context-aware log messages
logger.debug(String.format(
    "State[%s] Node[%s] Progress[%d%%]",
    getState(),
    getCurrentNode(),
    getProgress()
));
```

Remember: Safety and logging are crucial for reliable scripts. Use these tools to make your scripts more robust and user-friendly!

## Event System

### Overview
The event system provides a simple, convention-based way to handle script events. No annotations or complex setup required - just name your methods correctly!

### Quick Start

```java
public class MyNode extends SimpleNode<MyConfig> {
    // Just name your method after the event type!
    private void inventoryFull(ScriptEvent event) {
        log("Inventory full, banking...");
        setState(ScriptState.BANKING);
    }
    
    private void levelGained(ScriptEvent event) {
        log("Level up! " + event.getAttribute("skill"));
    }
}
```

### Available Events

All events from `EventType` enum can be handled by creating methods with matching names (case-insensitive):

#### Script Events
- `scriptStarted(ScriptEvent event)`
- `scriptStopped(ScriptEvent event)`
- `scriptPaused(ScriptEvent event)`
- `scriptResumed(ScriptEvent event)`

#### Node Events
- `nodeStarted(ScriptEvent event)`
- `nodeCompleted(ScriptEvent event)`
- `nodeFailed(ScriptEvent event)`

#### Inventory Events
- `inventoryFull(ScriptEvent event)`
- `inventoryEmpty(ScriptEvent event)`
- `itemGained(ScriptEvent event)`
- `itemLost(ScriptEvent event)`

#### Player Events
- `levelGained(ScriptEvent event)`
- `playerIdle(ScriptEvent event)`
- `playerMoving(ScriptEvent event)`
- `playerAnimating(ScriptEvent event)`

#### Combat Events
- `combatStarted(ScriptEvent event)`
- `combatEnded(ScriptEvent event)`
- `healthLow(ScriptEvent event)`

### Event Attributes

Access event data using attributes:

```java
private void itemGained(ScriptEvent event) {
    int itemId = (int) event.getAttribute("itemId");
    int quantity = (int) event.getAttribute("quantity");
    log("Gained " + quantity + "x item: " + itemId);
}
```

### Firing Events

```java
// From any ContextProvider class:
ScriptEvent event = EventFactory.createEvent(EventType.INVENTORY_FULL, "MyNode");
getEventManager().fireEvent(event);

// Or use helper methods:
getEventManager().fireInventoryEvent(
    EventType.ITEM_GAINED,
    "MyNode",
    itemId,
    quantity
);
```

### Best Practices

#### DO:
✅ Use descriptive method names matching event types
✅ Keep event handlers focused and simple
✅ Check event attributes before using them
✅ Log important event handling actions

```java
private void healthLow(ScriptEvent event) {
    log("Health is low, eating food");
    if (inventory.contains("Shark")) {
        inventory.interact("Shark", "Eat");
    } else {
        setState(ScriptState.EMERGENCY_TELEPORT);
    }
}
```

#### DON'T:
❌ Create multiple handlers for the same event type
❌ Perform long-running operations in event handlers
❌ Ignore event attributes
❌ Skip logging important events

### Common Patterns

1. **State Changes**
```java
private void inventoryFull(ScriptEvent event) {
    setState(ScriptState.BANKING);
}
```

2. **Resource Management**
```java
private void itemGained(ScriptEvent event) {
    updateResourceCount(
        (int) event.getAttribute("itemId"),
        (int) event.getAttribute("quantity")
    );
}
```

3. **Progress Tracking**
```java
private void levelGained(ScriptEvent event) {
    String skill = (String) event.getAttribute("skill");
    int level = (int) event.getAttribute("newLevel");
    
    updateProgress(skill, level);
    checkMilestones();
}
```

4. **Safety Checks**
```java
private void healthLow(ScriptEvent event) {
    if (!handleHealing()) {
        setState(ScriptState.EMERGENCY_TELEPORT);
    }
}
```

### Advanced Usage

1. **Custom Events**
```java
// Create custom event
ScriptEvent customEvent = new ScriptEvent("MyNode") {
    @Override
    public EventType getType() {
        return EventType.CUSTOM;
    }
};
customEvent.addAttribute("customData", "value");

// Fire custom event
getEventManager().fireEvent(customEvent);
```

2. **Event Chaining**
```java
private void nodeCompleted(ScriptEvent event) {
    if (shouldProgressToNextArea()) {
        // Fire a custom event to trigger area progression
        getEventManager().fireSimpleEvent(
            EventType.CUSTOM,
            "AreaProgression"
        );
    }
}
```

Remember: The event system is designed to be simple and intuitive. Just name your methods after the events you want to handle, and the framework takes care of the rest!