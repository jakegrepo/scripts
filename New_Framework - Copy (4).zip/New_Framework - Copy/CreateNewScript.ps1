# Script Generator for ScarFramework
# This script creates a new script based on the Template

# Function to replace content in a file
function Replace-FileContent {
    param (
        [string]$filePath,
        [string]$oldText,
        [string]$newText
    )

    try {
        $content = Get-Content -Path $filePath -Raw
        $content = $content.Replace($oldText, $newText)

        # Use Set-Content with ASCII encoding to avoid BOM character
        [System.IO.File]::WriteAllText($filePath, $content, [System.Text.Encoding]::ASCII)

        # Add a small delay to ensure file is released
        Start-Sleep -Milliseconds 100
    }
    catch {
        Write-Host "Error replacing content in $filePath" -ForegroundColor Red
    }
}

# Function to replace file name and content
function Process-File {
    param (
        [string]$sourcePath,
        [string]$destPath,
        [string]$oldName,
        [string]$newName,
        [string]$oldPackage,
        [string]$newPackage,
        [hashtable]$replacements
    )

    try {
        # Create the destination directory if it doesn't exist
        $destDir = Split-Path -Path $destPath -Parent
        if (-not (Test-Path -Path $destDir)) {
            New-Item -Path $destDir -ItemType Directory | Out-Null
        }

        # Read the source file and write to destination with ASCII encoding to avoid BOM
        $content = Get-Content -Path $sourcePath -Raw
        [System.IO.File]::WriteAllText($destPath, $content, [System.Text.Encoding]::ASCII)

        # Add a small delay to ensure file is released
        Start-Sleep -Milliseconds 200

        # Replace content
        Replace-FileContent -filePath $destPath -oldText $oldPackage -newText $newPackage
        Replace-FileContent -filePath $destPath -oldText $oldName -newText $newName

        # Apply additional replacements
        foreach ($key in $replacements.Keys) {
            Replace-FileContent -filePath $destPath -oldText $key -newText $replacements[$key]
        }

        Write-Host "Created file: $destPath" -ForegroundColor Green
    }
    catch {
        Write-Host "Error processing file $destPath" -ForegroundColor Red
    }
}

# Clear the console
Clear-Host

Write-Host "===== ScarFramework Script Generator =====" -ForegroundColor Cyan
Write-Host "This tool will create a new script based on the Template." -ForegroundColor Cyan
Write-Host "Please provide the following information:" -ForegroundColor Cyan
Write-Host ""

# Get script information
$scriptName = Read-Host "Script Name (e.g., Woodcutter)"
$scriptDescription = Read-Host "Script Description"
$scriptCategory = Read-Host "Script Category (e.g., WOODCUTTING, MINING, COMBAT, etc.)"
$authorName = Read-Host "Author Name (default: Scarfade)"

if ([string]::IsNullOrWhiteSpace($authorName)) {
    $authorName = "Scarfade"
}

# Validate input
if ([string]::IsNullOrWhiteSpace($scriptName)) {
    Write-Host "Script name cannot be empty. Exiting..." -ForegroundColor Red
    exit
}

# Format script name
$scriptNameNoSpaces = $scriptName -replace '\s+', ''
$scriptNameLower = $scriptNameNoSpaces.ToLower()
$scriptNameUpper = $scriptNameNoSpaces.Substring(0, 1).ToUpper() + $scriptNameNoSpaces.Substring(1)

# Set paths
$baseDir = "src\scripts\$scriptNameUpper"
$templateDir = "src\scripts\Template"

# Create the main directory
if (-not (Test-Path -Path $baseDir)) {
    New-Item -Path $baseDir -ItemType Directory | Out-Null
    Write-Host "Created directory: $baseDir" -ForegroundColor Green
} else {
    Write-Host "Directory already exists: $baseDir" -ForegroundColor Yellow
    $overwrite = Read-Host "Do you want to overwrite existing files? (y/n)"
    if ($overwrite -ne "y") {
        Write-Host "Operation cancelled. Exiting..." -ForegroundColor Red
        exit
    }
}

# Create subdirectories
$directories = @(
    "$baseDir\config",
    "$baseDir\gui",
    "$baseDir\nodes",
    "$baseDir\utils"
)

foreach ($dir in $directories) {
    if (-not (Test-Path -Path $dir)) {
        New-Item -Path $dir -ItemType Directory | Out-Null
        Write-Host "Created directory: $dir" -ForegroundColor Green
    }
}

# Define replacements
$replacements = @{
    "Template Script" = "$scriptName"
    "Template script for creating new scripts" = "$scriptDescription"
    "Category.MISC" = "Category.$scriptCategory"
    "Scarfade" = "$authorName"
    "ExampleNode" = "${scriptNameUpper}Node"
    "Example Node" = "$scriptName Node"
    "Example node for the template script" = "$scriptName node for the script"
    "example node for the" = "$scriptNameLower node for the"
    "Executing example node" = "Executing $scriptNameLower node"
    "itemsProcessed" = "actionsCompleted"
    "Items Processed" = "Actions Completed"
    "incrementItemsProcessed" = "incrementActionsCompleted"
    "getItemsProcessed" = "getActionsCompleted"
    "Template Stats" = "$scriptName Stats"
    "isExampleBooleanSetting" = "is${scriptNameUpper}BooleanSetting"
    "getExampleIntSetting" = "get${scriptNameUpper}IntSetting"
    "getExampleListSetting" = "get${scriptNameUpper}ListSetting"
    "getExampleMapSetting" = "get${scriptNameUpper}MapSetting"
    "exampleBooleanSetting" = "${scriptNameLower}BooleanSetting"
    "exampleIntSetting" = "${scriptNameLower}IntSetting"
    "exampleStringSetting" = "${scriptNameLower}StringSetting"
    "exampleListSetting" = "${scriptNameLower}ListSetting"
    "exampleMapSetting" = "${scriptNameLower}MapSetting"
    "Example Boolean Setting" = "$scriptName Boolean Setting"
    "Example Int Setting" = "$scriptName Int Setting"
    "Example String Setting" = "$scriptName String Setting"
    "=== TEMPLATE SCRIPT INITIALIZATION ===" = "=== ${scriptNameUpper} SCRIPT INITIALIZATION ==="
}

# Process main script file
Process-File -sourcePath "$templateDir\TemplateScript.java" `
             -destPath "$baseDir\${scriptNameUpper}Script.java" `
             -oldName "Template" `
             -newName $scriptNameUpper `
             -oldPackage "package scripts.Template;" `
             -newPackage "package scripts.$scriptNameUpper;" `
             -replacements $replacements

# Process config file
Process-File -sourcePath "$templateDir\config\TemplateConfig.java" `
             -destPath "$baseDir\config\${scriptNameUpper}Config.java" `
             -oldName "Template" `
             -newName $scriptNameUpper `
             -oldPackage "package scripts.Template.config;" `
             -newPackage "package scripts.$scriptNameUpper.config;" `
             -replacements $replacements

# Process utils file
Process-File -sourcePath "$templateDir\utils\ConfigUtil.java" `
             -destPath "$baseDir\utils\ConfigUtil.java" `
             -oldName "Template" `
             -newName $scriptNameUpper `
             -oldPackage "package scripts.Template.utils;" `
             -newPackage "package scripts.$scriptNameUpper.utils;" `
             -replacements $replacements

# Process node file
Process-File -sourcePath "$templateDir\nodes\ExampleNode.java" `
             -destPath "$baseDir\nodes\${scriptNameUpper}Node.java" `
             -oldName "Example" `
             -newName $scriptNameUpper `
             -oldPackage "package scripts.Template.nodes;" `
             -newPackage "package scripts.$scriptNameUpper.nodes;" `
             -replacements $replacements

# Process overlay file
Process-File -sourcePath "$templateDir\gui\TemplateOverlay.java" `
             -destPath "$baseDir\gui\${scriptNameUpper}Overlay.java" `
             -oldName "Template" `
             -newName $scriptNameUpper `
             -oldPackage "package scripts.Template.gui;" `
             -newPackage "package scripts.$scriptNameUpper.gui;" `
             -replacements $replacements

# Process settings tab file
Process-File -sourcePath "$templateDir\gui\TemplateSettingsTab.java" `
             -destPath "$baseDir\gui\${scriptNameUpper}SettingsTab.java" `
             -oldName "Template" `
             -newName $scriptNameUpper `
             -oldPackage "package scripts.Template.gui;" `
             -newPackage "package scripts.$scriptNameUpper.gui;" `
             -replacements $replacements

# Update imports and other references in all files
try {
    # Add a small delay to ensure all files are released
    Start-Sleep -Seconds 1

    $files = Get-ChildItem -Path $baseDir -Recurse -Filter "*.java"
    foreach ($file in $files) {
        # Update imports
        Replace-FileContent -filePath $file.FullName -oldText "import scripts.Template." -newText "import scripts.$scriptNameUpper."

        # Update class references
        Replace-FileContent -filePath $file.FullName -oldText "TemplateScript" -newText "${scriptNameUpper}Script"
        Replace-FileContent -filePath $file.FullName -oldText "TemplateConfig" -newText "${scriptNameUpper}Config"

        # Update method references
        Replace-FileContent -filePath $file.FullName -oldText "Template script" -newText "$scriptName script"
        Replace-FileContent -filePath $file.FullName -oldText "Template SCRIPT" -newText "$scriptNameUpper SCRIPT"
        Replace-FileContent -filePath $file.FullName -oldText "TEMPLATE SCRIPT" -newText "$scriptNameUpper SCRIPT"
    }

    Write-Host "Updated references in all files" -ForegroundColor Green
}
catch {
    Write-Host "Error updating references" -ForegroundColor Red
}

Write-Host ""
Write-Host "===== Script Generation Complete =====" -ForegroundColor Green
Write-Host "Your new script has been created at: $baseDir" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "1. Build the project with 'mvn clean package'" -ForegroundColor Cyan
Write-Host "2. Start customizing your script logic in ${scriptNameUpper}Node.java" -ForegroundColor Cyan
Write-Host "3. Add more nodes as needed in the nodes directory" -ForegroundColor Cyan
Write-Host "4. Customize the configuration in ${scriptNameUpper}Config.java" -ForegroundColor Cyan
Write-Host "5. Customize the UI in ${scriptNameUpper}SettingsTab.java and ${scriptNameUpper}Overlay.java" -ForegroundColor Cyan
Write-Host ""
Write-Host "Happy scripting!" -ForegroundColor Cyan
