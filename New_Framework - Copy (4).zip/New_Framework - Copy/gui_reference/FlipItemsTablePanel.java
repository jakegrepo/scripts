package scripts.ScarFlip.gui;

import core.gui.components.LoadingIndicator;
import core.gui.components.ModernCardPanel;
import core.gui.style.StyleManager;
import org.dreambot.api.utilities.Logger;
import scripts.ScarFlip.config.FlipItem;
import scripts.ScarFlip.config.ScarFlipConfig;
import scripts.ScarFlip.enums.Status;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * A modern, card-based panel that displays flip items with rich visual indicators
 * Completely redesigned for enhanced user experience and visual appeal
 */
public class FlipItemsTablePanel extends JPanel {

    private final ScarFlipConfig config;
    private final JTable itemTable;
    private final SimpleFlipItemTableModel tableModel;

    // Controls
    private final JButton removeItemButton;
    private final JButton resetStatusButton;

    // Right-click menu
    private final JPopupMenu contextMenu;

    // Update indicator
    private LoadingIndicator updateIndicator;
    private Timer fadeTimer;

    public FlipItemsTablePanel(ScarFlipConfig config) {
        this.config = config;

        // Create panel layout with modern styling
        setLayout(new BorderLayout(StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setBackground(StyleManager.PANEL_BG);

        // Create table model and table (still used for data management)
        tableModel = new SimpleFlipItemTableModel(config);
        itemTable = new JTable(tableModel);
        itemTable.setVisible(false); // We'll use our custom view instead

        // Create header panel with title and search
        JPanel headerPanel = new JPanel(new BorderLayout(10, 0));
        headerPanel.setOpaque(false);

        // Create title with counter
        JLabel titleLabel = new JLabel("Flip Items");
        titleLabel.setFont(StyleManager.HEADER_FONT_SMALL);
        titleLabel.setForeground(StyleManager.FOREGROUND);

        // Create update indicator
        updateIndicator = new LoadingIndicator(16, StyleManager.ACCENT);
        updateIndicator.setVisible(false);

        // Create search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        searchPanel.setOpaque(false);

        JTextField searchField = new JTextField(15);
        StyleManager.styleTextField(searchField);
        searchField.putClientProperty("JTextField.placeholderText", "Search items...");

        JComboBox<String> filterCombo = new JComboBox<>(new String[] {
            "All Items", "Active Buys", "Active Sells", "Completed", "Ready to Buy", "Ready to Sell"
        });
        StyleManager.styleComboBox(filterCombo);

        searchPanel.add(searchField);
        searchPanel.add(filterCombo);

        // Add title and search to header
        JPanel titleSearchPanel = new JPanel(new BorderLayout(10, 0));
        titleSearchPanel.setOpaque(false);

        // Create title panel with indicator
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        titlePanel.setOpaque(false);
        titlePanel.add(titleLabel);
        titlePanel.add(updateIndicator);

        titleSearchPanel.add(titlePanel, BorderLayout.WEST);
        titleSearchPanel.add(searchPanel, BorderLayout.EAST);

        headerPanel.add(titleSearchPanel, BorderLayout.WEST);

        // Create Add Item panel
        JPanel addItemPanel = createAddItemSection();

        // Action buttons panel with modern styling
        JPanel actionPanel = new JPanel();
        actionPanel.setLayout(new BoxLayout(actionPanel, BoxLayout.X_AXIS));
        actionPanel.setOpaque(false);
        actionPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));

        // Add spacer to push buttons to the right
        actionPanel.add(Box.createHorizontalGlue());

        // Create modern buttons with icons
        resetStatusButton = new JButton("Reset Status");
        StyleManager.styleButton(resetStatusButton);
        resetStatusButton.setEnabled(false);

        removeItemButton = new JButton("Remove Selected");
        StyleManager.styleButton(removeItemButton);
        removeItemButton.setEnabled(false);

        // Add spacing between buttons
        actionPanel.add(resetStatusButton);
        actionPanel.add(Box.createHorizontalStrut(8));
        actionPanel.add(removeItemButton);

        // Add header to action panel
        headerPanel.add(actionPanel, BorderLayout.EAST);

        // Create context menu with modern styling
        contextMenu = new JPopupMenu();
        contextMenu.setBackground(StyleManager.CARD_BG);
        contextMenu.setBorder(BorderFactory.createLineBorder(StyleManager.BORDER_COLOR, 1));

        JMenuItem removeItem = new JMenuItem("Remove Item");
        removeItem.setForeground(StyleManager.FOREGROUND);
        removeItem.setBackground(StyleManager.CARD_BG);

        JMenuItem resetItem = new JMenuItem("Reset Item Status");
        resetItem.setForeground(StyleManager.FOREGROUND);
        resetItem.setBackground(StyleManager.CARD_BG);

        contextMenu.add(removeItem);
        contextMenu.add(resetItem);

        // Create custom card-based item view
        JPanel itemsPanel = createItemsPanel();
        JScrollPane scrollPane = new JScrollPane(itemsPanel);
        StyleManager.styleScrollPane(scrollPane);

        // Create a top panel to hold header and add item panel
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(headerPanel, BorderLayout.NORTH);
        topPanel.add(addItemPanel, BorderLayout.CENTER);

        // Add components to main panel
        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Initialize event handlers
        initializeEventHandlers(removeItem, resetItem);
    }

    /**
     * Returns the table model for external updates
     */
    public SimpleFlipItemTableModel getTableModel() {
        return tableModel;
    }

    /**
     * Creates a modern sidebar for the Flip Items panel
     */
    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(25, 25, 30)); // Darker than main background
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 15, 20, 15));

        // Add logo/title at the top
        JLabel sidebarTitle = new JLabel("Flip Manager");
        sidebarTitle.setFont(StyleManager.HEADER_FONT_SMALL);
        sidebarTitle.setForeground(StyleManager.ACCENT);
        sidebarTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add separator
        JSeparator separator = new JSeparator();
        separator.setForeground(new Color(45, 45, 50));
        separator.setBackground(new Color(45, 45, 50));
        separator.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        separator.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add Item section
        JPanel addItemPanel = createAddItemSection();
        addItemPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add filter section
        JPanel filterPanel = createFilterSection();
        filterPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add statistics section
        JPanel statsPanel = createStatsSection();
        statsPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add components to sidebar
        sidebar.add(sidebarTitle);
        sidebar.add(Box.createVerticalStrut(15));
        sidebar.add(separator);
        sidebar.add(Box.createVerticalStrut(20));
        sidebar.add(addItemPanel);
        sidebar.add(Box.createVerticalStrut(25));
        sidebar.add(filterPanel);
        sidebar.add(Box.createVerticalStrut(25));
        sidebar.add(statsPanel);
        sidebar.add(Box.createVerticalGlue());

        return sidebar;
    }

    /**
     * Creates the Add Item section for the sidebar
     */
    private JPanel createAddItemSection() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        // Section title
        JLabel title = new JLabel("Add New Item");
        title.setFont(StyleManager.REGULAR_FONT_BOLD);
        title.setForeground(StyleManager.FOREGROUND);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Item name field
        JTextField itemNameField = new JTextField();
        itemNameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        StyleManager.styleTextField(itemNameField);
        itemNameField.putClientProperty("JTextField.placeholderText", "Enter item name...");
        itemNameField.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add button
        JButton addItemButton = new JButton("Add Item");
        addItemButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        StyleManager.stylePrimaryButton(addItemButton);
        addItemButton.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Clear all button
        JButton clearAllButton = new JButton("Clear All Items");
        clearAllButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        StyleManager.styleButton(clearAllButton);
        clearAllButton.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add event handlers
        addItemButton.addActionListener(e -> {
            String itemName = itemNameField.getText().trim();
            if (!itemName.isEmpty()) {
                // Add the item to the table model
                config.addItem(itemName);
                tableModel.updateData();
                itemNameField.setText("");
                updateTable();
            }
        });

        clearAllButton.addActionListener(e -> {
            // Clear all items
            config.initializeDefaults(); // This clears and adds default items
            tableModel.updateData();
            updateTable();
        });

        // Add components
        panel.add(title);
        panel.add(Box.createVerticalStrut(10));
        panel.add(itemNameField);
        panel.add(Box.createVerticalStrut(8));
        panel.add(addItemButton);
        panel.add(Box.createVerticalStrut(8));
        panel.add(clearAllButton);

        return panel;
    }

    /**
     * Creates the filter section for the sidebar
     */
    private JPanel createFilterSection() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        // Section title
        JLabel title = new JLabel("Filter Items");
        title.setFont(StyleManager.REGULAR_FONT_BOLD);
        title.setForeground(StyleManager.FOREGROUND);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Create filter options
        JComboBox<String> filterCombo = new JComboBox<>(new String[] {
            "All Items", "Active Buys", "Active Sells", "Completed", "Ready to Buy", "Ready to Sell"
        });
        filterCombo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        StyleManager.styleComboBox(filterCombo);
        filterCombo.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Search field
        JTextField searchField = new JTextField();
        searchField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        StyleManager.styleTextField(searchField);
        searchField.putClientProperty("JTextField.placeholderText", "Search items...");
        searchField.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add filter event handler
        filterCombo.addActionListener(e -> {
            // Filter items based on selection
            updateTable();
        });

        // Add search event handler
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateTable();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateTable();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateTable();
            }
        });

        // Add components
        panel.add(title);
        panel.add(Box.createVerticalStrut(10));
        panel.add(filterCombo);
        panel.add(Box.createVerticalStrut(8));
        panel.add(searchField);

        return panel;
    }

    /**
     * Creates the statistics section for the sidebar
     */
    private JPanel createStatsSection() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        // Section title
        JLabel title = new JLabel("Statistics");
        title.setFont(StyleManager.REGULAR_FONT_BOLD);
        title.setForeground(StyleManager.FOREGROUND);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Create stat items
        JPanel totalItemsPanel = createStatItem("Total Items", "0", StyleManager.FOREGROUND);
        JPanel activeItemsPanel = createStatItem("Active Items", "0", StyleManager.WARNING);
        JPanel completedItemsPanel = createStatItem("Completed Today", "0", StyleManager.SUCCESS);
        JPanel profitPanel = createStatItem("Total Profit", "0 gp", StyleManager.SUCCESS);

        // Add components
        panel.add(title);
        panel.add(Box.createVerticalStrut(10));
        panel.add(totalItemsPanel);
        panel.add(Box.createVerticalStrut(8));
        panel.add(activeItemsPanel);
        panel.add(Box.createVerticalStrut(8));
        panel.add(completedItemsPanel);
        panel.add(Box.createVerticalStrut(8));
        panel.add(profitPanel);

        return panel;
    }

    /**
     * Creates a single stat item for the stats panel
     */
    private JPanel createStatItem(String label, String value, Color valueColor) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(StyleManager.SMALL_FONT);
        labelComponent.setForeground(StyleManager.FOREGROUND_SECONDARY);

        JLabel valueComponent = new JLabel(value);
        valueComponent.setFont(StyleManager.REGULAR_FONT_BOLD);
        valueComponent.setForeground(valueColor);

        panel.add(labelComponent, BorderLayout.WEST);
        panel.add(valueComponent, BorderLayout.EAST);

        return panel;
    }

    /**
     * Creates a modern list-based panel for displaying flip items
     */
    /**
     * Creates the main items panel with a modern design
     */
    private JPanel createItemsPanel() {
        // Create a panel with modern styling
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(StyleManager.PANEL_BG);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        // Get current items from the model
        int itemCount = tableModel.getRowCount();

        if (itemCount == 0) {
            // Show empty state
            JPanel emptyPanel = createEmptyStatePanel();
            mainPanel.add(emptyPanel, BorderLayout.CENTER);
            return mainPanel;
        }

        // Create a container for all items with proper spacing
        JPanel itemsContainer = new JPanel();
        itemsContainer.setLayout(new BoxLayout(itemsContainer, BoxLayout.Y_AXIS));
        itemsContainer.setBackground(StyleManager.PANEL_BG);
        itemsContainer.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Add category headers and group items
        JPanel activeItems = new JPanel();
        activeItems.setLayout(new BoxLayout(activeItems, BoxLayout.Y_AXIS));
        activeItems.setOpaque(false);
        activeItems.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel pendingItems = new JPanel();
        pendingItems.setLayout(new BoxLayout(pendingItems, BoxLayout.Y_AXIS));
        pendingItems.setOpaque(false);
        pendingItems.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel completedItems = new JPanel();
        completedItems.setLayout(new BoxLayout(completedItems, BoxLayout.Y_AXIS));
        completedItems.setOpaque(false);
        completedItems.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Count items in each category
        int activeCount = 0;
        int completedCount = 0;
        int pendingCount = 0;

        // Create a row for each item and add to appropriate category
        for (int i = 0; i < itemCount; i++) {
            JPanel itemRow = createModernItemCard(i);
            String status = tableModel.getValueAt(i, 2).toString();

            if (status.contains("BUYING") || status.contains("SELLING")) {
                activeItems.add(itemRow);
                activeCount++;
                // Add spacing between rows
                if (activeCount < itemCount) {
                    activeItems.add(Box.createVerticalStrut(15));
                }
            } else if (status.contains("COMPLETED")) {
                completedItems.add(itemRow);
                completedCount++;
                // Add spacing between rows
                if (completedCount < itemCount) {
                    completedItems.add(Box.createVerticalStrut(15));
                }
            } else {
                pendingItems.add(itemRow);
                pendingCount++;
                // Add spacing between rows
                if (pendingCount < itemCount) {
                    pendingItems.add(Box.createVerticalStrut(15));
                }
            }
        }

        // Add sections to the container
        if (activeCount > 0) {
            JPanel sectionPanel = createSectionPanel("Active Flips", activeCount, activeItems);
            itemsContainer.add(sectionPanel);
            itemsContainer.add(Box.createVerticalStrut(30));
        }

        if (pendingCount > 0) {
            JPanel sectionPanel = createSectionPanel("Pending Flips", pendingCount, pendingItems);
            itemsContainer.add(sectionPanel);
            itemsContainer.add(Box.createVerticalStrut(30));
        }

        if (completedCount > 0) {
            JPanel sectionPanel = createSectionPanel("Completed Flips", completedCount, completedItems);
            itemsContainer.add(sectionPanel);
        }

        // Add the container to a scroll pane
        mainPanel.add(itemsContainer, BorderLayout.CENTER);

        // Update statistics
        updateStatistics(activeCount, pendingCount, completedCount);

        return mainPanel;
    }

    /**
     * Creates a section panel with title and items
     */
    private JPanel createSectionPanel(String title, int count, JPanel itemsPanel) {
        JPanel sectionPanel = new JPanel();
        sectionPanel.setLayout(new BoxLayout(sectionPanel, BoxLayout.Y_AXIS));
        sectionPanel.setOpaque(false);
        sectionPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Create section header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        headerPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(StyleManager.REGULAR_FONT_BOLD);
        titleLabel.setForeground(StyleManager.FOREGROUND);

        JLabel countLabel = new JLabel("(" + count + ")");
        countLabel.setFont(StyleManager.REGULAR_FONT);
        countLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);

        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(countLabel, BorderLayout.EAST);

        // Add header and items to section
        sectionPanel.add(headerPanel);
        sectionPanel.add(itemsPanel);

        return sectionPanel;
    }

    /**
     * Updates the statistics in the sidebar
     */
    private void updateStatistics(int activeCount, int pendingCount, int completedCount) {
        int totalItems = activeCount + pendingCount + completedCount;
        int totalProfit = 0;

        // Calculate total profit
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String marginStr = tableModel.getValueAt(i, 6).toString().replace(",", "").replace(" gp", "");
            try {
                int margin = Integer.parseInt(marginStr);
                totalProfit += margin;
            } catch (NumberFormatException e) {
                // Ignore invalid margins
            }
        }

        // Find the stats panel in the sidebar
        Component[] components = getComponents();
        if (components.length > 0 && components[0] instanceof JPanel) {
            JPanel container = (JPanel) components[0];
            Component[] containerComponents = container.getComponents();

            // Find the sidebar
            for (Component component : containerComponents) {
                if (component instanceof JPanel && component.getPreferredSize().width == 250) {
                    JPanel sidebar = (JPanel) component;
                    Component[] sidebarComponents = sidebar.getComponents();

                    // Find the stats panel
                    for (Component sidebarComponent : sidebarComponents) {
                        if (sidebarComponent instanceof JPanel) {
                            JPanel panel = (JPanel) sidebarComponent;
                            Component[] panelComponents = panel.getComponents();

                            // Look for the stats items
                            for (Component panelComponent : panelComponents) {
                                if (panelComponent instanceof JPanel) {
                                    JPanel statItem = (JPanel) panelComponent;
                                    Component[] statComponents = statItem.getComponents();

                                    // Find the label component
                                    for (Component statComponent : statComponents) {
                                        if (statComponent instanceof JLabel) {
                                            JLabel label = (JLabel) statComponent;
                                            String text = label.getText();

                                            // Update the appropriate stat
                                            if (text.equals("Total Items")) {
                                                updateStatValue(statItem, String.valueOf(totalItems), StyleManager.FOREGROUND);
                                            } else if (text.equals("Active Items")) {
                                                updateStatValue(statItem, String.valueOf(activeCount), StyleManager.WARNING);
                                            } else if (text.equals("Completed Today")) {
                                                updateStatValue(statItem, String.valueOf(completedCount), StyleManager.SUCCESS);
                                            } else if (text.equals("Total Profit")) {
                                                updateStatValue(statItem, totalProfit + " gp", StyleManager.SUCCESS);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Updates a stat value in the sidebar
     */
    private void updateStatValue(JPanel statItem, String value, Color valueColor) {
        Component[] components = statItem.getComponents();
        for (Component component : components) {
            if (component instanceof JLabel && component.getFont() == StyleManager.REGULAR_FONT_BOLD) {
                JLabel valueLabel = (JLabel) component;
                valueLabel.setText(value);
                valueLabel.setForeground(valueColor);
                break;
            }
        }
    }

    /**
     * Creates a modern card for a single flip item
     */
    private JPanel createModernItemCard(int rowIndex) {
        // Get item data from the model
        String itemName = tableModel.getValueAt(rowIndex, 0).toString();
        String offerType = tableModel.getValueAt(rowIndex, 1).toString();
        String status = tableModel.getValueAt(rowIndex, 2).toString();
        String slot = tableModel.getValueAt(rowIndex, 3).toString();
        String buyPrice = tableModel.getValueAt(rowIndex, 4).toString();
        String sellPrice = tableModel.getValueAt(rowIndex, 5).toString();
        String marginGp = tableModel.getValueAt(rowIndex, 6).toString();
        String marginPercent = tableModel.getValueAt(rowIndex, 7).toString();
        String lastUpdate = tableModel.getValueAt(rowIndex, 8).toString();

        // Create a modern card panel with clean design
        JPanel card = new JPanel(new BorderLayout(15, 0));
        card.setBorder(BorderFactory.createCompoundBorder(
            // Outer border with subtle shadow effect
            BorderFactory.createLineBorder(new Color(30, 30, 35), 1),
            // Inner padding
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        card.setBackground(new Color(40, 40, 45));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));

        // Add status indicator on the left side
        JPanel statusIndicator = new JPanel();
        statusIndicator.setPreferredSize(new Dimension(5, 0));
        statusIndicator.setBackground(getStatusColor(status));
        statusIndicator.setBorder(BorderFactory.createEmptyBorder());

        // Add the status indicator to the left
        card.add(statusIndicator, BorderLayout.WEST);

        // Store the row index for selection
        card.putClientProperty("rowIndex", rowIndex);

        // Create main content panel
        JPanel contentPanel = new JPanel(new BorderLayout(20, 0));
        contentPanel.setOpaque(false);

        // Left section with item name and status
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setOpaque(false);
        leftPanel.setPreferredSize(new Dimension(200, 0));

        // Item name with icon
        JLabel nameLabel = new JLabel(itemName);
        nameLabel.setFont(StyleManager.REGULAR_FONT_BOLD);
        nameLabel.setForeground(StyleManager.FOREGROUND);
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Status badge
        JPanel statusBadge = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        statusBadge.setOpaque(true);
        statusBadge.setBackground(getStatusColor(status));
        statusBadge.setBorder(BorderFactory.createEmptyBorder(2, 6, 2, 6));
        statusBadge.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel statusLabel = new JLabel(status);
        statusLabel.setFont(StyleManager.SMALL_FONT_BOLD);
        statusLabel.setForeground(Color.WHITE);
        statusBadge.add(statusLabel);

        // Offer type label
        JLabel offerTypeLabel = new JLabel(offerType);
        offerTypeLabel.setFont(StyleManager.SMALL_FONT);
        offerTypeLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        offerTypeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        leftPanel.add(nameLabel);
        leftPanel.add(Box.createVerticalStrut(5));
        leftPanel.add(statusBadge);
        leftPanel.add(Box.createVerticalStrut(5));
        leftPanel.add(offerTypeLabel);

        // Center section with prices and margin
        JPanel centerPanel = new JPanel(new GridLayout(2, 2, 15, 5));
        centerPanel.setOpaque(false);

        // Buy price panel
        JPanel buyPricePanel = new JPanel(new BorderLayout());
        buyPricePanel.setOpaque(false);
        JLabel buyPriceTitleLabel = new JLabel("Buy Price");
        buyPriceTitleLabel.setFont(StyleManager.SMALL_FONT);
        buyPriceTitleLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        JLabel buyPriceValueLabel = new JLabel(buyPrice);
        buyPriceValueLabel.setFont(StyleManager.REGULAR_FONT);
        buyPriceValueLabel.setForeground(StyleManager.FOREGROUND);
        buyPricePanel.add(buyPriceTitleLabel, BorderLayout.NORTH);
        buyPricePanel.add(buyPriceValueLabel, BorderLayout.CENTER);

        // Sell price panel
        JPanel sellPricePanel = new JPanel(new BorderLayout());
        sellPricePanel.setOpaque(false);
        JLabel sellPriceTitleLabel = new JLabel("Sell Price");
        sellPriceTitleLabel.setFont(StyleManager.SMALL_FONT);
        sellPriceTitleLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        JLabel sellPriceValueLabel = new JLabel(sellPrice);
        sellPriceValueLabel.setFont(StyleManager.REGULAR_FONT);
        sellPriceValueLabel.setForeground(StyleManager.FOREGROUND);
        sellPricePanel.add(sellPriceTitleLabel, BorderLayout.NORTH);
        sellPricePanel.add(sellPriceValueLabel, BorderLayout.CENTER);

        // Margin GP panel
        JPanel marginGpPanel = new JPanel(new BorderLayout());
        marginGpPanel.setOpaque(false);
        JLabel marginGpTitleLabel = new JLabel("Margin");
        marginGpTitleLabel.setFont(StyleManager.SMALL_FONT);
        marginGpTitleLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        JLabel marginGpValueLabel = new JLabel(marginGp);
        marginGpValueLabel.setFont(StyleManager.REGULAR_FONT_BOLD);
        marginGpValueLabel.setForeground(StyleManager.SUCCESS);
        marginGpPanel.add(marginGpTitleLabel, BorderLayout.NORTH);
        marginGpPanel.add(marginGpValueLabel, BorderLayout.CENTER);

        // Margin percent panel
        JPanel marginPercentPanel = new JPanel(new BorderLayout());
        marginPercentPanel.setOpaque(false);
        JLabel marginPercentTitleLabel = new JLabel("ROI");
        marginPercentTitleLabel.setFont(StyleManager.SMALL_FONT);
        marginPercentTitleLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        JLabel marginPercentValueLabel = new JLabel(marginPercent);
        marginPercentValueLabel.setFont(StyleManager.REGULAR_FONT_BOLD);
        marginPercentValueLabel.setForeground(StyleManager.SUCCESS);
        marginPercentPanel.add(marginPercentTitleLabel, BorderLayout.NORTH);
        marginPercentPanel.add(marginPercentValueLabel, BorderLayout.CENTER);

        centerPanel.add(buyPricePanel);
        centerPanel.add(sellPricePanel);
        centerPanel.add(marginGpPanel);
        centerPanel.add(marginPercentPanel);

        // Right section with action buttons
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setOpaque(false);
        rightPanel.setPreferredSize(new Dimension(100, 0));

        // Action buttons
        JButton resetButton = new JButton("Reset");
        resetButton.setFont(StyleManager.SMALL_FONT);
        resetButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
        resetButton.setMaximumSize(new Dimension(80, 25));
        StyleManager.styleButton(resetButton);
        resetButton.addActionListener(e -> resetSelectedItemStatus());

        JButton removeButton = new JButton("Remove");
        removeButton.setFont(StyleManager.SMALL_FONT);
        removeButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
        removeButton.setMaximumSize(new Dimension(80, 25));
        StyleManager.styleButton(removeButton);
        removeButton.addActionListener(e -> removeSelectedItem());

        rightPanel.add(Box.createVerticalGlue());
        rightPanel.add(resetButton);
        rightPanel.add(Box.createVerticalStrut(5));
        rightPanel.add(removeButton);
        rightPanel.add(Box.createVerticalGlue());

        // Add panels to content panel
        contentPanel.add(leftPanel, BorderLayout.WEST);
        contentPanel.add(centerPanel, BorderLayout.CENTER);
        contentPanel.add(rightPanel, BorderLayout.EAST);

        // Add content panel to card
        card.add(contentPanel, BorderLayout.CENTER);

        // Add selection behavior
        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Select the corresponding row in the table
                itemTable.setRowSelectionInterval(rowIndex, rowIndex);

                // Show context menu on right-click
                if (e.isPopupTrigger() || e.getButton() == MouseEvent.BUTTON3) {
                    showContextMenu(e);
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                card.setBackground(new Color(45, 45, 50));
                card.setBorder(BorderFactory.createCompoundBorder(
                    // Outer border with highlight
                    BorderFactory.createLineBorder(StyleManager.ACCENT, 1),
                    // Inner padding
                    BorderFactory.createEmptyBorder(15, 15, 15, 15)
                ));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                card.setBackground(new Color(40, 40, 45));
                card.setBorder(BorderFactory.createCompoundBorder(
                    // Outer border - normal
                    BorderFactory.createLineBorder(new Color(30, 30, 35), 1),
                    // Inner padding
                    BorderFactory.createEmptyBorder(15, 15, 15, 15)
                ));
            }
        });

        return card;
    }

    /**
     * Creates a styled status badge
     */
    private JLabel createStatusBadge(String status) {
        JLabel badge = new JLabel(status);
        badge.setFont(StyleManager.SMALL_FONT_BOLD);
        badge.setForeground(Color.WHITE);
        badge.setOpaque(true);
        badge.setBackground(getStatusColor(status));
        badge.setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));
        return badge;
    }

    /**
     * Creates an empty state panel when there are no items
     */
    private JPanel createEmptyStatePanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(50, 20, 50, 20));

        JLabel iconLabel = new JLabel("No Items");
        iconLabel.setFont(StyleManager.HEADER_FONT);
        iconLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel messageLabel = new JLabel("Add items to start flipping");
        messageLabel.setFont(StyleManager.REGULAR_FONT);
        messageLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        messageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(Box.createVerticalGlue());
        panel.add(iconLabel);
        panel.add(Box.createVerticalStrut(10));
        panel.add(messageLabel);
        panel.add(Box.createVerticalGlue());

        return panel;
    }

    /**
     * Gets the appropriate color for a status
     */
    private Color getStatusColor(String status) {
        if (status == null) {
            return StyleManager.FOREGROUND_SECONDARY;
        }

        if (status.contains("BUYING")) {
            return StyleManager.WARNING;
        } else if (status.contains("SELLING")) {
            return StyleManager.INFO;
        } else if (status.contains("COMPLETED")) {
            return StyleManager.SUCCESS;
        } else if (status.contains("ERROR") || status.contains("FAILED")) {
            return StyleManager.ERROR;
        } else if (status.contains("READY_TO_BUY")) {
            return StyleManager.ACCENT_PURPLE;
        } else if (status.contains("READY_TO_SELL")) {
            return StyleManager.ACCENT_TEAL;
        } else {
            return StyleManager.FOREGROUND_SECONDARY;
        }
    }

    /**
     * Gets the appropriate color for a margin value
     */
    private Color getMarginColor(String marginStr) {
        if (marginStr == null) {
            return StyleManager.FOREGROUND;
        }

        try {
            String cleanMargin = marginStr.replace("%", "").trim();
            double margin = Double.parseDouble(cleanMargin);

            if (margin > 5.0) {
                return StyleManager.SUCCESS;
            } else if (margin > 2.0) {
                return StyleManager.WARNING;
            } else if (margin < 0) {
                return StyleManager.ERROR;
            } else {
                return StyleManager.FOREGROUND;
            }
        } catch (NumberFormatException e) {
            return StyleManager.FOREGROUND;
        }
    }

    /**
     * Configures the table appearance and renderers
     */
    private void configureTable() {
        // Set table properties
        itemTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        itemTable.setRowHeight(25);
        itemTable.setAutoCreateRowSorter(true);
        itemTable.setFillsViewportHeight(true);

        // Configure columns
        TableColumnModel columnModel = itemTable.getColumnModel();

        // Set custom renderers
        columnModel.getColumn(2).setCellRenderer(new StatusCellRenderer()); // Status column
        columnModel.getColumn(4).setCellRenderer(new NumericCellRenderer(false)); // Buy Price
        columnModel.getColumn(5).setCellRenderer(new NumericCellRenderer(false)); // Sell Price
        columnModel.getColumn(6).setCellRenderer(new NumericCellRenderer(false)); // Margin GP
        columnModel.getColumn(7).setCellRenderer(new NumericCellRenderer(true));  // Margin %

        // Set column widths
        columnModel.getColumn(0).setPreferredWidth(150); // Item Name
        columnModel.getColumn(1).setPreferredWidth(60);  // Offer Type
        columnModel.getColumn(2).setPreferredWidth(120); // Status
        columnModel.getColumn(3).setPreferredWidth(50);  // Slot
        columnModel.getColumn(4).setPreferredWidth(80);  // Buy Price
        columnModel.getColumn(5).setPreferredWidth(80);  // Sell Price
        columnModel.getColumn(6).setPreferredWidth(70);  // Margin GP
        columnModel.getColumn(7).setPreferredWidth(70);  // Margin %
        columnModel.getColumn(8).setPreferredWidth(100); // Last Updated
        columnModel.getColumn(9).setPreferredWidth(100); // Stale Timer
    }

    /**
     * Shows the context menu at the mouse position
     */
    private void showContextMenu(MouseEvent e) {
        JTable table = (JTable) e.getSource();
        int row = table.rowAtPoint(e.getPoint());

        if (row >= 0 && row < table.getRowCount()) {
            // Select the row under the mouse
            table.setRowSelectionInterval(row, row);

            // Show context menu
            contextMenu.show(e.getComponent(), e.getX(), e.getY());
        }
    }

    /**
     * Initializes event handlers for all components
     */
    private void initializeEventHandlers(JMenuItem removeMenuItem, JMenuItem resetMenuItem) {
        // Remove button action
        removeItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeSelectedItem();
            }
        });

        // Reset status button action
        resetStatusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetSelectedItemStatus();
            }
        });

        // Selection listener for buttons state
        itemTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                boolean hasSelection = itemTable.getSelectedRow() != -1;
                removeItemButton.setEnabled(hasSelection);
                resetStatusButton.setEnabled(hasSelection);
            }
        });

        // Context menu popup trigger
        itemTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                handleTableMouseEvent(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                handleTableMouseEvent(e);
            }
        });

        // Context menu actions
        removeMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeSelectedItem();
            }
        });

        resetMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetSelectedItemStatus();
            }
        });
    }

    /**
     * Handles mouse events on the table for context menu
     */
    private void handleTableMouseEvent(MouseEvent e) {
        if (e.isPopupTrigger()) {
            JTable table = (JTable) e.getSource();
            int row = table.rowAtPoint(e.getPoint());

            if (row >= 0 && row < table.getRowCount()) {
                // Select the row under the mouse
                table.setRowSelectionInterval(row, row);

                // Show context menu
                contextMenu.show(e.getComponent(), e.getX(), e.getY());
            }
        }
    }

    /**
     * Removes the currently selected item
     */
    private void removeSelectedItem() {
        int selectedRow = itemTable.getSelectedRow();
        if (selectedRow == -1) {
            return;
        }

        // Convert view row index to model row index in case of sorting
        int modelRow = itemTable.convertRowIndexToModel(selectedRow);
        FlipItem itemToRemove = tableModel.getItemAt(modelRow);

        if (itemToRemove == null) {
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to remove " + itemToRemove.getItemName() + "?",
            "Confirm Removal",
            JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (config.removeItem(itemToRemove.getItemName())) {
                tableModel.updateData(); // Refresh table
            } else {
                JOptionPane.showMessageDialog(this,
                    "Failed to remove item from config.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Resets the selected item's status to initial state
     */
    private void resetSelectedItemStatus() {
        int selectedRow = itemTable.getSelectedRow();
        if (selectedRow == -1) {
            return;
        }

        // Convert view row index to model row index in case of sorting
        int modelRow = itemTable.convertRowIndexToModel(selectedRow);
        FlipItem item = tableModel.getItemAt(modelRow);

        if (item == null) {
            return;
        }

        // Reset the item's status
        item.setStatus(Status.DISCOVERING_PRICE);
        Logger.log("Reset status for item: " + item.getItemName());

        tableModel.updateData(); // Refresh table
    }

    /**
     * Updates the table data from the config and refreshes the card view
     * Shows a brief animation to indicate real-time updates
     */
    public void updateTable() {
        // Show update indicator
        showUpdateIndicator();

        // Update the table model data
        tableModel.updateData();

        // Find the scroll pane that contains our cards panel
        Component[] components = getComponents();
        for (Component component : components) {
            if (component instanceof JScrollPane) {
                JScrollPane scrollPane = (JScrollPane) component;

                // Save the current scroll position
                JViewport viewport = scrollPane.getViewport();
                Point position = viewport.getViewPosition();

                // Replace the cards panel with a new one
                JPanel newItemsPanel = createItemsPanel();
                scrollPane.setViewportView(newItemsPanel);

                // Restore scroll position if possible
                if (position != null && newItemsPanel.getHeight() > viewport.getHeight()) {
                    viewport.setViewPosition(position);
                }

                break;
            }
        }
    }

    /**
     * Shows the update indicator briefly to indicate real-time updates
     */
    private void showUpdateIndicator() {
        // Stop any existing fade timer
        if (fadeTimer != null && fadeTimer.isRunning()) {
            fadeTimer.stop();
        }

        // Show the indicator
        updateIndicator.setVisible(true);

        // Create a timer to hide it after 500ms
        fadeTimer = new Timer(500, e -> {
            updateIndicator.setVisible(false);
            ((Timer)e.getSource()).stop();
        });
        fadeTimer.setRepeats(false);
        fadeTimer.start();
    }
}