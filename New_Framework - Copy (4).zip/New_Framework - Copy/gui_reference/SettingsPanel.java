package scripts.ScarFlip.gui;

import core.gui.components.ModernCardPanel;
import core.gui.style.StyleManager;
import scripts.ScarFlip.config.ScarFlipConfig;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.text.NumberFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.util.concurrent.TimeUnit;

/**
 * A modern, visually improved panel for script settings with enhanced user experience
 */
public class SettingsPanel extends JPanel {

    private final ScarFlipConfig config;

    // Settings fields
    private JFormattedTextField minMarginField;
    private JFormattedTextField staleTimeoutField;
    private JFormattedTextField maxGpPerItemField;
    private JFormattedTextField gpToAllocateField;
    private JFormattedTextField maxConcurrentField;
    private JFormattedTextField priceCooldownField;

    // Extra UI components
    private JButton saveButton;
    private JButton resetButton;

    public SettingsPanel(ScarFlipConfig config) {
        this.config = config;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(),
                "Script Settings",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Dialog", Font.BOLD, 14)
            ),
            new EmptyBorder(10, 10, 10, 10)
        ));

        // Create the settings fields
        initializeFields();

        // Create main settings panel
        JPanel settingsGrid = createSettingsGrid();

        // Create buttons panel
        JPanel buttonsPanel = createButtonsPanel();

        // Add to main layout
        add(settingsGrid, BorderLayout.CENTER);
        add(buttonsPanel, BorderLayout.SOUTH);

        // Load initial values
        loadConfigValues();
    }

    private void initializeFields() {
        // Create formatters for numeric input
        NumberFormat integerFormat = NumberFormat.getIntegerInstance();
        integerFormat.setGroupingUsed(true);
        NumberFormatter integerFormatter = new NumberFormatter(integerFormat);
        integerFormatter.setValueClass(Integer.class);
        integerFormatter.setAllowsInvalid(false);
        integerFormatter.setMinimum(0);

        NumberFormat doubleFormat = NumberFormat.getNumberInstance();
        doubleFormat.setMinimumFractionDigits(1);
        doubleFormat.setMaximumFractionDigits(2);
        NumberFormatter doubleFormatter = new NumberFormatter(doubleFormat);
        doubleFormatter.setValueClass(Double.class);
        doubleFormatter.setAllowsInvalid(false);
        doubleFormatter.setMinimum(0.0);

        // Create fields with formatters
        minMarginField = new JFormattedTextField(doubleFormatter);
        configureField(minMarginField, true);

        staleTimeoutField = new JFormattedTextField(integerFormatter);
        configureField(staleTimeoutField, false);

        maxGpPerItemField = new JFormattedTextField(integerFormatter);
        configureField(maxGpPerItemField, false);

        gpToAllocateField = new JFormattedTextField(integerFormatter);
        configureField(gpToAllocateField, false);

        maxConcurrentField = new JFormattedTextField(integerFormatter);
        configureField(maxConcurrentField, false);

        priceCooldownField = new JFormattedTextField(integerFormatter);
        configureField(priceCooldownField, false);

        // Create buttons
        saveButton = new JButton("Save Settings");
        saveButton.setFont(new Font("Dialog", Font.BOLD, 12));

        resetButton = new JButton("Reset to Defaults");
        resetButton.setFont(new Font("Dialog", Font.PLAIN, 12));

        // Add action listeners
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveSettings();
            }
        });

        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetToDefaults();
            }
        });
    }

    private void configureField(JFormattedTextField field, boolean isPercent) {
        field.setColumns(10);
        field.setHorizontalAlignment(SwingConstants.RIGHT);

        // Apply modern styling
        StyleManager.styleTextField(field);
    }

    private JPanel createSettingsGrid() {
        // Create main panel with modern styling
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setOpaque(false);

        // Create trading settings card
        ModernCardPanel tradingCard = new ModernCardPanel("Trading Settings");
        JPanel tradingPanel = new JPanel(new GridBagLayout());
        tradingPanel.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Minimum margin percentage
        JLabel minMarginLabel = new JLabel("Minimum Margin %:");
        minMarginLabel.setFont(StyleManager.REGULAR_FONT);
        minMarginLabel.setForeground(StyleManager.FOREGROUND);
        minMarginLabel.setToolTipText("Minimum profit margin required to flip an item");
        minMarginField.setToolTipText("Minimum profit margin required to flip an item");

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.0;
        gbc.anchor = GridBagConstraints.EAST;
        tradingPanel.add(minMarginLabel, gbc);

        gbc.gridx = 1; gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        tradingPanel.add(minMarginField, gbc);

        // Max GP per item
        JLabel maxGpLabel = new JLabel("Max GP Per Item:");
        maxGpLabel.setFont(StyleManager.REGULAR_FONT);
        maxGpLabel.setForeground(StyleManager.FOREGROUND);
        maxGpLabel.setToolTipText("Maximum amount to spend on a single item");
        maxGpPerItemField.setToolTipText("Maximum amount to spend on a single item");

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.0;
        gbc.anchor = GridBagConstraints.EAST;
        tradingPanel.add(maxGpLabel, gbc);

        gbc.gridx = 1; gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        tradingPanel.add(maxGpPerItemField, gbc);

        // GP to allocate
        JLabel allocateLabel = new JLabel("GP to Allocate:");
        allocateLabel.setFont(StyleManager.REGULAR_FONT);
        allocateLabel.setForeground(StyleManager.FOREGROUND);
        allocateLabel.setToolTipText("Total GP to use for flipping");
        gpToAllocateField.setToolTipText("Total GP to use for flipping");

        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0.0;
        gbc.anchor = GridBagConstraints.EAST;
        tradingPanel.add(allocateLabel, gbc);

        gbc.gridx = 1; gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        tradingPanel.add(gpToAllocateField, gbc);

        // Max concurrent flips
        JLabel maxConcurrentLabel = new JLabel("Max Concurrent Flips:");
        maxConcurrentLabel.setFont(StyleManager.REGULAR_FONT);
        maxConcurrentLabel.setForeground(StyleManager.FOREGROUND);
        maxConcurrentLabel.setToolTipText("Maximum number of items to flip at once");
        maxConcurrentField.setToolTipText("Maximum number of items to flip at once");

        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0.0;
        gbc.anchor = GridBagConstraints.EAST;
        tradingPanel.add(maxConcurrentLabel, gbc);

        gbc.gridx = 1; gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        tradingPanel.add(maxConcurrentField, gbc);

        tradingCard.setContent(tradingPanel);

        // Create timing settings card
        ModernCardPanel timingCard = new ModernCardPanel("Timing Settings");
        JPanel timingPanel = new JPanel(new GridBagLayout());
        timingPanel.setOpaque(false);

        // Stale timeout
        JLabel staleLabel = new JLabel("Stale Timeout (mins):");
        staleLabel.setFont(StyleManager.REGULAR_FONT);
        staleLabel.setForeground(StyleManager.FOREGROUND);
        staleLabel.setToolTipText("Time before an item is considered stale");
        staleTimeoutField.setToolTipText("Time before an item is considered stale");

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.0;
        gbc.anchor = GridBagConstraints.EAST;
        timingPanel.add(staleLabel, gbc);

        gbc.gridx = 1; gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        timingPanel.add(staleTimeoutField, gbc);

        // Price check cooldown
        JLabel cooldownLabel = new JLabel("Price Check Cooldown (mins):");
        cooldownLabel.setFont(StyleManager.REGULAR_FONT);
        cooldownLabel.setForeground(StyleManager.FOREGROUND);
        cooldownLabel.setToolTipText("Time between price checks");
        priceCooldownField.setToolTipText("Time between price checks");

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.0;
        gbc.anchor = GridBagConstraints.EAST;
        timingPanel.add(cooldownLabel, gbc);

        gbc.gridx = 1; gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        timingPanel.add(priceCooldownField, gbc);

        timingCard.setContent(timingPanel);

        // Add cards to main panel with spacing
        mainPanel.add(tradingCard);
        mainPanel.add(Box.createVerticalStrut(StyleManager.SECTION_SPACING));
        mainPanel.add(timingCard);

        // Add filler to push cards to the top
        mainPanel.add(Box.createVerticalGlue());

        return mainPanel;
    }



    private JPanel createButtonsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        // Add spacer to push buttons to the right
        panel.add(Box.createHorizontalGlue());

        // Apply modern styling to buttons
        StyleManager.styleButton(resetButton);
        StyleManager.stylePrimaryButton(saveButton);

        // Add spacing between buttons
        panel.add(resetButton);
        panel.add(Box.createHorizontalStrut(8));
        panel.add(saveButton);

        return panel;
    }

    /**
     * Loads current config values into the UI fields
     */
    public void loadConfigValues() {
        minMarginField.setValue(config.getMinMarginPercent());
        staleTimeoutField.setValue(TimeUnit.MILLISECONDS.toMinutes(config.getStaleOfferTimeoutMillis()));
        maxGpPerItemField.setValue(config.getMaxGpPerFlipItem());
        gpToAllocateField.setValue(config.getGpToAllocatePerItem());
        maxConcurrentField.setValue(config.getMaxConcurrentFlips());
        priceCooldownField.setValue(TimeUnit.MILLISECONDS.toMinutes(config.getPriceDiscoveryCooldownMillis()));
    }

    /**
     * Saves the current UI field values to the config
     */
    public void saveSettings() {
        try {
            config.setMinMarginPercent(((Number) minMarginField.getValue()).doubleValue());
            config.setStaleOfferTimeoutMillis(TimeUnit.MINUTES.toMillis(((Number) staleTimeoutField.getValue()).longValue()));
            config.setMaxGpPerFlipItem(((Number) maxGpPerItemField.getValue()).intValue());
            config.setGpToAllocatePerItem(((Number) gpToAllocateField.getValue()).intValue());
            config.setMaxConcurrentFlips(((Number) maxConcurrentField.getValue()).intValue());
            config.setPriceDiscoveryCooldownMillis(TimeUnit.MINUTES.toMillis(((Number) priceCooldownField.getValue()).longValue()));

            JOptionPane.showMessageDialog(this,
                "Settings saved successfully!",
                "Settings Saved",
                JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error saving settings: " + e.getMessage(),
                "Settings Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Resets fields to default values
     */
    public void resetToDefaults() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Reset all settings to default values?",
            "Confirm Reset",
            JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            minMarginField.setValue(5.0);
            staleTimeoutField.setValue(5);
            maxGpPerItemField.setValue(7_000_000);
            gpToAllocateField.setValue(25_000_000);
            maxConcurrentField.setValue(3);
            priceCooldownField.setValue(5);

            saveSettings();
        }
    }
}