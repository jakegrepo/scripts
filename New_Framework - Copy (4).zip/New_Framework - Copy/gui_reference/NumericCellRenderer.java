package scripts.ScarFlip.gui;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * A custom renderer for numeric columns (prices, margins) in the items table.
 * Formats numbers with commas and uses colors to indicate positive/negative values.
 */
public class NumericCellRenderer extends DefaultTableCellRenderer {
    
    private final NumberFormat integerFormat;
    private final NumberFormat percentFormat;
    private final boolean isPercent;
    
    public NumericCellRenderer(boolean isPercent) {
        super();
        this.isPercent = isPercent;
        
        if (isPercent) {
            this.percentFormat = DecimalFormat.getPercentInstance();
            this.percentFormat.setMinimumFractionDigits(1);
            this.percentFormat.setMaximumFractionDigits(2);
            this.integerFormat = null;
        } else {
            this.integerFormat = NumberFormat.getIntegerInstance();
            this.percentFormat = null;
        }
        
        setHorizontalAlignment(SwingConstants.RIGHT);
    }
    
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        // Format the value first
        if (value != null) {
            if (isPercent && value instanceof Number) {
                double doubleValue = ((Number) value).doubleValue();
                // Convert from percentage value (e.g. 5.0) to decimal (0.05) for formatting
                value = percentFormat.format(doubleValue / 100.0);
            } else if (!isPercent && value instanceof Number) {
                value = integerFormat.format(((Number) value).longValue());
            }
        }
        
        Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        
        // Don't override selection colors
        if (isSelected) {
            return component;
        }
        
        // Apply colors based on value
        if (value instanceof String && ((String) value).contains("-")) {
            // Negative value
            setForeground(Color.RED);
        } else if (value instanceof Number) {
            Number num = (Number) value;
            if (num.doubleValue() < 0) {
                setForeground(Color.RED);
            } else if (num.doubleValue() > 0) {
                setForeground(new Color(0, 128, 0)); // Dark green
            } else {
                setForeground(Color.BLACK);
            }
        } else {
            setForeground(Color.BLACK);
        }
        
        return component;
    }
} 