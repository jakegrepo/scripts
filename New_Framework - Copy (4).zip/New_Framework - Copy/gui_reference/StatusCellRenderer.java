package scripts.ScarFlip.gui;

import scripts.ScarFlip.enums.Status;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

/**
 * A custom renderer for the Status column in the items table.
 * Makes the table more visually appealing by applying different colors based on status.
 */
public class StatusCellRenderer extends DefaultTableCellRenderer {
    
    private final Color DISCOVERING_COLOR = new Color(135, 206, 250); // Light blue
    private final Color READY_TO_BUY_COLOR = new Color(173, 255, 173); // Light green
    private final Color BUYING_COLOR = new Color(144, 238, 144); // Green
    private final Color READY_TO_SELL_COLOR = new Color(255, 160, 122); // Light salmon
    private final Color SELLING_COLOR = new Color(255, 127, 80); // Coral
    private final Color IDLE_COLOR = new Color(245, 245, 245); // Light grey
    private final Color ERROR_COLOR = new Color(255, 192, 203); // Light pink
    private final Color STALE_COLOR = new Color(255, 204, 204); // Light red
    private final Color COLLECTING_COLOR = new Color(230, 230, 255); // Light purple
    
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        
        // Reset alignment and colors
        setHorizontalAlignment(SwingConstants.CENTER);
        setBackground(null);
        setForeground(null);
        
        // Don't override selection background
        if (isSelected) {
            return component;
        }
        
        // Apply colors based on status
        if (value instanceof Status) {
            Status status = (Status) value;
            switch (status) {
                case IDLE:
                    setBackground(IDLE_COLOR);
                    break;
                case DISCOVERING_PRICE:
                    setBackground(DISCOVERING_COLOR);
                    break;
                case READY_TO_BUY:
                    setBackground(READY_TO_BUY_COLOR);
                    break;
                case SUBMITTING_BUY_OFFER:
                case BUYING:
                    setBackground(BUYING_COLOR);
                    break;
                case READY_TO_SELL:
                    setBackground(READY_TO_SELL_COLOR);
                    break;
                case SUBMITTING_SELL_OFFER:
                case SELLING:
                    setBackground(SELLING_COLOR);
                    break;
                case COLLECTING:
                    setBackground(COLLECTING_COLOR);
                    break;
                case STALE:
                    setBackground(STALE_COLOR);
                    break;
                case ERROR:
                    setBackground(ERROR_COLOR);
                    break;
            }
        }
        
        return component;
    }
} 