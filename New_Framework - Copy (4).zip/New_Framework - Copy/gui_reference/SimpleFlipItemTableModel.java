package scripts.ScarFlip.gui;

import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.grandexchange.GrandExchangeItem;
import scripts.ScarFlip.config.FlipItem;
import scripts.ScarFlip.config.ScarFlipConfig;
import scripts.ScarFlip.enums.Status;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * A table model that displays flip items with separate rows for buy and sell offers.
 */
public class SimpleFlipItemTableModel extends AbstractTableModel {

    private final ScarFlipConfig config;
    private List<FlipItem> currentItems; // Local cache to avoid concurrent modification issues during rendering
    private final String[] columnNames = {
            "Item Name", "Offer Type", "Status", "Slot", "Buy Price", "Sell Price", 
            "Margin GP", "Margin %", "Last Updated", "Stale Timer"
    };

    public SimpleFlipItemTableModel(ScarFlipConfig config) {
        this.config = config;
        this.currentItems = new ArrayList<>(config.getItemsToFlip()); // Initial copy
    }

    // Method to be called periodically to refresh data from config
    public void updateData() {
        // Get a fresh copy from the potentially updated config list
        this.currentItems = new ArrayList<>(config.getItemsToFlip());
        // Notify the table that the data has changed
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        // Each item can have both a buy and sell offer, so we need to count both
        int totalRows = 0;
        
        for (FlipItem item : currentItems) {
            // Check buy offer
            if (item.hasActiveBuyOffer() || item.getStatus() == Status.DISCOVERING_PRICE || 
                item.getStatus() == Status.READY_TO_BUY) {
                totalRows++;
            }
            
            // Check sell offer
            if (item.hasActiveSellOffer() || item.getStatus() == Status.READY_TO_SELL) {
                totalRows++;
            }
            
            // If no offers at all, show at least one row
            if (!item.hasActiveBuyOffer() && !item.hasActiveSellOffer() && 
                item.getStatus() != Status.DISCOVERING_PRICE && 
                item.getStatus() != Status.READY_TO_BUY && 
                item.getStatus() != Status.READY_TO_SELL) {
                totalRows++;
            }
        }
        return totalRows;
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0: return String.class;  // Item Name
            case 1: return String.class;  // Offer Type
            case 2: return Status.class;  // Status
            case 3: return Integer.class; // Slot
            case 4: case 5: case 6: return Integer.class; // Buy Price, Sell Price, Margin GP
            case 7: return Double.class;  // Margin %
            case 8: case 9: return String.class;  // Last Updated, Stale Timer
            default: return Object.class;
        }
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        // Find the appropriate item for this row
        FlipItem item = null;
        boolean isBuyOffer = false;
        int currentRow = 0;
        
        for (FlipItem currentItem : currentItems) {
            // Check buy offer
            if (currentItem.hasActiveBuyOffer() || currentItem.getStatus() == Status.DISCOVERING_PRICE || 
                currentItem.getStatus() == Status.READY_TO_BUY) {
                if (currentRow == rowIndex) {
                    item = currentItem;
                    isBuyOffer = true;
                    break;
                }
                currentRow++;
            }
            
            // Check sell offer
            if (currentItem.hasActiveSellOffer() || currentItem.getStatus() == Status.READY_TO_SELL) {
                if (currentRow == rowIndex) {
                    item = currentItem;
                    isBuyOffer = false;
                    break;
                }
                currentRow++;
            }
            
            // If no offers at all, show at least one row
            if (!currentItem.hasActiveBuyOffer() && !currentItem.hasActiveSellOffer() && 
                currentItem.getStatus() != Status.DISCOVERING_PRICE && 
                currentItem.getStatus() != Status.READY_TO_BUY && 
                currentItem.getStatus() != Status.READY_TO_SELL) {
                if (currentRow == rowIndex) {
                    item = currentItem;
                    isBuyOffer = true; // Default to buy view
                    break;
                }
                currentRow++;
            }
        }
        
        if (item == null) return null;

        switch (columnIndex) {
            case 0: return item.getItemName();
            case 1: return isBuyOffer ? "Buy" : "Sell";
            case 2: return item.getStatus();
            case 3: return isBuyOffer ? 
                    (item.getBuyGeSlot() == -1 ? 0 : item.getBuyGeSlot() + 1) :
                    (item.getSellGeSlot() == -1 ? 0 : item.getSellGeSlot() + 1);
            case 4: return item.getInstantSellPrice() <= 0 ? 0 : item.getInstantSellPrice();  // Buy price (what we pay)
            case 5: return item.getInstantBuyPrice() <= 0 ? 0 : item.getInstantBuyPrice();    // Sell price (what we get)
            case 6: return item.hasValidPrices() ? item.getMargin() : 0;                      // Margin GP
            case 7: return item.hasValidPrices() ? item.getMarginPercent() : 0.0;             // Margin %
            case 8: return formatLastUpdated(item);                                           // Last Updated
            case 9: return formatStaleTimer(item, isBuyOffer);                                // Stale Timer
            default: return null;
        }
    }

    private String formatLastUpdated(FlipItem item) {
        long lastTime = item.getLastDiscoveryTime();
        
        if (lastTime <= 0) {
            return "Never";
        }
        
        long timeSince = System.currentTimeMillis() - lastTime;
        long minutes = TimeUnit.MILLISECONDS.toMinutes(timeSince);
        
        if (minutes < 1) {
            return "Just now";
        } else if (minutes == 1) {
            return "1 minute ago";
        } else if (minutes < 60) {
            return minutes + " minutes ago";
        } else {
            long hours = minutes / 60;
            if (hours == 1) {
                return "1 hour ago";
            } else {
                return hours + " hours ago";
            }
        }
    }
    
    private String formatStaleTimer(FlipItem item, boolean isBuyOffer) {
        // Only show stale timer for active offers
        if (item.getStatus() != Status.BUYING && item.getStatus() != Status.SELLING) {
            return "-";
        }
        
        // Get the appropriate start time based on offer type
        long startTime = isBuyOffer ? item.getBuyOfferStartTime() : item.getSellOfferStartTime();
        
        if (startTime <= 0) {
            return "-";
        }
        
        // Get stale threshold from config if available
        long staleThresholdMillis = 300000; // Default 5 minutes
        try {
            if (config != null && config.getStaleOfferTimeoutMillis() > 0) {
                staleThresholdMillis = config.getStaleOfferTimeoutMillis();
            }
        } catch (Exception e) {
            // If we can't get the timeout, use default
        }
        
        // Calculate how close to stale threshold based on start time
        long timeSinceStart = System.currentTimeMillis() - startTime;
        double stalePercentage = (double) timeSinceStart / staleThresholdMillis;
        
        // Format the time display
        long seconds = TimeUnit.MILLISECONDS.toSeconds(timeSinceStart) % 60;
        long minutes = TimeUnit.MILLISECONDS.toMinutes(timeSinceStart) % 60;
        long hours = TimeUnit.MILLISECONDS.toHours(timeSinceStart);
        
        String timeFormat;
        if (hours > 0) {
            timeFormat = String.format("%dh %dm %ds", hours, minutes, seconds);
        } else {
            timeFormat = String.format("%dm %ds", minutes, seconds);
        }
        
        // Add visual indicators based on stale percentage
        if (stalePercentage >= 0.8) {
            return "⚠️ " + timeFormat; // Warning icon for >80% of threshold
        } else if (stalePercentage >= 0.5) {
            return "⏳ " + timeFormat; // Hourglass icon for >50% of threshold
        } else {
            return timeFormat;
        }
    }

    // Helper method to get the FlipItem at a specific row
    public FlipItem getItemAt(int rowIndex) {
        int currentRow = 0;
        for (FlipItem item : currentItems) {
            // Check buy offer
            if (item.hasActiveBuyOffer() || item.getStatus() == Status.DISCOVERING_PRICE || 
                item.getStatus() == Status.READY_TO_BUY) {
                if (currentRow == rowIndex) return item;
                currentRow++;
            }
            
            // Check sell offer
            if (item.hasActiveSellOffer() || item.getStatus() == Status.READY_TO_SELL) {
                if (currentRow == rowIndex) return item;
                currentRow++;
            }
            
            // If no offers at all, show at least one row
            if (!item.hasActiveBuyOffer() && !item.hasActiveSellOffer() && 
                item.getStatus() != Status.DISCOVERING_PRICE && 
                item.getStatus() != Status.READY_TO_BUY && 
                item.getStatus() != Status.READY_TO_SELL) {
                if (currentRow == rowIndex) return item;
                currentRow++;
            }
        }
        return null;
    }
    
    /**
     * Returns whether the item at the given row is a buy offer or not
     */
    public boolean isBuyOfferAt(int rowIndex) {
        int currentRow = 0;
        for (FlipItem item : currentItems) {
            // Check buy offer
            if (item.hasActiveBuyOffer() || item.getStatus() == Status.DISCOVERING_PRICE || 
                item.getStatus() == Status.READY_TO_BUY) {
                if (currentRow == rowIndex) return true;
                currentRow++;
            }
            
            // Check sell offer
            if (item.hasActiveSellOffer() || item.getStatus() == Status.READY_TO_SELL) {
                if (currentRow == rowIndex) return false;
                currentRow++;
            }
            
            // If no offers at all, show at least one row
            if (!item.hasActiveBuyOffer() && !item.hasActiveSellOffer() && 
                item.getStatus() != Status.DISCOVERING_PRICE && 
                item.getStatus() != Status.READY_TO_BUY && 
                item.getStatus() != Status.READY_TO_SELL) {
                if (currentRow == rowIndex) return true; // Default to buy view
                currentRow++;
            }
        }
        return true;
    }
} 