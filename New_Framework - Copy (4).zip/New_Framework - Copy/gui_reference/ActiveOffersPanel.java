package scripts.ScarFlip.gui;

import core.gui.components.LoadingIndicator;
import core.gui.style.StyleManager;
import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.grandexchange.GrandExchangeItem;
import org.dreambot.api.methods.grandexchange.Status;
import scripts.ScarFlip.config.FlipItem;
import scripts.ScarFlip.config.ScarFlipConfig;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Panel showing currently active GE offers with modern visual indicators and improved UI.
 * Completely redesigned for enhanced user experience and visual appeal.
 */
public class ActiveOffersPanel extends JPanel {

    private final ScarFlipConfig config;
    private final Map<Integer, OfferDisplayPanel> slotPanels = new HashMap<>();

    // Update indicator
    private LoadingIndicator updateIndicator;
    private Timer fadeTimer;

    // UI Components
    private JPanel mainContentPanel;
    private JLabel statusCountLabel;

    public ActiveOffersPanel(ScarFlipConfig config) {
        this.config = config;

        // Use a clean, modern layout
        setLayout(new BorderLayout(0, 0));
        setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        setBackground(StyleManager.PANEL_BG);

        // Create a modern sidebar layout
        createModernLayout();
    }

    /**
     * Creates a modern, professional layout with sidebar and main content area
     */
    private void createModernLayout() {
        // Create a split layout with sidebar and main content
        JPanel container = new JPanel(new BorderLayout(0, 0));
        container.setBackground(StyleManager.PANEL_BG);

        // Create sidebar
        JPanel sidebar = createSidebar();

        // Create main content area
        mainContentPanel = new JPanel();
        mainContentPanel.setLayout(new BorderLayout(0, 0));
        mainContentPanel.setBackground(StyleManager.PANEL_BG);

        // Create header for main content
        JPanel contentHeader = new JPanel(new BorderLayout());
        contentHeader.setBackground(new Color(35, 35, 40));
        contentHeader.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel titleLabel = new JLabel("Active Grand Exchange Offers");
        titleLabel.setFont(StyleManager.HEADER_FONT_SMALL);
        titleLabel.setForeground(StyleManager.FOREGROUND);

        // Create update indicator
        updateIndicator = new LoadingIndicator(16, StyleManager.ACCENT);
        updateIndicator.setVisible(false);

        // Create title panel with indicator
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        titlePanel.setOpaque(false);
        titlePanel.add(titleLabel);
        titlePanel.add(updateIndicator);

        // Status count label
        statusCountLabel = new JLabel("0 active offers");
        statusCountLabel.setFont(StyleManager.SMALL_FONT);
        statusCountLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);

        // Add refresh button
        JButton refreshButton = new JButton("Refresh");
        StyleManager.styleButton(refreshButton);
        refreshButton.addActionListener(e -> updateOffers());

        contentHeader.add(titlePanel, BorderLayout.WEST);
        contentHeader.add(statusCountLabel, BorderLayout.CENTER);
        contentHeader.add(refreshButton, BorderLayout.EAST);

        // Create offers display area
        JPanel offersPanel = createOffersPanel();
        JScrollPane scrollPane = new JScrollPane(offersPanel);
        StyleManager.styleScrollPane(scrollPane);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        // Add components to main content
        mainContentPanel.add(contentHeader, BorderLayout.NORTH);
        mainContentPanel.add(scrollPane, BorderLayout.CENTER);

        // Add sidebar and main content to container
        container.add(sidebar, BorderLayout.WEST);
        container.add(mainContentPanel, BorderLayout.CENTER);

        // Add container to panel
        add(container, BorderLayout.CENTER);
    }

    /**
     * Creates a modern sidebar with statistics and filters
     */
    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(25, 25, 30)); // Darker than main background
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 15, 20, 15));

        // Add logo/title at the top
        JLabel sidebarTitle = new JLabel("GE Overview");
        sidebarTitle.setFont(StyleManager.HEADER_FONT_SMALL);
        sidebarTitle.setForeground(StyleManager.ACCENT);
        sidebarTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add separator
        JSeparator separator = new JSeparator();
        separator.setForeground(new Color(45, 45, 50));
        separator.setBackground(new Color(45, 45, 50));
        separator.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        separator.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add statistics section
        JPanel statsPanel = createStatsPanel();
        statsPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add filter section
        JPanel filterPanel = createFilterPanel();
        filterPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add components to sidebar
        sidebar.add(sidebarTitle);
        sidebar.add(Box.createVerticalStrut(15));
        sidebar.add(separator);
        sidebar.add(Box.createVerticalStrut(20));
        sidebar.add(statsPanel);
        sidebar.add(Box.createVerticalStrut(25));
        sidebar.add(filterPanel);
        sidebar.add(Box.createVerticalGlue());

        return sidebar;
    }

    /**
     * Creates a statistics panel for the sidebar
     */
    private JPanel createStatsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        // Section title
        JLabel title = new JLabel("Statistics");
        title.setFont(StyleManager.REGULAR_FONT_BOLD);
        title.setForeground(StyleManager.FOREGROUND);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Create stat items
        JPanel buyOffersPanel = createStatItem("Buy Offers", "0", StyleManager.WARNING);
        JPanel sellOffersPanel = createStatItem("Sell Offers", "0", StyleManager.INFO);
        JPanel emptySlotPanel = createStatItem("Empty Slots", "8", StyleManager.FOREGROUND_SECONDARY);
        JPanel completedPanel = createStatItem("Completed Today", "0", StyleManager.SUCCESS);

        // Add components
        panel.add(title);
        panel.add(Box.createVerticalStrut(10));
        panel.add(buyOffersPanel);
        panel.add(Box.createVerticalStrut(8));
        panel.add(sellOffersPanel);
        panel.add(Box.createVerticalStrut(8));
        panel.add(emptySlotPanel);
        panel.add(Box.createVerticalStrut(8));
        panel.add(completedPanel);

        return panel;
    }

    /**
     * Creates a single stat item for the stats panel
     */
    private JPanel createStatItem(String label, String value, Color valueColor) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(StyleManager.SMALL_FONT);
        labelComponent.setForeground(StyleManager.FOREGROUND_SECONDARY);

        JLabel valueComponent = new JLabel(value);
        valueComponent.setFont(StyleManager.REGULAR_FONT_BOLD);
        valueComponent.setForeground(valueColor);

        panel.add(labelComponent, BorderLayout.WEST);
        panel.add(valueComponent, BorderLayout.EAST);

        return panel;
    }

    /**
     * Creates a filter panel for the sidebar
     */
    private JPanel createFilterPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        // Section title
        JLabel title = new JLabel("Filters");
        title.setFont(StyleManager.REGULAR_FONT_BOLD);
        title.setForeground(StyleManager.FOREGROUND);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Create filter options
        JCheckBox showBuyOffersCheck = new JCheckBox("Show Buy Offers");
        showBuyOffersCheck.setFont(StyleManager.REGULAR_FONT);
        showBuyOffersCheck.setForeground(StyleManager.FOREGROUND);
        showBuyOffersCheck.setBackground(null);
        showBuyOffersCheck.setOpaque(false);
        showBuyOffersCheck.setSelected(true);
        showBuyOffersCheck.setAlignmentX(Component.LEFT_ALIGNMENT);

        JCheckBox showSellOffersCheck = new JCheckBox("Show Sell Offers");
        showSellOffersCheck.setFont(StyleManager.REGULAR_FONT);
        showSellOffersCheck.setForeground(StyleManager.FOREGROUND);
        showSellOffersCheck.setBackground(null);
        showSellOffersCheck.setOpaque(false);
        showSellOffersCheck.setSelected(true);
        showSellOffersCheck.setAlignmentX(Component.LEFT_ALIGNMENT);

        JCheckBox showEmptySlotsCheck = new JCheckBox("Show Empty Slots");
        showEmptySlotsCheck.setFont(StyleManager.REGULAR_FONT);
        showEmptySlotsCheck.setForeground(StyleManager.FOREGROUND);
        showEmptySlotsCheck.setBackground(null);
        showEmptySlotsCheck.setOpaque(false);
        showEmptySlotsCheck.setSelected(true);
        showEmptySlotsCheck.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add components
        panel.add(title);
        panel.add(Box.createVerticalStrut(10));
        panel.add(showBuyOffersCheck);
        panel.add(Box.createVerticalStrut(5));
        panel.add(showSellOffersCheck);
        panel.add(Box.createVerticalStrut(5));
        panel.add(showEmptySlotsCheck);

        return panel;
    }

    /**
     * Creates the main offers display panel
     */
    private JPanel createOffersPanel() {
        // Create a modern card-based layout for offers
        JPanel offersPanel = new JPanel();
        offersPanel.setLayout(new BoxLayout(offersPanel, BoxLayout.Y_AXIS));
        offersPanel.setBackground(StyleManager.PANEL_BG);
        offersPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create buy offers section
        JPanel buyOffersSection = createOfferSection("Buy Offers", 0, 3);
        buyOffersSection.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Create sell offers section
        JPanel sellOffersSection = createOfferSection("Sell Offers", 4, 7);
        sellOffersSection.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add sections to panel
        offersPanel.add(buyOffersSection);
        offersPanel.add(Box.createVerticalStrut(30));
        offersPanel.add(sellOffersSection);
        offersPanel.add(Box.createVerticalGlue());

        return offersPanel;
    }

    /**
     * Creates a section for a group of offers (buy or sell)
     */
    private JPanel createOfferSection(String title, int startSlot, int endSlot) {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setOpaque(false);

        // Section title
        JLabel sectionTitle = new JLabel(title);
        sectionTitle.setFont(StyleManager.REGULAR_FONT_BOLD);
        sectionTitle.setForeground(StyleManager.FOREGROUND);
        sectionTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Add title
        section.add(sectionTitle);
        section.add(Box.createVerticalStrut(15));

        // Create a panel for the offer cards
        JPanel cardsPanel = new JPanel();
        cardsPanel.setLayout(new BoxLayout(cardsPanel, BoxLayout.Y_AXIS));
        cardsPanel.setOpaque(false);
        cardsPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Create offer cards
        for (int i = startSlot; i <= endSlot; i++) {
            OfferDisplayPanel panel = new OfferDisplayPanel(i);
            slotPanels.put(i, panel);
            panel.setAlignmentX(Component.LEFT_ALIGNMENT);
            cardsPanel.add(panel);

            // Add spacing between cards
            if (i < endSlot) {
                cardsPanel.add(Box.createVerticalStrut(10));
            }
        }

        // Add cards to section
        section.add(cardsPanel);

        return section;
    }

    /**
     * Updates all slot panels with current GE data
     * Shows a brief animation to indicate real-time updates
     */
    public void updateOffers() {
        // Show update indicator
        showUpdateIndicator();

        GrandExchangeItem[] geItems = GrandExchange.getItems();

        if (geItems == null) {
            return;
        }

        // Count different types of offers
        int buyOffers = 0;
        int sellOffers = 0;
        int emptySlots = 0;
        int completedOffers = 0;

        for (int i = 0; i < 8 && i < geItems.length; i++) {
            OfferDisplayPanel panel = slotPanels.get(i);
            if (panel != null) {
                GrandExchangeItem geItem = (i < geItems.length) ? geItems[i] : null;
                panel.updateOffer(geItem);

                // Count offer types
                if (geItem != null && geItem.getStatus() != org.dreambot.api.methods.grandexchange.Status.EMPTY) {
                    if (geItem.getStatus() == org.dreambot.api.methods.grandexchange.Status.BUY_COLLECT ||
                        geItem.getStatus() == org.dreambot.api.methods.grandexchange.Status.SELL_COLLECT) {
                        completedOffers++;
                    } else if (geItem.isBuyOffer()) {
                        buyOffers++;
                    } else {
                        sellOffers++;
                    }
                } else {
                    emptySlots++;
                }
            }
        }

        // Update statistics in sidebar
        updateStatistics(buyOffers, sellOffers, emptySlots, completedOffers);

        // Update status count label
        int activeOffers = buyOffers + sellOffers;
        statusCountLabel.setText(activeOffers + " active offer" + (activeOffers != 1 ? "s" : ""));
    }

    /**
     * Inner class representing a single GE slot display
     */
    private class OfferDisplayPanel extends JPanel {
        private final int slotNumber;
        private final JLabel itemNameLabel;
        private final JLabel statusLabel;
        private final JLabel priceLabel;
        private final JLabel quantityLabel;
        private final JProgressBar progressBar;
        private final JPanel progressPanel;
        private final JPanel statusIndicator;

        // Colors for different offer types
        private final Color BUY_COLOR = StyleManager.WARNING; // Orange for buy offers
        private final Color SELL_COLOR = StyleManager.INFO; // Blue for sell offers
        private final Color COMPLETE_COLOR = StyleManager.SUCCESS; // Green for completed offers
        private final Color EMPTY_COLOR = StyleManager.FOREGROUND_SECONDARY; // Gray for empty slots

        public OfferDisplayPanel(int slotNumber) {
            this.slotNumber = slotNumber;

            // Setup panel with modern styling - card-based design
            setLayout(new BorderLayout(0, 0));
            setBackground(new Color(40, 40, 45)); // Slightly darker than panel background
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(50, 50, 55), 1),
                BorderFactory.createEmptyBorder(0, 0, 0, 0)
            ));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 120)); // Fixed height, flexible width

            // Left panel with slot number and status indicator
            JPanel leftPanel = new JPanel(new BorderLayout());
            leftPanel.setPreferredSize(new Dimension(60, 0));
            leftPanel.setBackground(new Color(35, 35, 40)); // Darker than card background
            leftPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            // Slot number
            JLabel slotLabel = new JLabel("#" + (slotNumber + 1));
            slotLabel.setFont(StyleManager.HEADER_FONT_SMALL);
            slotLabel.setForeground(StyleManager.FOREGROUND);
            slotLabel.setHorizontalAlignment(SwingConstants.CENTER);

            // Status indicator
            statusIndicator = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(getBackground());
                    g2.fillOval(0, 0, getWidth(), getHeight());
                    g2.dispose();
                }
            };
            statusIndicator.setOpaque(false);
            statusIndicator.setPreferredSize(new Dimension(12, 12));
            statusIndicator.setBackground(EMPTY_COLOR);
            statusIndicator.setAlignmentX(Component.CENTER_ALIGNMENT);

            JPanel indicatorPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            indicatorPanel.setOpaque(false);
            indicatorPanel.add(statusIndicator);

            leftPanel.add(slotLabel, BorderLayout.CENTER);
            leftPanel.add(indicatorPanel, BorderLayout.SOUTH);

            // Main content panel
            JPanel contentPanel = new JPanel();
            contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
            contentPanel.setBackground(new Color(40, 40, 45));
            contentPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            // Item name with better styling
            itemNameLabel = new JLabel("Empty");
            itemNameLabel.setFont(StyleManager.REGULAR_FONT_BOLD);
            itemNameLabel.setForeground(StyleManager.FOREGROUND);
            itemNameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

            // Status label
            statusLabel = new JLabel("No Offer");
            statusLabel.setFont(StyleManager.SMALL_FONT);
            statusLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
            statusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

            // Details panel with price and quantity
            JPanel detailsPanel = new JPanel(new GridLayout(1, 2, 15, 0));
            detailsPanel.setOpaque(false);
            detailsPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
            detailsPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

            // Price panel
            JPanel pricePanel = new JPanel(new BorderLayout());
            pricePanel.setOpaque(false);
            JLabel priceTitleLabel = new JLabel("Price");
            priceTitleLabel.setFont(StyleManager.SMALL_FONT);
            priceTitleLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
            priceLabel = new JLabel("");
            priceLabel.setFont(StyleManager.REGULAR_FONT_BOLD);
            priceLabel.setForeground(StyleManager.FOREGROUND);
            pricePanel.add(priceTitleLabel, BorderLayout.NORTH);
            pricePanel.add(priceLabel, BorderLayout.CENTER);

            // Quantity panel
            JPanel quantityPanel = new JPanel(new BorderLayout());
            quantityPanel.setOpaque(false);
            JLabel quantityTitleLabel = new JLabel("Quantity");
            quantityTitleLabel.setFont(StyleManager.SMALL_FONT);
            quantityTitleLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
            quantityLabel = new JLabel("");
            quantityLabel.setFont(StyleManager.REGULAR_FONT_BOLD);
            quantityLabel.setForeground(StyleManager.FOREGROUND);
            quantityPanel.add(quantityTitleLabel, BorderLayout.NORTH);
            quantityPanel.add(quantityLabel, BorderLayout.CENTER);

            detailsPanel.add(pricePanel);
            detailsPanel.add(quantityPanel);

            // Progress panel with modern progress bar
            progressPanel = new JPanel(new BorderLayout());
            progressPanel.setOpaque(false);
            progressPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
            progressPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
            progressPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 20));

            progressBar = new JProgressBar(0, 100);
            progressBar.setBackground(new Color(50, 50, 55));
            progressBar.setForeground(EMPTY_COLOR);
            progressBar.setBorderPainted(false);
            progressBar.setStringPainted(true); // Show percentage
            progressBar.setString("0%");
            progressBar.setPreferredSize(new Dimension(getWidth(), 8));
            progressPanel.add(progressBar, BorderLayout.CENTER);

            // Add components to content panel
            contentPanel.add(itemNameLabel);
            contentPanel.add(Box.createVerticalStrut(4));
            contentPanel.add(statusLabel);
            contentPanel.add(Box.createVerticalStrut(15));
            contentPanel.add(detailsPanel);
            contentPanel.add(Box.createVerticalStrut(10));
            contentPanel.add(progressPanel);

            // Add components to main panel
            add(leftPanel, BorderLayout.WEST);
            add(contentPanel, BorderLayout.CENTER);

            // Set initial empty state
            setEmptyState();

            // Add hover effect
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    setBackground(new Color(45, 45, 50));
                    setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(StyleManager.ACCENT, 1),
                        BorderFactory.createEmptyBorder(0, 0, 0, 0)
                    ));
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    setBackground(new Color(40, 40, 45));
                    setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(50, 50, 55), 1),
                        BorderFactory.createEmptyBorder(0, 0, 0, 0)
                    ));
                }
            });
        }

        /**
         * Updates this panel with current GE item data
         */
        public void updateOffer(GrandExchangeItem geItem) {
            if (geItem == null || geItem.getStatus() == org.dreambot.api.methods.grandexchange.Status.EMPTY) {
                setEmptyState();
                return;
            }

            // Set item information with improved formatting
            itemNameLabel.setText(geItem.getName());
            statusLabel.setText(geItem.getStatus().toString().replace("_", " "));

            // Format price with commas
            int price = geItem.getPrice();
            priceLabel.setText(String.format("%,d gp", price));

            // Set quantity info with percentage
            int quantityTotal = geItem.getAmount();
            int quantityTraded = geItem.getTransferredAmount();
            int percentComplete = (quantityTotal > 0) ? (quantityTraded * 100 / quantityTotal) : 0;
            quantityLabel.setText(String.format("%d / %d", quantityTraded, quantityTotal));

            // Update progress bar
            progressBar.setValue(percentComplete);
            progressBar.setString(percentComplete + "%");
            progressBar.setVisible(true);

            // Color code based on the GE status
            Color statusColor;
            Color progressColor;

            if (geItem.getStatus() == org.dreambot.api.methods.grandexchange.Status.BUY_COLLECT ||
                geItem.getStatus() == org.dreambot.api.methods.grandexchange.Status.SELL_COLLECT) {
                // Completed offers
                statusColor = COMPLETE_COLOR;
                progressColor = COMPLETE_COLOR;
            } else if (geItem.isBuyOffer()) {
                // Buy offers
                statusColor = BUY_COLOR;
                progressColor = BUY_COLOR;
            } else {
                // Sell offers
                statusColor = SELL_COLOR;
                progressColor = SELL_COLOR;
            }

            // Update status indicator colors
            statusLabel.setForeground(statusColor);
            progressBar.setForeground(progressColor);
            statusIndicator.setBackground(statusColor);

            // Highlight panel if it's being used by our script
            boolean isScriptSlot = false;
            for (FlipItem item : config.getItemsToFlip()) {
                if (item.getBuyGeSlot() == slotNumber || item.getSellGeSlot() == slotNumber) {
                    isScriptSlot = true;
                    break;
                }
            }

            // Apply special styling for script slots
            if (isScriptSlot) {
                // Add a special border for script-managed slots
                setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(statusColor, 2),
                    BorderFactory.createEmptyBorder(0, 0, 0, 0)
                ));

                // Make the slot number label match the status color
                Component[] leftPanelComponents = ((Container)getComponent(0)).getComponents();
                if (leftPanelComponents.length > 0 && leftPanelComponents[0] instanceof JLabel) {
                    ((JLabel)leftPanelComponents[0]).setForeground(statusColor);
                }
            } else {
                // Regular border for non-script slots
                setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(50, 50, 55), 1),
                    BorderFactory.createEmptyBorder(0, 0, 0, 0)
                ));

                // Reset slot number label color
                Component[] leftPanelComponents = ((Container)getComponent(0)).getComponents();
                if (leftPanelComponents.length > 0 && leftPanelComponents[0] instanceof JLabel) {
                    ((JLabel)leftPanelComponents[0]).setForeground(StyleManager.FOREGROUND);
                }
            }
        }

        /**
         * Creates a border with a glow effect
         */
        private Border createGlowBorder(Color color, int thickness) {
            return BorderFactory.createCompoundBorder(
                new Border() {
                    @Override
                    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                        // Create glow effect
                        for (int i = 0; i < thickness; i++) {
                            g2.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 150 - (i * 30)));
                            g2.draw(new RoundRectangle2D.Double(x + i, y + i, width - (i * 2) - 1, height - (i * 2) - 1, 8, 8));
                        }

                        g2.dispose();
                    }

                    @Override
                    public Insets getBorderInsets(Component c) {
                        return new Insets(thickness, thickness, thickness, thickness);
                    }

                    @Override
                    public boolean isBorderOpaque() {
                        return false;
                    }
                },
                BorderFactory.createEmptyBorder(8, 8, 8, 8)
            );
        }

        /**
         * Sets this panel to empty state
         */
        private void setEmptyState() {
            itemNameLabel.setText("Empty");
            statusLabel.setText("No Offer");
            statusLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
            priceLabel.setText("");
            quantityLabel.setText("");

            progressBar.setValue(0);
            progressBar.setString("0%");
            progressBar.setVisible(false);
            progressBar.setForeground(EMPTY_COLOR);

            // Reset border
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(50, 50, 55), 1),
                BorderFactory.createEmptyBorder(0, 0, 0, 0)
            ));
            setBackground(new Color(40, 40, 45));

            // Reset status indicator
            statusIndicator.setBackground(EMPTY_COLOR);

            // Reset slot number label color
            Component[] leftPanelComponents = ((Container)getComponent(0)).getComponents();
            if (leftPanelComponents.length > 0 && leftPanelComponents[0] instanceof JLabel) {
                ((JLabel)leftPanelComponents[0]).setForeground(StyleManager.FOREGROUND);
            }
        }
    }

    /**
     * Updates the statistics in the sidebar
     */
    private void updateStatistics(int buyOffers, int sellOffers, int emptySlots, int completedOffers) {
        // Find the stats panel in the sidebar
        Component[] components = getComponents();
        if (components.length > 0 && components[0] instanceof JPanel) {
            JPanel container = (JPanel) components[0];
            Component[] containerComponents = container.getComponents();

            // Find the sidebar
            for (Component component : containerComponents) {
                if (component instanceof JPanel && component.getPreferredSize().width == 220) {
                    JPanel sidebar = (JPanel) component;
                    Component[] sidebarComponents = sidebar.getComponents();

                    // Find the stats panel
                    for (Component sidebarComponent : sidebarComponents) {
                        if (sidebarComponent instanceof JPanel) {
                            JPanel panel = (JPanel) sidebarComponent;
                            Component[] panelComponents = panel.getComponents();

                            // Look for the stats items
                            for (int i = 0; i < panelComponents.length; i++) {
                                if (panelComponents[i] instanceof JPanel) {
                                    JPanel statItem = (JPanel) panelComponents[i];
                                    Component[] statComponents = statItem.getComponents();

                                    // Find the value label
                                    for (Component statComponent : statComponents) {
                                        if (statComponent instanceof JLabel) {
                                            JLabel label = (JLabel) statComponent;
                                            String text = label.getText();

                                            // Update the appropriate stat
                                            if (text.contains("Buy Offers")) {
                                                updateStatValue(statItem, String.valueOf(buyOffers), StyleManager.WARNING);
                                            } else if (text.contains("Sell Offers")) {
                                                updateStatValue(statItem, String.valueOf(sellOffers), StyleManager.INFO);
                                            } else if (text.contains("Empty Slots")) {
                                                updateStatValue(statItem, String.valueOf(emptySlots), StyleManager.FOREGROUND_SECONDARY);
                                            } else if (text.contains("Completed Today")) {
                                                updateStatValue(statItem, String.valueOf(completedOffers), StyleManager.SUCCESS);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Updates a stat value in the sidebar
     */
    private void updateStatValue(JPanel statItem, String value, Color valueColor) {
        Component[] components = statItem.getComponents();
        for (Component component : components) {
            if (component instanceof JLabel && ((JLabel) component).getText().length() <= 3) {
                JLabel valueLabel = (JLabel) component;
                valueLabel.setText(value);
                valueLabel.setForeground(valueColor);
                break;
            }
        }
    }

    /**
     * Shows the update indicator briefly to indicate real-time updates
     */
    private void showUpdateIndicator() {
        // Stop any existing fade timer
        if (fadeTimer != null && fadeTimer.isRunning()) {
            fadeTimer.stop();
        }

        // Show the indicator
        updateIndicator.setVisible(true);

        // Create a timer to hide it after 500ms
        fadeTimer = new Timer(500, e -> {
            updateIndicator.setVisible(false);
            ((Timer)e.getSource()).stop();
        });
        fadeTimer.setRepeats(false);
        fadeTimer.start();
    }
}