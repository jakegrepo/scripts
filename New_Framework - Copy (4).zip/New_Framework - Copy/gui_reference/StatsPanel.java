package scripts.ScarFlip.gui;

import core.gui.style.StyleManager;
import org.dreambot.api.methods.container.impl.Inventory;
import scripts.ScarFlip.config.CompletedFlip;
import scripts.ScarFlip.config.ScarFlipConfig;
import scripts.ScarFlip.ScarFlip;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.text.NumberFormat;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * An enhanced panel for displaying statistics about the script's performance.
 * Redesigned with modern visuals and improved data presentation.
 */
public class StatsPanel extends JPanel {

    private final ScarFlipConfig config;
    private final NumberFormat numberFormat = NumberFormat.getIntegerInstance();
    private ScarFlip script; // Reference to main script for ProfitTracker access

    // Stats labels
    private final JLabel runtimeLabel;
    private final JLabel profitLabel;
    private final JLabel calculatedProfitLabel; // New label for accurate profit
    private final JLabel assetValueLabel; // New label for total asset value
    private final JLabel flipsCompletedLabel;
    private final JLabel currentGpLabel;
    private final JLabel profitPerHourLabel;
    private final JLabel statusLabel;

    // Stats values
    private long startTime;
    private long lastRefreshTime;

    // Data visualization components
    private JProgressBar profitProgressBar;
    private JPanel profitTrendPanel;

    // Constants for styling
    private static final Color PROFIT_COLOR = new Color(75, 210, 140);
    private static final Color LOSS_COLOR = new Color(235, 90, 90);
    private static final int STAT_LABEL_WIDTH = 150;

    public StatsPanel(ScarFlipConfig config) {
        this.config = config;
        this.startTime = System.currentTimeMillis();
        this.lastRefreshTime = startTime;

        // Set up panel with modern layout
        setLayout(new BorderLayout(10, 10));
        setBackground(StyleManager.CARD_BG);
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // Create main stats grid
        JPanel statsGrid = new JPanel(new GridLayout(4, 2, 15, 10));
        statsGrid.setOpaque(false);

        // Initialize labels with modern styling
        runtimeLabel = createStatsLabel("Runtime", "00:00:00", StyleManager.ACCENT);
        profitLabel = createStatsLabel("Trade Profit", "0 gp", PROFIT_COLOR);
        calculatedProfitLabel = createStatsLabel("Actual Profit", "Calculating...", StyleManager.ACCENT_TEAL);
        assetValueLabel = createStatsLabel("Total Assets", "Calculating...", StyleManager.ACCENT_YELLOW);
        flipsCompletedLabel = createStatsLabel("Flips Completed", "0", StyleManager.ACCENT_PURPLE);
        currentGpLabel = createStatsLabel("Current GP", "Calculating...", StyleManager.ACCENT_YELLOW);
        profitPerHourLabel = createStatsLabel("Profit/Hour", "0 gp/hr", PROFIT_COLOR);
        statusLabel = createStatsLabel("Status", "Initializing", StyleManager.INFO);

        // Add components to stats grid
        statsGrid.add(runtimeLabel);
        statsGrid.add(profitLabel);
        statsGrid.add(calculatedProfitLabel);
        statsGrid.add(assetValueLabel);
        statsGrid.add(flipsCompletedLabel);
        statsGrid.add(currentGpLabel);
        statsGrid.add(profitPerHourLabel);
        statsGrid.add(statusLabel);

        // Create profit visualization panel
        JPanel visualPanel = new JPanel(new BorderLayout(5, 5));
        visualPanel.setOpaque(false);
        visualPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        // Create profit progress bar
        profitProgressBar = new JProgressBar(0, 100);
        profitProgressBar.setValue(0);
        profitProgressBar.setStringPainted(true);
        profitProgressBar.setString("0% of Target Profit");
        profitProgressBar.setForeground(PROFIT_COLOR);
        profitProgressBar.setBackground(StyleManager.COMPONENT_BG);
        profitProgressBar.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));

        // Add profit visualization
        visualPanel.add(profitProgressBar, BorderLayout.NORTH);

        // Add all components to main panel
        add(statsGrid, BorderLayout.CENTER);
        add(visualPanel, BorderLayout.SOUTH);
    }

    /**
     * Set reference to main script to access ProfitTracker
     */
    public void setScript(ScarFlip script) {
        this.script = script;
    }

    /**
     * Updates all stats with current values and visualizations
     */
    public void updateStats() {
        long now = System.currentTimeMillis();
        long runtime = now - startTime;

        // Update runtime
        updateStatsLabel(runtimeLabel, formatTime(runtime), StyleManager.ACCENT);

        // Get completed flip count and total profit
        List<CompletedFlip> completedFlips = config.getCompletedFlips();
        int flipsCount = completedFlips.size();
        long totalProfit = config.getTotalProfit();

        // Update flip count
        updateStatsLabel(flipsCompletedLabel, String.valueOf(flipsCount), StyleManager.ACCENT_PURPLE);

        // Update profit with color coding
        Color profitColor = totalProfit > 0 ? PROFIT_COLOR : (totalProfit < 0 ? LOSS_COLOR : StyleManager.FOREGROUND);
        updateStatsLabel(profitLabel, formatGp(totalProfit), profitColor);

        // Update calculated profit if script is available
        if (script != null && script.getProfitTracker() != null) {
            long calculatedProfit = config.getCalculatedProfit();
            Color calcProfitColor = calculatedProfit > 0 ? PROFIT_COLOR :
                                   (calculatedProfit < 0 ? LOSS_COLOR : StyleManager.FOREGROUND);
            updateStatsLabel(calculatedProfitLabel, formatGp(calculatedProfit), calcProfitColor);

            // Update asset value
            long assetValue = script.getProfitTracker().getTotalAssetValue();
            updateStatsLabel(assetValueLabel, formatGp(assetValue), StyleManager.ACCENT_YELLOW);
        }

        // Update current GP
        long currentGp = Inventory.count("Coins");
        updateStatsLabel(currentGpLabel, formatGp(currentGp), StyleManager.ACCENT_YELLOW);

        // Calculate and update profit per hour
        if (runtime > 0) {
            // Use calculated profit for profit/hour if available
            long profitToUse = (script != null && script.getProfitTracker() != null) ?
                               config.getCalculatedProfit() : totalProfit;

            // Avoid division by zero
            long profitPerHour = (long) ((double) profitToUse / ((double) runtime / 3600000));

            // Determine color based on profit per hour
            Color hourlyColor;
            if (profitPerHour > 500000) {
                hourlyColor = PROFIT_COLOR;
            } else if (profitPerHour > 0) {
                hourlyColor = new Color(60, 180, 120); // Medium green
            } else if (profitPerHour < 0) {
                hourlyColor = LOSS_COLOR;
            } else {
                hourlyColor = StyleManager.FOREGROUND;
            }

            updateStatsLabel(profitPerHourLabel, formatGp(profitPerHour) + "/hr", hourlyColor);
        }

        // Update profit progress bar
        updateProfitProgressBar(totalProfit);

        // Save last update time
        lastRefreshTime = now;
    }

    /**
     * Updates the profit progress bar based on target profit
     */
    private void updateProfitProgressBar(long totalProfit) {
        // Set a target profit goal (can be made configurable)
        long targetProfit = 1_000_000; // 1M GP

        // Calculate percentage of target reached
        int percentage = (int) Math.min(100, Math.max(0, (totalProfit * 100) / targetProfit));

        // Update progress bar
        profitProgressBar.setValue(percentage);
        profitProgressBar.setString(percentage + "% of Target Profit");

        // Color based on profit/loss
        if (totalProfit >= 0) {
            profitProgressBar.setForeground(PROFIT_COLOR);
        } else {
            profitProgressBar.setForeground(LOSS_COLOR);
        }
    }

    /**
     * Sets the current script status with appropriate color
     */
    public void setStatus(String status) {
        Color statusColor = StyleManager.INFO;

        // Color-code status based on keywords
        if (status.contains("Error") || status.contains("error") || status.contains("Failed")) {
            statusColor = StyleManager.ERROR;
        } else if (status.contains("Running") || status.contains("Executing")) {
            statusColor = StyleManager.SUCCESS;
        } else if (status.contains("Analyzing") || status.contains("Waiting")) {
            statusColor = StyleManager.WARNING;
        }

        updateStatsLabel(statusLabel, status, statusColor);
    }

    /**
     * Creates a styled label for displaying stats with color coding
     */
    private JLabel createStatsLabel(String name, String value, Color valueColor) {
        JPanel container = new JPanel(new BorderLayout(5, 0));
        container.setOpaque(false);

        JLabel nameLabel = new JLabel(name + ":");
        nameLabel.setFont(StyleManager.REGULAR_FONT);
        nameLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
        nameLabel.setPreferredSize(new Dimension(STAT_LABEL_WIDTH, 25));

        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(StyleManager.STATS_FONT);
        valueLabel.setForeground(valueColor);

        container.add(nameLabel, BorderLayout.WEST);
        container.add(valueLabel, BorderLayout.CENTER);

        JLabel wrapperLabel = new JLabel();
        wrapperLabel.setLayout(new BorderLayout());
        wrapperLabel.add(container);

        return wrapperLabel;
    }

    /**
     * Updates the text of a stats label
     */
    private void updateStatsLabel(JLabel label, String value, Color valueColor) {
        JPanel container = (JPanel) ((BorderLayout) label.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        JLabel valueLabel = (JLabel) ((BorderLayout) container.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        valueLabel.setText(value);
        valueLabel.setForeground(valueColor);
    }

    /**
     * Creates a stats text with consistent formatting - kept for backward compatibility
     */
    private String createStatsText(String name, String value) {
        return "<html><b>" + name + ":</b> " + value + "</html>";
    }

    /**
     * Formats a time in milliseconds to HH:MM:SS
     */
    private String formatTime(long ms) {
        long s = TimeUnit.MILLISECONDS.toSeconds(ms) % 60;
        long m = TimeUnit.MILLISECONDS.toMinutes(ms) % 60;
        long h = TimeUnit.MILLISECONDS.toHours(ms);
        return String.format("%02d:%02d:%02d", h, m, s);
    }

    /**
     * Formats GP value with commas and 'gp' suffix
     */
    private String formatGp(long gp) {
        return numberFormat.format(gp) + " gp";
    }

    /**
     * Reset the start time for calculating stats
     */
    public void resetRuntime() {
        this.startTime = System.currentTimeMillis();
        this.lastRefreshTime = startTime;
    }
}