package scripts.ScarFlip.gui;

import org.dreambot.api.methods.grandexchange.GrandExchange;
import org.dreambot.api.methods.grandexchange.GrandExchangeItem;
import scripts.ScarFlip.config.FlipItem;
import scripts.ScarFlip.config.ScarFlipConfig;
import scripts.ScarFlip.enums.Status;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class FlipItemTableModel extends AbstractTableModel {

    private final ScarFlipConfig config;
    private List<FlipItem> currentItems; // Local cache to avoid concurrent modification issues during rendering
    private final String[] columnNames = {
            "Item Name", "Offer Type", "Status", "Slot", "Quantity", "Price",
            "Insta Sell", "Insta Buy", "Margin GP", "Margin %", "Stale Timer"
    };

    public FlipItemTableModel(ScarFlipConfig config) {
        this.config = config;
        this.currentItems = new ArrayList<>(config.getItemsToFlip()); // Initial copy
    }

    // Method to be called periodically to refresh data from config
    public void updateData() {
        // Get a fresh copy from the potentially updated config list
        this.currentItems = new ArrayList<>(config.getItemsToFlip());
        // Notify the table that the data has changed
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        // Each item can have both a buy and sell offer, so we need to count both
        int totalRows = 0;
        GrandExchangeItem[] geItems = GrandExchange.getItems();
        
        for (FlipItem item : currentItems) {
            // Check buy offer
            if (item.hasActiveBuyOffer()) {
                totalRows++;
            }
            
            // Check sell offer
            if (item.hasActiveSellOffer()) {
                totalRows++;
            }
        }
        return totalRows;
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0: return String.class;  // Item Name
            case 1: return String.class;  // Offer Type
            case 2: return Status.class;  // Status
            case 3: case 4: case 5: case 6: case 7: case 8: return Integer.class; // Slot, Qty, Prices, Margin GP
            case 9: return Double.class;  // Margin %
            case 10: return String.class; // Stale Timer
            default: return Object.class;
        }
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        // Find the appropriate item for this row
        FlipItem item = null;
        boolean isBuyOffer = false;
        int currentRow = 0;
        
        for (FlipItem currentItem : currentItems) {
            // Check buy offer
            if (currentItem.hasActiveBuyOffer()) {
                if (currentRow == rowIndex) {
                    item = currentItem;
                    isBuyOffer = true;
                    break;
                }
                currentRow++;
            }
            
            // Check sell offer
            if (currentItem.hasActiveSellOffer()) {
                if (currentRow == rowIndex) {
                    item = currentItem;
                    isBuyOffer = false;
                    break;
                }
                currentRow++;
            }
        }
        
        if (item == null) return null;

        switch (columnIndex) {
            case 0: return item.getItemName();
            case 1: return isBuyOffer ? "Buy" : "Sell";
            case 2: return item.getStatus();
            case 3: return isBuyOffer ? 
                    (item.getBuyGeSlot() == -1 ? 0 : item.getBuyGeSlot() + 1) :
                    (item.getSellGeSlot() == -1 ? 0 : item.getSellGeSlot() + 1);
            case 4: return isBuyOffer ? item.getBuyQuantityInOffer() : item.getSellQuantityInOffer();
            case 5: return isBuyOffer ? item.getInstantSellPrice() : item.getInstantBuyPrice();
            case 6: return item.getInstantSellPrice() <= 0 ? 0 : item.getInstantSellPrice();
            case 7: return item.getInstantBuyPrice() <= 0 ? 0 : item.getInstantBuyPrice();
            case 8: return item.hasValidPrices() ? item.getMargin() : 0;
            case 9: return item.hasValidPrices() ? item.getMarginPercent() : 0.0;
            case 10: return formatStaleTimer(item, isBuyOffer);
            default: return null;
        }
    }

    private String formatStaleTimer(FlipItem item, boolean isBuyOffer) {
        // Only show stale timer for active offers
        if (item.getStatus() != Status.BUYING && item.getStatus() != Status.SELLING) {
            return "-";
        }
        
        // Get the appropriate start time based on offer type
        long startTime = isBuyOffer ? item.getBuyOfferStartTime() : item.getSellOfferStartTime();
        
        if (startTime <= 0) {
            return "-";
        }
        
        // Get stale threshold from config if available
        long staleThresholdMillis = 300000; // Default 5 minutes
        try {
            if (config != null && config.getStaleOfferTimeoutMillis() > 0) {
                staleThresholdMillis = config.getStaleOfferTimeoutMillis();
            }
        } catch (Exception e) {
            // If we can't get the timeout, use default
        }
        
        // Calculate how close to stale threshold based on start time
        long timeSinceStart = System.currentTimeMillis() - startTime;
        double stalePercentage = (double) timeSinceStart / staleThresholdMillis;
        
        // Format the time display
        long seconds = TimeUnit.MILLISECONDS.toSeconds(timeSinceStart) % 60;
        long minutes = TimeUnit.MILLISECONDS.toMinutes(timeSinceStart) % 60;
        long hours = TimeUnit.MILLISECONDS.toHours(timeSinceStart);
        
        String timeFormat;
        if (hours > 0) {
            timeFormat = String.format("%dh %dm %ds", hours, minutes, seconds);
        } else {
            timeFormat = String.format("%dm %ds", minutes, seconds);
        }
        
        // Add visual indicators based on stale percentage
        if (stalePercentage >= 0.8) {
            return "⚠️ " + timeFormat; // Warning icon for >80% of threshold
        } else if (stalePercentage >= 0.5) {
            return "⏳ " + timeFormat; // Hourglass icon for >50% of threshold
        } else {
            return timeFormat;
        }
    }

    // Helper method to get the FlipItem at a specific row
    public FlipItem getItemAt(int rowIndex) {
        int currentRow = 0;
        for (FlipItem item : currentItems) {
            // Check buy offer
            if (item.hasActiveBuyOffer()) {
                if (currentRow == rowIndex) return item;
                currentRow++;
            }
            
            // Check sell offer
            if (item.hasActiveSellOffer()) {
                if (currentRow == rowIndex) return item;
                currentRow++;
            }
        }
        return null;
    }
} 