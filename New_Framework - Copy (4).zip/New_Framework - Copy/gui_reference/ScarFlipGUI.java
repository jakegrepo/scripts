package scripts.ScarFlip.gui;

import core.gui.components.LoadingIndicator;
import core.gui.components.ModernCardPanel;
import core.gui.components.ToastNotification;
import core.gui.style.StyleManager;
import org.dreambot.api.utilities.Logger;
import scripts.ScarFlip.ScarFlip;
import scripts.ScarFlip.config.FlipItem;
import scripts.ScarFlip.config.ScarFlipConfig;
import scripts.ScarFlip.context.FlipContext;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Modern GUI for the ScarFlip script with enhanced visuals and user experience
 */
public class ScarFlipGUI extends JFrame {

    private final ScarFlipConfig config;
    private final ScarFlip script;

    // Components
    private StatsPanel statsPanel;
    private ItemManagementPanel itemManagementPanel;
    private ActiveOffersPanel activeOffersPanel;
    private FlipItemsTablePanel flipItemsTablePanel;
    private SettingsPanel settingsPanel;
    private JTabbedPane tabbedPane;

    // Controls
    private JButton startButton;
    private JButton stopButton;

    // Status components
    private JLabel statusLabel;
    private LoadingIndicator loadingIndicator;

    // Update timer
    private Timer updateTimer;
    private volatile boolean scriptRunning = false;
    private long scriptStartTime = System.currentTimeMillis();

    public ScarFlipGUI(ScarFlip script, ScarFlipConfig config) {
        this.script = script;
        this.config = config;

        setTitle("ScarFlip - Grand Exchange Flipping");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setMinimumSize(StyleManager.MAIN_WINDOW_SIZE);

        // Initialize components
        initComponents();

        // Set up layout
        layoutComponents();

        // Initialize event handlers
        initEventHandlers();

        // Start update timer
        startUpdateTimer();

        Logger.log("GUI Initialized");
    }

    private void initComponents() {
        // Create the custom panels with modern styling
        itemManagementPanel = new ItemManagementPanel(config);
        activeOffersPanel = new ActiveOffersPanel(config);
        flipItemsTablePanel = new FlipItemsTablePanel(config);
        settingsPanel = new SettingsPanel(config);

        // Connect the table model to the item management panel for updates
        itemManagementPanel.setTableModel(flipItemsTablePanel.getTableModel());

        // Create status components
        statusLabel = new JLabel("Ready");
        statusLabel.setFont(StyleManager.REGULAR_FONT_BOLD);
        statusLabel.setForeground(StyleManager.FOREGROUND);

        loadingIndicator = new LoadingIndicator(24, StyleManager.ACCENT);
        loadingIndicator.setVisible(false);

        // Create control buttons with modern styling
        startButton = new JButton("Start Script");
        StyleManager.stylePrimaryButton(startButton);

        stopButton = new JButton("Stop Script");
        StyleManager.styleButton(stopButton);
        stopButton.setEnabled(false);

        // Create tabbed pane for main content with modern styling
        tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        StyleManager.styleTabbedPane(tabbedPane);
    }

    private void layoutComponents() {
        // Set background color for the frame
        getContentPane().setBackground(StyleManager.BACKGROUND);

        // Use modern layout with proper spacing
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(StyleManager.BACKGROUND);

        // Create a header panel with logo and controls
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(25, 25, 30)); // Darker than background
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // Create logo/title
        JLabel titleLabel = new JLabel("ScarFlip");
        titleLabel.setFont(new Font(StyleManager.PRIMARY_FONT, Font.BOLD, 18));
        titleLabel.setForeground(StyleManager.ACCENT_LIGHTER);

        // Create control buttons panel
        JPanel controlsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        controlsPanel.setOpaque(false);

        // Style buttons for header
        startButton.setForeground(Color.WHITE);
        startButton.setBackground(StyleManager.ACCENT_DARKER);
        startButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));

        stopButton.setForeground(Color.WHITE);
        stopButton.setBackground(StyleManager.ACCENT_DARKER);
        stopButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));

        // Add status indicator
        JPanel statusIndicator = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        statusIndicator.setOpaque(false);
        statusIndicator.add(loadingIndicator);
        statusIndicator.add(statusLabel);
        statusLabel.setForeground(Color.WHITE);

        controlsPanel.add(statusIndicator);
        controlsPanel.add(startButton);
        controlsPanel.add(stopButton);

        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(controlsPanel, BorderLayout.EAST);

        // Create content panel
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(StyleManager.BACKGROUND);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        // Create scroll pane for settings
        JScrollPane settingsScrollPane = new JScrollPane(settingsPanel);
        StyleManager.styleScrollPane(settingsScrollPane);

        // Add each panel to its own tab for better visibility and organization
        tabbedPane.addTab("Flip Items", flipItemsTablePanel);
        tabbedPane.addTab("Active Offers", activeOffersPanel);

        // Create a dashboard panel for overview
        JPanel dashboardPanel = createDashboardPanel();
        tabbedPane.addTab("Dashboard", dashboardPanel);

        // Add settings to its own tab
        tabbedPane.addTab("Settings", settingsScrollPane);

        // Style the tabs
        tabbedPane.setFont(StyleManager.REGULAR_FONT_BOLD);
        tabbedPane.setBackground(StyleManager.BACKGROUND);
        tabbedPane.setForeground(StyleManager.FOREGROUND);

        // Add tab change listener to force updates when switching tabs
        tabbedPane.addChangeListener(e -> {
            // Force immediate update when tab changes
            updateAllPanels();
        });

        // Add tabbed pane to content panel
        contentPanel.add(tabbedPane, BorderLayout.CENTER);

        // Add components to main panel
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        // Add main panel to frame
        setContentPane(mainPanel);
    }

    private void initEventHandlers() {
        // Start button
        startButton.addActionListener(e -> {
            // Save settings first
            settingsPanel.saveSettings();

            // Update UI state
            scriptRunning = true;
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
            setStatus("Running", true);

            // Signal the FlipContext to start from GUI
            if (script != null && script.getContext() != null) {
                FlipContext context = script.getContext();

                if (config.getItemsToFlip().isEmpty()) {
                    Logger.log("Warning: No items to analyze! Add items before starting.");
                    setStatus("No items to analyze", false);
                    ToastNotification.showWarning(this, "No items to analyze! Add items before starting.");

                    // Reset UI state
                    scriptRunning = false;
                    startButton.setEnabled(true);
                    stopButton.setEnabled(false);
                } else {
                    // Set the script state to analyzing market
                    context.setCurrentState(FlipContext.ScriptState.ANALYZING_MARKET);
                    Logger.log("GUI: Set script state to ANALYZING_MARKET");

                    // Make sure each item is added to the analysis list
                    for (FlipItem item : config.getItemsToFlip()) {
                        context.addItemToAnalyze(item.getItemName());
                        Logger.log("GUI: Added item for analysis: " + item.getItemName());
                    }

                    // Reset runtime for stats tracking
                    statsPanel.resetRuntime();

                    // Show success notification
                    ToastNotification.showSuccess(this, "Script started successfully!");
                }
            }

            Logger.log("GUI: Start button pressed");
        });

        // Stop button
        stopButton.addActionListener(e -> {
            // Update UI state
            scriptRunning = false;
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
            setStatus("Stopped by user", false);

            // Signal the script to stop
            if (script != null && script.getContext() != null) {
                script.getContext().setCurrentState(FlipContext.ScriptState.IDLE);
                Logger.log("GUI: Set script state to IDLE");
            }

            // Show notification
            ToastNotification.showInfo(this, "Script stopped");

            Logger.log("GUI: Stop button pressed");
        });

        // Window closing handler
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Ensure timer is stopped
                if (updateTimer != null && updateTimer.isRunning()) {
                    updateTimer.stop();
                }

                // Update script state if it was running
                if (scriptRunning && script != null && script.getContext() != null) {
                    script.getContext().setCurrentState(FlipContext.ScriptState.IDLE);
                    Logger.log("GUI: Set script state to IDLE (window closing)");
                }

                scriptRunning = false;
                Logger.log("GUI Disposed");
            }
        });
    }

    /**
     * Starts the timer for real-time updates of all panels
     */
    private void startUpdateTimer() {
        // Create a timer that updates every 500ms for more responsive real-time updates
        updateTimer = new Timer(500, e -> {
            updateAllPanels();
        });
        updateTimer.setInitialDelay(200); // Start updates sooner
        updateTimer.start();

        Logger.log("Real-time updates enabled");
    }

    @Override
    public void dispose() {
        // Stop the timer when the GUI is closed
        if (updateTimer != null && updateTimer.isRunning()) {
            updateTimer.stop();
        }
        scriptRunning = false;
        Logger.log("GUI Disposed");
        super.dispose();
    }

    // Method for the script to check if it should be running
    public boolean isScriptRunning() {
        return scriptRunning;
    }

    /**
     * Sets the status text and loading indicator
     */
    private void setStatus(String status, boolean loading) {
        statusLabel.setText(status);
        loadingIndicator.setVisible(loading);
        if (loading) {
            loadingIndicator.start();
        } else {
            loadingIndicator.stop();
        }
    }

    /**
     * Creates a dashboard panel with overview of all activities
     */
    private JPanel createDashboardPanel() {
        JPanel dashboardPanel = new JPanel(new BorderLayout(StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING));
        dashboardPanel.setBackground(StyleManager.PANEL_BG);
        dashboardPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create a grid layout for the dashboard cards
        JPanel cardsPanel = new JPanel(new GridLayout(2, 2, StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING));
        cardsPanel.setOpaque(false);

        // Create summary cards
        ModernCardPanel profitCard = createSummaryCard("Profit Overview", "profit");
        ModernCardPanel itemsCard = createSummaryCard("Items Overview", "items");
        ModernCardPanel offersCard = createSummaryCard("Active Offers", "offers");
        ModernCardPanel historyCard = createSummaryCard("Recent Activity", "history");

        // Add cards to the grid
        cardsPanel.add(profitCard);
        cardsPanel.add(itemsCard);
        cardsPanel.add(offersCard);
        cardsPanel.add(historyCard);

        // Add the cards panel to the dashboard
        dashboardPanel.add(cardsPanel, BorderLayout.CENTER);

        return dashboardPanel;
    }

    /**
     * Creates a summary card for the dashboard
     */
    private ModernCardPanel createSummaryCard(String title, String type) {
        ModernCardPanel card = new ModernCardPanel(title);
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);

        switch (type) {
            case "profit":
                // Profit overview content
                addLabelRow(content, "Total Profit:", "0 gp", StyleManager.SUCCESS);
                addLabelRow(content, "Profit Today:", "0 gp", StyleManager.SUCCESS);
                addLabelRow(content, "Profit/Hour:", "0 gp/hr", StyleManager.SUCCESS);
                addLabelRow(content, "Best Item:", "None", StyleManager.FOREGROUND);

                // Add a small profit chart
                JPanel chartPanel = new JPanel();
                chartPanel.setPreferredSize(new Dimension(200, 100));
                chartPanel.setBackground(StyleManager.COMPONENT_BG);
                chartPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
                chartPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
                content.add(chartPanel);
                break;

            case "items":
                // Items overview content
                addLabelRow(content, "Total Items:", "0", StyleManager.FOREGROUND);
                addLabelRow(content, "Active Items:", "0", StyleManager.WARNING);
                addLabelRow(content, "Completed Flips:", "0", StyleManager.SUCCESS);
                addLabelRow(content, "Avg. Margin:", "0%", StyleManager.INFO);

                // Add a button to add new items
                JButton addItemButton = new JButton("Add New Item");
                StyleManager.styleButton(addItemButton);
                addItemButton.setAlignmentX(Component.LEFT_ALIGNMENT);
                addItemButton.addActionListener(e -> {
                    // Switch to the Add Items tab
                    for (int i = 0; i < tabbedPane.getTabCount(); i++) {
                        if (tabbedPane.getTitleAt(i).equals("Add Items")) {
                            tabbedPane.setSelectedIndex(i);
                            break;
                        }
                    }
                });

                JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 10));
                buttonPanel.setOpaque(false);
                buttonPanel.add(addItemButton);
                buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
                content.add(buttonPanel);
                break;

            case "offers":
                // Active offers overview
                addLabelRow(content, "Active Buy Offers:", "0", StyleManager.WARNING);
                addLabelRow(content, "Active Sell Offers:", "0", StyleManager.INFO);
                addLabelRow(content, "Completed Today:", "0", StyleManager.SUCCESS);
                addLabelRow(content, "Available Slots:", "8", StyleManager.FOREGROUND);

                // Add a button to view offers
                JButton viewOffersButton = new JButton("View Offers");
                StyleManager.styleButton(viewOffersButton);
                viewOffersButton.setAlignmentX(Component.LEFT_ALIGNMENT);
                viewOffersButton.addActionListener(e -> {
                    // Switch to the Active Offers tab
                    for (int i = 0; i < tabbedPane.getTabCount(); i++) {
                        if (tabbedPane.getTitleAt(i).equals("Active Offers")) {
                            tabbedPane.setSelectedIndex(i);
                            break;
                        }
                    }
                });

                JPanel offersButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 10));
                offersButtonPanel.setOpaque(false);
                offersButtonPanel.add(viewOffersButton);
                offersButtonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
                content.add(offersButtonPanel);
                break;

            case "history":
                // Recent activity
                JPanel activityPanel = new JPanel();
                activityPanel.setLayout(new BoxLayout(activityPanel, BoxLayout.Y_AXIS));
                activityPanel.setOpaque(false);
                activityPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

                // Add some sample activity items
                addActivityItem(activityPanel, "Dragon bones", "Bought 100 @ 2,500 gp", "5 mins ago");
                addActivityItem(activityPanel, "Nature rune", "Sold 1000 @ 250 gp", "10 mins ago");
                addActivityItem(activityPanel, "Cannonball", "Margin checked", "15 mins ago");

                content.add(activityPanel);
                break;
        }

        card.setContent(content);
        return card;
    }

    /**
     * Adds a label row to a panel
     */
    private void addLabelRow(JPanel panel, String label, String value, Color valueColor) {
        JPanel rowPanel = new JPanel(new BorderLayout(10, 0));
        rowPanel.setOpaque(false);
        rowPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(StyleManager.REGULAR_FONT);
        labelComponent.setForeground(StyleManager.FOREGROUND_SECONDARY);

        JLabel valueComponent = new JLabel(value);
        valueComponent.setFont(StyleManager.REGULAR_FONT_BOLD);
        valueComponent.setForeground(valueColor);

        rowPanel.add(labelComponent, BorderLayout.WEST);
        rowPanel.add(valueComponent, BorderLayout.EAST);

        panel.add(rowPanel);
        panel.add(Box.createVerticalStrut(8));
    }

    /**
     * Adds an activity item to the history panel
     */
    private void addActivityItem(JPanel panel, String item, String action, String time) {
        JPanel itemPanel = new JPanel(new BorderLayout());
        itemPanel.setOpaque(false);
        itemPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, StyleManager.BORDER_COLOR));
        itemPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel itemLabel = new JLabel(item);
        itemLabel.setFont(StyleManager.REGULAR_FONT_BOLD);
        itemLabel.setForeground(StyleManager.FOREGROUND);

        JLabel actionLabel = new JLabel(action);
        actionLabel.setFont(StyleManager.SMALL_FONT);
        actionLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);

        JLabel timeLabel = new JLabel(time);
        timeLabel.setFont(StyleManager.SMALL_FONT);
        timeLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);

        JPanel leftPanel = new JPanel(new GridLayout(2, 1));
        leftPanel.setOpaque(false);
        leftPanel.add(itemLabel);
        leftPanel.add(actionLabel);

        itemPanel.add(leftPanel, BorderLayout.WEST);
        itemPanel.add(timeLabel, BorderLayout.EAST);

        panel.add(itemPanel);
        panel.add(Box.createVerticalStrut(8));
    }

    /**
     * Updates all panels regardless of which tab is visible
     */
    private void updateAllPanels() {
        // Update status when script is running
        if (scriptRunning) {
            // Update status with current script state
            if (script != null && script.getContext() != null) {
                FlipContext.ScriptState state = script.getContext().getCurrentState();

                if (state != FlipContext.ScriptState.IDLE) {
                    String status;
                    boolean isLoading = true;

                    switch (state) {
                        case ANALYZING_MARKET:
                            status = "Analyzing market prices";
                            break;
                        case EXECUTING_TRADES:
                            status = "Executing trades";
                            break;
                        case HANDLING_ERROR:
                            status = "Handling error";
                            isLoading = false;
                            break;
                        default:
                            status = "Running";
                    }
                    setStatus(status, isLoading);
                }
            }
        }

        // These panels always update
        SwingUtilities.invokeLater(() -> {
            flipItemsTablePanel.updateTable();
            activeOffersPanel.updateOffers();
            updateDashboard(); // Update dashboard with real-time data
        });
    }

    /**
     * Updates the dashboard with real-time data
     */
    private void updateDashboard() {
        // Calculate statistics from flip items
        SimpleFlipItemTableModel tableModel = flipItemsTablePanel.getTableModel();
        int totalItems = tableModel.getRowCount();
        int activeItems = 0;
        int completedItems = 0;
        int totalProfit = 0;
        String bestItem = "None";
        int bestItemProfit = 0;

        // Calculate statistics
        for (int i = 0; i < totalItems; i++) {
            String status = tableModel.getValueAt(i, 2).toString();
            String itemName = tableModel.getValueAt(i, 0).toString();

            // Count active items
            if (status.contains("BUYING") || status.contains("SELLING")) {
                activeItems++;
            }

            // Count completed items
            if (status.contains("COMPLETED")) {
                completedItems++;
            }

            // Calculate profit
            String marginStr = tableModel.getValueAt(i, 6).toString().replace(",", "").replace(" gp", "");
            try {
                int margin = Integer.parseInt(marginStr);
                totalProfit += margin;

                // Track best item
                if (margin > bestItemProfit) {
                    bestItemProfit = margin;
                    bestItem = itemName;
                }
            } catch (NumberFormatException e) {
                // Ignore invalid margins
            }
        }

        // Calculate average margin
        double avgMargin = totalItems > 0 ? (double) totalProfit / totalItems : 0;
        String avgMarginStr = String.format("%.1f%%", avgMargin);

        // Calculate profit per hour (assuming script has been running for at least 1 hour)
        long scriptRunTime = System.currentTimeMillis() - scriptStartTime;
        double hoursRunning = Math.max(1, scriptRunTime / (1000.0 * 60 * 60));
        int profitPerHour = (int) (totalProfit / hoursRunning);

        // Update dashboard cards
        updateDashboardCard("profit", new String[][] {
            {"Total Profit:", String.format("%,d gp", totalProfit), totalProfit > 0 ? "SUCCESS" : "FOREGROUND"},
            {"Profit Today:", String.format("%,d gp", totalProfit), totalProfit > 0 ? "SUCCESS" : "FOREGROUND"},
            {"Profit/Hour:", String.format("%,d gp/hr", profitPerHour), profitPerHour > 0 ? "SUCCESS" : "FOREGROUND"},
            {"Best Item:", bestItem, "FOREGROUND"}
        });

        updateDashboardCard("items", new String[][] {
            {"Total Items:", String.valueOf(totalItems), "FOREGROUND"},
            {"Active Items:", String.valueOf(activeItems), activeItems > 0 ? "WARNING" : "FOREGROUND"},
            {"Completed Flips:", String.valueOf(completedItems), completedItems > 0 ? "SUCCESS" : "FOREGROUND"},
            {"Avg. Margin:", avgMarginStr, avgMargin > 0 ? "INFO" : "FOREGROUND"}
        });

        // Update recent activity
        updateRecentActivity();
    }

    /**
     * Updates a dashboard card with new data
     */
    private void updateDashboardCard(String type, String[][] data) {
        // Find the dashboard panel
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            if (tabbedPane.getTitleAt(i).equals("Dashboard")) {
                JScrollPane scrollPane = (JScrollPane) tabbedPane.getComponentAt(i);
                JViewport viewport = scrollPane.getViewport();
                JPanel dashboardPanel = (JPanel) viewport.getView();

                // Find the card panel
                for (Component component : dashboardPanel.getComponents()) {
                    if (component instanceof JPanel) {
                        JPanel rowPanel = (JPanel) component;
                        for (Component rowComponent : rowPanel.getComponents()) {
                            if (rowComponent instanceof ModernCardPanel) {
                                ModernCardPanel card = (ModernCardPanel) rowComponent;
                                String title = card.getTitle();

                                if ((type.equals("profit") && title.equals("Profit Overview")) ||
                                    (type.equals("items") && title.equals("Items Overview"))) {

                                    // Update the card content
                                    JPanel content = (JPanel) card.getContentPanel().getComponent(0);

                                    // Update each row
                                    int rowIndex = 0;
                                    for (Component contentComponent : content.getComponents()) {
                                        if (contentComponent instanceof JPanel && rowIndex < data.length) {
                                            JPanel labelRow = (JPanel) contentComponent;
                                            if (labelRow.getComponentCount() >= 2) {
                                                // Update the value label
                                                JLabel valueLabel = (JLabel) labelRow.getComponent(1);
                                                valueLabel.setText(data[rowIndex][1]);

                                                // Update color based on data
                                                Color color = StyleManager.FOREGROUND;
                                                switch (data[rowIndex][2]) {
                                                    case "SUCCESS":
                                                        color = StyleManager.SUCCESS;
                                                        break;
                                                    case "WARNING":
                                                        color = StyleManager.WARNING;
                                                        break;
                                                    case "ERROR":
                                                        color = StyleManager.ERROR;
                                                        break;
                                                    case "INFO":
                                                        color = StyleManager.INFO;
                                                        break;
                                                }
                                                valueLabel.setForeground(color);
                                                rowIndex++;
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
                break;
            }
        }
    }

    /**
     * Updates the recent activity panel with latest events
     */
    private void updateRecentActivity() {
        // Find the dashboard panel
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            if (tabbedPane.getTitleAt(i).equals("Dashboard")) {
                JScrollPane scrollPane = (JScrollPane) tabbedPane.getComponentAt(i);
                JViewport viewport = scrollPane.getViewport();
                JPanel dashboardPanel = (JPanel) viewport.getView();

                // Find the activity card
                for (Component component : dashboardPanel.getComponents()) {
                    if (component instanceof JPanel) {
                        JPanel rowPanel = (JPanel) component;
                        for (Component rowComponent : rowPanel.getComponents()) {
                            if (rowComponent instanceof ModernCardPanel) {
                                ModernCardPanel card = (ModernCardPanel) rowComponent;
                                if (card.getTitle().equals("Recent Activity")) {
                                    // Get the activity panel
                                    JPanel activityPanel = (JPanel) card.getContentPanel().getComponent(0);

                                    // Clear existing activities
                                    activityPanel.removeAll();

                                    // Add new activities based on recent events
                                    SimpleFlipItemTableModel tableModel = flipItemsTablePanel.getTableModel();
                                    int itemCount = Math.min(5, tableModel.getRowCount());

                                    if (itemCount == 0) {
                                        // Show empty state
                                        JLabel emptyLabel = new JLabel("No recent activity");
                                        emptyLabel.setFont(StyleManager.REGULAR_FONT);
                                        emptyLabel.setForeground(StyleManager.FOREGROUND_SECONDARY);
                                        emptyLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
                                        activityPanel.add(emptyLabel);
                                    } else {
                                        // Add recent items
                                        for (int j = 0; j < itemCount; j++) {
                                            String itemName = tableModel.getValueAt(j, 0).toString();
                                            String status = tableModel.getValueAt(j, 2).toString();
                                            String time = tableModel.getValueAt(j, 8).toString();

                                            addActivityItem(activityPanel, itemName, status, time);

                                            // Add spacing between items
                                            if (j < itemCount - 1) {
                                                activityPanel.add(Box.createVerticalStrut(8));
                                            }
                                        }
                                    }

                                    // Refresh the panel
                                    activityPanel.revalidate();
                                    activityPanel.repaint();
                                    break;
                                }
                            }
                        }
                    }
                }
                break;
            }
        }
    }



    /**
     * Returns the appropriate color for a status
     */
    private Color getStatusColor(String status) {
        if (status.contains("BUYING")) {
            return StyleManager.WARNING;
        } else if (status.contains("SELLING")) {
            return StyleManager.INFO;
        } else if (status.contains("COMPLETED")) {
            return StyleManager.SUCCESS;
        } else {
            return StyleManager.FOREGROUND_SECONDARY;
        }
    }
}