package scripts.ScarFlip.gui;

import core.gui.components.ToastNotification;
import core.gui.style.StyleManager;
import org.dreambot.api.utilities.Logger;
import scripts.ScarFlip.config.FlipItem;
import scripts.ScarFlip.config.ScarFlipConfig;
import scripts.ScarFlip.enums.Status;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * A panel for adding new flip items with a modern, visual interface
 */
public class ItemManagementPanel extends JPanel {

    private final ScarFlipConfig config;

    // Controls
    private final JTextField itemNameField;
    private final JButton addItemButton;
    private final JButton clearAllButton;

    // Reference to the table model to update when items are added/removed
    private SimpleFlipItemTableModel tableModel;

    public ItemManagementPanel(ScarFlipConfig config) {
        this.config = config;

        // Create panel layout with modern styling
        setLayout(new BorderLayout(StyleManager.COMPONENT_SPACING, StyleManager.COMPONENT_SPACING));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setBackground(StyleManager.PANEL_BG);

        // Create header panel with title
        JPanel headerPanel = new JPanel(new BorderLayout(10, 0));
        headerPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("Add Flip Items");
        titleLabel.setFont(StyleManager.HEADER_FONT_SMALL);
        titleLabel.setForeground(StyleManager.FOREGROUND);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        // Create item management controls with modern styling
        JPanel controlsPanel = new JPanel();
        controlsPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        controlsPanel.setOpaque(false);
        controlsPanel.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));

        // Item name field with modern styling - smaller size
        itemNameField = new JTextField(15);
        itemNameField.setToolTipText("Enter item name to flip");
        itemNameField.setPreferredSize(new Dimension(200, 30));
        itemNameField.setMaximumSize(new Dimension(200, 30));
        StyleManager.styleTextField(itemNameField);

        // Add button with primary styling - smaller size
        addItemButton = new JButton("Add Item");
        addItemButton.setPreferredSize(new Dimension(100, 30));
        StyleManager.stylePrimaryButton(addItemButton);

        // Clear all button with secondary styling - smaller size
        clearAllButton = new JButton("Clear All");
        clearAllButton.setPreferredSize(new Dimension(100, 30));
        StyleManager.styleButton(clearAllButton);

        // Create a compact panel for the add item controls
        JPanel addPanel = new JPanel();
        addPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 0));
        addPanel.setOpaque(false);

        JLabel nameLabel = new JLabel("Item Name:");
        nameLabel.setFont(StyleManager.REGULAR_FONT);
        nameLabel.setForeground(StyleManager.FOREGROUND);

        // Add components in a horizontal flow
        addPanel.add(nameLabel);
        addPanel.add(itemNameField);
        addPanel.add(addItemButton);
        addPanel.add(Box.createHorizontalStrut(20)); // Add some spacing
        addPanel.add(clearAllButton);

        // Add controls to panel
        controlsPanel.add(addPanel);

        // Create card panel for item suggestions
        JPanel suggestionsPanel = createSuggestionsPanel();

        // Add components to main panel
        add(headerPanel, BorderLayout.NORTH);
        add(controlsPanel, BorderLayout.CENTER);
        add(suggestionsPanel, BorderLayout.SOUTH);

        // Initialize event handlers
        initializeEventHandlers();
    }

    /**
     * Creates a panel with suggested items to flip
     */
    private JPanel createSuggestionsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel suggestionsLabel = new JLabel("Suggested Items");
        suggestionsLabel.setFont(StyleManager.REGULAR_FONT_BOLD);
        suggestionsLabel.setForeground(StyleManager.FOREGROUND);
        suggestionsLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(suggestionsLabel);
        panel.add(Box.createVerticalStrut(8));

        // Create a panel for suggestion buttons
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttonsPanel.setOpaque(false);

        // Add some common high-volume items as suggestions
        String[] suggestions = {
            "Dragon bones", "Zulrah's scales", "Cannonball", "Blood rune",
            "Nature rune", "Adamant dart", "Dragon dart", "Saradomin brew(4)"
        };

        for (String item : suggestions) {
            JButton suggestionButton = new JButton(item);
            StyleManager.styleButton(suggestionButton);
            suggestionButton.addActionListener(e -> {
                itemNameField.setText(item);
                addNewItem();
            });
            buttonsPanel.add(suggestionButton);
        }

        buttonsPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(buttonsPanel);

        return panel;
    }

    /**
     * Set the table model that should be updated when items change
     */
    public void setTableModel(SimpleFlipItemTableModel model) {
        this.tableModel = model;
    }

    /**
     * Initializes event handlers for all components
     */
    private void initializeEventHandlers() {
        // Add item button action
        addItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNewItem();
            }
        });

        // Enter key in text field also adds item
        itemNameField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNewItem();
            }
        });

        // Clear all button action
        clearAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearAllItems();
            }
        });
    }

    /**
     * Adds a new item from the text field
     */
    private void addNewItem() {
        String itemName = itemNameField.getText().trim();

        if (itemName.isEmpty()) {
            showErrorToast("Please enter an item name.");
            return;
        }

        if (config.addItem(itemName)) {
            // Show success message
            showSuccessToast("Added " + itemName + " to flip list");

            // Clear field on success
            itemNameField.setText("");

            // Update table if available
            if (tableModel != null) {
                tableModel.updateData();
            }

            // Focus back to field for rapid entry
            itemNameField.requestFocus();
        } else {
            showWarningToast("Failed to add item: '" + itemName + "'. It might already exist.");
        }
    }

    /**
     * Shows a success toast notification
     */
    private void showSuccessToast(String message) {
        Window window = SwingUtilities.getWindowAncestor(this);
        if (window instanceof JFrame) {
            ToastNotification.showSuccess((JFrame) window, message);
        }
    }

    /**
     * Shows a warning toast notification
     */
    private void showWarningToast(String message) {
        Window window = SwingUtilities.getWindowAncestor(this);
        if (window instanceof JFrame) {
            ToastNotification.showWarning((JFrame) window, message);
        }
    }

    /**
     * Shows an error toast notification
     */
    private void showErrorToast(String message) {
        Window window = SwingUtilities.getWindowAncestor(this);
        if (window instanceof JFrame) {
            ToastNotification.showError((JFrame) window, message);
        }
    }

    /**
     * Clears all items after confirmation
     */
    private void clearAllItems() {
        if (config.getItemsToFlip().isEmpty()) {
            showWarningToast("No items to clear.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to remove ALL items?",
            "Confirm Remove All",
            JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // Create a copy of the list to avoid concurrent modification
            List<FlipItem> itemsToRemove = new ArrayList<>(config.getItemsToFlip());
            int count = itemsToRemove.size();

            boolean success = true;
            for (FlipItem item : itemsToRemove) {
                if (!config.removeItem(item.getItemName())) {
                    success = false;
                }
            }

            // Update table if available
            if (tableModel != null) {
                tableModel.updateData();
            }

            if (success) {
                showSuccessToast("Removed all " + count + " items successfully");
                Logger.log("Removed all items successfully");
            } else {
                showWarningToast("Some items could not be removed");
                Logger.log("Some items could not be removed");
            }
        }
    }
}