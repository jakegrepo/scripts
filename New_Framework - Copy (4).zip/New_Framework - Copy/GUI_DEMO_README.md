# GUI Preview Demo

This demo application allows you to preview the new GUI components and layout without needing to run it in DreamBot.

## How to Run the Demo

### Option 1: Using the Batch File

1. Simply double-click the `run_gui_demo.bat` file in the project root directory.
2. This will build the project and run the demo application.

### Option 2: Manual Execution

1. Build the project:
   ```
   mvn clean package
   ```

2. Run the demo application:
   ```
   java -cp target\scar-framework-1.0-SNAPSHOT.jar demo.GUIPreviewDemo
   ```

## Demo Features

The demo showcases the following UI components and features:

1. **Modern Navigation System**
   - Sidebar navigation panel with tabs
   - Visual indicators for selected and hovered items

2. **Enhanced Visual Design**
   - Dark theme with vibrant accent colors
   - Gradient backgrounds and subtle animations
   - Improved typography and spacing

3. **Modern UI Components**
   - Modern buttons, text fields, combo boxes, and spinners
   - Toggle switches as alternatives to checkboxes
   - Card components with glass-like appearance

4. **Improved Layout**
   - More efficient use of space
   - Better grouping of related controls
   - Consistent spacing and alignment

## Notes

- This is a preview demo only. No actual functionality is implemented.
- The demo uses standard Swing components with custom styling to match our new UI design.
- In the actual framework, these components will be fully integrated with DreamBot's API.

## Troubleshooting

If you encounter any issues running the demo:

1. Make sure you have Java 11 or later installed.
2. Ensure Maven is properly installed and configured.
3. Check that all required dependencies are available in your local Maven repository.
